#!/usr/bin/env python3
"""
Build data/locations.json from the verified research pack
(Rocket_Coverage_Research_2026-09-23, copied into data/source/).

This is a pure transform. Nothing is invented, filled in or upgraded:
- blank stays blank (null)
- inferred aliases stay labelled inferred
- terminated postcodes stay terminated
- venue status (ACTIVE / UNCERTAIN / DEMOLISHED) is carried through

To import a newer research pack later, drop its JSON files into
data/source/ and re-run:  python3 scripts/import_locations.py
No code change is needed.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "data", "source")
OUT = os.path.join(HERE, "..", "data", "locations.json")
CORRECTIONS = os.path.join(HERE, "..", "data", "corrections.json")


def load(name):
    with open(os.path.join(SRC, name), encoding="utf-8-sig") as f:
        return json.load(f)


def num(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def main():
    postcodes = load("01_postcodes.json")
    venues = load("02_venues.json")
    aliases = load("03_aliases.json")
    ambiguities = load("05_ambiguities.json")
    localities = load("08_localities.json")
    coverage = load("coverage.json")
    with open(CORRECTIONS, encoding="utf-8") as f:
        corrections = json.load(f)
    drop_alias = {(c["venueId"], a.lower()) for c in corrections.get("excludeAliases", []) for a in c["aliases"]}
    drop_amb = {(c["venueId"], t) for c in corrections.get("excludeFromAmbiguities", []) for t in c["terms"]}
    not_meeting = {c["venueId"] for c in corrections.get("notMeetingPoints", [])}

    active, terminated = {}, {}
    for p in postcodes:
        rec = {"lat": num(p.get("latitude")), "lng": num(p.get("longitude")),
               "district": p.get("postcode_district")}
        if p.get("status") == "ACTIVE":
            active[p["postcode"]] = rec
        else:
            terminated[p["postcode"]] = rec

    venue_out = []
    for v in venues:
        venue_out.append({
            "id": v["venue_id"],
            "name": v["canonical_name"],
            "commonName": v.get("common_name"),
            "category": v.get("category"),
            "town": v.get("town"),
            "postcode": v.get("full_postcode") or v.get("postcode"),
            "lat": num(v.get("latitude")),
            "lng": num(v.get("longitude")),
            "status": v.get("current_status"),
            "confidence": v.get("confidence"),
            "qualityFlags": v.get("quality_flags") or [],
            "meetingPoint": v["venue_id"] not in not_meeting,
        })

    alias_out = []
    dropped_aliases = 0
    for a in aliases:
        if (a["venue_id"], a["alias"].lower()) in drop_alias:
            dropped_aliases += 1
            continue
        alias_out.append({
            "venueId": a["venue_id"],
            "alias": a["alias"],
            "type": a.get("alias_type"),
            # CONFIRMED vs INFERRED is kept exactly as the research labels it
            "evidence": a.get("evidence_status"),
        })

    amb_out = []
    for a in ambiguities:
        amb_out.append({
            "term": a["term"],
            "venueIds": [c["venue_id"] for c in a.get("possible_locations", [])
                         if c.get("venue_id") and (c["venue_id"], a["term"]) not in drop_amb],
            "towns": a.get("possible_towns") or [],
        })

    towns = set()
    for v in venues:
        if v.get("town") and v["town"] != "UNRESOLVED":
            towns.add(v["town"])
    for l in localities:
        name = l.get("locality")
        # Only plain place names; composite labels like "Yatton precinct / Pages Court"
        # are venues/areas, not towns a customer would name on their own.
        if name and "/" not in name and "precinct" not in name.lower() and "estate" not in name.lower():
            towns.add(name)

    dataset = {
        "_provenance": {
            "source": "Rocket_Coverage_Research_2026-09-23 (SHA-256 verified on import)",
            "postcodeSnapshot": "ONS Postcode Directory, August 2026",
            "researchComplete": coverage.get("research_complete"),
            "note": "Research release, not exhaustive. Most venues have UNCERTAIN trading status "
                    "and unverified entrances. See data/source/RESEARCH_README.md.",
        },
        "coveredDistricts": ["BS48", "BS49", "BS21", "BS20"],
        "activePostcodes": active,
        "terminatedPostcodes": terminated,
        "venues": venue_out,
        "aliases": alias_out,
        "ambiguities": amb_out,
        "towns": sorted(towns),
        # From the research README: Portishead and Pill stations are under construction,
        # not open passenger stations. A customer saying "station" there must be asked.
        "notOperational": [
            {"term": "station", "towns": ["Portishead", "Pill"],
             "reply": "Portishead and Pill stations aren't open yet. Where exactly should we meet? "
                      "Send a full postcode or share a location pin."}
        ],
    }

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(dataset, f, ensure_ascii=False)

    print(f"active postcodes {len(active)}, terminated {len(terminated)}, venues {len(venue_out)}, "
          f"aliases {len(alias_out)}, ambiguity terms {len(amb_out)}, towns {len(towns)}")
    expected = (coverage["active_postcodes"], coverage["all_postcodes"] - coverage["active_postcodes"],
                coverage["venues"], coverage["aliases"], coverage["ambiguities"])
    got = (len(active), len(terminated), len(venue_out), len(alias_out) + dropped_aliases, len(amb_out))
    print(f"corrections applied: {dropped_aliases} aliases removed, {len(not_meeting)} venue(s) marked not a meeting point")
    if expected != got:
        print(f"MISMATCH against coverage.json: expected {expected}, got {got}", file=sys.stderr)
        sys.exit(1)
    print("Counts match coverage.json")


if __name__ == "__main__":
    main()
