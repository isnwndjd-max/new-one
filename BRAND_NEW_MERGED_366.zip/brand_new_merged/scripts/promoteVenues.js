#!/usr/bin/env node
'use strict';

/*
 * OFFLINE maintenance tool - not run automatically, not part of the SMS
 * pipeline. Reads an Engine state export's `promotionCandidates` (venues
 * that have now been explicitly confirmed by PROMOTION_CONFIRM_THRESHOLD
 * separate orders - see src/engine.js's _maybeRecordVenueConfirmation)
 * and reports them for a human to review before flipping their status to
 * ACTIVE in data/locations.json.
 *
 * Deliberately does NOT flip anything automatically: promoting a venue to
 * ACTIVE removes its confirmation step for every future customer, so it
 * follows the same "a person signs off before verified data changes"
 * rule this project has used everywhere else (new roads, new alleys, new
 * ambiguity terms).
 *
 * Usage:
 *   node scripts/promoteVenues.js <path-to-engine-state.json> [--apply]
 *
 * Without --apply: prints a report only, changes nothing.
 * With --apply: after printing the report, writes the promoted venues'
 *   status to "ACTIVE" in data/locations.json (confidence/qualityFlags
 *   left as-is other than adding "promoted_from_customer_confirmations"),
 *   and clears the promoted ids out of promotionCandidates in a COPY of
 *   the state file written alongside the original (never overwrites the
 *   input file).
 */

const fs = require('fs');
const path = require('path');

const statePath = process.argv[2];
const apply = process.argv.includes('--apply');

if (!statePath) {
  console.error('Usage: node scripts/promoteVenues.js <path-to-engine-state.json> [--apply]');
  process.exit(1);
}

const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
const locationsPath = path.join(__dirname, '..', 'data', 'locations.json');
const locations = JSON.parse(fs.readFileSync(locationsPath, 'utf8'));
const venuesById = new Map(locations.venues.map((v) => [v.id, v]));

const candidates = state.promotionCandidates || [];
if (!candidates.length) {
  console.log('No promotion candidates in this state export.');
  process.exit(0);
}

console.log(`${candidates.length} promotion candidate(s):\n`);
const toPromote = [];
for (const id of candidates) {
  const v = venuesById.get(id);
  const count = (state.venueConfirmations || {})[id] || 0;
  if (!v) {
    console.log(`  ${id} - NOT FOUND in data/locations.json (skipping)`);
    continue;
  }
  console.log(`  ${id}  "${v.name}" (${v.town || 'town unknown'})  confirmed ${count}x  status=${v.status}`);
  if (v.status !== 'ACTIVE') toPromote.push(v);
}

if (!apply) {
  console.log('\nDry run only - nothing changed. Re-run with --apply to promote these to ACTIVE.');
  process.exit(0);
}

for (const v of toPromote) {
  v.status = 'ACTIVE';
  v.qualityFlags = [...new Set([...(v.qualityFlags || []), 'promoted_from_customer_confirmations'])];
}
fs.writeFileSync(locationsPath, JSON.stringify(locations, null, 1));
console.log(`\nPromoted ${toPromote.length} venue(s) to ACTIVE in data/locations.json.`);

const promotedIds = new Set(toPromote.map((v) => v.id));
const newState = { ...state, promotionCandidates: candidates.filter((id) => !promotedIds.has(id)) };
const outPath = statePath.replace(/\.json$/, '') + '.promoted.json';
fs.writeFileSync(outPath, JSON.stringify(newState, null, 1));
console.log(`Wrote updated state (candidates cleared) to ${outPath} - your original state file was left untouched.`);
