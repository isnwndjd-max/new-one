# Rollback notes — Remaining Offline Fixes

Nothing in this session was deployed anywhere, so "rollback" here means:
how to revert this working copy (or a ZIP built from it) back to the
previous behaviour, in case any of the nine items needs to be undone
independently after review — without having to discard the whole session.

Each item below is close to independent: reverting one should not require
reverting the others, with the one noted exception (stock underpins the
referral free-item redemption, since redeeming a free item still deducts
stock).

## General

All new/changed state lives inside the existing `Engine` state object
(`state.stock`, `state.stockLedger`, `state.lowStockAlerts`,
`state.freeItemRewards`, `state.pointsAdjustments`, `state.idempotency`,
`d.cash` on each driver, `state.auditLog`). A `state.json` written by this
session's code will still **load** fine in a rolled-back engine that
doesn't know about these new fields — `Store.load()` merges into
`emptyEngineState()`'s defaults, so unknown-but-present keys are simply
carried along inertly if the code reading them is reverted. The reverse
(an *old* `state.json` loaded by *this* session's code) also works, since
every new field has a safe default. No migration script is required
either direction.

## 1. Stock accounting

To revert: remove the stock section from `src/engine.js` (everything
between the comment marker before `_defaultLowStockThreshold` and before
`_confirm`'s pricing step), remove the `_reserveStock`/
`_releaseStockReservation`/`_deductStock` calls from `_confirm`/`_cancel`/
`_complete`, and drop the `stock`/`stockLedger`/`lowStockAlerts` boss
routes from `server/index.js`. Orders will confirm without any stock check
again (the pre-existing behaviour). `data/config.json`'s `stock` block can
stay — it's simply unread if the engine code is reverted.

**Caveat:** free-item referral redemption (item 4) also calls
`_deductStock`, so reverting stock accounting alone will make a redeemed
free item stop deducting stock, silently drifting from a real item leaving
the shelf. If stock accounting is reverted, either revert item 4 too, or
leave the (now dead) `_deductStock` call in the referral path.

## 2. Loyalty (3 points/item)

To revert: restore `pointsPerOrder`/`referrerRewardPoints` to
`data/config.json`'s `rewards` block, and change `Engine._complete`'s
loyalty line back from `totalItemsForLoyalty * config.rewards.pointsPerItem`
to the flat `config.rewards.pointsPerOrder`. The three pre-existing tests
this session updated (`test/driverRelay.adapter.test.js` ×2,
`test/fullSystem.e2e.test.js` ×1) would need their assertions reverted
back to the hardcoded `10`/`50` figures they originally had — those
figures are preserved in this project's git-free history only as this
changelog and the diff itself; there is no separate backup file, since the
brief's instruction was to change this rule, not merely test it both ways.

## 3. Debt rules

To revert: remove the debt-block check from `Engine._confirm` (the call
into `_overdueDebtTotal`), remove `debt.blockOverdueAmount` from
`data/config.json` (or leave it — unread once the check is removed), and
restore `Engine._complete`'s debt section to whatever single-debt handling
existed before (this session's diff shows the exact prior shape). The
combined-payment allocation logic can be removed independently of the
£100 block if only one half is unwanted.

## 4. Referrals (free item vs. points)

To revert: restore `referrerRewardPoints` handling in `Engine._complete`'s
referral section (award points to the referrer's `state.customers[phone]
.points` instead of creating a `state.freeItemRewards` entry), and remove
the `_availableFreeItemReward`/`_applyFreeItemReward` calls from
`Engine._confirm`. `GET /boss/rewards` can stay (it'll just always report
an empty list) or be removed.

## 5. £250 driver cash limit

To revert: remove the cash-limit check from `Engine._accept`, remove the
cash-tracking block from `Engine._complete`, and drop the `d.cash` field
from `registerDriver` (existing driver records without it would need
`d.cash || { held: 0, adjustments: [] }` defensive reads removed too, or
left in — they're harmless no-ops without the rest). Remove the `/boss/
cash` and `/boss/drivers/:id/cash/adjust` routes.

## 6. Boss controls

Each new route in `server/index.js` (search for the block starting right
after the existing `GET /boss/drivers` route) is independently removable —
delete the specific route(s) no longer wanted; none of them are load-
bearing for any other route. The matching UI section in `boss/index.html`
can be removed the same way (each is its own clearly-commented `<div>` +
`render*()` function + wiring line in `refresh()`).

## 7. FOOT mode accuracy

To revert: restore the previous `_isNailseaLocation` implementation (the
BS48-district shortcut) — this session's diff shows the exact prior body.
**Not recommended** — the prior behaviour was factually wrong (it would
route Backwell/Wraxall/Flax Bourton jobs to FOOT drivers as if they were
Nailsea), which is exactly what this item was brought to fix. If reverted,
also revert the FOOT-related assertions in `test/driverSubsystem.test.js`
back to the bare-postcode-only pattern, and remove
`test/footModeAccuracy.test.js`.

## 8. Security startup guard

To revert: remove the `checkStartupSafety(...)` call from `server/index.js`'s
`if (require.main === module)` block (three lines plus the `require` for
`src/startupGuard.js`) and/or delete `src/startupGuard.js` and
`test/startupGuard.test.js`. This has zero effect on `createApp()`, the
HTTP surface, or any other test either way — it was deliberately kept
fully isolated to the real-process startup path.

## 9. 30-order concurrency test

Purely additive — a test file with no production-code dependency of its
own beyond what items 1–8 already added. Delete
`test/concurrency30Orders.test.js` to remove it; nothing else references
it.

## Post-review tightening (7-day debt, £250 cash cap, TAKE/Bonus)

Each of the three post-review fixes is independently revertable:

- **7-day debt block:** in `Engine._confirm`, change the block condition
  back from `overdue > 0.001` to `overdue >= blockAt - 0.001` to restore
  the old £100-only behaviour. The test "a debt under £100 STILL blocks
  once it is overdue" would need removing or reverting alongside it.
- **£250 cash cap:** in `Engine._complete`'s cash section, remove the
  `wouldBeHeld > cashLimit` branch and go back to unconditionally setting
  `d.cash.held = Math.round((d.cash.held + paid) * 100) / 100` to restore
  the old (uncapped, warn-after-the-fact) behaviour.
- **TAKE Bonus deduction/review flag:** in `Engine._take`, remove the
  Bonus-deduction block and the direct `state.review.push(...)` call added
  after the `DRIVER_TAKE` audit event, restoring TAKE to its original
  stock-only effect.
- **Referral-code-shaped-like-a-postcode parsing fix:** in
  `Engine.handleCustomerBurst`, remove the `textForParsing` stripping step
  and pass the original `text` to `parseItems`/`conv.handle` again, same
  as before. **Not recommended** — this restores a real, reproducible bug
  (roughly 1 in 1,000 random referral codes silently stranding an order in
  DRAFT); it isn't a stylistic change like the FOOT-mode one, it's a
  correctness fix with no real tradeoff. If reverted, also remove "a
  referral code that happens to look like a UK postcode never breaks
  item/location parsing in the same message" from
  `test/remainingOfflineFixes.test.js`.

## 10. README/handover cleanup

Purely documentation. To revert, remove the "Remaining Offline Fixes (this
session)" and "Environment variables (deployment)" sections from
`README.md` and restore the original test-count line at the top — the
rest of the README (everything from "## What's real and tested" onward)
was left as-written and needs no reversal.
