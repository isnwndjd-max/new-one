# Boss app

A small admin surface on top of the same engine state everything else in
this project already reads and writes — the debt ledger, referral codes,
menu, review queue, driver roster, and order list. There's no new state
model here: `src/engine.js` already tracked all of this; this is a page and
some HTTP routes to see and act on it without reading `state.json` by hand.

## Getting to it

1. Change `config.boss.token` in `data/config.json` from the placeholder
   `CHANGE_ME_BEFORE_GOING_LIVE` to a real secret. **Every `/boss/*` route
   refuses to work while the token is still the placeholder** — see
   `bossTokenOk()` in `server/index.js`, which treats an unset/placeholder
   check as "never allow" rather than "allow everything."
2. Start the server (`node server/index.js`, or however it's already being
   run).
3. Open `http://<host>:<port>/boss` in a browser and enter the token. The
   token is kept in `sessionStorage` only (cleared when the tab closes), and
   sent on every API call as an `X-Boss-Token` header — **never in the URL**.
   A boss token in a query string would end up in server access logs, any
   reverse proxy's logs, and browser history; `bossTokenOk()` in
   `server/index.js` only accepts the header form, and refuses a request
   that tries `?token=...` even with the correct value (401).

`GET /boss` itself does not require the token — it just serves the static
page. Every API call the page then makes (`/boss/summary`, `/boss/review`,
etc.) requires the `X-Boss-Token` header.

## What it shows and does

- **Status** — the same counts `GET /health` exposes (open orders, drivers
  on duty, open review items, drivers reporting GPS).
- **Review queue** — every `state.review` entry that isn't resolved yet
  (things the engine flagged for a human: an order it couldn't price, a pin
  outside the service area, a driver's GPS gone stale, and so on). Each can
  be resolved with an optional note, which calls `Engine.resolveReview()` —
  new this session; before it, nothing in the engine ever cleared a review
  flag, so the queue only ever grew.
- **Debts** — `state.debts` (money owed after a driver reported a lower cash
  amount than the order total). A payment can be recorded against a debt,
  which calls the existing `Engine.recordDebtPayment()`.
- **Referral codes** — `state.referralCodes`, read-only here: owner, which
  order issued it, which order redeemed it, and whether it's been redeemed.
- **Drivers** — `state.drivers`, read-only: on-duty status, active order,
  last GPS fix time.
- **Menu** — editable as raw JSON, the Boss-owned master copy. **The master
  now lives only in this browser's own `localStorage`, not on the VPS** —
  see "Master menu vs. synced menu" below for why. It can carry
  internal-only fields (e.g. `costPrice`) that the order-processing side of
  the system never sees. Saving PUTs the edited master to `/boss/menu`,
  which calls `Engine.setMenu()` (via `resyncMenuFromMaster()`) to validate
  every item (a code, a name, a non-negative `unitPrice`, valid tiers) and
  every bundle (a code, a label, a non-negative price, and that every item
  code it bundles actually exists) *before* the server writes anything to
  disk. A bad edit is rejected with a specific error and the synced
  projection is left untouched. A valid edit is immediately projected into
  `data/menu.sync.json` (temp file, then rename), which is what the live
  engine actually prices against — and only then is it saved into this
  browser's `localStorage` as the new local master. Use **Export backup**
  after editing and keep the file somewhere safe: this browser's storage is
  the only copy of the master (cost price, notes, etc.) that exists
  anywhere. **Import backup** loads a previously exported file back into the
  editor (still requires clicking Save to take effect) — use it to restore
  after clearing browser data, or to carry the master to a different
  device/browser.

## Master menu vs. synced menu

Two owners, on purpose, and — as of this build — genuinely two different
places, not just two files on the same disk:

- The **master** — the Boss app's own copy, kept in this browser's
  `localStorage` only. The only place menu edits are made. Can carry
  fields the order-processing engine has no business seeing (currently
  `costPrice`; the boundary is enforced by `src/menuSync.js`'s allowlist
  projection, not by convention). **The VPS never stores this — not on
  disk, not in memory beyond the single request that derives the
  projection below.** A stolen VPS disk, backup, or snapshot has nothing to
  give up here.
- `data/menu.sync.json` — a generated, minimal projection (`code`, `name`,
  `aliases`, `unitPrice`, `tiers` for items; `code`, `label`, `contains`,
  `price` for bundles) that `server/index.js` loads at startup and is the
  *only* menu file the live order-processing engine ever reads, and the
  *only* menu data the VPS's disk ever holds.

`GET /boss/menu` returns the synced projection (no `costPrice`, no
internal-only fields — the VPS doesn't have them to return); the menu
editor is instead seeded from this browser's own saved master. `PUT
/boss/menu` sends the edited master to the server, which derives and
rewrites the synced projection from it, then discards the master — it is a
plain function argument for the duration of that one request, never
assigned anywhere longer-lived, never written to disk. A restart trusts
whatever synced projection was last written; there is no master on the VPS
to re-derive it from, by design.

**Upgrading from an older build** that did keep `data/boss/menu.master.json`
on the VPS: the server reads that leftover file at startup and hands it to
the Boss app exactly once, the next time someone opens `/boss/menu` — at
which point the browser adopts it into `localStorage` and the server
deletes the file from its own disk. Nothing is lost, and nothing lingers on
the VPS once that one hand-off has happened. Export a backup right after
that migration.

## What this deliberately is not

- Not a login system. One shared token, entered once per browser tab. Fine
  for one owner; not fine for multiple staff with different permissions —
  that would need real accounts.
- Not real-time. The page polls every 15 seconds; it doesn't push.
- Not a form-based menu editor. Raw JSON, on purpose, given the time
  available — the validation is real (server-side, in `Engine.setMenu()`),
  the UI around it is intentionally minimal.
- Not tested against a browser. The server-side routes are covered by
  `test/boss.test.js` (real HTTP requests against a real `createApp()`
  instance, same pattern as `test/server.e2e.test.js`); the static page's
  JavaScript has not been exercised by an automated test or a real browser
  session — read it before trusting it, same caveat as the rest of this
  project's unverified pieces (Tasker, Signal against a real account,
  Traccar against a real server).
