# Location resolver hardening — changelog

Not deployed. Not sent to the live VPS, phones, Tasker, driver app or Boss
app. This only touches source files, test files and documentation in this
project checkout.

## What changed and why

The research data in `data/locations.json` (561 venues across BS48/BS49/
BS21/BS20) was already wired into a fairly sophisticated resolver
(`src/locationIndex.js` + `src/locationConversation.js`) — postcode
validation, alias ranking, ambiguity handling and town-context narrowing
were already implemented and working correctly. Verified this first rather
than rebuilding: see "What was already correct" below.

The real gap: **484 of the 561 venues (86%) are marked `status: "UNCERTAIN"`**
in the research data — meaning their current trading status was never
individually checked (see `data/source/RESEARCH_README.md`: *"Most newly
collected businesses have not been individually cross-checked for trading
status... Do not load the entire pack into automatic dispatch as though
every record were an open business"*). The resolver's auto-confirm path
only ever excluded `status: "DEMOLISHED"` — an `UNCERTAIN` venue with a
strong, unambiguous name match (e.g. "Ring O' Bells Nailsea") would resolve
and confirm a customer's order with **no confirmation step at all**, exactly
the failure mode the research pack warns against.

### 1. Venue status gating (the main fix)

`src/locationConversation.js`'s `_resolve()`:
- Only a venue with `status: "ACTIVE"` can auto-resolve to `RESOLVED` from a
  strong name match. Everything else (`UNCERTAIN`, or any status the data
  doesn't mark `ACTIVE`) now returns a new outcome type, `UNVERIFIED_LOCATION`
  — same "yes"/correction flow as the existing `CONFIRM` outcome (reuses
  `state.proposed`), just with wording that says dispatch hasn't checked
  it's still open, rather than implying doubt about *which* place was meant.
- A venue whose own status is `DEMOLISHED`/`FORMER`/`CLOSED` (a new
  `FORMER_STATUSES` set in `src/locationIndex.js`, currently just
  `DEMOLISHED` in the real data) is recognised by name but never offered as
  a meeting point — reported as a new outcome type, `FORMER_LOCATION`,
  instead of a generic unexplained `NOT_FOUND`.
- A customer's explicit "yes" to an `UNVERIFIED_LOCATION` still confirms it
  — the customer's own confirmation *is* the verification the research data
  is missing. This mirrors the existing `CONFIRM` yes/no flow exactly.

### 2. Former-locations mechanism (new, currently empty)

Added a `formerLocations` hook (`LocationIndex.findFormerLocation()`) for a
phrase that names a historic site by a name **no current venue carries**
(distinct from a current venue whose own status went `DEMOLISHED` — that's
handled by (1) above via ordinary name matching). `data/locations.json`
ships this array empty — see "What's still missing" below for why, and
`test/locationResolverHardening.test.js` proves the mechanism itself works
using a synthetic fixture record, clearly labelled as a test fixture, not
real data.

### 3. New structured result types

Two additions to the existing outcome vocabulary
(`RESOLVED`/`CONFIRM`/`ASK_TOWN`/`ASK_WHICH`/`TOWN_ONLY`/`NOT_IN_TOWN`/
`SPECIAL`/`POSTCODE_TERMINATED`/`NOT_FOUND`/`OUTSIDE_AREA`/`ETA`/`ARRIVAL`/
`NONE`), each wired into `engine.js`'s `_locationQuestion()` with its own
customer-facing message in `data/messages.json`:
- `UNVERIFIED_LOCATION` — `messages.unverified_location`
- `FORMER_LOCATION` — `messages.former_location`

**Not renamed:** the task brief's suggested vocabulary (`AMBIGUOUS`,
`OUT_OF_AREA`, `INVALID_POSTCODE`, `TERMINATED_POSTCODE`,
`NEEDS_CLARIFICATION`) maps onto outcome types that already existed and
already worked correctly (`CONFIRM`/`ASK_TOWN`/`ASK_WHICH` ≈ `AMBIGUOUS`/
`NEEDS_CLARIFICATION`, `OUTSIDE_AREA` ≈ `OUT_OF_AREA`, `NOT_FOUND` (postcode
reason) ≈ `INVALID_POSTCODE`, `POSTCODE_TERMINATED` ≈ `TERMINATED_POSTCODE`).
Renaming them would have touched every call site in `engine.js` and dozens
of existing passing tests for a cosmetic string change, against the brief's
own instruction to make "the smallest clean changes required." Only added
the two outcome types that represent genuinely new *behaviour*.

## What was already correct (verified, not rebuilt)

- **Postcode validation** (`LocationIndex.findPostcode`): already accepts
  only postcodes present in the dataset and marked `ACTIVE`, distinguishes
  `TERMINATED` from unknown-but-in-district from fully `OUTSIDE_AREA`, and
  already rejects a format-valid postcode outside BS48/49/21/20 (e.g.
  `SW1A 1AA`) and a format-valid-but-nonexistent one inside a covered
  district (e.g. `BS49 9ZZ`). Confirmed with real dataset lookups and new
  tests; no code change needed.
- **Exact alias matching beating generic keywords**: `KIND_RANK`/`STRONG`
  already rank a `canonical` or `confirmed` (evidence-backed) alias above a
  bare ambiguity term, and `findVenue()` already prefers the longest phrase
  match. "Yatton station" (a `CONFIRMED` alias) already resolved ahead of
  the generic "station" ambiguity term before this change.
- **Town-context narrowing**: `LocationConversation._resolve()` already
  filters multi-town candidates down by a named or previously-stated town.
- **Text normalisation**: `src/text.js`'s `normalise()` already folds `&`
  to "and", strips apostrophes/punctuation/case/whitespace. "Ship & Castle"
  and "Ship and Castle" already normalised identically.
- **Coordinate safety**: `findPin()` already rejects `|lat| > 90` or
  `|lng| > 180`; `Engine.submitLocationPin()` (the customer GPS-share
  endpoint) has the same bounds check independently.
- **Postcode centre never silently becomes an exact destination**: a
  `RESOLVED` postcode location already carries `exactPointKnown: false`,
  and `Engine._navLink()`'s fallback to a postcode centroid (only used when
  a *venue* has no coordinates of its own) already triggers the
  "postcode/area only" note on the driver's job offer via that same flag.
- **Order state surviving a clarification cycle**: items accumulate on
  `order.items` regardless of location outcome, and `order.location` is the
  full `LocationConversation` state (including `pending`/`proposed`), so
  this was already structurally guaranteed by the existing architecture,
  not something needing new machinery. New tests make this explicit for
  both an `ASK_TOWN`→resolve cycle and the new `UNVERIFIED_LOCATION`
  confirm cycle.

## What's still missing (honest gap, not silently worked around)

The original research pack's own file manifest and checksums
(`data/source/SHA256SUMS.txt`) list `04_local_language.json`,
`06_former_closed_locations.json` and `07_manual_review_queue.json` as part
of the release — **none of the three are present in this project's
`data/source/` folder**, only `01_postcodes`, `02_venues`, `03_aliases`,
`05_ambiguities` and `08_localities` were imported. This means:
- The `formerLocations` mechanism added in this change has no real data to
  populate it beyond the one venue already flagged `DEMOLISHED` inside
  `02_venues` ("Lord Nelson, former site"). It's tested with a synthetic
  fixture only.
- There's no manual-review-queue data beyond simply listing every
  non-`ACTIVE` venue (see below) — the original pack's own curated review
  queue, with whatever specific reasons its researchers flagged, isn't here
  to use.
- No local-language/regional-phrasing data beyond what's already folded
  into `03_aliases`/`05_ambiguities`.

To get real data into any of these, the original research release would
need to be re-supplied (or re-run) with those three files included.

## Records still needing human verification

`data/source/MANUAL_VERIFICATION_QUEUE.json` (generated directly from
`data/locations.json`, not hand-picked) lists all **485** non-`ACTIVE`
venue records — 484 `UNCERTAIN` + 1 `DEMOLISHED` — with their id, name,
town, postcode, status, confidence and quality flags. Breakdown of why
they're flagged (a venue can have more than one flag):

| flag | count |
|---|---|
| operating_status_unverified | 484 |
| entrance_coordinates_unverified | 364 |
| coordinates_missing | 120 |
| postcode_missing | 26 |
| boundary_or_restricted_site | 16 |
| locality_missing | 15 |
| postcode_terminated | 8 |

None of these can auto-dispatch after this change — a customer naming one
of them now gets asked to confirm (`UNVERIFIED_LOCATION`) rather than
being silently sent a driver.

## Test results

New file `test/locationResolverHardening.test.js` (26 tests) plus 3 small
edits to existing tests where they'd used an `UNCERTAIN`-status venue as an
"of course this auto-resolves" test fixture (that assumption was the bug —
see below). No existing test was deleted.

```
# tests 153
# pass 153
# fail 0
```
(run 4 times consecutively to rule out flakiness; a pre-existing,
unrelated port-timing flake in `test/fullSystem.e2e.test.js` — documented
in an earlier session, not caused by this change — showed up once across
those runs and was confirmed unrelated by 3 clean isolated reruns of just
that file.)

### Existing tests updated (not deleted)

- `test/engine.test.js`: two tests ("mentioning the confirmed venue again…",
  "a genuinely different location sent after confirmation…") used "Cheungs
  Chinese Takeaway" (status `UNCERTAIN`) as a venue that should immediately
  auto-confirm an order. Swapped to "The Bridge Inn" (status `ACTIVE`) —
  same test intent (post-confirmation review-flag behaviour), now using a
  venue the new gating correctly still auto-resolves.
- `test/locationConversation.test.js`: the "yeah not that one, cheungs
  chinese takeaway" correction test asserted the corrected venue became
  `state.confirmed` immediately. Updated to assert the new, correct
  behaviour — it becomes `UNVERIFIED_LOCATION` and only lands in
  `state.confirmed` after an explicit "yes" (both branches now covered).

## Files touched

- `src/locationIndex.js` — `FORMER_STATUSES`, `VERIFIED_STATUS`,
  `formerLocations` constructor wiring, `findFormerLocation()`.
- `src/locationConversation.js` — status-gated `_resolve()`,
  `FORMER_LOCATION` phrase check, doc comment.
- `src/engine.js` — two new `_locationQuestion()` cases.
- `data/messages.json` — `unverified_location`, `former_location`.
- `data/locations.json` — no data changed; schema note only (see below).
- `test/locationResolverHardening.test.js` — new, 26 tests.
- `test/engine.test.js`, `test/locationConversation.test.js` — 3 tests
  updated per above.
- `data/source/MANUAL_VERIFICATION_QUEUE.json` — new, generated list of
  the 485 records needing human verification before they could ever be
  marked `ACTIVE`.
