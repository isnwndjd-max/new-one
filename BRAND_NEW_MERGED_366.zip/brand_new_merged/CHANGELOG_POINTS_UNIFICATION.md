# Rocket Dispatch — Points Unification (SMS + Customer App)

**Status: OFFLINE ONLY. Not deployed.**

## 1. What was found

Two genuinely separate points ledgers existed:
- rocket-dispatch's own engine tally (`state.customers[phone].points`) -
  flat `pointsPerOrder` per completed order, earn-only, no spend.
- the customer app's own local ledger (`customer.db`'s `customers.points`)
  - proportional to money spent (`pointsPerPound`), and DOES support
  spending (Reel Frenzy Spin redemption).

`customer-relay/adapter.js` only ever reflected order completions back to
the app for orders the app itself knew about (`/api/integration/
mappings`, i.e. orders that started life in the app). A customer who
texted Rocket directly through real Tasker SMS, with no app order at all,
completed fine in rocket-dispatch's own tally - but that never reached
the app. Opening the app later would show zero points for every order
they'd ever placed by text.

## 2. The fix

**`customer-app/server.py`**: new `POST /api/integration/points-credit`.
Unlike the existing `/api/integration/order-complete` (which requires a
row in the app's own `orders` table - 404s otherwise, since it was built
for app-originated orders only), this credits by **phone number**
directly, auto-creating the customer's account row if they've never
opened the app (`insert or ignore into customers(phone)`). Takes
`paidPence`, not a pre-computed point count, and runs the exact same
remainder-carry points math `order-complete` already used
(`points_remainder_pence`) - one formula, whichever channel the order
came from. Idempotent via the existing unique index on
`points_ledger(phone, external_ref)`: a repeat call with the same
`externalRef` (rocket-dispatch's own order id) is a safe no-op, not a
double-credit - caught explicitly (`sqlite3.IntegrityError`) rather than
relying on the caller never retrying.

**`customer-relay/adapter.js`**: new `pointsSyncSmsOnly()`, called every
poll alongside the existing `syncActiveOrders()`. Looks at every
rocket-dispatch order (`/boss/orders`), and for any that's `COMPLETED`
and has **no** app mapping at all (tracked via a persistent,
ever-accumulating `appOrderRocketIds` set - see the code comment on why a
per-poll snapshot of "currently mapped" isn't enough: an app order drops
out of `/api/integration/mappings` the moment it completes, so a
snapshot would wrongly treat an already-credited app order as a
pure-SMS one on the very next poll), calls the new endpoint. An
app-originated order continues to be credited exactly as before, through
the existing `completeOrder()` -> `order-complete` path - this is
additive, not a replacement.

## 3. Decision made along the way

Asked the user whether a points record should be auto-created for a
customer who's never opened the app, so it's waiting for them when they
do, versus only syncing customers who already have an app account.
**User confirmed: auto-create.**

## 4. Not changed

- The existing app-originated order-complete path (points math, spin
  awards, `reward_applied` flagging) - untouched.
- Redemption (`/api/loyalty/redeem`) - untouched; still spends from the
  same single local ledger, now correctly topped up from both channels.
- rocket-dispatch's own engine-side `state.customers[phone].points` tally
  - untouched, still exists, still flat-rate. This fix is about getting
  SMS order value INTO the app's ledger too, not about removing or
  replacing the engine's own separate tally.

## 5. Test results

**274 / 274 passing** (`node --test test/*.js`). 3 new tests in
`test/customerRelay.adapter.test.js` (against a protocol-faithful mock of
`customer-app/server.py`'s integration surface, plus a real
rocket-dispatch server over real HTTP - same pattern the rest of that
file already uses): a pure-SMS order's points reach the app once it
completes; polling repeatedly after that doesn't re-credit it; an
app-originated order is never double-credited by the new SMS-only path.
`customer-app/server.py`'s new endpoint was checked for valid Python
syntax (`ast.parse`) but not run against the real Python process in this
pass - see `customer-relay/README.md` for what a real end-to-end check
against the Python server would still need.

## 6. Rollback

Both changes are additive: a new endpoint in `server.py` (nothing
existing modified), a new function in `adapter.js` called from
`pollOnce()` (the existing `syncActiveOrders()`/`resolveAwaitingCreation()`
calls are unchanged in behaviour). Removing the new endpoint and the
`pointsSyncSmsOnly()` call reverts to the previous, two-ledger state.
