'use strict';

/*
 * Rocket Dispatch transport server.
 *
 * Tasker talks to this over plain HTTP - it works identically whether this
 * process runs on the phone itself (Termux/local) or on a VPS; only the base
 * URL Tasker is pointed at changes. That keeps the phone-local-vs-VPS
 * decision open rather than baked into the code.
 *
 * A future Signal adapter talks to the same engine through the /driver/*
 * endpoints below, using the same shape as the customer SMS endpoints.
 *
 * Endpoints:
 *   POST /sms/inbound            { from, text, messageId? }
 *   GET  /sms/outbound/pending   -> { messages: [{id,to,text}] }
 *   POST /sms/outbound/ack       { id, ok, error? }
 *
 *   POST /driver/inbound         { driverId, text, messageId? }
 *   GET  /driver/outbound/pending
 *   POST /driver/outbound/ack    { id, ok, error? }
 *   POST /driver/register        { id, name?, traccarId? }
 *
 *   All of the above (the "gateway" surface Tasker and the Signal adapter
 *   call) require an X-Gateway-Token header matching config.gateway.token.
 *   Without this, anyone who can reach the server - not just Tasker or
 *   Signal - could inject fake customer orders or fake driver replies.
 *   HEADER ONLY, never a ?token= query param: URLs end up in proxy/server
 *   access logs, shell history and browser history, none of which should
 *   ever see a secret. Change config.gateway.token from its placeholder
 *   before this server is reachable from anywhere but localhost. See
 *   tasker/TASKER_SETUP.md and docs/SIGNAL_INTEGRATION.md.
 *
 *   POST /gps/traccar            Traccar "position forwarding" (type: json)
 *                                 webhook target. See docs/TRACCAR_INTEGRATION.md
 *                                 for how to point a Traccar server at this.
 *                                 Requires an X-Gps-Token header (HEADER
 *                                 ONLY, same reasoning as the gateway token
 *                                 above - Traccar supports custom forward
 *                                 headers; see docs/TRACCAR_INTEGRATION.md).
 *   GET  /track/:orderId         last known driver position + rough ETA for
 *                                 one order. Requires that order's own
 *                                 trackingToken (?token= or X-Tracking-Token)
 *                                 - an order id alone (4 guessable digits)
 *                                 must not be enough to see a stranger's
 *                                 live driver location. Unlike the
 *                                 server-to-server tokens above, this one is
 *                                 meant to be handed to a customer as part
 *                                 of a link, so a query param is fine here.
 *
 *   /boss/*                      the owner's own admin API (debts, referrals,
 *                                 menu, review queue). See boss/BOSS_APP.md.
 *                                 Every /boss/* request requires an
 *                                 X-Boss-Token header (HEADER ONLY) matching
 *                                 config.boss.token.
 *   GET  /boss                   serves boss/index.html (the admin page itself)
 *
 *   GET  /health                 gateway/queue status, for Tasker or Boss to show honestly
 *
 * State is saved to disk after every change (see src/store.js), ENCRYPTED
 * AT REST (AES-256-GCM, key from ROCKET_STATE_KEY), so a restart does not
 * lose in-flight orders and a stolen disk/backup does not hand over every
 * customer's phone number, order history and debts in plain text.
 *
 * The menu the order engine prices against is data/menu.sync.json, a
 * minimal projection (see src/menuSync.js) of the Boss app's own MASTER
 * menu. As of this build, the master itself is NOT stored on the VPS at
 * all, in memory or on disk: the Boss app (boss/index.html) is the sole
 * keeper of the master, in the browser's own localStorage on the owner's
 * device. PUT /boss/menu receives the master only transiently, inside a
 * single request, to validate it and derive the minimal projection that
 * gets written to menu.sync.json and hot-loaded into the engine - the
 * master itself is discarded the moment that response is sent, never
 * written to disk. This is deliberate: a compromise of the VPS's disk (a
 * stolen backup, a misconfigured snapshot, a nosy hosting provider) no
 * longer hands over cost prices, supplier notes, or any other internal-only
 * field the owner keeps on the master - the VPS never has them to lose.
 * See the legacyMasterPath handling below for the one-time migration off an
 * older build that did persist the master to disk.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');
const { BurstBuffer } = require('../src/burst');
const { Store } = require('../src/store');
const { parseTraccarForward } = require('../src/gps');
const { projectMenu } = require('../src/menuSync');

function timingSafeEqual(a, b) {
  const bufA = Buffer.from(String(a || ''));
  const bufB = Buffer.from(String(b || ''));
  // crypto.timingSafeEqual throws on mismatched lengths rather than just
  // returning false, and a length mismatch is itself the common case for a
  // wrong/missing token - so it's checked first, not caught as an error.
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// The "share your exact location" page. Deliberately a single self-
// contained HTML file (no external CSS/JS, no CDN) - it has to render and
// run correctly on whatever phone browser a customer taps the SMS link
// with, cold, with nothing cached. It only ever calls the Geolocation API
// and POSTs back to its own URL (same origin, same token in the query
// string it was loaded with) - never any third-party endpoint.
function renderLocPage(orderId, token) {
  const safeId = escHtml(orderId);
  const safeToken = escHtml(token);
  return `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Share your location - Rocket</title>
<style>
body{font-family:-apple-system,system-ui,sans-serif;background:#0b1410;color:#eafff0;margin:0;padding:24px;text-align:center}
h1{font-size:1.2rem;margin:0 0 8px}
p{color:#9fd6b4;margin:0 0 24px}
button{background:#1f9d55;color:#fff;border:0;border-radius:10px;padding:16px 28px;font-size:1.05rem;font-weight:600}
button:disabled{opacity:.6}
#status{margin-top:20px;font-size:.95rem}
.ok{color:#4ade80}.err{color:#f87171}
</style></head>
<body>
<h1>Order ${safeId}</h1>
<p>Share your exact location and we'll send it straight to dispatch.</p>
<button id="go">Share my location</button>
<div id="status"></div>
<script>
var st=document.getElementById('status'), btn=document.getElementById('go');
btn.onclick=function(){
  btn.disabled=true; st.textContent='Getting your location...'; st.className='';
  if(!navigator.geolocation){st.textContent='Your browser cannot share location. Please text us a postcode instead.';st.className='err';btn.disabled=false;return;}
  navigator.geolocation.getCurrentPosition(function(pos){
    st.textContent='Sending...';
    fetch(window.location.pathname+window.location.search,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy
    })}).then(function(r){return r.json();}).then(function(j){
      if(j.ok){st.textContent='Got it - thanks! You can close this page.';st.className='ok';}
      else{st.textContent=j.error||'Could not use that location.';st.className='err';btn.disabled=false;}
    }).catch(function(){st.textContent='Could not reach dispatch. Please try again.';st.className='err';btn.disabled=false;});
  }, function(err){
    st.textContent='Could not get your location (' + (err && err.message ? err.message : 'permission denied') + '). Please text us a postcode instead.';
    st.className='err'; btn.disabled=false;
  }, { enableHighAccuracy: true, timeout: 15000 });
};
</script>
</body></html>`;
}

const LOC_PAGE_NOT_FOUND = '<!doctype html><html><body style="font-family:sans-serif;text-align:center;padding:40px">' +
  '<p>This link has expired or is no longer valid.</p></body></html>';

function createApp({ dataDir, statePath, stateEncryptionKey, now = () => Date.now(), burstWindowMs, tickIntervalMs = 2000 } = {}) {
  const root = dataDir || path.join(__dirname, '..', 'data');
  // Only kept for one-time migration off a pre-hardening install that did
  // write the master to disk (see below) - this build never writes to it.
  const legacyMenuMasterPath = path.join(root, 'boss', 'menu.master.json');
  const menuSyncPath = path.join(root, 'menu.sync.json');
  const index = new LocationIndex(require(path.join(root, 'locations.json')));
  // Road/alley layer (offline addition - see CHANGELOG_ROAD_ALLEY_INTEGRATION.md).
  // Entirely optional: data/roads.json and data/alleys.json are separate
  // files from locations.json and are never required for the server to
  // start. If they aren't present (e.g. an older install that hasn't taken
  // this update), index.roadIndex stays unset and every road/alley branch
  // in locationConversation.js is a no-op - identical behaviour to before.
  const roadsPath = path.join(root, 'roads.json');
  const alleysPath = path.join(root, 'alleys.json');
  // Locality-context layer (see CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_
  // FIX.md) - also optional. Its absence just means no accepted_town_context
  // matching beyond a road's own OSM locality; roads.json/alleys.json still
  // work fully without it.
  const localityContextPath = path.join(root, 'localityContext.json');
  // Local alley alias layer (see CHANGELOG_ALLEY_LOCAL_ALIAS.md) - also
  // optional, on top of the road/alley layer above. Its absence just means
  // alleys keep matching by their own OSM name/generated label only, same
  // as before this addition.
  const alleyAliasesPath = path.join(root, 'alleyAliases.json');
  if (fs.existsSync(roadsPath) && fs.existsSync(alleysPath)) {
    const { RoadIndex } = require('../src/roadIndex');
    const contextData = fs.existsSync(localityContextPath) ? require(localityContextPath) : null;
    const alleyAliasData = fs.existsSync(alleyAliasesPath) ? require(alleyAliasesPath) : null;
    index.roadIndex = new RoadIndex(require(roadsPath), require(alleysPath), contextData, alleyAliasData);
  }
  const messages = require(path.join(root, 'messages.json'));
  // Load a fresh config object for each app instance, then overlay production
  // secrets from environment variables. This keeps real credentials out of
  // data/config.json and out of source-control / handover ZIPs while preserving
  // the existing placeholder values for local/offline development.
  const config = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf8'));
  if (process.env.ROCKET_BOSS_TOKEN) {
    config.boss = config.boss || {};
    config.boss.token = process.env.ROCKET_BOSS_TOKEN;
  }
  if (process.env.ROCKET_GATEWAY_TOKEN) {
    config.gateway = config.gateway || {};
    config.gateway.token = process.env.ROCKET_GATEWAY_TOKEN;
  }
  if (process.env.ROCKET_GPS_FORWARD_TOKEN) {
    config.gps = config.gps || {};
    config.gps.forwardToken = process.env.ROCKET_GPS_FORWARD_TOKEN;
  }

  // The engine loads ONLY the synced projection - never the master. The
  // master is never persisted on the VPS at all (see the file header
  // comment), so there is nothing to regenerate the projection from at
  // startup other than menu.sync.json itself, already written by the last
  // Boss save.
  let menu = fs.existsSync(menuSyncPath) ? JSON.parse(fs.readFileSync(menuSyncPath, 'utf8')) : { items: [], bundles: [] };

  const store = new Store(statePath || path.join(root, 'state.json'), { encryptionKey: stateEncryptionKey });
  const state = store.load(emptyEngineState);
  // A state.json saved by a build from before these fields existed won't
  // have them - default them in place rather than let the first real use
  // throw. Safe no-op for a state file that already has them.
  if (!state.pendingInboundSms) state.pendingInboundSms = [];
  if (!state.venueConfirmations) state.venueConfirmations = {};
  if (!state.promotionCandidates) state.promotionCandidates = [];

  const auditLog = [];
  const audit = (e) => {
    auditLog.push(e);
    if (auditLog.length > 5000) auditLog.shift();
  };

  const engine = new Engine({ index, menu, messages, config, state, audit, now });
  const burst = new BurstBuffer({ windowMs: burstWindowMs ?? config.burstWindowSeconds * 1000 });

  let dirty = false;
  const markDirty = () => { dirty = true; };
  const flush = () => { if (dirty) { store.save(engine.state); dirty = false; } };

  // Recover any inbound SMS that was durably saved (see
  // Engine.recordPendingInboundSms / CHANGELOG_SMS_INBOUND_DURABILITY.md)
  // but never made it into a processed burst - i.e. the server crashed or
  // was killed in the gap between saving it and finishing the burst that
  // contained it. Re-feeding it into the in-memory burst buffer here means
  // it goes through the exact same processBurst() path a fresh message
  // would, including the existing messageId dedup, so this is safe even
  // if the crash actually happened AFTER processing but just before the
  // pending record was cleared.
  if (state.pendingInboundSms.length) {
    console.warn(`[startup] recovering ${state.pendingInboundSms.length} inbound SMS not confirmed processed before the last shutdown`);
    for (const p of state.pendingInboundSms) burst.add(p.from, p.text, p.messageId, now(), p.id);
  }

  function writeJsonAtomic(filePath, obj) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = filePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2) + '\n');
    fs.renameSync(tmp, filePath);
  }

  // Regenerates menu.sync.json from a master handed to it (the request body
  // of a PUT /boss/menu call) and hot-loads it into the running engine. The
  // master itself is a plain function argument here, never assigned to
  // anything outside this call - it lives only for the duration of this
  // function and is garbage-collected once it returns, never written to
  // disk or held in any longer-lived variable.
  function resyncMenuFromMaster(master) {
    const projected = projectMenu(master);
    // Validate/apply BEFORE writing to disk - setMenu() throws on invalid
    // input without mutating anything, so an invalid master never reaches
    // menu.sync.json even for an instant.
    engine.setMenu(projected);
    writeJsonAtomic(menuSyncPath, projected);
    menu = projected;
  }

  // One-time migration: an install from before this change may still have
  // boss/menu.master.json sitting on disk from an earlier build. Read it at
  // startup, but do NOT delete it yet - only after it has actually been
  // served to the Boss app (see the GET /boss/menu handler below). Deleting
  // it here, before anyone has fetched it, would risk losing it for good if
  // the server restarts (a crash, a redeploy) before an operator ever opens
  // the Boss app to collect it - leaving it on disk until it's actually
  // handed off is what makes the migration safe to run unattended. If a
  // fresh install never had that file, this whole block does nothing.
  let legacyMasterForOneTimeMigration = null;
  if (fs.existsSync(legacyMenuMasterPath)) {
    try {
      legacyMasterForOneTimeMigration = JSON.parse(fs.readFileSync(legacyMenuMasterPath, 'utf8'));
      console.warn(
        '[menu] found a master menu file left on disk from an older build ' +
        '(boss/menu.master.json). It will be handed to the Boss app once, the ' +
        'next time someone opens it, so it can be saved into the browser - ' +
        'which is now the only place the master menu lives - and only then ' +
        'deleted from the VPS.'
      );
    } catch (e) {
      console.warn('[menu] found boss/menu.master.json but could not read it: ' + e.message);
    }
  }

  function processBurst(phone, texts, ids, pendingIds) {
    // Pure check first (no side effect): if ANY id in this burst was already
    // processed, skip the whole burst untouched. Using firstSeen() directly
    // inside .some() here previously marked some ids seen while still
    // bailing out early (Array.some stops at the first true), silently
    // dropping whichever new messages came after the first duplicate in the
    // same burst - a real inbound-message-loss bug, not just a duplicate risk.
    if (ids.some((id) => engine.alreadySeen(id))) {
      // Already processed in an earlier burst (or this is a startup replay
      // of a message that actually finished processing just before the
      // last shutdown) - nothing to do, but the durable pending record for
      // it is now redundant and safe to clear either way.
      engine.clearPendingInboundSms(pendingIds);
      markDirty();
      return;
    }
    for (const id of ids) engine.firstSeen(id); // now actually mark all of them
    engine.handleCustomerBurst(phone, texts);
    // Only clear the durable "not yet processed" record now that
    // handleCustomerBurst has actually run - see recordPendingInboundSms.
    engine.clearPendingInboundSms(pendingIds);
    markDirty();
  }

  function tick() {
    for (const { phone, texts, ids, pendingIds } of burst.flushReady(now())) processBurst(phone, texts, ids, pendingIds);
    engine.tick();
    markDirty();
    flush();
  }
  const timer = setInterval(tick, tickIntervalMs);
  if (timer.unref) timer.unref();

  function json(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  }
  function html(res, code, body) {
    res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let data = '';
      req.on('data', (c) => { data += c; if (data.length > 1e6) req.destroy(); });
      req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
      req.on('error', reject);
    });
  }

  // Boss app auth: every /boss/* request must carry the configured token as
  // an X-Boss-Token header - HEADER ONLY, deliberately not a ?token= query
  // param. A query param ends up in access logs, proxy logs, browser
  // history and Referer headers on any outbound link from the page; none
  // of those should ever hold this secret. timingSafeEqual so a
  // network-visible response-time difference can't be used to guess the
  // token one byte at a time. An unset token means "refused", not "open".
  function bossTokenOk(req) {
    const expected = config.boss && config.boss.token;
    if (!expected) return false;
    return timingSafeEqual(req.headers['x-boss-token'], expected);
  }

  // Same idea for the gateway surface (/sms/*, /driver/*) that Tasker and
  // the Signal adapter call. This previously had no auth at all - anyone
  // who could reach the server's port could POST a fake customer order to
  // /sms/inbound or a fake driver ACCEPT to /driver/inbound.
  function gatewayTokenOk(req) {
    const expected = config.gateway && config.gateway.token;
    if (!expected) return false;
    return timingSafeEqual(req.headers['x-gateway-token'], expected);
  }

  // Traccar's own webhook forwarder ("position forwarding") supports adding
  // custom headers - see docs/TRACCAR_INTEGRATION.md - so this doesn't need
  // a query-param fallback either.
  function gpsTokenOk(req) {
    const expected = config.gps && config.gps.forwardToken;
    if (!expected) return false;
    return timingSafeEqual(req.headers['x-gps-token'], expected);
  }

  const server = http.createServer(async (req, res) => {
    try {
      const parsedUrl = new URL(req.url, 'http://internal');
      const url = parsedUrl.pathname;

      if (url === '/boss' || url.startsWith('/boss/')) {
        // GET /boss (the admin page itself) is served without the token so
        // the page can load and then ask the person for it client-side; every
        // /boss/* API call below still requires it.
        if (req.method === 'GET' && url === '/boss') {
          try {
            const html = fs.readFileSync(path.join(__dirname, '..', 'boss', 'index.html'));
            res.writeHead(200, { 'Content-Type': 'text/html', 'Content-Length': Buffer.byteLength(html) });
            return res.end(html);
          } catch (e) {
            return json(res, 500, { ok: false, error: 'boss/index.html missing' });
          }
        }

        if (url !== '/boss' && !bossTokenOk(req)) {
          return json(res, 401, { ok: false, error: 'bad or missing boss token' });
        }

        if (req.method === 'GET' && url === '/boss/summary') {
          return json(res, 200, { ok: true, now: now(), ...engine.summary() });
        }

        if (req.method === 'GET' && url === '/boss/review') {
          return json(res, 200, { ok: true, review: engine.state.review.filter((r) => !r.resolved) });
        }
        if (req.method === 'POST' && url.startsWith('/boss/review/') && url.endsWith('/resolve')) {
          const reviewId = url.slice('/boss/review/'.length, -'/resolve'.length);
          const b = await readBody(req);
          const found = engine.resolveReview(reviewId, b.note);
          markDirty(); flush();
          return json(res, found ? 200 : 404, { ok: found });
        }

        if (req.method === 'GET' && url === '/boss/debts') {
          return json(res, 200, { ok: true, debts: engine.state.debts });
        }
        if (req.method === 'POST' && url.startsWith('/boss/debts/') && url.endsWith('/payment')) {
          const debtId = decodeURIComponent(url.slice('/boss/debts/'.length, -'/payment'.length));
          const b = await readBody(req);
          if (!(Number(b.amount) > 0)) return json(res, 400, { ok: false, error: 'amount must be a positive number' });
          const found = engine.recordDebtPayment(debtId, Number(b.amount));
          markDirty(); flush();
          return json(res, found ? 200 : 404, { ok: found });
        }

        if (req.method === 'GET' && url === '/boss/referrals') {
          return json(res, 200, { ok: true, referralCodes: engine.state.referralCodes });
        }

        if (req.method === 'GET' && url === '/boss/orders') {
          return json(res, 200, { ok: true, orders: Object.values(engine.state.orders) });
        }

        if (req.method === 'GET' && url === '/boss/drivers') {
          return json(res, 200, { ok: true, drivers: engine.state.drivers });
        }

        // ------------------------------------------------------- stock
        if (req.method === 'GET' && url === '/boss/stock') {
          return json(res, 200, { ok: true, stock: engine.allStockSummary(), lowStockAlerts: engine.state.lowStockAlerts });
        }
        if (req.method === 'POST' && url.startsWith('/boss/stock/') && url.endsWith('/restock')) {
          const code = decodeURIComponent(url.slice('/boss/stock/'.length, -'/restock'.length));
          const b = await readBody(req);
          if (!(Number(b.qty) > 0)) return json(res, 400, { ok: false, error: 'qty must be a positive number' });
          try {
            const summary = engine.restockProduct(code, Number(b.qty), b.note, b.idempotencyKey);
            markDirty(); flush();
            return json(res, 200, { ok: true, stock: summary });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }
        if (req.method === 'POST' && url.startsWith('/boss/stock/') && url.endsWith('/adjust')) {
          const code = decodeURIComponent(url.slice('/boss/stock/'.length, -'/adjust'.length));
          const b = await readBody(req);
          if (!Number.isFinite(Number(b.delta)) || Number(b.delta) === 0) return json(res, 400, { ok: false, error: 'delta must be a non-zero number' });
          try {
            const summary = engine.adjustStock(code, Number(b.delta), b.note, b.idempotencyKey);
            markDirty(); flush();
            return json(res, 200, { ok: true, stock: summary });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }
        // Loads stock onto a driver (draws from the driver's own carried
        // ledger only - see Engine.loadDriverStock from the driver
        // subsystem pass; unchanged here).
        if (req.method === 'POST' && url.startsWith('/boss/drivers/') && url.endsWith('/stock')) {
          const driverId = decodeURIComponent(url.slice('/boss/drivers/'.length, -'/stock'.length));
          const b = await readBody(req);
          try {
            const held = engine.loadDriverStock(driverId, b.code, Number(b.qty));
            markDirty(); flush();
            return json(res, 200, { ok: true, code: b.code, held });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }

        // ------------------------------------------------------- Bonus (driver pay rates)
        if (req.method === 'GET' && url === '/boss/driverPay') {
          return json(res, 200, { ok: true, driverPay: engine.config.driverPay, driverEarnings: engine.summary().driverEarnings });
        }
        if (req.method === 'PUT' && url === '/boss/driverPay') {
          const b = await readBody(req);
          const firstItemBonus = Number(b.firstItemBonus);
          const extraItemBonus = Number(b.extraItemBonus);
          if (!(firstItemBonus >= 0) || !(extraItemBonus >= 0)) {
            return json(res, 400, { ok: false, error: 'firstItemBonus and extraItemBonus must both be >= 0' });
          }
          // Editable rate, applied to every completion from now on (engine
          // stays the single source of truth - this mutates the SAME config
          // object the engine already reads from `this.config.driverPay`,
          // it does not create a separate Boss-side copy). Also written back
          // to data/config.json so the new rate survives a restart, same as
          // any other config value would.
          engine.config.driverPay.firstItemBonus = firstItemBonus;
          engine.config.driverPay.extraItemBonus = extraItemBonus;
          try { fs.writeFileSync(path.join(root, 'config.json'), JSON.stringify(config, null, 2) + '\n'); } catch (e) { /* non-fatal - in-memory rate still applies this run */ }
          engine.auditNote('DRIVER_PAY_RATE_CHANGED', `firstItemBonus=${firstItemBonus} extraItemBonus=${extraItemBonus}`);
          markDirty(); flush();
          return json(res, 200, { ok: true, driverPay: engine.config.driverPay });
        }

        // ------------------------------------------------------- loyalty
        if (req.method === 'GET' && url.startsWith('/boss/loyalty/')) {
          const phone = decodeURIComponent(url.slice('/boss/loyalty/'.length));
          const cust = engine.state.customers[phone] || { points: 0, completedOrders: 0 };
          return json(res, 200, { ok: true, phone, points: cust.points, completedOrders: cust.completedOrders });
        }
        if (req.method === 'POST' && url.startsWith('/boss/loyalty/') && url.endsWith('/adjust')) {
          const phone = decodeURIComponent(url.slice('/boss/loyalty/'.length, -'/adjust'.length));
          const b = await readBody(req);
          if (!Number.isFinite(Number(b.delta)) || Number(b.delta) === 0) return json(res, 400, { ok: false, error: 'delta must be a non-zero number' });
          try {
            const cust = engine.adjustLoyaltyPoints(phone, Number(b.delta), b.note, b.idempotencyKey);
            markDirty(); flush();
            return json(res, 200, { ok: true, phone, points: cust.points });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }

        // ------------------------------------------------------- referrals (free-item rewards)
        if (req.method === 'GET' && url === '/boss/rewards') {
          return json(res, 200, { ok: true, freeItemRewards: engine.state.freeItemRewards });
        }

        // ------------------------------------------------------- debt (summary + manual adjustment)
        if (req.method === 'GET' && url.startsWith('/boss/debts/') && url.endsWith('/summary')) {
          const phone = decodeURIComponent(url.slice('/boss/debts/'.length, -'/summary'.length));
          return json(res, 200, { ok: true, summary: engine.debtSummaryForPhone(phone) });
        }
        if (req.method === 'POST' && url.startsWith('/boss/debts/') && url.endsWith('/adjust')) {
          const debtId = decodeURIComponent(url.slice('/boss/debts/'.length, -'/adjust'.length));
          const b = await readBody(req);
          if (!Number.isFinite(Number(b.delta)) || Number(b.delta) === 0) return json(res, 400, { ok: false, error: 'delta must be a non-zero number' });
          try {
            const debt = engine.adjustDebt(debtId, Number(b.delta), b.note, b.idempotencyKey);
            markDirty(); flush();
            return json(res, 200, { ok: true, debt });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }

        // ------------------------------------------------------- driver cash (£250 limit)
        if (req.method === 'GET' && url === '/boss/cash') {
          return json(res, 200, {
            ok: true,
            limit: (engine.config.driverCash && engine.config.driverCash.limit) ?? 250,
            drivers: Object.keys(engine.state.drivers).map((id) => engine.driverCashSummary(id)),
          });
        }
        if (req.method === 'POST' && url.startsWith('/boss/drivers/') && url.endsWith('/cash/adjust')) {
          const driverId = decodeURIComponent(url.slice('/boss/drivers/'.length, -'/cash/adjust'.length));
          const b = await readBody(req);
          if (!Number.isFinite(Number(b.delta)) || Number(b.delta) === 0) return json(res, 400, { ok: false, error: 'delta must be a non-zero number' });
          try {
            const cash = engine.adjustDriverCash(driverId, Number(b.delta), b.note, b.idempotencyKey);
            markDirty(); flush();
            return json(res, 200, { ok: true, cash });
          } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
        }

        // GET returns the minimal synced projection the VPS actually holds
        // - the master (cost price, supplier notes, etc.) is not stored
        // here, so there is nothing more to serve. The one exception is the
        // single-use legacy migration payload: if an older build's master
        // file was found on disk at startup, it rides along here exactly
        // once so the Boss app can pull it into the browser's own
        // localStorage, then it's cleared from memory - a second GET after
        // that gets menu only, same as a fresh install always would.
        if (req.method === 'GET' && url === '/boss/menu') {
          const body = { ok: true, menu };
          if (legacyMasterForOneTimeMigration) {
            body.legacyMaster = legacyMasterForOneTimeMigration;
            legacyMasterForOneTimeMigration = null;
            // Only delete the legacy file now that it has actually gone out
            // in a response - not at startup (see the comment above where
            // it's read), so a crash or restart before anyone opens the
            // Boss app leaves the file in place to try again.
            try { fs.unlinkSync(legacyMenuMasterPath); } catch (e) { /* already gone, or never existed */ }
          }
          return json(res, 200, body);
        }
        // PUT receives the MASTER (the Boss app's source of truth, kept in
        // its own browser storage) in the request body, validates it and
        // derives the minimal projection the order engine actually runs
        // against - but the master itself is never written to disk here.
        // `b` goes out of scope once this handler returns; the VPS is left
        // holding only menu.sync.json.
        if (req.method === 'PUT' && url === '/boss/menu') {
          const b = await readBody(req);
          try {
            resyncMenuFromMaster(b);
            markDirty(); flush();
            // Echoes the master straight back from the request body (not
            // from any stored copy - there isn't one) so the Boss app's UI
            // can confirm what was accepted without a second round trip.
            return json(res, 200, { ok: true, menu: b });
          } catch (e) {
            return json(res, 400, { ok: false, error: e.message });
          }
        }

        return json(res, 404, { ok: false, error: 'not found' });
      }

      const gatewayRoutes = [
        '/sms/inbound', '/sms/outbound/pending', '/sms/outbound/ack',
        '/driver/register', '/driver/inbound', '/driver/outbound/pending', '/driver/outbound/ack',
      ];
      if (gatewayRoutes.includes(url)) {
        if (!gatewayTokenOk(req)) return json(res, 401, { ok: false, error: 'bad or missing gateway token' });
      }

      if (req.method === 'POST' && url === '/sms/inbound') {
        const b = await readBody(req);
        if (!b.from || typeof b.text !== 'string') return json(res, 400, { ok: false, error: 'from and text required' });
        // Durability fix (CHANGELOG_SMS_INBOUND_DURABILITY.md): SAVE first,
        // THEN respond 202, THEN process. Previously this message only
        // existed in the in-memory burst buffer for the whole burst window
        // before the response went out - if the process crashed in that
        // gap, the customer's phone would show the text as sent and Tasker
        // would have gotten a 202, but the message itself was gone. flush()
        // here is a synchronous, fsync'd, atomic write (see src/store.js) -
        // it genuinely does not return until the message is durably on
        // disk, so the 202 below is only ever sent once that's true.
        const pendingId = engine.recordPendingInboundSms(b.from, b.text, b.messageId || null);
        markDirty();
        flush();
        burst.add(b.from, b.text, b.messageId || null, now(), pendingId);
        return json(res, 202, { ok: true, buffered: true });
      }

      if (req.method === 'GET' && url === '/sms/outbound/pending') {
        return json(res, 200, { ok: true, messages: engine.claimOutbox('sms', 20) });
      }
      if (req.method === 'POST' && url === '/sms/outbound/ack') {
        const b = await readBody(req);
        const found = engine.ackOutbox(b.id, !!b.ok, b.error);
        markDirty(); flush();
        return json(res, found ? 200 : 404, { ok: found });
      }

      if (req.method === 'POST' && url === '/driver/register') {
        const b = await readBody(req);
        if (!b.id) return json(res, 400, { ok: false, error: 'id required' });
        try {
          const d = engine.registerDriver(b.id, b.name, { traccarId: b.traccarId || null });
          markDirty(); flush();
          return json(res, 200, { ok: true, driver: d });
        } catch (e) {
          return json(res, 400, { ok: false, error: e.message });
        }
      }

      if (req.method === 'POST' && url === '/driver/inbound') {
        const b = await readBody(req);
        if (!b.driverId || typeof b.text !== 'string') return json(res, 400, { ok: false, error: 'driverId and text required' });
        if (!engine.firstSeen(b.messageId || null)) return json(res, 202, { ok: true, duplicate: true });
        // quotedOrderId: set only when the transport (the Signal adapter)
        // could reliably tell which of its own earlier outbound messages
        // this reply quotes, and that message had an orderId. Engine only
        // falls back to it when the text itself has no explicit "R1234" -
        // see Engine.handleDriverMessage.
        const result = engine.handleDriverMessage(b.driverId, b.text, { quotedOrderId: b.quotedOrderId || null });
        markDirty(); flush();
        return json(res, 200, result);
      }

      if (req.method === 'GET' && url === '/driver/outbound/pending') {
        return json(res, 200, { ok: true, messages: engine.claimOutbox('driver', 20) });
      }
      if (req.method === 'POST' && url === '/driver/outbound/ack') {
        const b = await readBody(req);
        const found = engine.ackOutbox(b.id, !!b.ok, b.error);
        markDirty(); flush();
        return json(res, found ? 200 : 404, { ok: found });
      }

      if (req.method === 'POST' && url === '/gps/traccar') {
        if (!gpsTokenOk(req)) return json(res, 401, { ok: false, error: 'bad or missing X-Gps-Token header' });
        const b = await readBody(req);
        const fix = parseTraccarForward(b);
        if (!fix) return json(res, 400, { ok: false, error: 'not a recognised Traccar position payload' });
        const result = engine.updateDriverLocation(fix);
        markDirty(); flush();
        return json(res, result.ok ? 200 : 202, result);
      }

      if (req.method === 'GET' && url.startsWith('/track/')) {
        const orderId = url.slice('/track/'.length).toUpperCase();
        const order = engine.state.orders[orderId];
        // Same "doesn't exist" response either way (order missing, or
        // wrong/missing token) - a 404-vs-401 split would let someone probe
        // which order ids are real without knowing their tokens.
        if (!order) return json(res, 404, { ok: false, error: 'no live position for that order yet' });
        const supplied = parsedUrl.searchParams.get('token') || req.headers['x-tracking-token'];
        if (!timingSafeEqual(supplied, order.trackingToken)) return json(res, 404, { ok: false, error: 'no live position for that order yet' });
        const snap = engine.liveTracking(orderId);
        if (!snap) return json(res, 404, { ok: false, error: 'no live position for that order yet' });
        return json(res, 200, { ok: true, ...snap });
      }

      // GET/POST /loc/:orderId - the "share your exact location" link sent
      // in ask_location (see Engine._locationShareSuffix). GET serves a
      // tiny self-contained page (no external scripts/styles - it has to
      // work reliably on a customer's phone browser with nothing cached)
      // that asks for the browser's own Geolocation permission and POSTs
      // the result back to the same URL. Same trackingToken + same
      // "order missing or wrong token -> identical 404" pattern as
      // /track/:orderId above, so this can't be used to probe order ids.
      if ((req.method === 'GET' || req.method === 'POST') && url.startsWith('/loc/')) {
        const orderId = url.slice('/loc/'.length).toUpperCase();
        const order = engine.state.orders[orderId];
        const supplied = parsedUrl.searchParams.get('token') || req.headers['x-tracking-token'];
        const notFound = () => (req.method === 'GET'
          ? html(res, 404, LOC_PAGE_NOT_FOUND)
          : json(res, 404, { ok: false, error: 'no such order' }));
        if (!order || !timingSafeEqual(supplied, order.trackingToken)) return notFound();

        if (req.method === 'GET') {
          return html(res, 200, renderLocPage(orderId, supplied));
        }

        // POST: the page's own fetch(), body { lat, lng, accuracy }
        const b = await readBody(req);
        const lat = typeof b.lat === 'number' ? b.lat : parseFloat(b.lat);
        const lng = typeof b.lng === 'number' ? b.lng : parseFloat(b.lng);
        const accuracy = typeof b.accuracy === 'number' ? b.accuracy : (b.accuracy != null ? parseFloat(b.accuracy) : null);
        const result = engine.submitLocationPin(orderId, lat, lng, accuracy);
        markDirty(); flush();
        if (!result.ok && result.reason === 'ALREADY_CONFIRMED') {
          return json(res, 409, { ok: false, error: 'This order already has a confirmed meeting point. Text us if you need to change it.' });
        }
        if (!result.ok) return json(res, 400, { ok: false, error: 'could not use that location' });
        return json(res, 200, { ok: true });
      }

      if (req.method === 'GET' && url === '/health') {
        return json(res, 200, { ok: true, now: now(), ...engine.summary() });
      }

      json(res, 404, { ok: false, error: 'not found' });
    } catch (err) {
      json(res, 500, { ok: false, error: err.message });
    }
  });

  return { server, engine, burst, tick, flush, stop: () => { clearInterval(timer); flush(); }, store, config };
}

if (require.main === module) {
  const { checkStartupSafety } = require('../src/startupGuard.js');
  const port = process.env.ROCKET_PORT || 8787;
  const app = createApp({ statePath: process.env.ROCKET_STATE || undefined });

  // Refuse to start in staging/production with placeholder credentials or
  // the dev encryption-key fallback still in place (Remaining Offline Fixes
  // brief, item 8). development/test (the default when ROCKET_ENV is unset)
  // is intentionally not enforced, so this never affects the test suite,
  // none of which sets ROCKET_ENV or calls this block.
  checkStartupSafety({
    env: process.env.ROCKET_ENV,
    config: app.config,
    usingDevFallback: app.store.usingDevFallback,
  });

  app.server.listen(port, () => console.log(`Rocket transport server listening on :${port}`));
  process.on('SIGTERM', () => { app.stop(); app.server.close(() => process.exit(0)); });
  process.on('SIGINT', () => { app.stop(); app.server.close(() => process.exit(0)); });
}

module.exports = { createApp };
