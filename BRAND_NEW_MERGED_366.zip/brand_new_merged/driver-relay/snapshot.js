'use strict';

/*
 * Builds a snapshot in the exact shape the Driver APK's own client-side
 * validation expects (driver-app/source/src/com/rocket/driverprivate/
 * DriverClient.java's validateSnapshot(), and driver-app/source/assets/
 * rules.js's demo() fixture) out of this project's own engine state
 * (src/engine.js). Pure function: no network, no file access, no mutation
 * of engine state.
 *
 * This only concerns itself with what the app needs to SHOW and validate.
 * It never includes a customer phone number - see docs/DRIVER_APP.md and
 * the driver-isolation tests in test/engine.test.js for why that matters,
 * a rule this snapshot builder keeps by construction: nothing here reads
 * order.phone into the output.
 */

const { toAppOrderId } = require('./orderIds');

// The app only understands these three job states (DriverClient.java's
// validateSnapshot: "OFFERED|ASSIGNED|ARRIVED"). rocket-dispatch's engine
// has a fourth, EN_ROUTE, with no app-side equivalent - it is shown as
// ASSIGNED, same as the app already does for "accepted but not yet arrived".
// See driver-relay/README.md's gap list.
function jobStatus(orderState) {
  if (orderState === 'OFFERED') return 'OFFERED';
  if (orderState === 'ARRIVED') return 'ARRIVED';
  if (orderState === 'ASSIGNED' || orderState === 'EN_ROUTE') return 'ASSIGNED';
  return null; // DRAFT/CONFIRMED/COMPLETED/CANCELLED/EXPIRED - not shown to a driver
}

function outstandingDebtPence(engine, phone) {
  let owed = 0;
  let oldestCreatedAt = null;
  for (const d of engine.state.debts) {
    if (d.phone !== phone) continue;
    const paid = (d.payments || []).reduce((n, p) => n + p.amount, 0);
    const remaining = Math.round((d.amount - paid) * 100) / 100;
    if (remaining > 0.001) {
      owed += remaining;
      if (oldestCreatedAt === null || d.createdAt < oldestCreatedAt) oldestCreatedAt = d.createdAt;
    }
  }
  return { owedPence: Math.round(owed * 100), oldestCreatedAt };
}

function describeOrderItems(menu, items) {
  const byCode = new Map(menu.items.map((i) => [i.code, i]));
  return (items || []).map((i) => ({ name: (byCode.get(i.code) || {}).name || i.code, qty: i.qty }));
}

/**
 * Build the app-shaped snapshot for one driver.
 * @param {object} engine - a src/engine.js Engine instance
 * @param {string} driverId
 * @param {{now?: number, revOf: (orderId: string, stateKey?: string) => number}} opts
 *   revOf supplies the per-order "rev" counter the app requires (see
 *   driver-relay/revTracker.js's RevTracker - rocket-dispatch's own engine
 *   has no revision counter on orders, so the adapter tracks one itself
 *   rather than adding one to src/engine.js, to keep this integration
 *   additive rather than touching tested engine internals). The optional
 *   second argument lets the tracker notice a real change (see the call
 *   site below, which passes the job's app-visible `status`).
 */
function buildSnapshot(engine, driverId, opts) {
  const now = (opts && opts.now) || engine.now();
  const revOf = opts && opts.revOf;
  if (typeof revOf !== 'function') throw new Error('buildSnapshot requires opts.revOf(orderId, stateKey?) -> integer rev');
  const driver = engine.state.drivers[driverId];
  if (!driver) throw new Error('unknown driver: ' + driverId);

  const jobs = [];
  for (const order of Object.values(engine.state.orders)) {
    const status = jobStatus(order.state);
    if (!status) continue;
    const isMine = order.driverId === driverId;
    const isOfferedToMe = order.state === 'OFFERED' && order.offeredTo.includes(driverId);
    if (!isMine && !isOfferedToMe) continue;

    const { owedPence, oldestCreatedAt } = outstandingDebtPence(engine, order.phone);
    const overdueDays = oldestCreatedAt ? Math.floor((now - oldestCreatedAt) / 86400000) : 0;
    const totalPence = Math.round(order.total * 100);
    const loc = order.location && order.location.confirmed;

    jobs.push({
      // Translated to the app's own required id shape (A + 4 digits) - see
      // driver-relay/orderIds.js. revOf() stays keyed by rocket-dispatch's
      // OWN id (order.id, "R####") since that's the stable id the rest of
      // this integration (and the engine itself) uses internally.
      id: toAppOrderId(order.id),
      // status is what the app actually displays and gates actions on, so
      // it's exactly the right "has this changed" key for RevTracker - see
      // driver-relay/revTracker.js.
      rev: revOf(order.id, status),
      status,
      // The app requires offerExpires only while OFFERED; rocket-dispatch
      // doesn't track a per-offer expiry today (offers stay open until
      // accepted or the order itself expires), so this is a generous
      // synthetic window, not a real server-enforced deadline - a real
      // deadline would need to be added to src/engine.js, out of scope for
      // this offline adapter. See the gap list.
      offerExpires: status === 'OFFERED' ? now + 10 * 60000 : undefined,
      totalPence,
      cashDuePence: totalPence,
      checksRequired: false, // rocket-dispatch has no delivery-checks concept - see gap list
      customerLabel: 'Order ' + toAppOrderId(order.id), // never the phone number - see file header
      owedPence: owedPence > 0 ? owedPence : undefined,
      overdueDays: owedPence > 0 ? overdueDays : undefined,
      overdue: owedPence > 0 && overdueDays >= 1 ? true : undefined,
      debtLabel: owedPence > 0 ? 'OWES £' + (owedPence / 100).toFixed(2) + (overdueDays ? ' • ' + overdueDays + ' DAYS' : '') : undefined,
      items: describeOrderItems(engine.menu, order.items || []),
      location: {
        label: engine._placeLabel(loc) || 'Location to confirm',
        lat: loc && typeof loc.lat === 'number' ? loc.lat : null,
        lon: loc && typeof loc.lng === 'number' ? loc.lng : null,
        confirmed: !!(loc && loc.lat != null && loc.lng != null),
      },
    });
    // Strip undefined keys so the JSON the app parses matches its own
    // optional-field handling (JSONObject.optX) rather than sending nulls
    // it doesn't expect.
    const j = jobs[jobs.length - 1];
    for (const k of Object.keys(j)) if (j[k] === undefined) delete j[k];
  }

  // Driver stock: engine tracks it as { code: qty }; the app's "My Stock"
  // page wants [{ name, held, free }]. There's no reservation concept in
  // the engine (stock isn't held-against-an-order), so free === held -
  // every unit a driver carries is available to TAKE.
  const stock = Object.entries(driver.stock || {})
    .filter(([, qty]) => qty > 0)
    .map(([code, qty]) => {
      const item = (engine.menu.items || []).find((i) => i.code === code);
      return { name: item ? item.name : code, held: qty, free: qty };
    });

  return {
    v: 1,
    seq: undefined, // filled in by the caller (driver-relay/adapter.js), which owns the monotonic sequence
    at: now,
    // Driver bonus totals now live durably on the engine's own driver
    // record (see src/engine.js's _complete()) - surfaced here instead of
    // the previous placeholder zeros.
    earningsTodayPence: Math.round(((driver.earnings && driver.earnings.totalBonus) || 0) * 100),
    jobsCompletedToday: (driver.earnings && driver.earnings.completedOrders) || 0,
    driver: {
      id: driver.id,
      name: driver.name,
      // status is the engine's authoritative 3-state; BREAK now reports as
      // BREAK (not OFF) - see driver-relay/commands.js's applyShift().
      shift: driver.status === 'ON' ? driver.mode : (driver.status || 'OFF'),
      enabled: true,
      // The Driver app's own ui.js reads totalWagesPence/jobsCompleted off
      // the driver object (its ??-chain in totalWages()/summaryStats() -
      // these were never previously sent, so the app always showed "—".
      // Wired here to the same durable per-driver figures as above.
      totalWagesPence: Math.round(((driver.earnings && driver.earnings.totalBonus) || 0) * 100),
      jobsCompleted: (driver.earnings && driver.earnings.completedOrders) || 0,
    },
    stock,
    jobs,
  };
}

module.exports = { buildSnapshot, jobStatus };
