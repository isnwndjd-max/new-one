'use strict';

/*
 * The Driver app requires every job to carry a "rev" counter (an integer
 * that changes whenever the job's state changes) and rejects any command
 * whose expectedRev doesn't match the job's CURRENT rev
 * (DriverClient.java's validAction(): "rev!=j.getLong('rev')" -> "Job
 * changed; refresh first"). rocket-dispatch's own engine has no such
 * counter on an order - it wasn't designed for optimistic concurrency
 * against a polling client - and this integration deliberately does not
 * add one to src/engine.js to get it: that's tested, shipped engine code,
 * and this whole integration is meant to be additive, not a reason to
 * touch it.
 *
 * Instead, the adapter (the only thing that owns a RevTracker instance)
 * derives a rev purely from what it can already see: every time it builds
 * a snapshot for a job it hasn't seen in this state before, the rev
 * advances. This is enough to give the app's own "refresh first" safety
 * net real meaning (a stale rev really does mean the job has moved on
 * since the driver last saw it) without needing the engine to know
 * anything about revs at all.
 *
 * One RevTracker per driver (a job only ever needs a rev while it's
 * visible to a particular driver's snapshot).
 */

class RevTracker {
  constructor() {
    this._revs = new Map(); // rocket-dispatch orderId -> { rev, lastKey }
    this._snapshotSeq = 0;
  }

  /**
   * Called from snapshot.js's revOf() while building a snapshot. `stateKey`
   * should capture whatever the app needs to be told "changed" about -
   * status and, since the app also shows it, the assigned driver - so a rev
   * bump happens exactly when the app's own job view would look different,
   * not on every poll.
   */
  revOf(orderId, stateKey) {
    const existing = this._revs.get(orderId);
    if (!existing) {
      this._revs.set(orderId, { rev: 1, lastKey: stateKey });
      return 1;
    }
    if (stateKey !== undefined && stateKey !== existing.lastKey) {
      existing.rev += 1;
      existing.lastKey = stateKey;
    }
    return existing.rev;
  }

  /** The rev a command's expectedRev is checked against - null if this driver has no live rev for that order (never seen it, or it's dropped out of their snapshot). */
  currentRev(orderId) {
    const existing = this._revs.get(orderId);
    return existing ? existing.rev : null;
  }

  /** Snapshot.seq must be monotonically increasing per the app's own replay check (DriverClient.java#status: "seq<floor" is rejected). */
  nextSnapshotSeq() {
    this._snapshotSeq += 1;
    return this._snapshotSeq;
  }

  /** Stop tracking an order once it can never appear in this driver's snapshot again (completed/cancelled/expired, or reassigned to someone else). Keeps this from growing forever across a long-running process. */
  forget(orderId) {
    this._revs.delete(orderId);
  }
}

module.exports = { RevTracker };
