# Driver relay adapter (offline prep)

This directory lets the **existing, already-signed, already-paired Driver
APK** (`driver-app/`, package `com.rocket.driverprivate`, v1.1.5) and its
**existing encrypted relay** (pinned to `100.103.3.32:8911` for the driver
client) work against rocket-dispatch's own engine as the business-logic
processor behind that relay - **without** replacing or modifying the live
relay, without touching V35, without rebuilding or re-signing the APK, and
without ever having had the private signing key or a real pairing bundle.

Architecture (unchanged from what was asked for):

```
Existing Driver APK -> existing pinned TLS relay :8911 -> existing relay
    -> backend/adapter interface :8912 -> driver-relay/ (this) -> rocket-dispatch engine
```

**Everything in this directory has been built and tested OFFLINE ONLY.**
Nothing here has been deployed, nothing here has been pointed at
`100.103.3.32:8912` or a real device, the existing `:8911` relay has never
been touched, and Tasker/the Driver phone/live customer or order state have
never been touched. See "What is NOT yet verified" below before this goes
anywhere near that.

## What's here

| File | What it does |
|---|---|
| `protocol.js` | Node re-implementation of the Driver APK's own RD1 envelope protocol (seal/open/fingerprint/etc.), ported line-for-line from `driver-app/source/src/com/rocket/driverprivate/Protocol.java` and `Crypto.java`. |
| `orderIds.js` | Translates between rocket-dispatch's own order id shape (`R####`) and the shape the app's own client-side validation *requires* (`A` + 3-8 digits - `DriverClient.java#validateSnapshot`). Without this the real app would throw the whole snapshot away as invalid. |
| `snapshot.js` | Builds a snapshot in the exact JSON shape the app's own `DriverClient.java#validateSnapshot()` checks, from rocket-dispatch's own engine state. Pure function, no I/O, never includes a customer phone number. |
| `revTracker.js` | Derives the per-job `rev` counter the app requires (rocket-dispatch's engine has no such concept) purely by watching when a job's app-visible status changes - not stored in the engine, not persisted, one instance per driver. |
| `commands.js` | Server-side mirror of the app's own client-side command validation (`DriverClient.java#validAction()`), plus translation of a validated command into rocket-dispatch's engine (via `Engine.handleDriverMessage()`'s existing text-command language - the engine itself is never modified or reached into). |
| `adapter.js` | The polling loop: pulls commands and GPS fixes from the relay's backend interface, applies them, pushes fresh snapshots, and seals/sends receipts. |
| `config.example.json` | Shape of the config a real deployment would need - every value in it is a fabricated example, not a real secret (see below). |

## Test coverage

`test/driverRelay.adapter.test.js` (15 tests) + `test/helpers/mockAdapterServer.js`
(a real HTTP server standing in for the `:8912` interface - same "real
protocol, not a stub" approach as `test/signalAdapter.test.js`'s mocked
signal-cli daemon). Covers, against **real sealed/opened RD1 envelopes**
built with `protocol.js`:

1. snapshot -> offer -> accept -> active order (end to end)
2. an offer already taken by another driver is rejected, not silently accepted
3. ETA and HERE (including: EN_ROUTE has no app-visible status, so the rev
   correctly does *not* change between ETA and HERE)
4. HERE attempted before the job is even assigned is rejected
5. COMPLETE with full payment (no debt), partial payment (debt for the
   shortfall), and nothing collected/"owe" (full amount as debt)
6. the exact same command envelope redelivered (a real app retry) is never
   applied twice, and gets back the identical cached receipt
7. two different envelopes for the same logical ACCEPT are still safe
   (engine-level idempotency, not just envelope-id dedup)
8. a receipt is sealed under the same envelope id as its request, with a
   `commandHash` that is the fingerprint of the *original* request packet
9. two drivers' concurrently-arriving commands each get their own correctly
   matched receipt (not cross-wired)
10. the relay being unreachable (a failed request, and a connection refused)
    fails a poll soft - logged, no throw, no partial state change - and
    recovers cleanly on the next poll with no restart needed
11. a GPS fix from the app drives the exact same tested auto-5-min/HERE
    logic a Traccar fix does (`src/engine.js#_maybeAutoGpsEvents`), via a
    synthetic device id rather than a second GPS code path
12. order-id translation round-trips

Run just this suite: `node --test test/driverRelay.adapter.test.js`

## Command mapping (app action -> engine command)

| App action | Engine command (`Engine.handleDriverMessage`) | Notes |
|---|---|---|
| `SHIFT` mode `CAR`/`FOOT` | `ON` (if not already on duty) then `CAR`/`FOOT` | Two engine calls - the engine's own command language doesn't combine them. |
| `SHIFT` mode `OFF` | `OFF` | Refused by the engine if the driver has an active job, same as the app's own client-side check. |
| `SHIFT` mode `BREAK` | `OFF` | **Gap** - see below. |
| `ACCEPT` | `ACCEPT <id>` | Idempotent in the engine itself (`_accept()`); a repeat is `{ok:true}` with "Already accepted." |
| `HERE` | `HERE <id>` | |
| `ETA` (minutes: 5/10/15/30) | `EN ROUTE <id> <minutes>` | |
| `COMPLETE` (collectedPence, checksConfirmed) | `COMPLETE <id> PAID <pounds>` | pence -> pounds conversion; the engine records a debt for any shortfall and flags an overpayment for review, independent of what this layer sends it. |
| `HELP` (reason) | `PROBLEM <reason> <id>` | Raises a Boss review item. |

Every non-`SHIFT` action requires `expectedRev` to match the job's current
rev (`revTracker.js`), mirroring the app's own "Job changed; refresh first"
client-side gate - checked again here, server-side, for the same
defense-in-depth reason every other driver-facing entry point in this
project double-checks what a client claims.

## What would later need connecting to `100.103.3.32:8912`

This was built and tested with **zero access to the real relay, real
pairing data, or the private signing key**, entirely by design (see the
original scope). Before this can be pointed at anything real:

1. **Confirm the `:8912` request/response JSON shapes.** Only the four
   route *names* were given (`POST /v1/adapter/snapshot`,
   `GET /v1/adapter/gps`, `GET /v1/adapter/commands`,
   `POST /v1/adapter/receipt`). This code's shapes for them
   (`{room, envelope}` for snapshot/receipt, `{commands:[...]}` /
   `{fixes:[...]}` for the two GETs) are this integration's own best-faith
   design, built to be consistent with the driver-facing side of the same
   relay (`Transport.java`/`DriverClient.java`'s `/v1/driver/gps`,
   `/v1/driver/commands`, `/v1/driver/status`) - **not independently
   confirmed against the real relay.** `adapter.js`'s header comment
   repeats this; check it against the real relay's actual behaviour (or
   its source, if available) before relying on it.
2. **Real pairing data per driver.** `config.example.json`'s `room`/`root`
   values are fabricated examples in the right shape, not real secrets.
   The real values come from the same pairing bundle (`RD2.` code) the
   Driver APK itself was paired with against the existing relay - this
   project has never had that, and has never asked for the private signing
   key needed to produce one.
3. **Decide how the adapter reaches rocket-dispatch's engine.**
   `adapter.js` currently takes a live `Engine` instance directly
   (`createDriverRelayAdapter({ engine, ... })`) - fast and simple to test,
   but it means running this **in the same process** as `server/index.js`
   (sharing that one `Engine` instance) if deployed as-is. That's a
   different shape from the Signal adapter and Tasker, which are both
   separate OS processes talking to `server/index.js` purely over HTTP
   (`/driver/*`). Two honest options when this is actually wired up:
   - Run it inside `server/index.js`'s own process (pass it the same
     `engine` the HTTP server already has, started/stopped alongside it) -
     smallest change, but a different process shape than every other
     adapter in this project.
   - Add one small, gateway-token-gated *read* endpoint to
     `server/index.js` (e.g. `GET /driver/snapshot?driverId=...`) that
     exposes exactly what `snapshot.js` needs, and have `adapter.js` call
     that plus the *existing* `POST /driver/inbound` (already used by
     Signal) instead of touching `engine` directly - keeps this a genuinely
     separate process, consistent with Signal/Tasker, at the cost of one
     new (small, additive, easy-to-review) route.

   Neither of these has been done - this is a real decision for whoever
   wires this up for real, not made unilaterally here.
4. **A live signal-cli/Traccar-style trial run has the same caveat as
   everything else in this project that talks to real external
   infrastructure**: this has been exercised against a protocol-faithful
   mock, never a live device or the real relay.

## Gap list - what the existing relay/app can do that this doesn't yet support

- **No `BREAK` shift state.** rocket-dispatch's engine only has
  onDuty(true/false) + mode(CAR/FOOT) - `SHIFT BREAK` is mapped to `OFF`,
  so a driver on a break shows as `OFF` in their own snapshot, not `BREAK`.
  Functionally equivalent (no new offers reach them either way) but not
  label-accurate. A real fix means adding a break concept to the engine
  itself - out of scope for this additive integration.
- **No real per-offer expiry.** The app requires `offerExpires` on an
  `OFFERED` job; rocket-dispatch doesn't track one, so `snapshot.js` sends
  a synthetic 10-minute window rather than a server-enforced deadline.
- **No delivery-checks concept.** `checksRequired`/`checksConfirmed` are
  always sent as `false` - rocket-dispatch's engine has no equivalent of
  the app's delivery-checklist feature.
- **No driver earnings-today ledger.** `earningsTodayPence` and
  `jobsCompletedToday` are always `0` - not tracked anywhere in the engine.
- **EN_ROUTE is invisible to the app.** The engine's own `EN_ROUTE` state
  (set by the `ETA` action) has no app-side equivalent and is shown as
  `ASSIGNED`, same as the app already does for "accepted, not yet arrived."
  This is why a job's `rev` does not change between an ETA and a HERE.
- **GPS accuracy/speed/staleness bounds are the app's own, not
  re-validated here.** `DriverClient.java#submitGps` already bounds
  accuracy (0-50m), speed (0-100m/s) and fix staleness (≤120s) client-side
  before it ever seals the envelope; this adapter forwards whatever it
  receives into the engine's existing GPS pipeline (which has its own
  independent accuracy/staleness handling for the auto-arrival logic - see
  `src/engine.js#_maybeAutoGpsEvents`) rather than re-implementing the
  app's bounds a second time.
- **The engine's own driver-channel text replies still get queued.**
  `Engine.handleDriverMessage()` always queues a human-readable reply via
  the engine's 'driver' outbox channel (meant for Signal). This adapter
  never claims/acks that channel for its own driver ids, so those messages
  accumulate harmlessly in `state.outbox` unclaimed rather than being
  drained - not a correctness bug (nothing exposes or relies on them), but
  worth draining or filtering out eventually rather than leaving them to
  grow forever in a long-running deployment.
- **Snapshot push cadence is polling, not push.** The real relay's own
  timing/backoff behaviour for `:8912` is unknown (see above) - this
  adapter pushes a fresh snapshot after every applied command and after
  any GPS-triggered engine change, plus once at startup, on a fixed
  `pollIntervalMs` timer otherwise. Real cadence requirements from the
  relay may differ.
