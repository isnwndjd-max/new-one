'use strict';

/*
 * Polling adapter that would eventually sit between the EXISTING, already
 * signed and paired Driver APK's relay backend interface (per the user's
 * own architecture: Driver APK -> pinned TLS relay :8911 -> relay ->
 * backend/adapter interface :8912 -> this) and rocket-dispatch's own
 * engine (src/engine.js).
 *
 * OFFLINE ONLY, exactly as instructed. This has never been pointed at the
 * real 100.103.3.32:8912 interface - only at a protocol-faithful MOCK HTTP
 * server built from the driver app's own known wire formats (Protocol.java,
 * Crypto.java, DriverClient.java, rules.js - see driver-relay/protocol.js
 * and driver-relay/snapshot.js). It never touches the existing 8911 relay,
 * Tasker, the Driver phone, or any live customer/order state - the only
 * things it talks to are `engine` (in-process, the same Engine class
 * server/index.js uses) and, over HTTP, whatever `adapterApiBase` points
 * at (a mock in every test, see test/driverRelay.adapter.test.js).
 *
 * IMPORTANT, undocumented assumption flagged up front: the user gave us
 * the four :8912 route NAMES (POST /v1/adapter/snapshot, GET
 * /v1/adapter/gps, GET /v1/adapter/commands, POST /v1/adapter/receipt) but
 * not their request/response JSON shapes - there is no spec for the
 * backend side of the existing relay available here. The shapes this file
 * uses are this integration's own best-faith design, built to be
 * consistent with what the DRIVER-facing side of the same relay already
 * does (Transport.java / DriverClient.java's own POST /v1/driver/gps,
 * /v1/driver/commands, GET /v1/driver/status). Confirming or correcting
 * these shapes against the real relay is real remaining work - see
 * driver-relay/README.md's gap list. Nothing here should be pointed at the
 * real relay without that confirmation first.
 */

const protocol = require('./protocol');
const { validateCommand, applyCommand, CommandError } = require('./commands');
const { buildSnapshot } = require('./snapshot');
const { RevTracker } = require('./revTracker');

function createDriverRelayAdapter({
  engine,
  adapterApiBase,
  adapterApiToken,
  drivers, // [{ driverId, room, root: base64url(32 bytes), name? }] - see config.example.json
  fetchImpl = fetch,
  pollIntervalMs = 3000,
  now = () => Date.now(),
  log = () => {},
}) {
  if (!engine) throw new Error('engine is required');
  if (!adapterApiBase) throw new Error('adapterApiBase is required');
  if (!Array.isArray(drivers) || !drivers.length) {
    throw new Error('drivers is required: [{ driverId, room, root }, ...] - see driver-relay/config.example.json');
  }

  const byRoom = new Map();
  const byDriverId = new Map();
  const revTrackers = new Map(); // driverId -> RevTracker

  for (const drv of drivers) {
    const root = Buffer.isBuffer(drv.root) ? drv.root : protocol.un64(drv.root);
    const rec = { driverId: drv.driverId, room: drv.room, root };
    byRoom.set(drv.room, rec);
    byDriverId.set(drv.driverId, rec);
    revTrackers.set(drv.driverId, new RevTracker());
    // Reuse the engine's EXISTING GPS pipeline (same code path a Traccar
    // fix takes, same tested auto-5-min/HERE logic in
    // src/engine.js#_maybeAutoGpsEvents) via a synthetic device id, rather
    // than adding a second location-update path to the engine. registerDriver()
    // is a no-op on fields other than traccarId if the driver already
    // exists (see src/engine.js), so this is safe to call every startup.
    engine.registerDriver(drv.driverId, drv.name || drv.driverId, { traccarId: `DRIVERAPP:${drv.driverId}` });
  }

  function revTrackerFor(driverId) {
    return revTrackers.get(driverId);
  }

  // Every command envelope id already applied, keyed by envelope id, so a
  // redelivered/retried envelope - the app resends the EXACT SAME saved
  // envelope on retry, see DriverClient.java#submit: "Retry sends the SAME
  // saved action" - gets the SAME receipt instead of being applied a
  // second time. This is what makes a duplicate command safe.
  const appliedCommands = new Map(); // envelope id -> { ok, message, snapshotSeq }

  const headers = () => Object.assign(
    { 'Content-Type': 'application/json' },
    adapterApiToken ? { 'X-Adapter-Token': adapterApiToken } : {}
  );

  async function pushSnapshot(driverId) {
    const rec = byDriverId.get(driverId);
    if (!rec) throw new Error(`unknown driver: ${driverId}`);
    const tracker = revTrackerFor(driverId);
    const snap = buildSnapshot(engine, driverId, { now: now(), revOf: (orderId, stateKey) => tracker.revOf(orderId, stateKey) });
    snap.seq = tracker.nextSnapshotSeq();
    const packet = protocol.seal(rec.root, rec.room, 'snapshot', protocol.id(), now(), protocol.SNAPSHOT_TTL, JSON.stringify(snap));
    let res;
    try {
      res = await fetchImpl(`${adapterApiBase}/v1/adapter/snapshot`, {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({ room: rec.room, envelope: protocol.encode(packet) }),
      });
    } catch (e) {
      log(`snapshot push for ${driverId} threw: ${e.message}`);
      return { ok: false, seq: snap.seq };
    }
    if (!res.ok) log(`snapshot push for ${driverId} failed: HTTP ${res.status}`);
    return { ok: res.ok, seq: snap.seq };
  }

  async function pushSnapshotsForAllDrivers() {
    for (const driverId of byDriverId.keys()) await pushSnapshot(driverId);
  }

  async function sendReceipt(rec, requestPacket, state, message, snapshotSeq) {
    const commandHash = protocol.fingerprint(requestPacket);
    const body = JSON.stringify({ id: requestPacket.id, state, message, commandHash, snapshotSeq });
    // Same envelope id as the ORIGINAL command, not a new one - this is
    // exactly what DriverClient.java#status() matches a receipt back to
    // its request by (both the envelope's own "id" field and the receipt
    // body's own "id" field must equal request.id - see that method's
    // "Wrong confirmation" check).
    const receiptPacket = protocol.seal(rec.root, rec.room, 'receipt', requestPacket.id, now(), protocol.RECEIPT_TTL, body);
    try {
      const res = await fetchImpl(`${adapterApiBase}/v1/adapter/receipt`, {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({ room: rec.room, envelope: protocol.encode(receiptPacket) }),
      });
      if (!res.ok) log(`POST /v1/adapter/receipt for ${rec.driverId} failed: HTTP ${res.status}`);
    } catch (e) {
      log(`POST /v1/adapter/receipt for ${rec.driverId} threw: ${e.message}`);
    }
  }

  async function handleCommandEnvelope({ room, envelope }) {
    const rec = byRoom.get(room);
    if (!rec) throw new Error(`unknown room: ${room}`);
    const decoded = protocol.decode(envelope);
    protocol.fresh(decoded, now(), protocol.COMMAND_TTL);

    const already = appliedCommands.get(decoded.id);
    if (already) {
      await sendReceipt(rec, decoded, already.ok ? 'applied' : 'rejected', already.message, already.snapshotSeq);
      return { duplicate: true };
    }

    const plaintext = protocol.open(rec.root, rec.room, 'command', decoded);
    let outcome;
    try {
      const cmd = validateCommand(JSON.parse(plaintext));
      // applyCommand() calls straight into engine.handleDriverMessage(),
      // which is synchronous (src/engine.js does not await anything to
      // mutate state) - so by the time this line has returned,
      // rocket-dispatch's state is ALREADY committed. The receipt below is
      // only ever sent after this point - never before, and never assumed.
      const tracker = revTrackerFor(rec.driverId);
      outcome = applyCommand(engine, rec.driverId, cmd, tracker);
    } catch (e) {
      const rejectedMessage = e instanceof CommandError ? e.message : `Internal error: ${e.message}`;
      outcome = { ok: false, message: rejectedMessage.slice(0, 300) };
    }

    const { seq: snapshotSeq } = await pushSnapshot(rec.driverId); // fresh snapshot reflects whatever just happened (applied or not)
    appliedCommands.set(decoded.id, { ok: outcome.ok, message: outcome.message, snapshotSeq });
    await sendReceipt(rec, decoded, outcome.ok ? 'applied' : 'rejected', outcome.message, snapshotSeq);
    return { duplicate: false, ok: outcome.ok };
  }

  async function pollCommandsOnce() {
    let res;
    try {
      res = await fetchImpl(`${adapterApiBase}/v1/adapter/commands`, { headers: headers() });
    } catch (e) {
      log(`could not reach adapter interface for commands: ${e.message}`);
      return { applied: 0, errors: 1 };
    }
    if (!res.ok) { log(`GET /v1/adapter/commands failed: HTTP ${res.status}`); return { applied: 0, errors: 1 }; }
    const body = await res.json();
    const items = (body && body.commands) || [];
    let applied = 0;
    let errors = 0;
    for (const item of items) {
      try {
        await handleCommandEnvelope(item);
        applied++;
      } catch (e) {
        log(`command envelope failed: ${e.message}`);
        errors++;
      }
    }
    return { applied, errors };
  }

  async function pollGpsOnce() {
    let res;
    try {
      res = await fetchImpl(`${adapterApiBase}/v1/adapter/gps`, { headers: headers() });
    } catch (e) {
      log(`could not reach adapter interface for gps: ${e.message}`);
      return { applied: 0, errors: 1 };
    }
    if (!res.ok) { log(`GET /v1/adapter/gps failed: HTTP ${res.status}`); return { applied: 0, errors: 1 }; }
    const body = await res.json();
    const items = (body && body.fixes) || [];
    let applied = 0;
    let errors = 0;
    let anyApplied = false;
    for (const item of items) {
      try {
        const rec = byRoom.get(item.room);
        if (!rec) throw new Error(`unknown room: ${item.room}`);
        const decoded = protocol.decode(item.envelope);
        protocol.fresh(decoded, now(), protocol.GPS_TTL);
        const plaintext = protocol.open(rec.root, rec.room, 'gps', decoded);
        const fix = JSON.parse(plaintext); // {v,driverId,at,lat,lon,accuracyM,speedMps} - see DriverClient.java#submitGps
        const result = engine.updateDriverLocation({
          uniqueId: `DRIVERAPP:${rec.driverId}`,
          lat: fix.lat,
          lng: fix.lon,
          speedKph: typeof fix.speedMps === 'number' ? fix.speedMps * 3.6 : undefined,
          accuracy: fix.accuracyM,
          valid: true,
        });
        if (result.applied) anyApplied = true;
        applied++;
      } catch (e) {
        log(`gps envelope failed: ${e.message}`);
        errors++;
      }
    }
    return { applied, errors, anyApplied };
  }

  async function tick() {
    const gps = await pollGpsOnce().catch((e) => { log(`gps poll crashed: ${e.message}`); return { applied: 0, errors: 1, anyApplied: false }; });
    const commands = await pollCommandsOnce().catch((e) => { log(`command poll crashed: ${e.message}`); return { applied: 0, errors: 1 }; });
    // A GPS-triggered auto event (5 MIN/HERE) changes engine state with no
    // command coming through at all - push a fresh snapshot afterward so
    // the app sees it promptly rather than only after its next own command.
    if (gps.anyApplied) await pushSnapshotsForAllDrivers().catch((e) => log(`snapshot push crashed: ${e.message}`));
    return { gps, commands };
  }

  let timer = null;
  function start() {
    if (timer) return;
    pushSnapshotsForAllDrivers().catch((e) => log(`initial snapshot push failed, will retry on next tick: ${e.message}`));
    timer = setInterval(() => { tick(); }, pollIntervalMs);
    if (timer.unref) timer.unref();
  }
  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
  }

  return {
    start, stop, tick,
    pollCommandsOnce, pollGpsOnce,
    pushSnapshot, pushSnapshotsForAllDrivers,
    // exposed for tests that need to inspect revs/idempotency state directly
    _revTrackerFor: revTrackerFor,
  };
}

module.exports = { createDriverRelayAdapter };
