'use strict';

/*
 * rocket-dispatch's own order ids are "R" + 4 digits (src/engine.js:
 * `const id = \`R${crypto.randomInt(1000, 10000)}\`;`). The Driver APK's
 * OWN client-side validation (DriverClient.java's validateSnapshot():
 * `id.matches("A[0-9]{3,8}")`) requires a job id to start with "A" and
 * have 3-8 digits - it rejects the whole snapshot as insecure otherwise
 * ("Invalid job", a SecurityException). Sending a bare "R1234" id would
 * make the real app throw that away, so every job id that leaves this
 * integration toward the app is translated to that shape, and every id
 * that comes back from an app command is translated back before it ever
 * reaches src/engine.js.
 *
 * Rocket ids are always exactly "R" + 4 digits, so this is a pure,
 * lossless, stateless swap of the leading letter - no lookup table needed,
 * nothing to keep in sync, nothing that can drift.
 */

const ROCKET_ID_RE = /^R\d{4}$/;
const APP_ID_RE = /^A\d{4}$/;

function toAppOrderId(rocketId) {
  if (!ROCKET_ID_RE.test(rocketId)) throw new Error(`not a rocket-dispatch order id: ${rocketId}`);
  return 'A' + rocketId.slice(1);
}

function toRocketOrderId(appId) {
  if (!APP_ID_RE.test(appId)) throw new Error(`not an app-shaped order id (expected A + 4 digits): ${appId}`);
  return 'R' + appId.slice(1);
}

module.exports = { toAppOrderId, toRocketOrderId, ROCKET_ID_RE, APP_ID_RE };
