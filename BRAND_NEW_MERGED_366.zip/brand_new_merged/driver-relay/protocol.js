'use strict';

/*
 * Node re-implementation of the driver app's RD1 envelope protocol, ported
 * line-for-line from the vendored Android client source
 * (driver-app/source/src/com/rocket/driverprivate/Protocol.java and
 * Crypto.java). This is NOT a new protocol design - it exists so this
 * offline adapter can construct/parse the exact same encrypted envelopes
 * the already-signed, already-paired Driver APK expects, without changing
 * a single byte of that app or its protocol.
 *
 * OFFLINE ONLY. Nothing here talks to a network. See driver-relay/adapter.js
 * for the HTTP polling loop that would use this against the real :8912
 * interface, and driver-relay/README.md for what is and isn't done.
 *
 * Cross-checked against the Java source, not against a running app or relay
 * (this sandbox has no route to the real 100.103.3.32 relay or a JVM to run
 * the Java side side-by-side) - see the "not verified" list in the README.
 */

const crypto = require('crypto');

const COMMAND_TTL = 120000;
const GPS_TTL = 120000;
const SNAPSHOT_TTL = 90000;
const RECEIPT_TTL = 86400000;

// --- base64url, matching Java's Base64.getUrlEncoder().withoutPadding() ---
function b64(buf) {
  return Buffer.from(buf).toString('base64url');
}
function un64(str) {
  return Buffer.from(str, 'base64url');
}

function utf(str) {
  return Buffer.from(str, 'utf8');
}
function text(buf) {
  return Buffer.from(buf).toString('utf8');
}

function random(n) {
  return crypto.randomBytes(n);
}

// mac(key, value) = HmacSHA256(key, value) - matches Crypto.java's mac().
function mac(key, value) {
  return crypto.createHmac('sha256', key).update(value).digest();
}

// derive(root, room, kind): HKDF-SHA256, one 32-byte output block, matching
// Crypto.java's derive() exactly - including the (unusual, but load-bearing)
// choice to key the extract step with "RocketDriver/1/"+room and mac the
// root key as the *data*, not the other way around. This must stay
// byte-for-byte identical to the Java side or every envelope will fail to
// decrypt on a real device.
function derive(root, room, kind) {
  if (!Buffer.isBuffer(root) || root.length !== 32) throw new Error('Invalid channel: root must be 32 bytes');
  if (!/^[a-f0-9]{32}$/.test(room)) throw new Error('Invalid channel: room');
  if (!/^(command|snapshot|receipt|gps)$/.test(kind)) throw new Error('Invalid channel: kind');
  const prk = mac(utf('RocketDriver/1/' + room), root);
  const info = utf('RocketDriver/1/' + kind);
  const block = Buffer.concat([info, Buffer.from([1])]);
  return mac(prk, block);
}

function hash(str) {
  return b64(crypto.createHash('sha256').update(utf(str)).digest());
}

// AES/GCM/NoPadding via Node, with ciphertext+tag concatenated into one
// buffer the way javax.crypto.Cipher#doFinal does on the Java side (Node
// keeps them separate by default - crypt() below re-joins them so the wire
// format matches exactly).
function encryptGcm(key, nonce, aad, plaintext) {
  const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce);
  cipher.setAAD(aad);
  const ct = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return Buffer.concat([ct, cipher.getAuthTag()]);
}
function decryptGcm(key, nonce, aad, ctAndTag) {
  if (ctAndTag.length < 16) throw new Error('Invalid ciphertext');
  const ct = ctAndTag.subarray(0, ctAndTag.length - 16);
  const tag = ctAndTag.subarray(ctAndTag.length - 16);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, nonce);
  decipher.setAAD(aad);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]);
}

// --- Protocol.java equivalents ---

function id() {
  return crypto.randomUUID();
}

function header(p) {
  return 'RD1\n' + p.room + '\n' + p.kind + '\n' + p.id + '\n' + p.issued + '\n' + p.expires;
}

function structure(p) {
  const ok =
    /^[a-f0-9]{32}$/.test(p.room) &&
    /^(command|snapshot|receipt|gps)$/.test(p.kind) &&
    /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(p.id) &&
    p.issued > 0 && p.expires > p.issued && p.expires - p.issued <= RECEIPT_TTL &&
    p.body.length <= 100000 && /^[A-Za-z0-9_-]{16}$/.test(p.nonce) && /^[A-Za-z0-9_-]+$/.test(p.body);
  if (!ok) throw new Error('Invalid envelope');
  const nonceBytes = un64(p.nonce), bodyBytes = un64(p.body);
  if (nonceBytes.length !== 12 || bodyBytes.length < 16 || bodyBytes.length > 65552) {
    throw new Error('Invalid ciphertext');
  }
}

/**
 * Seal a plaintext string into an envelope, exactly mirroring
 * Protocol.seal(root, room, kind, id, now, ttl, plain).
 */
function seal(root, room, kind, packetId, now, ttl, plain) {
  if (ttl <= 0 || ttl > RECEIPT_TTL || utf(plain).length > 65536) throw new Error('Payload too large or expired');
  const nonce = random(12);
  let p = { room, kind, id: packetId, issued: now, expires: now + ttl, nonce: b64(nonce), body: '' };
  const key = derive(root, room, kind);
  const ct = encryptGcm(key, nonce, utf(header(p)), utf(plain));
  p = { room, kind, id: packetId, issued: now, expires: now + ttl, nonce: p.nonce, body: b64(ct) };
  structure(p);
  return p;
}

/**
 * Open (decrypt+authenticate) an envelope, exactly mirroring
 * Protocol.open(root, room, kind, packet).
 */
function open(root, room, kind, p) {
  structure(p);
  if (room !== p.room || kind !== p.kind) throw new Error('Wrong channel');
  const key = derive(root, room, kind);
  const nonce = un64(p.nonce), ct = un64(p.body);
  return text(decryptGcm(key, nonce, utf(header(p)), ct));
}

function fresh(p, now, maxTtl) {
  structure(p);
  if (p.issued > now + 30000 || p.expires < now || p.expires - p.issued > maxTtl) {
    throw new Error('Expired or future envelope');
  }
}

function fingerprint(p) {
  structure(p);
  return hash(header(p) + '\n' + p.nonce + '\n' + p.body);
}

// --- DriverClient.java's encode()/decode() (JSON <-> Packet) ---

function encode(p) {
  return { v: 1, room: p.room, kind: p.kind, id: p.id, issued: p.issued, expires: p.expires, nonce: p.nonce, body: p.body };
}

function decode(e) {
  if (!e || typeof e !== 'object' || Array.isArray(e)) throw new Error('Wrong envelope');
  const keys = Object.keys(e);
  if (keys.length !== 8 || e.v !== 1) throw new Error('Wrong envelope');
  const wholeStr = (v, max) => { if (typeof v !== 'string' || v.length > max) throw new Error('Invalid text'); return v; };
  const p = {
    room: wholeStr(e.room, 32),
    kind: wholeStr(e.kind, 8),
    id: wholeStr(e.id, 36),
    issued: e.issued,
    expires: e.expires,
    nonce: wholeStr(e.nonce, 16),
    body: wholeStr(e.body, 100000),
  };
  if (!Number.isInteger(p.issued) || p.issued < 1) throw new Error('Invalid whole number');
  if (!Number.isInteger(p.expires) || p.expires < 1) throw new Error('Invalid whole number');
  structure(p);
  return p;
}

module.exports = {
  COMMAND_TTL, GPS_TTL, SNAPSHOT_TTL, RECEIPT_TTL,
  b64, un64, utf, text, random, mac, derive, hash,
  id, header, structure, seal, open, fresh, fingerprint,
  encode, decode,
};
