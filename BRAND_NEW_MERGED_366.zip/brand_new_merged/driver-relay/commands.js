'use strict';

/*
 * Server-side mirror of the Driver APK's OWN client-side action validation
 * (DriverClient.java's validAction()), plus the translation from a
 * validated app command into rocket-dispatch's engine (src/engine.js's own
 * text-command language, via handleDriverMessage() - the engine itself is
 * never reached into directly, and is left completely untouched by this
 * integration).
 *
 * Every check the app already does client-side (rev match, driver enabled,
 * valid ETA minutes, valid HELP reason, state preconditions like "must be
 * ASSIGNED before HERE") is checked AGAIN here, server-side. This isn't
 * redundant: a client-side check only stops an honest, unmodified app: it
 * does nothing about a malformed, replayed, or hand-crafted envelope
 * arriving at the relay boundary, which is exactly the seam this
 * integration sits on. Same defense-in-depth principle already used
 * elsewhere in this project (e.g. src/locationConversation.js's server-side
 * postcode/service-area checks, not just trusting what a customer's app or
 * SMS client might claim).
 */

const { toRocketOrderId } = require('./orderIds');

const ETA_MINUTES = new Set([5, 10, 15, 30]);
const HELP_REASONS = new Set(['CANNOT_FIND', 'PAYMENT_PROBLEM', 'DELIVERY_CHECK', 'OTHER']);
const SHIFT_MODES = new Set(['CAR', 'FOOT', 'BREAK', 'OFF']);
const APP_ORDER_ID_RE = /^A\d{4}$/;

class CommandError extends Error {}

/**
 * Validate a decoded app command (the plaintext JSON body of a 'command'
 * envelope - see driver-relay/protocol.js). Throws CommandError, with a
 * message in the same voice DriverClient.java itself would produce, on
 * anything invalid - a malformed or tampered command gets the same "no"
 * whether it's stopped by the app or by this.
 */
function validateCommand(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new CommandError('Malformed command');
  const action = typeof input.action === 'string' ? input.action : '';

  if (action === 'SHIFT') {
    const mode = typeof input.mode === 'string' ? input.mode : '';
    if (!SHIFT_MODES.has(mode)) throw new CommandError('Invalid shift');
    return { action, mode };
  }

  const orderId = typeof input.orderId === 'string' ? input.orderId : '';
  if (!APP_ORDER_ID_RE.test(orderId)) throw new CommandError('Invalid order id');
  const expectedRev = input.expectedRev;
  if (!Number.isInteger(expectedRev) || expectedRev < 1 || expectedRev > 1000000000) {
    throw new CommandError('Invalid whole number');
  }

  switch (action) {
    case 'ACCEPT':
    case 'HERE':
      return { action, orderId, expectedRev };

    case 'COMPLETE': {
      const collectedPence = input.collectedPence;
      if (!Number.isInteger(collectedPence) || collectedPence < 0 || collectedPence > 100000000) {
        throw new CommandError('Invalid whole number');
      }
      const checksConfirmed = input.checksConfirmed === true;
      return { action, orderId, expectedRev, collectedPence, checksConfirmed };
    }

    case 'ETA': {
      const minutes = input.minutes;
      if (!ETA_MINUTES.has(minutes)) throw new CommandError('Choose an ETA button');
      return { action, orderId, expectedRev, minutes };
    }

    case 'HELP': {
      const reason = typeof input.reason === 'string' ? input.reason : '';
      if (!HELP_REASONS.has(reason)) throw new CommandError('Choose a help reason');
      return { action, orderId, expectedRev, reason };
    }

    default:
      throw new CommandError('Unsupported driver action');
  }
}

function applyText(engine, driverId, text) {
  return engine.handleDriverMessage(driverId, text);
}

/**
 * Apply a validated command (validateCommand()'s output) against the
 * engine for one driver.
 *
 * @param {object} engine - a src/engine.js Engine instance
 * @param {string} driverId
 * @param {object} cmd
 * @param {{ currentRev: (rocketOrderId: string) => number|null }} revTracker
 *   see driver-relay/revTracker.js
 * @returns {{ ok: boolean, message: string }}
 *   Deliberately its own short, fixed message per outcome rather than
 *   whatever text src/engine.js happened to queue for the driver's Signal
 *   channel (see driver-relay/README.md's gap list for why those two
 *   message surfaces are intentionally not the same one) - ok/message here
 *   is exactly what goes into the receipt sent back to the app.
 */
function applyCommand(engine, driverId, cmd, revTracker) {
  const driver = engine.state.drivers[driverId];
  if (!driver) throw new CommandError('Unknown driver');

  if (cmd.action === 'SHIFT') return applyShift(engine, driver, cmd.mode);

  const rocketOrderId = toRocketOrderId(cmd.orderId);

  // Defense-in-depth rev check, mirroring the app's own client-side gate
  // (DriverClient.java: "rev!=j.getLong('rev')" -> "Job changed; refresh
  // first"). revTracker is owned by adapter.js (one per driver).
  const currentRev = revTracker.currentRev(rocketOrderId);
  if (currentRev == null) throw new CommandError('Job is no longer assigned or offered to this driver');
  if (currentRev !== cmd.expectedRev) throw new CommandError('Job changed; refresh first');

  switch (cmd.action) {
    case 'ACCEPT': {
      const r = applyText(engine, driverId, `ACCEPT ${rocketOrderId}`);
      return { ok: !!r.ok, message: r.ok ? (r.duplicate ? 'Already accepted.' : 'Accepted.') : 'Offer no longer available.' };
    }
    case 'HERE': {
      const r = applyText(engine, driverId, `HERE ${rocketOrderId}`);
      return { ok: !!r.ok, message: r.ok ? 'Marked arrived.' : 'Job must be assigned before arrival.' };
    }
    case 'ETA': {
      const r = applyText(engine, driverId, `EN ROUTE ${rocketOrderId} ${cmd.minutes}`);
      return { ok: !!r.ok, message: r.ok ? `ETA sent: ${cmd.minutes} minutes.` : 'Could not send ETA.' };
    }
    case 'COMPLETE': {
      // collectedPence is already capped at cashDuePence by the app's own
      // client-side check before it ever seals the envelope, but this side
      // never relies on that alone - src/engine.js's own _complete() does
      // its own accounting (a debt is recorded for any shortfall, an
      // overpayment is flagged for review) independent of what this layer
      // sends it, exactly like every other driver-facing entry point in
      // this project.
      const pounds = (cmd.collectedPence / 100).toFixed(2);
      const r = applyText(engine, driverId, `COMPLETE ${rocketOrderId} PAID ${pounds}`);
      return { ok: !!r.ok, message: r.ok ? (r.duplicate ? 'Already completed.' : 'Completed.') : 'Mark arrival before completion.' };
    }
    case 'HELP': {
      const r = applyText(engine, driverId, `PROBLEM ${cmd.reason} ${rocketOrderId}`);
      return { ok: !!r.ok, message: r.ok ? 'Help request sent to dispatch.' : 'Could not send help request.' };
    }
    default:
      throw new CommandError('Unsupported driver action');
  }
}

function applyShift(engine, driver, mode) {
  if (mode === 'OFF') {
    if (driver.status === 'OFF') return { ok: true, message: 'Already off shift.' };
    const r = applyText(engine, driver.id, 'OFF');
    return { ok: !!r.ok, message: r.ok ? 'Off shift.' : 'Finish the active job before going off shift.' };
  }
  if (mode === 'BREAK') {
    // The engine now has a real BREAK status (see src/engine.js's
    // handleDriverMessage) - a driver on BREAK receives no new offers,
    // same as OFF, but is reported to the app/Boss as BREAK rather than
    // OFF, and going back ON (SHIFT CAR/FOOT) resumes from it directly.
    if (driver.status === 'BREAK') return { ok: true, message: 'Already on break.' };
    const r = applyText(engine, driver.id, 'BREAK');
    return { ok: !!r.ok, message: r.ok ? 'On break.' : 'Finish the active job before going on break.' };
  }
  // CAR or FOOT: come on duty first if necessary (this also re-triggers
  // the engine's own _offerWaitingOrders(), same as a driver texting ON
  // themselves), then set/confirm the mode - two engine calls, because the
  // engine's own command language doesn't combine "come on duty" and "set
  // mode" into a single command the way the app's one SHIFT action does.
  if (!driver.onDuty) {
    const onResult = applyText(engine, driver.id, 'ON');
    if (!onResult.ok) return { ok: false, message: 'Could not start shift.' };
  }
  const modeResult = applyText(engine, driver.id, mode);
  return { ok: !!modeResult.ok, message: modeResult.ok ? `On shift (${mode}).` : 'Could not set shift mode.' };
}

module.exports = { CommandError, validateCommand, applyCommand };
