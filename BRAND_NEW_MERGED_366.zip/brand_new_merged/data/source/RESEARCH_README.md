# Rocket Dispatch location research — 23 September 2026

## Release status: populated research pack, NOT exhaustive or production-approved

This ZIP contains real CSV and JSON records, not templates. The complete four-district extraction of the **August 2026 ONS Postcode Directory hosted snapshot** contains 2,672 active and 1,222 terminated postcodes. This is completeness against that snapshot, not certification against today's Royal Mail PAF. Changes after the snapshot remain possible.

Venue coverage is a substantial but incomplete research inventory. Search saturation has **not** been established. Most newly collected businesses have not been individually cross-checked for trading status. Do not load the entire pack into automatic dispatch as though every record were an open business and a verified entrance.

## Files

Each numbered dataset has CSV and JSON versions. CSV array/object cells contain JSON; empty scalar cells mean unknown, not zero. JSON preserves nulls and typed arrays.

1. `01_postcodes`: active and terminated postcodes, coordinates, sectors, introduction/termination dates, official geographical codes and sources.
2. `02_venues`: named places, sourced addresses, coordinates where available, status and quality flags.
3. `03_aliases`: evidence-backed alternatives versus explicitly inferred matching variants. Canonical names are not counted as aliases.
4. `04_local_language`: regional evidence and separately labelled illustrative resolver patterns.
5. `05_ambiguities`: candidate IDs, names, towns and postcodes. Sets are not necessarily exhaustive.
6. `06_former_closed_locations`: former names and demolished landmarks, separate from active status.
7. `07_manual_review_queue`: missing fields, source disagreements, ambiguity and coverage gaps.
8. `08_localities`: address-supported localities and retained BS49 geographical notes, not boundary polygons.

`rocket_lookup.json` and `rocket_language.json` are compact integration records. Each district folder has its postcode and venue JSON plus a report. `coverage.json` holds calculated totals. `validation.json` records structural checks. `OVERALL_REPORT.md` includes counts, limitations and resolver recommendations. `conversation_tests.json` supplies illustrative multi-message acceptance cases, not genuine customer messages.

## Source and field interpretation

- ONSPD source: https://services1.arcgis.com/ESMARspQHYMw9BZ9/arcgis/rest/services/ONS_Postcode_Directory_(August_2026)_(Hosted_Table)/FeatureServer/0 . All pages were collected independently for each district and checked against the server's count query. `doterm` absent means active in this snapshot. Coordinates are postcode reference points, **not meeting points**. Special/non-geographic sectors are not silently removed.
- FSA source: https://api.ratings.food.gov.uk/Establishments?localAuthorityId=327 . All 1,722 North Somerset register records were retrieved over four pages, then filtered to the four full outward codes. Mobile caterers, caring premises, outward-only/private-address listings and most private catering records were excluded. Individual place records link to their public FHRS entries. An inspection date is not proof of current trading.
- Council, operator, sports/community and historical sources are recorded per venue/alias. Some earlier BS49 records retain their previous status assessment; quality flags still require entrance checks.
- Schools are geographical landmarks only. Catering operators are removed from names where the source clearly identifies the school. Some co-located school/caterer duplicates remain possible and need review.
- `town` is an address locality, not necessarily the Royal Mail post town. FSA address labels can themselves be inconsistent. No “postcode district equals main town” shortcut was used. **The postcode table's town/locality/street fields are currently null** because ONSPD does not provide them and a reliable complete street enrichment was not obtained. Parish/ward/built-up-area codes are retained for later official joins.
- No unknown venue coordinate is replaced by a postcode centroid. FSA geocodes and council points are source-supplied positions, not certified entrances. Null coordinates require a pin or manual verification.
- HIGH is reserved for selected cross-checked records. MEDIUM often means existence/address evidence but not verified current opening. UNCERTAIN is not synonymous with CLOSED.
- “Confirmed aliases” includes official alternatives and former names; it does not mean every alias is a local nickname. Inferred variants have no claim of observed local frequency. The language file is mostly synthetic test language. One public Bristol discussion supports “where you to”; it does not establish prevalence across every Rocket town.

## Known source disagreements / caution

Retained BS49 issues include Claverham Village Hall, Cleeve Village Hall, Cleeve Cricket Club and Yatton Rugby Club postcode differences. Congresbury Old School Rooms appears under differing postcodes and map points in two council directories. Salthouse Fields council parking postcode differs from the Marine Lake parking advice postcode. Grove and Ring O' Bells share a postcode but are separate venues. Royal Oak exists in Nailsea and Clevedon. Schools sharing a postcode are not automatically merged.

Portishead and Pill railway stations are **not included as operational passenger stations**. Network Rail describes construction, not an open service: https://www.networkrail.co.uk/our-work/our-routes/western/the-portishead-line/ . A customer saying “station” there needs clarification, not routing to a supposedly open station.

## Licensing and privacy

Keep source attribution when reusing records. ONSPD includes third-party Ordnance Survey/Royal Mail rights; consult the release's licensing terms before redistribution or commercial deployment. FSA open-data terms apply to FSA-derived records. Website facts do not transfer rights to wholesale website content. No private phone numbers, usernames, pupil/staff details or customer conversations are included. No credentials or live Rocket configuration are included.

This is an offline research deliverable. No live Tasker, VPS, phone, messaging or order data was altered.
