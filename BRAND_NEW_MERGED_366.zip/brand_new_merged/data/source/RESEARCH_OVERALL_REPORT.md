# Overall Rocket coverage report

Research release: 23 September 2026. **Not exhaustive; not production-approved.**

| District | Active postcodes | Terminated | Active sectors | Places |
|---|---:|---:|---:|---:|
| BS48 | 771 | 252 | 5 | 143 |
| BS49 | 346 | 80 | 2 | 119 |
| BS21 | 695 | 259 | 4 | 136 |
| BS20 | 860 | 631 | 5 | 163 |

Total: 2672 active postcodes, 1222 terminated, 561 venue/landmark records.
Aliases: 21 evidence-backed alternatives (including former names; only 3 explicitly classified local nicknames), 635 inferred search variants. Canonical names are excluded from alias totals.
Language: 67 phrases, predominantly illustrative test patterns rather than observed local SMS. Ambiguities: 41. Former/closed records: 8. Review queue: 623 rows.

## Places by town/locality

| Town/locality | Records |
|---|---:|
| Backwell | 26 |
| Barrow Gurney | 4 |
| Clapton-in-Gordano | 1 |
| Claverham | 6 |
| Cleeve | 17 |
| Clevedon | 127 |
| Congresbury | 52 |
| Easton-in-Gordano | 7 |
| Failand | 1 |
| Felton | 14 |
| Flax Bourton | 3 |
| Ham Green | 2 |
| Kenn | 1 |
| Kingston Seymour | 4 |
| Lulsgate Bottom | 1 |
| Nailsea | 81 |
| Pill | 22 |
| Portbury | 8 |
| Portishead | 108 |
| Tickenham | 3 |
| UNRESOLVED | 15 |
| Walton-in-Gordano | 1 |
| Weston-in-Gordano | 1 |
| Wraxall | 11 |
| Yatton | 45 |

These locality labels follow source addresses, which can straddle postal/administrative boundaries. Cleeve appears in a BS48 address, and Wraxall in a BS20 address; these are boundary/address-review cases, not proof that entire settlements belong to those districts. Failand and airport-related Felton addresses must not be blanket-mapped to one district.

## Places by category

| Category | Records |
|---|---:|
| pub | 67 |
| food | 178 |
| sports | 44 |
| community | 96 |
| retail | 112 |
| transport | 20 |
| hotel | 6 |
| outdoor | 28 |
| business | 9 |
| historic | 1 |

## Status and coordinates

{'ACTIVE': 75, 'UNCERTAIN': 485, 'DEMOLISHED': 1}
382 records have source-supplied coordinates. These have not been certified as customer-accessible entrances. Every venue has at least an entrance/coordinate review flag; no automated-dispatch readiness is implied.

## Ambiguity and duplicate names

- car park: Clevedon, Congresbury, Nailsea, Portishead, Yatton
- club: Backwell, Barrow Gurney, Clapton-in-Gordano, Claverham, Cleeve, Clevedon, Congresbury, Easton-in-Gordano, Felton, Nailsea, Pill, Portbury, Portishead, Weston-in-Gordano, Wraxall, Yatton
- co op: Nailsea, Pill, Portishead, Yatton
- coffee 1: Clevedon, Nailsea, Portishead
- coop: Nailsea, Pill, Portishead, Yatton
- cricket club: Barrow Gurney, Cleeve, Clevedon, Congresbury, Easton-in-Gordano, Portishead, Yatton
- dominos pizza: Clevedon, Nailsea, Portishead
- football: Backwell, Claverham, Clevedon, Congresbury, Easton-in-Gordano, Nailsea, Portishead, Yatton
- football club: Backwell, Claverham, Clevedon, Congresbury, Easton-in-Gordano, Nailsea, Portishead, Yatton
- greggs: Clevedon, Nailsea, Portishead
- iceland foods ltd: Nailsea, Portishead
- leisure centre: Backwell, Clevedon, Nailsea, Portishead
- lidl: Clevedon, Portishead
- main car park: Clevedon, Congresbury, Nailsea, Portishead, Yatton
- parsons bakery ltd: Backwell, Clevedon, Nailsea, Portishead
- plough inn: Congresbury, Portishead
- pub: Backwell, Barrow Gurney, Clapton-in-Gordano, Claverham, Cleeve, Clevedon, Congresbury, Easton-in-Gordano, Felton, Nailsea, Pill, Portbury, Portishead, Weston-in-Gordano, Yatton
- pullins bakers limited: Clevedon, Yatton
- rec: Claverham, Cleeve, Congresbury, Nailsea, Yatton
- royal oak: Clevedon, Nailsea
- rugby club: Clevedon, Nailsea, Yatton
- sainsburys: Clevedon, Portishead
- seafront: Clevedon, Portbury
- southern co operative: Nailsea, Pill, Portishead
- spoons: Nailsea, Portishead
- station: Backwell, Yatton
- subway: Portishead, Wraxall
- tesco: Clevedon, Nailsea
- the rec: Claverham, Cleeve, Congresbury, Nailsea, Yatton
- triangle: Clevedon, Portishead
- village hall: Backwell, Barrow Gurney, Claverham, Cleeve, Kingston Seymour, Portbury, Tickenham, Walton-in-Gordano, Wraxall, Yatton
- waitrose: Nailsea, Portishead
- weatherspoons: Nailsea, Portishead
- wetherspoons: Nailsea, Portishead

See `05_ambiguities` for all candidate IDs; this is not just a list of words. Generic terms remain open-ended. In particular “main car park” has no verified unique referent and must not choose the first car park in the array. “High street” requires town plus an actual meeting point; it is not a single venue. “Grove” may overlap sports and school names.

## Former/closed names retained

- Glass House → The Glassmaker (RENAMED)
- Queen's Head → Coates House (RENAMED)
- Drum & Monkey → Disati (RENAMED)
- Ship & Castle → Congresbury Arms (RENAMED)
- Mezze At The Ship & Castle → Congresbury Arms (RENAMED)
- Railway Inn (historic; collides with the current Station Road Railway Inn) → The Market Inn (RENAMED)
- Railway Hotel → The Railway Inn (RENAMED)
- Lord Nelson, former site → None (DEMOLISHED)

Rename dates and evidence of recent use are mostly unverified. Old names are lookup candidates, not assertions that the old business remains active.

## Coverage gaps — explicit

- ONSPD unit-postcode extraction is complete for the selected snapshot. Every postcode street, settlement and locality is **not** enriched; those fields remain null. A postcode resolves only to its reference point, not an address or entrance.
- Non-food shops, pharmacies, gyms, churches, bus stops, taxi ranks, footpath entrances, housing estates and minor rural localities remain unevenly covered. Sparse rural counts are not evidence of no other venues.
- No complete OSM/NaPTAN extraction was obtained. OSM request and street-enrichment access failed; no missing data was fabricated.
- Current status is not cross-checked for every business. The food register gives broad coverage but excludes non-food-only venues by design.
- Searches still yielded additional places. Saturation was not reached, so this release cannot honestly be described as the requested complete geographical database.
- Generic language is test coverage, not a corpus of real local SMS. Nicknames and former-name usage need ongoing public/local verification.

## Resolver recommendations

1. Preserve raw messages; derive a separate Unicode/case/punctuation-normalised matching key. Collapse spaces, normalise apostrophes and ampersands. Drop a leading “the” only in an alternate lookup key, not globally inside names.
2. Recognise a full postcode with optional internal space, uppercase it, then require an exact match in the active postcode index. Keep terminated matches separate and ask for confirmation. Do not treat BS48 XXX as valid.
3. Rank exact canonical or evidenced alias + current explicit town above inferred variants. Never automatically accept a fuzzy match simply because one candidate is nearer. Retain all candidates for a shared alias.
4. A customer/order town is useful context, not evidence that a venue is in that town. Current explicit corrections override older context. Conflicting postcode and venue evidence triggers a question.
5. Store pending town and venue tokens across consecutive messages in the same customer/order conversation. Use a bounded context lifetime and clear it at order completion/cancellation. Never merge different customers or orders.
6. Classify ETA and arrival separately. “im 10 mins” and “here now” must preserve an already confirmed location. Bare “im 10” and “you about” remain ambiguous unless context establishes the intended meaning.
7. Ask one focused question: town first for cross-town ambiguity, then ground/branch/entrance. Ask for a full postcode or map pin when town plus venue still leaves multiple candidates or when coordinate/address evidence is missing.
8. A supplied pin is independent location evidence. Check coverage using a proper geographic boundary or validated reverse lookup; a broad rectangular box or nearest postcode cannot prove service eligibility. Do not silently relocate a pin.
9. Parks, marinas, seafronts and school/club complexes need an entrance or landmark. A whole marina is not a pinpoint meeting point. Do not route to restricted airside sites or construction areas.
10. Keep versioned source dates, status review and alias provenance. Update postcode snapshots and recheck changed/closed venues; test offline before any Rocket integration.

## Reproducibility and validation

All seven required datasets are populated in both CSV and JSON. Structural checks cover unique IDs, alias references, postcode district prefixes, nonempty datasets and ONS query count equality. These checks detect packaging/schema errors, not real-world completeness. The ZIP has a SHA-256 manifest and is tested after creation. No live deployment is part of this work.
