# Rocket Dispatch — Road / Alley Layer Integration

**Status: OFFLINE ONLY. Not deployed.** Nothing in this change has touched
the live VPS, Tasker, phones, or sent an SMS. It is source code and data
files in this workspace, exactly as instructed: *"Stop after the offline
build and tests so I can review it before anything goes near the VPS."*

This wires the previously-delivered OSM road/alley datasets
(`Rocket_OSM_Road_Database_BS20_BS21_BS48_BS49.zip`, 1,694 roads + 1,873
alleys/footways) into the **existing** location resolver as a genuinely new
capability: Rocket can now recognise a road or alley name on its own — with
no postcode and no known venue — and resolve it to a real coordinate.

---

## 1. Exactly which files changed

### New files
| File | What it is |
|---|---|
| `src/roadIndex.js` | New module. Loads the road/alley layer and builds startup indexes (normalised name, alias, first-word bucket for fast lookup, postcode district). No linear scan of the whole dataset per SMS — see §6 Performance. |
| `data/roads.json` | Trimmed runtime copy of `rocket_roads_master.json` (1,694 records) + all alias rows, no geometry (not needed for text matching or a single nav coordinate). |
| `data/alleys.json` | Same, for the 1,873 alley/footway records, plus `anchor_strength` per record (see §4). |
| `test/roadAlleyIntegration.test.js` | 28 new automated tests (§5). |
| `CHANGELOG_ROAD_ALLEY_INTEGRATION.md` | This file. |

### Modified files
| File | What changed |
|---|---|
| `src/locationConversation.js` | The core change. `handle()` now tries road/alias matching (via `this.index.roadIndex`, if attached) after postcode and venue matching have both found nothing for the message. New `_resolveRoad()` method mirrors the existing `_resolve()` (venue) method's shape — same outcome types (`RESOLVED`/`CONFIRM`/`ASK_TOWN`/`ASK_WHICH`/`NOT_IN_TOWN`), so `engine.js` needed no new switch cases. New `roadLocation()` helper builds the result object. `emptyState()` gained one new field, `pendingRoad` (parallel to the existing `pending`, for a road/alley clarification waiting on a town). |
| `src/engine.js` | `_placeLabel()` gained a case for `loc.type === 'road' \| 'alley'` (was falling through to the `'shared location pin'` default before). No other change — `_navLink()`, `_maybeAutoGpsEvents()`, GPS auto-messaging, `_confirm()`, `_cancel()` all already work generically off `lat`/`lng`/`exactPointKnown`, unchanged. |
| `server/index.js` | Loads `data/roads.json` + `data/alleys.json` if present and attaches `index.roadIndex = new RoadIndex(...)`. Wrapped in `fs.existsSync(...)` — an install without these two files starts exactly as before, with no road/alley matching at all. |

### Explicitly NOT changed
- `data/locations.json` — the existing postcode/venue database. Untouched, not rebuilt, not merged with the road/alley data. `src/locationIndex.js` (venue/postcode matching) is unmodified.
- Every existing test file (`engine.test.js`, `locationConversation.test.js`, `locationResolverHardening.test.js`, `fullSystem.e2e.test.js`, etc.) — unmodified, and all still pass (§5).
- Nothing on the VPS, Tasker, phones, Signal, or SMS.

---

## 2. How matching priority works

Implemented exactly as specified, in this order, inside `LocationConversation.handle()`:

1. **Exact full postcode** — unchanged, existing code, checked first. A road name riding along with a full postcode in the same message still works exactly as before (as a text label only, via the pre-existing `STREET_RE`/`findStreet` mechanism) — the postcode's own coordinate wins, the road never overrides it.
2. **Existing exact venue** — unchanged, existing `findVenue()` runs next. A **genuine** venue match (a real canonical name or a confirmed alias) always wins outright; road/alias matching is never even attempted in that case.
3. **Exact road name** (+ town/postcode context)
4. **Exact road alias** (+ context) — abbreviations (`rd`/`st`/`ave`/…), concatenated forms, locality-suffixed forms
5. **Exact alley/path name** (+ context) — real OSM-named paths first, then generated labels (see §4)
6. **Normalised-but-exact match** — case, punctuation, apostrophes, hyphens, extra spaces are all folded by the existing `normalise()` function, reused for the road/alias index too. This project does **not** do fuzzy/misspelling matching anywhere, for venues or for roads — see §5's misspelling test. A genuinely misspelled road name safely returns `NOT_FOUND`/`NONE`, never a guessed match.
7. **Multiple candidates → clarification required** — `ASK_TOWN` (several localities) or `ASK_WHICH` (several distinct roads in the same locality), reusing the exact same outcome types and message templates the venue path already uses.

**One deliberate refinement beyond a literal ranking of 1–7**: a "venue match" that is only a *generic ambiguity term* (e.g. the word **"station"**, which every railway-adjacent venue in the dataset is indexed under) is not treated as a real venue match for this purpose. If the message also contains a longer, more specific road/alias phrase — **"station road"**, or **"station road yatton"** — the road wins, because it is stronger, more specific evidence than a bare ambiguity word. A **genuine** venue name (canonical or confirmed alias) is never second-guessed this way; see the before/after example in §3 and the dedicated test *"a genuine strong venue-name match is never second-guessed…"*.

Road matching only ever runs when `this.index.roadIndex` is attached. Every existing test and (until someone runs the loader change) the current production install constructs a plain `LocationIndex` with nothing attached, so this is a fully additive, opt-in layer.

---

## 3. Before / after examples (real output, same message, same underlying `data/locations.json`)

```
MSG: "kenn road"
  BEFORE: TOWN_ONLY  (town="Kenn" recognised, but no place - asks for the order/postcode)
  AFTER:  RESOLVED   -> Kenn Road, Clevedon (BS21 5BY), exactPointKnown:false

MSG: "weston road"
  BEFORE: CONFIRM    -> guesses "Sporting Weston Football Club" (a weak PARTIAL
                         single-word match on "weston" - exactly the kind of
                         fuzzy guess this integration was asked to avoid)
  AFTER:  ASK_TOWN    -> ["Long Ashton", "Failand", "Congresbury"] - the three
                         real, distinct Weston Roads - no guess at all

MSG: "station road yatton"
  BEFORE: ASK_WHICH   -> offers "Yatton railway station" / "Yatton station car
                         park" (matched the generic word "station", ignoring
                         "road yatton" entirely)
  AFTER:  RESOLVED    -> Station Road, Yatton (BS49 4FF)

MSG: "moor lane"
  BEFORE: CONFIRM     -> guesses "Yeo Moor Primary School" (weak PARTIAL match
                         on "moor")
  AFTER:  ASK_TOWN    -> the 6 real, distinct Moor Lanes - no guess
```

The "before" behaviour above is not a bug introduced by this change — it is
the existing, already-shipped `allowPartial` single-word venue fallback,
included here to show that the road layer often makes Rocket **more**
cautious, not less: several of these previously-silent-ish guesses now
correctly turn into an honest "which town?" question instead.

---

## 4. Alley/footway confidence gating

`data/alleys.json` carries an `anchor_strength` field per record, computed
during the offline OSM build:

| `anchor_strength` | Meaning | Resolver behaviour |
|---|---|---|
| `named` | OSM itself had a real name for the path | Resolves like a road (`RESOLVED` if unique + context-valid) |
| `road_pair` | Generated label anchored to a named road at **both** ends (e.g. "Footpath: Stock Way South to High Street") | Resolves like a road |
| `road_locality` | Anchored to one named road + a locality | Resolves like a road |
| `locality_only` / `district_only` | Weakest — generated label has no nearby named road to anchor to at all | **Always asks for confirmation** (`CONFIRM`), never auto-resolves |

This is implemented in `_resolveRoad()` and is deliberately more cautious
than the road layer, because a `locality_only`/`district_only` label is
Rocket's own construction, not something OSM or a resident ever called that
path — see `data/alleys.json`'s `_provenance` note and the original
`Rocket_OSM_Road_Database...` README for the full explanation.

---

## 5. Test results

**181 / 181 passing**, three consecutive full clean runs (`node --test
test/*.js`), zero failures, zero flakes observed in this session. Breakdown:
- **153** pre-existing tests, run completely unmodified — proves no
  regression to venue/postcode matching, GPS automation, Signal/driver
  flows, Boss app, or anything else already shipped.
- **28** new tests in `test/roadAlleyIntegration.test.js`, covering:
  - All 12 named roads from the brief (Weston Road, Kenn Road, Nailsea
    Wall, Backwell Bow, Claverham Drove, Old Church Road, Newfoundland Way,
    Harbour Road, Station Road, High Street, Moor Lane, The Avenue) —
    single-locality ones resolve directly, multi-locality ones correctly
    ask which town rather than guessing
  - Abbreviation matching (`kenn rd` == `kenn road`)
  - Filler-word tolerance (`on weston road`)
  - Road-name collisions kept separate (`station road` bare → asks;
    `station road yatton` → resolves Yatton specifically)
  - The "station" vs "station road" generic-ambiguity-term override, and
    the converse proof that a **genuine** strong venue match is never
    second-guessed
  - Road name + full postcode (postcode wins, road rides along as a label)
  - Road name + bare postcode district, narrowing an ambiguous road
  - Context carried across messages (asked once, not repeated)
  - Wrong town for a real road → `NOT_IN_TOWN`, not a guess
  - Unknown road and misspelled road → safely fall through, no fabrication
  - ETA / "here now" after a road match leave the confirmed location alone
  - Bare status words (`yes`/`yeah`/`yh`/`ok`/`no`/`nope`) never
    misinterpreted as a road
  - CANCEL after a road-resolved order still cancels (proves the
    pre-existing engine-level `CANCEL_RE` intercept, which runs before the
    location layer, is untouched)
  - Alley layer: a real OSM-named path resolves; a weakly-anchored
    generated label always asks; a strongly-anchored one can resolve
    (tested at the `_resolveRoad` mechanism level — see the in-file note on
    why a full generated label is not a realistic SMS to test through the
    text search path)
  - Roads always outrank alleys when both could match
  - Backward compatibility: a `LocationIndex` with no `roadIndex` attached
    (i.e. every existing test, and any install that hasn't taken this data
    update) behaves exactly as it did before this change
  - Two end-to-end tests through the real `Engine`/`handleCustomerBurst`
    path: order text + a road name reaches `CONFIRMED` state with the road
    name in the customer-facing text, and the driver offer still carries
    the "postcode/area only" note (`exactPointKnown: false`)

Run it yourself: `node --test test/*.js` from the project root (no
`package.json`/`npm install` needed — this project uses Node's built-in
test runner directly, same as every existing test file).

---

## 6. Performance

Indexes are built once at `RoadIndex` construction (server startup), not
per message. A naive full scan of the ~13,000 combined road+alias+alley
phrase entries measured **~0.78ms per lookup**. A first-word bucket index
(`roadFirstWord`/`alleyFirstWord` maps in `src/roadIndex.js`) was added so a
lookup only scans phrases that start with a word actually present in the
message, bringing that down to **~0.007ms per lookup** (measured, see the
module's inline benchmark comment) — roughly 115x, and nowhere near a
per-SMS bottleneck at Rocket's message volumes.

---

## 7. Ambiguous / risky areas — read before trusting this beyond testing

1. **Locality labels don't always match how people actually refer to a
   place.** The alley/road locality field is a *nearest-point* OSM
   settlement label, not an administrative boundary (this limitation was
   already flagged in the original road/alley delivery's README). Concrete
   example found while testing: **"station rd backwell"** does not resolve
   — the road serving Nailsea & Backwell railway station is spatially
   labelled `West Town` (a real hamlet between the two), not `Backwell`, so
   a customer naming the parish rather than the OSM locality gets
   `NOT_IN_TOWN` instead of a match. This is an honest data-labelling gap,
   not a matching bug — the underlying road/postcode data is correct, only
   the locality *label* doesn't match colloquial usage. A locality alias
   table (e.g. "Backwell" also covers "West Town") could close this, but
   was not built here — it wasn't part of the road/alley data delivered,
   and inventing one would mean guessing which OSM localities map to which
   colloquial town names without evidence.

2. **"High Street, Clevedon" does not exist in this data — and, as far as
   I can establish, does not exist in reality either**: Clevedon's real
   high street is officially named **Hill Road**. `high st clevedon`
   correctly returns `NOT_IN_TOWN` rather than being forced to match
   something. Flagged here in case this is wrong and there is a real,
   separately-named "High Street" in Clevedon the OSM extract missed —
   worth a human glance at `BS21_roads.csv` from the road delivery.

3. **Generated alley labels are not real SMS text.** As covered in §4/§5,
   a `road_pair`/`road_locality` alley's own generated name almost always
   contains a real road's name as a substring (that is how it was built),
   so texting the alley's full label back in will usually match the ROAD
   layer instead, per the stated priority. This is correct behaviour, not
   a bug — but it means the alley layer mostly helps the *data* side
   (geometry, coordinates, a record that a given cut-through exists at
   all) more than it helps live SMS matching for the ~1,777 generated
   labels. The 96 real OSM-named alleys (e.g. "Piggy Lane") work as
   ordinary named-place matching, same as a road.

4. **This still does not implement fuzzy/misspelling matching.** Consistent
   with how the venue side already worked (no edit-distance matching
   anywhere in this codebase), a misspelled road name safely does nothing
   rather than guessing. If Rocket wants "westun rd" to suggest "Weston
   Road", that is a deliberate, separate feature decision — implementing it
   without also touching venue matching would be an inconsistent,
   half-fixed change, so it was left out here.

5. **`postcode_district` narrowing (`weston road bs48`) uses only the
   bare outward code**, not a full postcode sector. It only narrows when
   more than one candidate remains and never forces a result the district
   doesn't actually contain — see the dedicated test — but a genuinely
   ambiguous case within one district (two same-named roads in different
   localities of the same postcode district) would still correctly ask
   rather than guess.

---

## 8. Rollback

Everything here is additive and gated on `this.index.roadIndex` being
attached (only true once `server/index.js` finds `data/roads.json` +
`data/alleys.json` on disk). To roll back completely:
- Delete `data/roads.json` and `data/alleys.json` (or just don't deploy
  them) — `server/index.js`'s `fs.existsSync` check means the server starts
  exactly as before, with zero road/alley matching, no code changes need
  reverting.
- Or, for a full source rollback: revert `src/locationConversation.js`,
  `src/engine.js`, `server/index.js` to their pre-integration versions and
  delete `src/roadIndex.js` + the two data files + the new test file.

No changes here touch `data/locations.json`, `src/locationIndex.js`, order
state persistence format (`pendingRoad` is a new, additively-optional field
in the existing JSON-serialisable conversation state — an order saved
before this change loads fine, `pendingRoad` is just `undefined` until the
next message sets it), or anything already running in production.
