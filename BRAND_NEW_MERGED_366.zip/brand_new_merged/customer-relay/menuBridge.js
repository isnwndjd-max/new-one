'use strict';

/*
 * Converts rocket-dispatch's own minimal synced menu (data/menu.sync.json,
 * already an allowlist projection - see src/menuSync.js's own header
 * comment: code/name/aliases/unitPrice/tiers only, no cost/margin/admin
 * field ever reaches it) into the shape the customer app's
 * POST /api/integration/menu endpoint expects.
 *
 * customerMeta is an OPTIONAL, purely cosmetic lookup ({code: {category,
 * emoji, size}}) for display fields rocket-dispatch's own menu schema has
 * no equivalent of. Nothing in customerMeta can change price or
 * availability - pricePence/active/deal all come only from the rocket-
 * dispatch item itself. See customer-relay/README.md "Known gap: menu
 * display metadata".
 */
function toCustomerMenu(rocketMenu, customerMeta = {}) {
  const items = (rocketMenu && rocketMenu.items) || [];
  return items.map((item) => {
    const meta = customerMeta[item.code] || {};
    const out = {
      code: item.code,
      name: item.name,
      size: meta.size || '',
      category: meta.category || 'Menu',
      emoji: meta.emoji || '📦',
      pricePence: Math.round((item.unitPrice || 0) * 100),
      aliases: Array.isArray(item.aliases) ? item.aliases.slice() : [],
      active: true,
    };
    const tier = (item.tiers || [])[0];
    if (tier) {
      out.deal = {
        qty: tier.qty,
        totalPence: Math.round(tier.price * 100),
        label: `${tier.qty} for £${tier.price.toFixed(2)}`,
      };
    }
    return out;
  });
}

module.exports = { toCustomerMenu };
