'use strict';

/*
 * Turns one pending web order (from the customer app's own
 * GET /api/integration/pending shape) into the plain-text burst
 * rocket-dispatch's engine already knows how to parse - the SAME text
 * language a real SMS customer would type, reused untouched (never a new
 * parser, never a new location code path - see docs/CUSTOMER_APP.md).
 *
 * Item lines use the rocket-dispatch item's own canonical `name`, which is
 * what src/menu.js#parseItems matches against - NOT the customer app's own
 * product name, which may differ before the two menus are back in sync
 * (menuBridge.js is what keeps them in sync). Falls back to the app's own
 * item name only if a code is missing from rocket-dispatch's menu, which
 * itemLinesAndPricing() below treats as a hard reject, not a silent guess.
 */
function itemLines(pendingOrder, rocketMenuByCode) {
  const lines = [];
  const unknown = [];
  for (const it of pendingOrder.items || []) {
    const known = rocketMenuByCode.get(it.code);
    if (!known) { unknown.push(it.code); continue; }
    lines.push(`${it.qty} ${known.name}`);
  }
  return { lines, unknown };
}

/**
 * One location line. Preference order matches the developer prompt's own
 * list: an exact shared pin is the most precise evidence available, then
 * postcode+street (both already tested in src/locationConversation.js),
 * then a venue/landmark name, then whatever free text the app collected.
 */
function locationLine(loc) {
  if (!loc) return '';
  if (loc.pinLat != null && loc.pinLng != null) {
    return `${Number(loc.pinLat).toFixed(6)}, ${Number(loc.pinLng).toFixed(6)}`;
  }
  const parts = [];
  if (loc.postcode) parts.push(loc.postcode);
  if (loc.street) parts.push(loc.street);
  if (parts.length) return parts.join(' ');
  if (loc.venue) return loc.venue;
  return (loc.text || '').trim();
}

module.exports = { itemLines, locationLine };
