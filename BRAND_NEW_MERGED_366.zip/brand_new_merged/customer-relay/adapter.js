'use strict';

/*
 * customer-relay: bridges the (adapted) customer app's own integration API
 * to rocket-dispatch, WITHOUT modifying server/index.js or src/engine.js.
 *
 * Runs as a separate process, like the Signal adapter and Tasker - not
 * in-process with the engine (unlike driver-relay/, which took the engine
 * directly; see driver-relay/README.md's own note that this was an open
 * decision). It talks to rocket-dispatch only through its EXISTING gateway
 * HTTP surface:
 *   - POST /sms/inbound              (X-Gateway-Token)  - same endpoint
 *     Tasker already uses for real SMS. An app order is turned into the
 *     SAME plain-text burst a real texting customer would send, so it goes
 *     through the exact tested parseItems()/LocationConversation code
 *     path, not a second copy of it. See orderText.js.
 *   - GET  /boss/orders, GET /boss/menu   (X-Boss-Token) - the same
 *     internal, trusted-operator surface the Boss app itself uses. A
 *     dispatch adapter is the same trust tier as the Boss app (it needs to
 *     read order state and the customer-safe menu projection), not the
 *     customer's own tier - it never receives a customer session token and
 *     never proxies Boss/Driver data back to the customer app.
 *
 * And to the customer app's own integration surface (X-Rocket-Integration-
 * Key, already implemented in customer-app/server.py, unmodified by this
 * file):
 *   - GET  /api/integration/pending
 *   - POST /api/integration/ack
 *   - POST /api/integration/order-complete
 *   - POST /api/integration/menu
 *
 * Customer phone numbers are used as rocket-dispatch's own `phone` key -
 * deliberately, so "Customer App OR SMS" (the developer prompt's own
 * phrase) is literally true: the engine's existing activeByPhone dedup
 * means a customer already mid-order over SMS can't also get a duplicate
 * order from the app for the same phone, and vice versa.
 */

const { priceOrder } = require('../src/menu');
const { customerStatusFor } = require('./statusMap');
const { toCustomerMenu } = require('./menuBridge');
const { itemLines, locationLine } = require('./orderText');

function createCustomerRelayAdapter({
  rocketDispatchBase,
  gatewayToken,
  bossToken,
  customerAppBase,
  integrationKey,
  customerMenuMeta = {},
  pollIntervalMs = 4000,
  // Must be long enough for rocket-dispatch's own burst window
  // (config.json's burstWindowSeconds, default 6s) PLUS at least one
  // engine tick (default every 2s) to have run. See server/index.js's own
  // tick()/burst.flushReady(). Pad generously rather than race it.
  burstSettleMs = 9000,
  fetchImpl = fetch,
  now = () => Date.now(),
  log = () => {},
}) {
  if (!rocketDispatchBase || !gatewayToken || !bossToken) throw new Error('rocketDispatchBase/gatewayToken/bossToken required');
  if (!customerAppBase || !integrationKey) throw new Error('customerAppBase/integrationKey required');

  // webOrderId -> { phone, sentAt, attempts }. In-memory only: once the
  // engine actually creates the order, the mapping lives durably in the
  // customer app's own `rocket_order_id` column (server.py already has
  // this), and /api/integration/pending stops returning it (its query is
  // `status='PENDING_DISPATCH'`, which the ack call below always changes).
  // Losing this map on restart just means an in-flight order gets
  // re-scanned, not duplicated - see "Restart / recovery" in README.md.
  const awaitingCreation = new Map();
  // webOrderId -> last customer-safe status already ack'd, so we only call
  // the app back when something actually changed.
  const lastAcked = new Map();
  // rocket-dispatch order id -> true, once its points have been synced to
  // the app via pointsSyncSmsOnly() below. Advisory only (saves a redundant
  // network call on the next poll) - the app's own unique index on
  // (phone, externalRef) is what actually prevents a double-credit if this
  // in-memory set is lost on restart. See CHANGELOG_POINTS_UNIFICATION.md.
  const pointsSynced = new Set();
  // Every rocket-dispatch order id EVER seen mapped to an app order, across
  // all polls - accumulates, never shrinks. Needed because
  // /api/integration/mappings only returns orders that are still active
  // (not COMPLETE/CANCELLED/REJECTED) - once an app order completes, it
  // drops out of that list on the very next poll. A per-poll snapshot of
  // "currently mapped" would then wrongly treat that (already-credited-via-
  // order-complete) order as a pure-SMS order with no mapping at all, and
  // double-credit it. Accumulating instead means it stays excluded forever
  // once seen, which is correct: an order that started in the app can
  // never retroactively become a pure-SMS order.
  const appOrderRocketIds = new Set();
  let stopped = false;
  let timer = null;

  async function rd(path, opts = {}) {
    const r = await fetchImpl(`${rocketDispatchBase}${path}`, {
      ...opts,
      headers: { 'Content-Type': 'application/json', 'X-Gateway-Token': gatewayToken, ...(opts.headers || {}) },
    });
    if (!r.ok) throw new Error(`rocket-dispatch ${path} -> HTTP ${r.status}`);
    return r.json();
  }
  async function rdBoss(path, opts = {}) {
    const r = await fetchImpl(`${rocketDispatchBase}${path}`, {
      ...opts,
      headers: { 'Content-Type': 'application/json', 'X-Boss-Token': bossToken, ...(opts.headers || {}) },
    });
    if (!r.ok) throw new Error(`rocket-dispatch ${path} -> HTTP ${r.status}`);
    return r.json();
  }
  async function app(path, opts = {}) {
    const r = await fetchImpl(`${customerAppBase}${path}`, {
      ...opts,
      headers: { 'Content-Type': 'application/json', 'X-Rocket-Integration-Key': integrationKey, ...(opts.headers || {}) },
    });
    if (!r.ok) throw new Error(`customer-app ${path} -> HTTP ${r.status}`);
    return r.json();
  }

  async function pushMenu() {
    const { menu } = await rdBoss('/boss/menu');
    const customerMenu = toCustomerMenu(menu, customerMenuMeta);
    await app('/api/integration/menu', { method: 'POST', body: JSON.stringify({ menu: customerMenu }) });
    return customerMenu;
  }

  async function ack(webOrderId, status, rocketOrderId) {
    if (lastAcked.get(webOrderId) === status) return;
    await app('/api/integration/ack', {
      method: 'POST',
      body: JSON.stringify({ orderId: webOrderId, status, rocketOrderId: rocketOrderId || '' }),
    });
    lastAcked.set(webOrderId, status);
  }

  async function completeOrder(webOrderId, order) {
    await app('/api/integration/order-complete', {
      method: 'POST',
      body: JSON.stringify({ orderId: webOrderId, paidPence: Math.round((order.paid || 0) * 100) }),
    });
    lastAcked.set(webOrderId, 'COMPLETE');
  }

  /** One order the app has that rocket-dispatch does not know about yet. */
  async function forwardNewOrder(pending, rocketMenu) {
    const byCode = new Map(rocketMenu.items.map((i) => [i.code, i]));
    const { lines, unknown } = itemLines(pending, byCode);
    if (unknown.length || !lines.length) {
      log(`order ${pending.orderId}: item(s) not in rocket-dispatch's menu (${unknown.join(',')}) - flagging for review, not guessing`);
      return ack(pending.orderId, 'REVIEW_REQUIRED');
    }
    // Server-side price re-validation: never trust the app's own totalPence.
    const priced = priceOrder(rocketMenu, pending.items.map((i) => ({ code: i.code, qty: i.qty })));
    if (!priced.ok) {
      log(`order ${pending.orderId}: cannot price against rocket-dispatch's menu (${priced.reason}) - flagging for review`);
      return ack(pending.orderId, 'REVIEW_REQUIRED');
    }
    const totalPence = Math.round(priced.total * 100);
    if (totalPence !== pending.totalPence) {
      log(`order ${pending.orderId}: app total ${pending.totalPence}p does not match rocket-dispatch's own price ${totalPence}p - flagging for review, not dispatching`);
      return ack(pending.orderId, 'REVIEW_REQUIRED');
    }
    const locLine = locationLine(pending.location);
    if (!locLine) {
      log(`order ${pending.orderId}: no usable meeting location - flagging for review`);
      return ack(pending.orderId, 'REVIEW_REQUIRED');
    }
    const texts = [...lines, locLine];
    if (pending.note) texts.push(pending.note.slice(0, 180));
    for (const text of texts) {
      await rd('/sms/inbound', { method: 'POST', body: JSON.stringify({ from: pending.phone, text, messageId: `${pending.orderId}:${texts.indexOf(text)}` }) });
    }
    awaitingCreation.set(pending.orderId, { phone: pending.phone, sentAt: now(), attempts: 0 });
  }

  /** Orders whose burst we sent - check whether the engine has resolved them yet. */
  async function resolveAwaitingCreation() {
    if (!awaitingCreation.size) return;
    const { orders } = await rdBoss('/boss/orders');
    for (const [webOrderId, waiting] of [...awaitingCreation]) {
      if (now() - waiting.sentAt < burstSettleMs) continue;
      const match = orders.find((o) => o.phone === waiting.phone && o.createdAt >= waiting.sentAt - 1000);
      if (match && match.state !== 'DRAFT') {
        awaitingCreation.delete(webOrderId);
        const status = customerStatusFor(match) || 'FORWARDED';
        await ack(webOrderId, status, match.id);
        continue;
      }
      waiting.attempts += 1;
      if (waiting.attempts >= 5) {
        // The burst never resolved into a priced, located order (e.g. the
        // engine is stuck asking a question our synthetic text didn't
        // answer). A human needs to look, same as any other review flag -
        // never silently drop the customer's order.
        awaitingCreation.delete(webOrderId);
        await ack(webOrderId, 'REVIEW_REQUIRED');
      }
    }
  }

  /** Orders already forwarded (have a rocketOrderId) - reflect status changes back. */
  async function syncActiveOrders() {
    const { orders: mapped } = await app('/api/integration/mappings');
    for (const row of mapped) if (row.rocketOrderId) appOrderRocketIds.add(row.rocketOrderId);
    if (!mapped.length) return;
    const { orders } = await rdBoss('/boss/orders');
    const byId = new Map(orders.map((o) => [o.id, o]));
    for (const row of mapped) {
      const order = byId.get(row.rocketOrderId);
      if (!order) continue;
      const status = customerStatusFor(order);
      if (!status) continue;
      if (status === 'COMPLETE') await completeOrder(row.orderId, order);
      else await ack(row.orderId, status, order.id);
    }
  }

  /**
   * Orders rocket-dispatch completed that the app has NO mapping for at
   * all - i.e. the customer ordered by real SMS/Tasker, never through the
   * app. Without this, that customer's points would only ever exist in
   * rocket-dispatch's own separate engine-side tally (state.customers),
   * never reaching the app's Rewards tab at all - see
   * CHANGELOG_POINTS_UNIFICATION.md. Uses the SAME rocket-dispatch order
   * list already fetched by syncActiveOrders() in the same poll, not a
   * second /boss/orders call.
   */
  async function pointsSyncSmsOnly(orders) {
    for (const order of orders) {
      if (order.state !== 'COMPLETED') continue;
      if (appOrderRocketIds.has(order.id)) continue; // already handled by syncActiveOrders/completeOrder
      if (pointsSynced.has(order.id)) continue;
      const paidPence = Math.round((order.paid || 0) * 100);
      try {
        await app('/api/integration/points-credit', {
          method: 'POST',
          body: JSON.stringify({ phone: order.phone, paidPence, externalRef: order.id }),
        });
        pointsSynced.add(order.id);
      } catch (e) {
        log(`points sync failed for ${order.id} (will retry next poll): ${e.message}`);
      }
    }
  }

  async function pollOnce() {
    const { menu: rocketMenu } = await rdBoss('/boss/menu');
    await resolveAwaitingCreation();
    await syncActiveOrders();
    const { orders: allOrders } = await rdBoss('/boss/orders');
    await pointsSyncSmsOnly(allOrders);
    const { orders: pending } = await app('/api/integration/pending');
    for (const p of pending) {
      if (p.rocketOrderId || awaitingCreation.has(p.orderId)) continue;
      await forwardNewOrder(p, rocketMenu);
    }
  }

  function start() {
    stopped = false;
    const loop = async () => {
      if (stopped) return;
      try { await pollOnce(); } catch (e) { log(`poll failed (will retry): ${e.message}`); }
      if (!stopped) timer = setTimeout(loop, pollIntervalMs);
    };
    loop();
  }
  function stop() { stopped = true; if (timer) clearTimeout(timer); }

  return { start, stop, pollOnce, pushMenu, _awaitingCreation: awaitingCreation, _lastAcked: lastAcked, _pointsSynced: pointsSynced };
}

module.exports = { createCustomerRelayAdapter };
