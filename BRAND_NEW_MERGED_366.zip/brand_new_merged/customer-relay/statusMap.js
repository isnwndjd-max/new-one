'use strict';

/*
 * Pure translation: a rocket-dispatch order's own state/sent fields (as
 * GET /boss/orders already returns them) -> the customer-safe status label
 * the customer app's /api/integration/ack endpoint expects.
 *
 * Deliberately reads only the same public fields the engine's own tests
 * assert on (order.state, order.sent.<KEY>) - never a driver id, never a
 * coordinate, never anything the customer app's own DB doesn't already
 * have a customer-safe field for.
 */
function customerStatusFor(order) {
  if (!order) return null;
  if (order.state === 'COMPLETED') return 'COMPLETE';
  if (order.state === 'CANCELLED' || order.state === 'EXPIRED') return 'CANCELLED';
  if (order.sent && order.sent.ARRIVED) return 'HERE';
  if (order.sent && order.sent.FIVE_MIN) return 'FIVE_MIN';
  if (order.state === 'ASSIGNED' || order.state === 'EN_ROUTE' || order.state === 'ARRIVED') return 'ASSIGNED';
  if (order.state === 'OFFERED' || order.state === 'CONFIRMED') return 'FORWARDED';
  return null; // DRAFT - not yet resolved into a real order; caller should review-flag, not ack
}

module.exports = { customerStatusFor };
