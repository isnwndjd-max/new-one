#!/usr/bin/env node
'use strict';

/*
 * Runnable entry point for customer-relay/adapter.js. Reads its config from
 * a JSON file (see config.example.json) and starts the polling loop.
 * Not run automatically by anything else in this repo - a real deployment
 * starts this as its own process, same as signal/ and driver-relay/'s own
 * scripts would be. See customer-relay/README.md.
 */
const fs = require('fs');
const path = require('path');
const { createCustomerRelayAdapter } = require('./adapter');

const configPath = process.argv[2] || process.env.ROCKET_CUSTOMER_RELAY_CONFIG || path.join(__dirname, 'config.json');
if (!fs.existsSync(configPath)) {
  console.error(`No config file at ${configPath}. Copy config.example.json, fill in real tokens (never commit them), and pass its path as the first argument.`);
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
delete cfg._note;
if (cfg.customerMenuMeta) delete cfg.customerMenuMeta._note;

const adapter = createCustomerRelayAdapter({
  ...cfg,
  log: (msg) => console.log(`[customer-relay] ${new Date().toISOString()} ${msg}`),
});

adapter.pushMenu()
  .then(() => console.log('[customer-relay] initial menu push OK'))
  .catch((e) => console.error(`[customer-relay] initial menu push failed: ${e.message}`));

adapter.start();
console.log(`[customer-relay] started, polling every ${cfg.pollIntervalMs || 4000}ms`);

process.on('SIGTERM', () => { adapter.stop(); process.exit(0); });
process.on('SIGINT', () => { adapter.stop(); process.exit(0); });
