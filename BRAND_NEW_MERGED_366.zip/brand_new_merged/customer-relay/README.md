# Customer-app relay adapter

Bridges the real customer app's backend (`customer-app/`, adapted from the
vendored `Current_Customer_Web_PWA` - see `docs/CUSTOMER_APP.md`) to
rocket-dispatch, **without modifying `server/index.js` or `src/engine.js`**,
and without modifying `customer-app/server.py`'s own order/menu handlers -
only its already-existing `/api/integration/*` surface is used.

```
Customer app (customer-app/server.py) <--HTTP--> customer-relay/adapter.js <--HTTP--> rocket-dispatch (server/index.js)
   /api/integration/pending                              |                               /sms/inbound
   /api/integration/ack                                  |                               /boss/orders  (X-Boss-Token)
   /api/integration/order-complete                        |                               /boss/menu    (X-Boss-Token)
   /api/integration/menu                                 |
   /api/integration/mappings                              |
   (X-Rocket-Integration-Key)
```

Runs as its own process (`node customer-relay/run.js <config.json>`), the
same shape as `signal/` and Tasker - **not** in-process with the engine
(unlike `driver-relay/`, which took the engine directly; see that
directory's own README for why that was flagged as an open decision there).
This adapter deliberately went the other way, so it only ever needs
rocket-dispatch's existing, already-tested gateway/boss HTTP surface.

## What's here

| File | What it does |
|---|---|
| `statusMap.js` | Pure: an order's own `state`/`sent` fields (as `GET /boss/orders` returns them) -> the customer-safe status label the app's `/api/integration/ack` expects. |
| `menuBridge.js` | Pure: rocket-dispatch's minimal synced menu -> the customer app's menu shape. `customerMenuMeta` supplies purely cosmetic category/emoji/size the rocket-dispatch schema has no field for; it can never affect price or availability. |
| `orderText.js` | Pure: a pending web order -> the plain-text burst the engine's existing `parseItems()`/`LocationConversation` already knows how to parse - the same text a real SMS customer would send, reused untouched. |
| `adapter.js` | The polling loop: forwards new orders, resolves them into real rocket-dispatch orders, reflects status changes back, re-prices every order server-side before dispatching it. |
| `config.example.json` | Shape of the config a real deployment needs - every value is a fabricated example, not a real secret. |
| `run.js` | Runnable entry point. `node customer-relay/run.js path/to/config.json`. |

## Why orders go through `/sms/inbound`, not a new order-creation path

The customer app already collects a fully structured order (item codes,
quantities, postcode/street/venue/pin). It would be possible to add a new
"create order from structured data" method to `src/engine.js`. This
adapter deliberately does not: it turns the structured order back into the
same plain-text burst a real SMS customer would type (`orderText.js`) and
sends it through the exact same `POST /sms/inbound` -> `parseItems()` ->
`LocationConversation` -> `Engine._confirm()` path every other order in
this project already goes through and is already tested against - rather
than building and maintaining a second, parallel order-creation code path
with its own edge cases. The cost is a short, bounded wait
(`burstSettleMs`) for the engine's own burst window and tick to actually
run - documented and defaulted generously (9s) rather than raced.

Because the customer's real phone number is used as rocket-dispatch's own
`phone` key, "Customer App OR SMS" (the developer prompt's own phrase) is
literally true: the engine's existing `activeByPhone` dedup means a
customer already mid-order over SMS cannot also get a duplicate order from
the app for the same phone, with no new rule required.

## Price/menu re-validation

`forwardNewOrder()` never trusts the app's own `totalPence` or item names.
It looks up every item code against rocket-dispatch's own menu (pulled
fresh from `GET /boss/menu` on every poll), re-runs the real
`priceOrder()` (`src/menu.js`, unmodified, imported directly - pure
function, no I/O), and only forwards the order if the app's own total
matches exactly. Any mismatch, or any item code rocket-dispatch's own menu
doesn't have, is ack'd `REVIEW_REQUIRED` - never guessed, never silently
dispatched with a wrong price.

## Idempotency / restart recovery

- **No duplicate engine orders across polls or restarts.** `pushNewOrder`
  only looks at orders whose customer-app status is still
  `PENDING_DISPATCH`; the first successful `ack()` call moves it out of
  that set (persisted in the customer app's own database, not in this
  adapter's memory). Restarting this adapter loses only its in-memory
  "awaiting creation" map, which just means an in-flight (not yet ack'd)
  order gets re-scanned on the next poll, never re-sent twice by two
  different attempts - `forwardNewOrder` is itself idempotent because it
  always re-checks the app's own current order status first.
- **No duplicate customer-app orders on client retry** - unchanged,
  already-existing behaviour of `customer-app/server.py`'s own
  `client_request_id`/`requestId` uniqueness constraint, proven again in
  this session's staging run (see the final report).
- **No repeated acks once nothing has changed** - `lastAcked` (in-memory)
  skips a network call when the derived status hasn't moved since the last
  poll.

## Test coverage

`test/customerRelay.adapter.test.js` (8 tests) + `test/helpers/mockCustomerAppServer.js`
(a real HTTP server standing in for `customer-app/server.py`'s own
`/api/integration/*` surface - same "real protocol, not a stub" approach as
`test/helpers/mockAdapterServer.js`/`test/signalAdapter.test.js`), running
against a **real `server/index.js` + `Engine`** over real HTTP (not a mock
of rocket-dispatch itself). Covers: menu conversion (no cost/admin
fields); a correctly-priced order forwarded end to end into a real engine
order; a mismatched client total rejected before dispatch; an unknown item
code rejected before dispatch; a shared GPS pin taking priority and
resolving to an exact coordinate; a full driver lifecycle (accept, 5-min,
here, complete) reflected back in order; no duplicate engine order across
repeated polls; no repeated acks once status is unchanged.

Run just this suite: `node --test test/customerRelay.adapter.test.js`

**This is not a test against the real `customer-app/server.py` Python
process** - see "What was verified live" below for that.

## What was verified live in this session (real processes, not just tests)

A real `server/index.js` (isolated `dataDir`, never the repo's own
`data/`), a real `customer-app/server.py` (plain `sqlite3` fallback, see
`docs/CUSTOMER_APP.md` "Staging substitutions"), and a real
`customer-relay/run.js` were run together as three real OS processes on
`127.0.0.1`. Full results are in the final report delivered alongside this
code; in short, all of: login -> menu -> cash order with a structured
postcode+street -> exactly one order created -> driver offer with no
customer phone number -> driver accept -> 5-min -> here -> complete ->
customer app reflects every state -> **a real process restart of
rocket-dispatch** (state recovered from its encrypted disk store) -> **a
real process restart of the customer app** (order state recovered from its
own database) -> retrying the original order request afterwards (no
duplicate) -> a second simultaneous customer + second driver + two active
orders, with GPS/status updates proven never to cross between them -> and
the six privacy checks the developer prompt asked for (see the report).

## What's NOT yet verified / real gaps

- **The real Android app was never rebuilt or re-signed** - no Android SDK
  and, correctly, no signing key in this sandbox. See
  `docs/CUSTOMER_APP.md` "APK".
- **HTTPS/TLS** was not exercised - both servers ran plain HTTP on
  `127.0.0.1` in this session, same as every other adapter in this
  project's staging runs. A real deployment needs TLS termination (see
  `tasker/TASKER_SETUP.md`'s own Tailscale/reverse-proxy guidance, which
  applies here identically).
- **The real Cloudflare tunnel / VPS deployment path** was not exercised -
  this session's "VPS" was a single sandbox running all three processes on
  localhost.
- **`sqlcipher3`** - see `docs/CUSTOMER_APP.md` point 1 under "Staging
  substitutions." This is the one place this build is weaker than the
  vendored original, and it must be restored before any real customer data
  is involved.
- **Rate limiting** was exercised only by reading the code
  (`LOGIN_LIMIT`/`LOGIN_WINDOW` in `customer-app/server.py`, unmodified
  from the vendored original) - not load-tested in this session.
