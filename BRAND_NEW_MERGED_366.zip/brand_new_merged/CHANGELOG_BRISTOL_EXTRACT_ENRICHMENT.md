# Rocket Dispatch — Bristol OSM Extract Cross-Check & Road Enrichment

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS.

Triggered by a full Greater Bristol OSM extract (`Bristol_osm.gz`, ~93MB,
~4.1M nodes) the user supplied, asking whether it could help. Scope was
explicitly narrowed by the user to: cross-check/enrich the existing 4
districts (BS20, BS21, BS48, BS49) rather than expand coverage further.

---

## 1. What was cross-checked

A bounding-box-filtered, memory-managed streaming parse (`iterparse` +
`elem.clear()`, ~47s) extracted every highway way and POI node/way inside
the 4 districts, then diffed them against the existing verified databases.

Findings:
- 72 named roads/paths present in OSM but missing from the road database.
- 1,015 venues/landmarks present in OSM but missing from `locations.json`.
- 44 pubs/bars missing from the venue database.
- The existing `ambiguities` entry for "spoons" (2 Wetherspoons pubs,
  BS20 + BS48) was independently confirmed correct against the extract -
  no fabrication, nothing to fix there.

## 2. Roads added (this phase)

Following the exact same pipeline conventions as the original road build
(union-find endpoint/centroid merge at the same 60m/350m thresholds,
same alias-generation rules, same JSON schema):

- 75 road clusters were built from the 72 missing names.
- 13 were excluded as cycleway/bridleway-only, consistent with the
  existing roads-master scope (never included those highway types) and
  the alley layer's own explicitly-agreed scope (footways + alleys/paths
  only).
- Of the remaining 62, **13 turned out to be partial re-detections of
  roads that already exist** under a neighbouring district's record -
  boundary roads whose segments span two districts, where the per-district
  diff flagged the road "missing" in the second district because only
  that district's segments were checked there. 12 of the 13 were 100%
  already covered by the existing record's OSM way ids (pure duplicates,
  same road, same geometry, nothing new). The 13th ("North Drove") had one
  additional way segment the existing record doesn't have. All 13 were
  **removed rather than merged into a verified existing record** - the
  existing record already resolves that road correctly, and merging
  geometry into it wasn't part of the agreed scope for this pass.
- **49 new road records were added.** No existing road_id was touched,
  removed, or renumbered.

New road_ids continue the existing per-district sequence
(`ROAD-{district}-{n:04d}`), never reusing a number. Each new record
carries `source: "Bristol_osm_full_extract_2026-09-25"` and an
`enrichment_note` explaining that locality/locality_type is approximated
from the nearest existing road/alley record's locality (this pass didn't
independently extract OSM place nodes), so it's flagged as an
approximation rather than claimed as independently derived, same as the
original build's convention for uncertain fields.

Files updated:
- `road_enrichment/deliverables/rocket_roads_master.json` (1,694 → 1,743)
- `road_enrichment/deliverables/rocket_roads_master.csv` (same)
- `road_enrichment/deliverables/rocket_road_aliases.csv` (+ new alias rows
  for the 49 roads: base/abbreviation/concatenated/with-locality forms,
  same generation rules as the original build)
- `rocket-dispatch/data/roads.json` regenerated from the above via the
  existing `road_integration/build_data.py` (unchanged script) - now 1,743
  records live in the runtime resolver.

## 3. House number fix (separate, bundled into this same test/data run)

See `CHANGELOG_HOUSE_NUMBER_FIX.md` for the full writeup - a house/flat
number given alongside a bare road name ("33 Greenfield Crescent") was
being silently dropped everywhere. Fixed in the same session, found via
the user's own question about how that address would be handled.

- The `Penpole Lane` (Shirehampton) name now covers 2 disconnected road
  segments (2 separate OSM ways too far apart to merge under the existing
  60m/350m thresholds) - both are legitimately separate records, not a
  duplicate-detection issue like the 13 above, so both were kept; the
  resolver correctly asks which one rather than guessing (see
  `test/bristolExtractRoads.test.js`).

## 4. Venues/landmarks added (this phase)

Per the user's own stated gating rules ("verified/existing alias -
auto-resolve. New OSM venue or uncertain nickname - ask once. Ambiguous
alias - ask which town/place. Once a new alias has been confirmed
reliably, it can be promoted to the verified database"):

- **811 new venue records added** (44 pubs/bars + 767 other named
  landmarks: cafes, shops, community centres, fuel stations, etc.),
  scoped strictly to the 4 covered districts.
- Every new venue is `status: "UNCERTAIN"` - this is the SAME gate
  (`VERIFIED_STATUS` in `src/locationIndex.js`) that already governs 484
  of the original 561 venues, not a new mechanism. It means every one of
  these asks the customer to confirm ("Do you mean X, [town]?") before an
  order can dispatch - never a silent auto-resolve.
- Town is approximated from the nearest existing venue/road/alley record
  (same "approximated, documented, not fabricated" convention as the
  road layer), flagged via `qualityFlags: ["town_approximated_from_nearest_record"]`.
  Postcode is filled the same way where a nearby active postcode is
  within 600m, otherwise left `null` rather than guessed.
- Nicknames are limited to well-established, non-fuzzy patterns (dropping
  a leading "The", pub-name shortening e.g. "Crown" for "The Crown Inn",
  concatenated form) - deliberately NOT a misspelling generator, since an
  edit-distance fuzzer risks inventing a form that collides with an
  unrelated real venue, which is exactly the kind of fabricated/
  mis-anchored alias this whole engagement has avoided throughout.
- Categories genuinely inappropriate to route a delivery driver to by
  default (schools, childcare, GP surgeries, dentists, vets, fire/police
  stations, funeral directors) are recognised by name for context but set
  `meetingPoint: false`, reusing the existing mechanism that already
  filters candidate meeting points in `locationConversation.js`.
- **4 candidate venues were caught and dropped** before merging: their
  name was identical to an existing/new ROAD name ("Station Road",
  "Gordano Services", "Moor End Spout", "Waverley Court") - a known OSM
  quirk where a parking/POI node inherits the adjoining street's `name`
  tag. Kept the road record (already correct), not a duplicate venue.
- Files updated: `data/locations.json` (`venues` 561 -> 1,372, `aliases`
  656 -> 1,458). No existing venue, alias or ambiguity entry was touched.

### Promotion mechanism (new)

`src/engine.js` now tracks, per venue, how many separate orders have
explicitly confirmed a not-yet-`ACTIVE` venue
(`state.venueConfirmations[venueId]`, `PROMOTION_CONFIRM_THRESHOLD = 3`).
Once a venue crosses the threshold it's added to
`state.promotionCandidates` and logged as a `VENUE_PROMOTION_CANDIDATE`
event - visible, but **never auto-promoted live**. Flipping a venue to
`ACTIVE` removes its confirmation step for every future customer, so
that step stays a human decision, same discipline as every other
new-data-becomes-verified step in this project (new roads, new alleys,
new ambiguity terms). `scripts/promoteVenues.js` is the offline tool for
that: given an exported engine state, it reports the candidates and,
only with `--apply`, flips them to `ACTIVE` in `data/locations.json` and
writes a `.promoted.json` copy of the state with those ids cleared - it
never overwrites the original state file, and a dry run (no `--apply`)
changes nothing at all.

## 5. Test results

**257 / 257 passing** (`node --test test/*.js`), zero failures.
- `test/bristolExtractRoads.test.js` (6 tests): road spot-checks, plus a
  regression check confirming the road layer itself still resolves
  correctly even where a same-named venue now also exists.
- `test/bristolExtractVenues.test.js` (6 tests): every new venue stays
  inside the 4 covered districts, every one is `UNCERTAIN` (never
  auto-verified), an ambiguous new pub asks rather than guessing, a
  distinctive new venue asks to confirm rather than dispatching silently,
  non-meeting-point categories are correctly flagged, and the 4 removed
  road-name collisions never made it into the live data.
- `test/venuePromotion.test.js` (4 tests): the confirmation counter
  increments across separate orders for the same venue, the threshold
  adds exactly one promotion-candidate entry, an already-`ACTIVE` venue
  is never counted, and `scripts/promoteVenues.js`'s dry run changes
  nothing in `data/locations.json`.
- Two pre-existing tests were updated (not weakened) because the
  expanded venue set legitimately changes what a couple of specific
  phrases now match - documented inline in both test files: this is new,
  correct venue-layer behaviour, and in both cases the actual dispatch
  behaviour stays safe (asks rather than guesses).

## 6. Rollback

`rocket-dispatch/data/roads.json` can be regenerated from
`road_enrichment/deliverables/rocket_roads_master.json` /
`rocket_road_aliases.csv` at any point via
`road_integration/build_data.py`. To fully roll back the road phase,
restore those two deliverable files to their pre-phase state (1,694
roads) and re-run the build script - `alleys.json`/
`rocket_alleys_master.json` were not touched by this phase at all.

For the venue phase: every new venue/alias record carries
`source: "Bristol_osm_full_extract_2026-09-25"` (venues) - filtering
`data/locations.json`'s `venues`/`aliases` arrays on that source field
and removing those entries fully reverts it. The promotion mechanism
(`src/engine.js`, `scripts/promoteVenues.js`) is additive-only (new
state fields with empty defaults, a new script) and safe to leave in
place even if the venue data itself is rolled back - `emptyEngineState()`
defaults `venueConfirmations`/`promotionCandidates` to empty either way.
