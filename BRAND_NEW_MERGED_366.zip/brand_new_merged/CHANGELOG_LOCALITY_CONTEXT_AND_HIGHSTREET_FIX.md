# Rocket Dispatch — Locality Context Aliases + Hill Road / "High Street" Fix

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS. Waiting for explicit authorisation
before any production integration, exactly as instructed.

This is a follow-up to `CHANGELOG_ROAD_ALLEY_INTEGRATION.md`, fixing two
specific gaps it flagged: roads whose OSM-derived locality label doesn't
match the town a customer actually says (e.g. "station rd backwell"), and
the Clevedon "High Street" question.

---

## 1. Exactly which files changed

### New files
| File | What it is |
|---|---|
| `data/localityContext.json` | 206 evidence-backed `road_id -> accepted town` entries, loaded by the server if present. |
| `test/localityContextAndHighStreet.test.js` | 22 new automated tests, covering all 20 scenarios from the brief plus 2 extra sanity checks. |
| `CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md` | This file. |

### Modified files
| File | What changed |
|---|---|
| `src/roadIndex.js` | `RoadIndex` constructor takes an optional third argument, `contextData` (`data/localityContext.json`), and builds `acceptedTownContexts` (`road_id -> Set(town)`). New `acceptsTown(roadId, normalisedTown)` method. `NAME_KINDS` extended to include `'colloquial_confirmed'` (see §5). |
| `src/locationConversation.js` | `_resolveRoad()`'s town filter now accepts a candidate if *either* its real OSM locality matches *or* `roadIndex.acceptsTown()` says so (evidence-backed context) — never a blanket remap, always scoped to one `road_id`. `roadLocation()` gained a `customerContextTown` field: the town the customer actually said, kept **separate** from `town`/`locality` (the road's real, unedited OSM geography). |
| `src/engine.js` | `_placeLabel()` now prefers `customerContextTown` over the raw OSM locality for driver/customer-facing text, when present. |
| `server/index.js` | Loads `data/localityContext.json` if present and passes it to `RoadIndex`. Optional — its absence changes nothing (no context matching beyond a road's own locality, same as before this fix). |
| `data/roads.json` | One record changed: `ROAD-BS21-0171` (Hill Road, Clevedon / Walton Park) gained three new alias entries — see §5. No other road record touched. |

### Explicitly NOT changed
- `data/locations.json` — read-only throughout, as always.
- Every road/alley's own `town`/`locality` field in `data/roads.json` / `data/alleys.json` — **none were rewritten**. "West Town" is still West Town; "Walton Park" is still Walton Park. The context layer sits alongside, never on top of, that data.
- No new road record was created for "High Street, Clevedon" (see §5 for why).
- Every existing test file — unmodified, all still pass (§6).

---

## 2. How the locality-context logic works

For every road/alley whose OSM locality is **not** one of Rocket's 33
known customer-facing towns, this build cross-checked the real postcode(s)
that road touches against **actual venue records already in
`data/locations.json`** — a venue there already carries a verified
`(town, postcode)` pair. If a road's postcode is independently linked, via
a real venue, to one specific town, that becomes an `ACCEPTED` context row
scoped to that exact `road_id`. If there's no such evidence, or it's tied
between two towns, the row is `REVIEW_REQUIRED` and **no alias is
created** — the resolver's behaviour for that road doesn't change at all.

A rejected alternative, deliberately: a blanket rule like *"West Town =
Backwell"* applied everywhere. That risks misrouting an unrelated West
Town road that's really in Nailsea. Every accepted row here is tied to one
`road_id`, backed by that road's own touched postcode(s) — see
`locality_context_audit.csv` in the delivered package for the full
breakdown.

Priority, as specified: exact town/locality match beats an accepted
context match, which beats postcode-district narrowing, which beats
asking. A full postcode always wins outright over all of this, because
postcode matching runs before road matching is even attempted (unchanged
from the prior integration) — so a weak or absent context alias can never
override a valid postcode.

**The road's real geography is never falsified.** `location.town` /
`location.locality` on a resolved road still report the actual OSM
locality (e.g. "West Town"). A new field, `location.customerContextTown`,
carries what the customer actually said (e.g. "Backwell"), and
`engine.js`'s driver-facing text prefers that field when present. Anyone
inspecting the raw data later sees the truth; the customer/driver sees
what they'll recognise.

## 3. How "station rd backwell" was fixed

- Road: `ROAD-BS48-0037`, Station Road, serves the Nailsea & Backwell
  railway station area.
- Its OSM locality is `West Town` — a real hamlet, not one of Rocket's 33
  towns.
- It touches postcode `BS48 3LH`.
- A real venue at `BS48 3LH` in `data/locations.json` is recorded with
  `town: "Backwell"`.
- Result: `data/localityContext.json` has `{road_id: "ROAD-BS48-0037",
  accepted_town: "Backwell"}`.
- "station rd backwell" / "station road backwell" now resolve to that
  road. `location.town` still says `"West Town"` (real, unedited);
  `location.customerContextTown` says `"Backwell"` (what the customer
  said, and what the driver text now shows).

## 4. Source/provenance for the "High Street" question

**Investigated first, before building anything**: checked the raw OSM
export (nearest "High Street" feature to Clevedon's centre is 5km away —
nowhere near it), the original research pack (`data/source/`, no
co-occurrence of "High Street" and "Clevedon" anywhere), and the existing
built road database (no "High Street" record in `BS21_roads.csv` at all).
**No source available to me supports a genuine, separate "High Street"
road in Clevedon.**

I raised this back to the person running Rocket rather than fabricating a
record, and they confirmed directly: **it isn't a second road — "High
Street" is what locals colloquially call Hill Road.** That's real,
first-hand local evidence, and it changes the fix from "recover a missing
road" (which would have meant inventing coordinates) to "add a confirmed
colloquial alias to the road that already exists":

- `ROAD-BS21-0171` (Hill Road, Clevedon / Walton Park, `BS21 7NU`) gained
  three new alias entries in `data/roads.json`:
  - `"High Street"` — `kind: "colloquial_confirmed"`
  - `"High St"`, `"Highstreet"` — `kind: "colloquial_confirmed_variant"`
- A new `alias_provenance` field on that same road record records exactly
  where this came from: *"Locals colloquially call Hill Road 'High
  Street' - confirmed directly by the Rocket operator (2026-09-24)."*
- `roadIndex.js`'s `NAME_KINDS` was extended to treat
  `colloquial_confirmed` as full name-strength (not weaker alias-strength)
  — deliberately, because it's a confirmed, evidence-backed fact, not a
  mechanically generated abbreviation.

## 5. Confirmation: High Street and Hill Road remain separate names, same one real road

- `data/roads.json` still has **exactly one** road record for this street
  — `ROAD-BS21-0171` — named `"Hill Road"`. No second record was created.
- Test #11 (`localityContextAndHighStreet.test.js`) proves "hill road
  clevedon" still resolves to that same record under its real name.
- Test #12 proves "high street clevedon" resolves to the *same*
  `road_id` as "hill road clevedon", and that no BS21 road is actually
  named `"High Street"` in the underlying data — confirming this is one
  road answering to two names, not a fabricated second one.

## 6. Other locality mismatches discovered (beyond Backwell/West Town)

The same evidence-based audit ran across all four districts, not just the
one requested example. Full detail in
`rocket_locality_context_aliases.csv` / `locality_context_audit.csv` in
the delivered package. Headline numbers:

- **206 roads/alleys** got an accepted, evidence-backed town context (top
  towns: Clevedon 52, Portishead 47, Flax Bourton 35, Backwell 16, Nailsea
  13, plus smaller counts across the rest).
- **1,980** had no locality outside Rocket's known towns *or* had
  insufficient evidence — left as `REVIEW_REQUIRED`, no alias created, no
  behaviour change.
- **38 direct conflicts**: the OSM locality *is* a real Rocket town, but
  venue-postcode evidence on that exact road points to a *different* real
  town (e.g. `Colehouse Lane`, OSM locality "Kenn" vs venue evidence
  "Clevedon"). These are **not** auto-resolved either way — listed in
  `locality_context_conflicts.csv` for a human to look at, exactly per the
  brief's "do not guess relationships" instruction.

## 7. Test results

**203 / 203 passing**, two consecutive full clean runs (`node --test
test/*.js`), zero failures. Breakdown:
- 153 pre-existing tests (unmodified)
- 28 road/alley integration tests from the prior phase (unmodified)
- **22 new tests** in `test/localityContextAndHighStreet.test.js`, covering
  all 20 scenarios listed in the brief (numbered 1–20 in the test file to
  match) plus 2 extra: a sanity check that every accepted context row
  references a real `road_id` and a real Rocket town, and an end-to-end
  test through the real `Engine` proving a Backwell customer's order
  reaches `CONFIRMED` with "Backwell" in their own confirmation text.

Run it yourself: `node --test test/*.js` from the project root.

## 8. Unresolved REVIEW_REQUIRED cases

**1,980 rows** in `rocket_locality_context_aliases.csv` are marked
`REVIEW_REQUIRED` — no alias was created for these, so the resolver's
behaviour for them is exactly what it was before this fix (they'll still
correctly disambiguate by real OSM locality, or ask, same as any other
road). The **38 conflict rows** in `locality_context_conflicts.csv` are a
smaller, higher-value list worth a human's attention first — each one is a
case where two pieces of real evidence (OSM's locality tag vs a real
venue's recorded town) genuinely disagree.

---

## 9. Rollback

Fully additive and optional, same pattern as the prior road/alley
integration:
- Delete `data/localityContext.json` (or don't deploy it) — `server/index.js`'s
  `fs.existsSync` check means the server starts with the road/alley layer
  working exactly as it did before this fix, no code changes need
  reverting.
- The three new aliases on `ROAD-BS21-0171` in `data/roads.json` can be
  removed by deleting the `alias_provenance` key and the three
  `colloquial_confirmed*` entries from that one record's `aliases` array —
  everything else in that file is unchanged.
- Or, for a full source rollback: revert `src/roadIndex.js`,
  `src/locationConversation.js`, `src/engine.js`, `server/index.js` to
  their pre-fix versions (see `CHANGELOG_ROAD_ALLEY_INTEGRATION.md`'s
  versions) and delete `data/localityContext.json` + the new test file.

No changes here touch `data/locations.json`, the postcode matching path,
venue matching, or anything already running in production.
