# Rocket Dispatch — Driver Subsystem Brief

**Status: OFFLINE ONLY. Not deployed.**

Implements the "ROCKET DISPATCH — DRIVER SUBSYSTEM BRIEF" (driver bonus,
ACCEPT/TAKE separation, ON/OFF/BREAK, FOOT/CAR enforcement, Driver app
wiring). Driver bonus math itself (£5 first item + £2.50/extra item) was
already built and tested in a prior pass (`test/driverBonus.test.js`) - this
pass adds the brief's remaining sub-requirements plus items 2-5.

## 1. Driver bonus - what's new here

Already done previously: the £5/£2.50 math, running total, duplicate-COMPLETE
guard, per-driver summary. This pass adds:
- **No bonus on cancellation**: confirmed by test (`src/engine.js`'s
  `_cancel()` never touches `driverBonus`/`earnings` - nothing needed
  changing, just verified with a regression test).
- **Bonus survives restart**: regression test using the real `Store`
  (AES-256-GCM, fsync'd) save/reload path, not just in-memory state.
- **"Wage" → "Bonus" in user-facing labels**: `driver-app/source/assets/
  ui.js` - "Total wages" → "Bonus total" (dashboard stat + quick-grid
  button), "Total wages" page title → "Bonus total", "YOUR EARNED WAGES" →
  "YOUR DRIVER BONUS". (`data/config.json`'s one "wage" mention is a
  code-comment note about the *concept*, not a rendered UI label - left
  alone.)
- **Bonus total now actually reaches the Driver app**: `driver-relay/
  snapshot.js` previously sent `earningsTodayPence: 0` with a "no earnings
  ledger yet" comment, and never set `driver.totalWagesPence` at all - the
  app's own `totalWages()` always showed "—" outside demo mode. Now wired
  to the real `driver.earnings.totalBonus`/`completedOrders`.

## 2. ACCEPT / TAKE command separation

`src/engine.js`'s command table had `TAKE` as a bare regex alias for
`ACCEPT` (`/^(ACCEPT|ACC|TAKE)\b/`) - sending `TAKE R1234` accepted a job.
Fixed:
- `TAKE` is now its own top-level command, parsed *before* the
  order-acceptance table (same tier as ON/OFF/BREAK/CAR/FOOT), and never
  touches an order.
- New `Engine._take(driver, text, reply)`: parses `TAKE <item> [qty]` or
  `TAKE [qty] <item>` (qty defaults to 1) against `menu.items` (code or
  name), decrements `driver.stock[code]`, refuses (doesn't clamp) if the
  driver doesn't hold enough, and writes a `DRIVER_TAKE` event.
- New `Engine.loadDriverStock(driverId, code, qty)` (Boss-only) to load
  stock onto a driver in the first place - there was no stock-loading
  mechanism anywhere in the codebase before this pass, so TAKE had nothing
  to deduct from otherwise. Purely additive.
- **Idempotency**: TAKE gets duplicate-message protection for free from
  the existing transport-level dedup (`server/index.js`'s driver-message
  route already calls `engine.firstSeen(messageId)` before invoking
  `handleDriverMessage()` at all, for every driver command) - no new
  dedup mechanism needed; regression test confirms a repeated messageId
  is a safe no-op.

## 3. Driver status ON / OFF / BREAK

Drivers previously had only a plain `onDuty` boolean. Added:
- `driver.status: 'OFF' | 'ON' | 'BREAK'` as the authoritative field.
  `driver.onDuty` is kept as a derived boolean (`true` only when
  `status==='ON'`) so every existing test/UI reading `onDuty` (dispatch,
  `summary()`, Boss dashboard, `driverRelay`/`signalAdapter`/`fullSystem`
  tests) keeps working unchanged - nothing there had to be touched.
- New `BREAK`/`ON BREAK`/`PAUSE` text command: same "finish your active
  job first" guard as OFF, sets `status='BREAK'`, `onDuty=false` (so
  `_freeDrivers()` - unchanged - already excludes a BREAK driver from new
  offers, same mechanism as OFF).
- `ON`/`ON DUTY`/`START`/`RESUME` resumes from BREAK exactly like from OFF
  (single existing command, no new one needed).
- **driver-relay**: `driver-relay/commands.js`'s `applyShift()` previously
  collapsed `SHIFT BREAK` into a plain `OFF` engine command, with a comment
  explaining the engine had no real BREAK state yet - that gap is exactly
  what this pass closes. It now sends the engine's own `BREAK` command and
  reports it back honestly. `driver-relay/snapshot.js`'s `driver.shift`
  field now reports `'BREAK'` (was previously always reported as `'OFF'`
  to the app). The Driver app's own `ui.js` already had a BREAK-aware
  shift-note string (`"On break · choose your mode to resume"`) that was
  simply never reachable before - no app UI change was needed for this.

## 4. Driver mode FOOT / CAR enforcement

`mode: 'CAR'|'FOOT'` already existed on driver records and was settable,
but nothing ever checked it during dispatch - a FOOT driver could be
offered (and accept) any job. Fixed:
- New `Engine._isNailseaLocation(loc)`: true if the location's resolved
  `town` is Nailsea, or - for a bare-postcode location with no resolved
  town (see `locationConversation.js`) - if its postcode is in the BS48
  district. **Documented approximation, not exact geocoding**: BS48 also
  covers some neighbouring villages (Backwell, Wraxall, Long Ashton per
  the Bristol OSM extract used earlier in this project), so a bare-postcode
  order in one of those can't be distinguished from Nailsea proper without
  re-deriving locality data - out of scope per "don't redesign".
- `_freeDrivers(order)` now takes the order being dispatched and excludes
  a FOOT driver whose location isn't Nailsea - enforced at the engine's
  actual offer-selection point (`_dispatch`/`_offerWaitingOrders`), not
  just left to the UI.
- `_accept()` re-checks the same rule as defense-in-depth, so a FOOT
  driver can't acquire a non-Nailsea job even via a stray/hand-crafted
  ACCEPT that bypassed the offer step.

## 5. Driver app wiring

Investigated the existing Driver app (`driver-app/source/assets/{shell.html,
ui.js,rules.js}`) and its `driver-relay/` integration layer before changing
anything, per "don't redesign / reuse what exists":
- The app's `SHIFT` action already sends real engine commands via
  `driver-relay/commands.js` (not local-only UI state) for CAR/FOOT/
  BREAK/OFF, and its GPS/pairing/reconnect flow already restores state
  from the engine on every poll (`ui.js`'s `refresh()`/`call('status')`).
  This was already correctly wired before this pass, apart from the BREAK
  gap (§3) and the bonus/stock gaps below.
- `driver-relay/snapshot.js` now also carries `driver.totalWagesPence`,
  `driver.jobsCompleted` and a top-level `stock` array (`[{name, held,
  free}]`, built from `driver.stock`), matching the exact shape the app's
  `ui.js` already reads (`totalWages()`, `summaryStats()`, `stockPage()`)
  but which was previously never populated - the app always showed "—"
  for bonus/stock outside demo mode.
- **Not changed** (out of scope / already correct): `ACCEPT`/`HERE`/
  `ETA`/`COMPLETE`/`HELP` action wiring, rev-based duplicate-ACCEPT
  protection (`driver-relay/revTracker.js` + the app's own client-side
  `expectedRev` check), and the "customer contact details hidden from
  drivers" rule (`driver-relay/snapshot.js` never reads `order.phone` into
  the job payload - unchanged, already correct, see the file's own header
  comment).
- **Genuinely unfinished**: `TAKE` has no button/screen in the Driver app
  UI yet - `loadDriverStock()`/`_take()` and the stock figures reaching the
  app are new, but the app's own "My Stock" page is still read-only
  display, and `TAKE` itself is reachable only via the driver text-command
  channel (Signal/SMS), not a tap in the app. Adding an app-side TAKE
  button/modal (plus its `driver-relay/commands.js` action + validation)
  is the next step if a driver needs to record TAKE without a text
  channel open; flagged rather than guessed at, since the brief's app
  screens list doesn't specify the exact interaction (quantity picker vs.
  fixed increments) and inventing one risks the wrong UX.

## Concurrency / reliability

- **Simultaneous ACCEPT**: unchanged mechanism, re-verified by regression
  test - `_accept()` runs synchronously in JS, so two ACCEPTs can never
  interleave; the second sees `order.driverId` already set and is refused.
- **Duplicate bonus award**: unchanged mechanism (COMPLETE on an already-
  COMPLETED order returns the existing `duplicate: true` reply without
  re-running the bonus block) - re-verified by test.
- **Double stock deduction**: new `TAKE` inherits the transport-level
  message dedup described in §2, plus its own "never below zero" guard
  (a TAKE for more than the driver holds is refused outright, not
  clamped).
- **Two drivers owning the same order**: unchanged `_accept()` mechanism,
  re-verified by test alongside the new FOOT/CAR and BREAK checks.

## Files changed

- `src/engine.js`: `driver.status`/`driver.stock` fields; `BREAK` command;
  `_take()`/`loadDriverStock()`; TAKE split out of the ACCEPT regex;
  `_isNailseaLocation()`; `_freeDrivers(order)` FOOT/CAR filter;
  `_accept()` FOOT/CAR defense-in-depth check.
- `data/messages.json`: `driver_break`, `driver_mode_foot_area`,
  `driver_take_ok`, `driver_take_unknown_item`, `driver_take_insufficient`;
  `driver_help` updated to list BREAK/TAKE.
- `driver-relay/commands.js`: `applyShift()` sends real `BREAK` instead of
  collapsing it into `OFF`.
- `driver-relay/snapshot.js`: real `driver.shift` BREAK reporting, bonus
  totals, stock array.
- `driver-app/source/assets/ui.js`: "wage" → "Bonus" label renames.
- `test/driverSubsystem.test.js` (new, 18 tests): cancellation/restart
  bonus edges, ACCEPT/TAKE separation, ON/OFF/BREAK, FOOT/CAR enforcement,
  driver-relay wiring, concurrency.

## Test results

**292 / 292 passing** (`node --test test/*.js`; 274 pre-existing + 18 new
in `test/driverSubsystem.test.js`). No existing test was changed. Full run
takes ~15s on this sandbox.

## Genuinely unfinished / next steps

1. **TAKE has no Driver-app UI** (button/modal) - see §5. Engine + relay
   support it; the app itself doesn't expose it yet.
2. **FOOT/Nailsea matching is postcode-district-based, not exact** for a
   bare-postcode order with no resolved venue/road `town` - see §4.
3. **`earningsTodayPence`/`jobsCompletedToday`** (in `driver-relay/
   snapshot.js`, matching field names the app's `rules.js` demo fixture
   already used) are actually **all-time** totals, not day-scoped - there
   is no daily-reset/rollover mechanism anywhere in the engine. Renaming
   or adding a real "today" figure is a separate piece of work; flagged
   rather than silently mislabelled.
4. Stock's `free` figure is always equal to `held` (no reservation-against-
   an-order concept exists) - documented in `driver-relay/snapshot.js`'s
   comment rather than invented.
