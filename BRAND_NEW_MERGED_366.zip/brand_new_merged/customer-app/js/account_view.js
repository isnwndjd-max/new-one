/* Pure debt/points presentation for the rocket-dispatch-backed account.
   Replaces the old V35-specific view (v35_account_view.js) now that
   rocket-dispatch, not V35, is the local order/reward authority - points
   and debt come straight from this app's own server.py, no external sync
   status to reflect. */
export function accountLabels(debt, reward, sync) {
  debt = debt || {}; reward = reward || {}; sync = sync || {};
  const stale = sync.status === 'OFFLINE';
  const validDebt = debt.available === true && Number.isSafeInteger(debt.owedPence) && debt.owedPence >= 0;
  const points = Number.isSafeInteger(reward.points) ? reward.points : 0;
  const money = validDebt ? '£' + (debt.owedPence / 100).toFixed(2) : 'No account balance';
  const status = stale ? 'Offline - showing last known balance'
    : (!validDebt ? 'Account up to date' : (debt.blocked ? 'Account on hold' : (debt.overdue ? 'Payment overdue' : 'Account up to date')));
  return {
    money, points: points.toLocaleString('en-GB'), status, stale, known: validDebt, pointsKnown: true,
    due: validDebt && debt.dueAt ? 'Payment due ' + new Date(debt.dueAt * 1000).toLocaleDateString('en-GB') : '',
    updated: stale ? 'Last checked a moment ago' : 'Updated just now',
    canRedeem: false, canCheckout: true,
  };
}
