ROCKET CUSTOMER PWA — STAGING

Purpose
- Invite-only customer web app/PWA
- Cash-only checkout
- Menu, basket, multibuy deals
- Rocket Reel Frenzy
- 2 free spins per £5 qualifying completed spend
- Weekly prize pool + Prize Vault
- Separate staging integration outbox for Rocket Dispatch

Safety
- This project does not modify the live dispatch phone.
- Orders are written to integration/customer_outbox.jsonl until the staging dispatch bridge is enabled.
- Card payments are intentionally unsupported.
- Rewards in this staging build are test rewards only.

Run
  python3 server.py
Default listen: 127.0.0.1:8930

Admin
  tools/admin.py invite --phone +447700900123 --name "Demo" --area "Nailsea, BS48"
  tools/admin.py prize --code FREEDEL --qty 10
  tools/admin.py status

Integration contract
- Each submitted order appends one JSON line to integration/customer_outbox.jsonl.
- The line includes mapped invite phone, canonical order body, note, total and CASH payment method.
- A dispatch bridge can consume this and submit it to R19S as INGEST:<phone>.
- Spins should be awarded only after verified completed/paid dispatch orders via the integration completion callback.
