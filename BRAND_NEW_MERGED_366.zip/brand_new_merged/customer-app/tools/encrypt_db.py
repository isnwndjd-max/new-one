#!/home/ubuntu/rocket-customer-sqlcipher-env/bin/python
import argparse, os, sqlite3
from pathlib import Path
from sqlcipher3 import dbapi2 as cipher

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source',required=True);p.add_argument('--dest',required=True);p.add_argument('--key-file',required=True)
    a=p.parse_args();src=Path(a.source);dst=Path(a.dest);key=Path(a.key_file).read_bytes().strip()
    if len(key)!=32: raise SystemExit('key must be 32 raw bytes')
    if dst.exists(): raise SystemExit('destination exists')
    plain=sqlite3.connect('file:'+str(src)+'?mode=ro',uri=True)
    tables=[r[0] for r in plain.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
    counts={t:plain.execute('select count(*) from "'+t+'"').fetchone()[0] for t in tables}
    plain.close()
    c=cipher.connect(str(src));c.execute('PRAGMA cipher_memory_security = ON')
    safe=str(dst).replace("'","''")
    c.execute("ATTACH DATABASE '"+safe+"' AS encrypted KEY \"x'"+key.hex()+"'\"")
    c.execute("SELECT sqlcipher_export('encrypted')")
    c.execute('DETACH DATABASE encrypted');c.close();os.chmod(dst,0o600)
    e=cipher.connect(str(dst));e.execute("PRAGMA key = \"x'"+key.hex()+"'\"");e.execute('PRAGMA cipher_memory_security = ON')
    check=e.execute('PRAGMA integrity_check').fetchone()
    if not check or check[0]!='ok': raise SystemExit('cipher integrity failed')
    for t,n in counts.items():
        if e.execute('select count(*) from "'+t+'"').fetchone()[0]!=n: raise SystemExit('row mismatch '+t)
    e.close();print('ENCRYPTED_OK',len(tables))

if __name__=='__main__':main()
