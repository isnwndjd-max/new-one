#!/usr/bin/env python3
import argparse, hashlib, secrets, sqlite3, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];DB=ROOT/'data'/'customer.db'
def sha(v):return hashlib.sha256(v.encode()).hexdigest()
p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True)
a=sub.add_parser('invite');a.add_argument('--phone',required=True);a.add_argument('--name',default='Customer');a.add_argument('--area',default='Nailsea, BS48');a.add_argument('--days',type=int,default=7)
b=sub.add_parser('prize');b.add_argument('--code',required=True);b.add_argument('--qty',type=int,required=True)
sub.add_parser('status')
args=p.parse_args();c=sqlite3.connect(DB);c.row_factory=sqlite3.Row
if args.cmd=='invite':
    code='ROCKET-'+secrets.token_hex(4).upper()
    c.execute('insert into invites(code_hash,phone,label,area_label,expires_at,max_uses) values(?,?,?,?,?,1)',(sha(code),args.phone,args.name,args.area,int(time.time())+args.days*86400))
    c.execute('insert or ignore into customers(phone) values(?)',(args.phone,));c.commit();print(code)
elif args.cmd=='prize':
    r=c.execute('select code from prize_pool where code=?',(args.code.upper(),)).fetchone()
    if not r:raise SystemExit('Unknown prize code')
    c.execute('update prize_pool set weekly_qty=?,remaining=? where code=?',(args.qty,args.qty,args.code.upper()));c.commit();print('UPDATED',args.code.upper(),args.qty)
else:
    print('INVITES',c.execute('select count(*) from invites').fetchone()[0]);print('SESSIONS',c.execute('select count(*) from sessions').fetchone()[0]);print('ORDERS',c.execute('select count(*) from orders').fetchone()[0])
    for r in c.execute('select code,label,remaining,weekly_qty from prize_pool order by code'):print(dict(r))
c.close()
