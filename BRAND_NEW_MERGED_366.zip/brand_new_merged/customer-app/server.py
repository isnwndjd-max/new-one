#!/usr/bin/env python3
#
# Rocket Customer app backend, adapted for rocket-dispatch.
#
# What changed from the vendored original (Current_Customer_Web_PWA, pulled
# in from the developer handover) and why - see docs/CUSTOMER_APP.md for the
# full account. In short:
#   - the V35-specific binding module (v35_customer_sync.py) and the
#     external points_runtime module are no longer imported. rocket-dispatch
#     is the new authority; this file's own local order/menu/reward handling
#     (already fully implemented below, and NOT V35-shaped) is what runs.
#   - the SQLCipher vendor import is now a soft dependency: this sandbox has
#     no access to the real vendored sqlcipher3 build, so it falls back to
#     plain sqlite3 for STAGING ONLY (see below). A real deployment must
#     restore the sqlcipher3 import and a real key file - see
#     docs/CUSTOMER_APP.md's "Staging substitutions" section.
#   - POST /api/orders now accepts optional structured location fields
#     (postcode/street/venue/lat/lng) alongside the existing free-text
#     `location`, and a new GET /api/orders/current exposes the customer's
#     own active/last order with a customer-safe status label.
import json, os, re, secrets, hashlib, time, threading, sys
try:
    sys.path.insert(0, os.environ.get('ROCKET_CUSTOMER_SQLCIPHER_VENDOR_PATH', ''))
    from sqlcipher3 import dbapi2 as sqlite3
    DB_ENCRYPTED = True
except Exception:
    # STAGING FALLBACK ONLY. The real deployment's sqlcipher3 vendor build
    # was deliberately excluded from the developer handover (see
    # 06_REMOTE_SOURCE_PATHS/WHAT_IS_NOT_INCLUDED.txt in the original
    # handover pack) and is not present in this sandbox. Falling back to
    # plain sqlite3 means the staging customer.db is NOT encrypted at rest -
    # fine for a synthetic test account on a throwaway sandbox, never for a
    # real customer database. See docs/CUSTOMER_APP.md.
    import sqlite3
    DB_ENCRYPTED = False
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DB=ROOT/'data'/'customer.db'
DB_KEY_FILE=Path(os.environ.get('ROCKET_CUSTOMER_DB_KEY', str(ROOT/'data'/'db.key')))
MENU=json.loads((ROOT/'data'/'menu.json').read_text())
REWARDS=json.loads((ROOT/'data'/'rewards.json').read_text())
LOYALTY_DEFAULT=json.loads((ROOT/'data'/'loyalty.json').read_text())
FIRST_INVITE=ROOT/'FIRST_INVITE.txt'
INTEGRATION_KEY_FILE=ROOT/'INTEGRATION_KEY.txt'
TEST_BRIDGE_SHA256='2fc14574eedec1f5d4d70791e8ca8299c1924918eaaa087b75f1c16a77377a8b'
TEST_BRIDGE_PHONE='+447700900321'
OUTBOX=ROOT/'integration'/'customer_outbox.jsonl'
LOGIN_LOCK=threading.Lock()
LOGIN_FAIL={}
LOGIN_WINDOW=300
LOGIN_LIMIT=12

def client_ip(h):
    v=(h.headers.get('CF-Connecting-IP') or h.client_address[0] or '').strip()
    return v[:64]

def login_limited(h):
    k=client_ip(h);cut=now()-LOGIN_WINDOW
    with LOGIN_LOCK:
        a=[x for x in LOGIN_FAIL.get(k,[]) if x>=cut]
        LOGIN_FAIL[k]=a
        return len(a)>=LOGIN_LIMIT

def login_fail(h):
    k=client_ip(h);cut=now()-LOGIN_WINDOW
    with LOGIN_LOCK:
        a=[x for x in LOGIN_FAIL.get(k,[]) if x>=cut];a.append(now());LOGIN_FAIL[k]=a[-LOGIN_LIMIT:]

def login_success(h):
    with LOGIN_LOCK: LOGIN_FAIL.pop(client_ip(h),None)

def now(): return int(time.time())
def sha(v): return hashlib.sha256(v.encode()).hexdigest()
def account_id(phone):
    digits=re.sub(r'\D','',str(phone or ''))
    return digits[-5:] if len(digits)>=5 else ''
def make_invite_code(c):
    for _ in range(100):
        code=f'{secrets.randbelow(1000000):06d}'
        if not c.execute('select 1 from invites where code_hash=?',(sha(code),)).fetchone():return code
    raise RuntimeError('Could not allocate invite code')
def db():
    c=sqlite3.connect(DB,timeout=10)
    if DB_ENCRYPTED:
        key=DB_KEY_FILE.read_bytes()
        if len(key)!=32: raise RuntimeError('Customer database key unavailable')
        c.execute("PRAGMA key = \"x'%s'\"" % key.hex())
        c.execute('PRAGMA cipher_memory_security = ON')
    c.execute('PRAGMA busy_timeout=10000')
    c.row_factory=sqlite3.Row
    return c

def init_db():
    DB.parent.mkdir(parents=True,exist_ok=True);OUTBOX.parent.mkdir(parents=True,exist_ok=True)
    if not DB_ENCRYPTED and not DB_KEY_FILE.exists():
        # Staging-only convenience so `db()` never needs branching at every
        # call site. Unused while DB_ENCRYPTED is False, written only so a
        # later switch to a real sqlcipher3 build has a key file in place.
        DB_KEY_FILE.parent.mkdir(parents=True,exist_ok=True)
        DB_KEY_FILE.write_bytes(secrets.token_bytes(32));os.chmod(DB_KEY_FILE,0o600)
    c=db();x=c.cursor()
    x.execute('PRAGMA journal_mode=WAL')
    x.executescript('''
    create table if not exists invites(code_hash text primary key, phone text not null, label text, area_label text, expires_at integer, max_uses integer not null default 1, used_count integer not null default 0, active integer not null default 1);
    create table if not exists sessions(token_hash text primary key, phone text not null, created_at integer not null, expires_at integer not null);
    create table if not exists customers(phone text primary key, spins integer not null default 0, spend_remainder_pence integer not null default 0, pin_salt text, pin_hash text, pin_set_at integer not null default 0);
    create table if not exists orders(id text primary key, phone text not null, items_json text not null, location text not null, note text, total_pence integer not null, payment_method text not null, status text not null, created_at integer not null, reward_applied integer not null default 0, client_request_id text);
    create table if not exists vault(id integer primary key autoincrement, phone text not null, code text not null, label text not null, icon text, status text not null default 'ACTIVE', won_at integer not null);
    create table if not exists prize_pool(code text primary key, label text not null, icon text, kind text not null, weekly_qty integer not null, remaining integer not null, week_key text not null);
    create table if not exists spins(id integer primary key autoincrement, phone text not null, at integer not null, winner integer not null, prize_code text, result_json text not null);
    create table if not exists settings(key text primary key, value text not null);
    create table if not exists scratch_claims(phone text not null, day_key text not null, winner integer not null, label text not null, icon text, kind text not null, value integer not null default 0, created_at integer not null, primary key(phone,day_key));
    create table if not exists points_ledger(id integer primary key autoincrement, phone text not null, delta integer not null, balance_after integer not null, reason text not null, external_ref text, created_at integer not null);
    create unique index if not exists idx_points_ledger_ref on points_ledger(phone,external_ref) where external_ref is not null;
    create table if not exists loyalty_redemptions(id integer primary key autoincrement, phone text not null, request_id text not null, code text not null, cost_points integer not null, label text not null, result_json text not null, at integer not null, unique(phone,request_id));
    create table if not exists credit_accounts(phone text primary key, owed_pence integer not null default 0, credit_limit_pence integer not null default 0, due_at integer, blocked integer not null default 0, status_label text not null default 'OK', updated_at integer not null, source_rev text);
    create table if not exists v35_loyalty(phone text primary key, points integer not null default 0, source_rev text, updated_at integer not null);
    ''')
    try:
        x.execute('alter table orders add column rocket_order_id text')
    except sqlite3.OperationalError:
        pass
    try:
        x.execute('alter table orders add column client_request_id text')
    except sqlite3.OperationalError:
        pass
    x.execute('create unique index if not exists idx_orders_client_request on orders(client_request_id) where client_request_id is not null')
    # Structured location, additive to the existing free-text `location`.
    # rocket-dispatch's own locationConversation.js resolves these into one
    # final meeting coordinate - see docs/CUSTOMER_APP.md "Location".
    for col,ddl in [('postcode','text'),('street','text'),('venue','text'),('pin_lat','real'),('pin_lng','real')]:
        try:
            x.execute('alter table orders add column '+col+' '+ddl)
        except sqlite3.OperationalError:
            pass
    try:
        x.execute('alter table prize_pool add column managed integer not null default 0')
    except sqlite3.OperationalError:
        pass
    for col,ddl in [('pin_salt','text'),('pin_hash','text'),('pin_set_at','integer not null default 0'),('points','integer not null default 0'),('points_remainder_pence','integer not null default 0')]:
        try:
            x.execute('alter table customers add column '+col+' '+ddl)
        except sqlite3.OperationalError:
            pass
    x.execute("insert or ignore into settings(key,value) values('loyalty_json',?)",(json.dumps(LOYALTY_DEFAULT,separators=(',',':')),))
    for p in REWARDS:
        wk=time.strftime('%G-W%V',time.gmtime())
        row=x.execute('select week_key from prize_pool where code=?',(p['code'],)).fetchone()
        if not row:
            x.execute('insert into prize_pool(code,label,icon,kind,weekly_qty,remaining,week_key) values(?,?,?,?,?,?,?)',(p['code'],p['label'],p.get('icon','🎁'),p['kind'],p['weeklyQty'],p['weeklyQty'],wk))
        elif row['week_key']!=wk:
            full=x.execute('select managed,weekly_qty from prize_pool where code=?',(p['code'],)).fetchone()
            if full and int(full['managed'] or 0):
                x.execute('update prize_pool set remaining=weekly_qty,week_key=? where code=?',(wk,p['code']))
            else:
                x.execute('update prize_pool set weekly_qty=?,remaining=?,week_key=?,label=?,icon=?,kind=? where code=?',(p['weeklyQty'],p['weeklyQty'],wk,p['label'],p.get('icon','🎁'),p['kind'],p['code']))
    if not x.execute('select 1 from invites limit 1').fetchone():
        code='ROCKET-'+secrets.token_hex(16).upper()
        x.execute('insert into invites(code_hash,phone,label,area_label,expires_at,max_uses) values(?,?,?,?,?,1)',(sha(code),'+447700900123','Demo Customer','Nailsea, BS48',now()+7*86400))
        x.execute('insert or ignore into customers(phone,spins,spend_remainder_pence) values(?,?,?)',('+447700900123',3,0))
        FIRST_INVITE.write_text(code+'\n')
        os.chmod(FIRST_INVITE,0o600)
    if not INTEGRATION_KEY_FILE.exists():
        INTEGRATION_KEY_FILE.write_text(secrets.token_urlsafe(32)+'\n');os.chmod(INTEGRATION_KEY_FILE,0o600)
    c.commit();c.close()

def json_body(h):
    n=int(h.headers.get('Content-Length','0') or 0)
    if n>100000: raise ValueError('request too large')
    return json.loads(h.rfile.read(n) or b'{}')

def send(h,status,obj):
    b=json.dumps(obj,separators=(',',':')).encode()
    h.send_response(status);h.send_header('Content-Type','application/json');h.send_header('Cache-Control','no-store');h.send_header('Content-Length',str(len(b)));h.end_headers();h.wfile.write(b)

def bearer_value(h):
    a=h.headers.get('Authorization','')
    return a[7:].strip() if a.startswith('Bearer ') else ''

def normalize_phone_input(v):
    x=re.sub(r'[^0-9+]','',str(v or ''))
    if x.startswith('07') and len(x)==11:x='+44'+x[1:]
    elif x.startswith('44') and len(x)==12:x='+'+x
    return x if re.fullmatch(r'\+44\d{10}',x) else ''

def pin_digest(pin,salt_hex):
    return hashlib.scrypt(str(pin).encode(),salt=bytes.fromhex(salt_hex),n=16384,r=8,p=1,dklen=32).hex()

def token_phone(h):
    t=bearer_value(h)
    if not t:return None
    c=db();r=c.execute('select phone,expires_at from sessions where token_hash=?',(sha(t),)).fetchone();c.close()
    if not r or r['expires_at']<now(): return None
    return r['phone']

def effective_menu(c):
    r=c.execute("select value from settings where key='menu_json'").fetchone()
    if r:
        try:
            m=json.loads(r['value'])
            if isinstance(m,list): return m
        except Exception:
            pass
    return MENU

def product_map(c=None):
    own=False
    if c is None: c=db();own=True
    m={p['code']:p for p in effective_menu(c) if p.get('active')}
    if own:c.close()
    return m

def price_line(p,qty):
    regular=p['pricePence']*qty;d=p.get('deal')
    if not d:return regular
    return (qty//d['qty'])*d['totalPence']+(qty%d['qty'])*p['pricePence']

def weekly_prizes(c):
    return [dict(code=r['code'],label=r['label'],icon=r['icon'],remaining=r['remaining'],weeklyQty=r['weekly_qty']) for r in c.execute('select * from prize_pool where remaining>0 order by label')]

def loyalty_config(c):
    r=c.execute("select value from settings where key='loyalty_json'").fetchone()
    try: cfg=json.loads(r['value']) if r else dict(LOYALTY_DEFAULT)
    except Exception: cfg=dict(LOYALTY_DEFAULT)
    cfg['pointsPerPound']=max(0,min(10000,int(cfg.get('pointsPerPound',10) or 0)))
    cfg['pointsSpinCost']=max(1,min(1000000,int(cfg.get('pointsSpinCost',100) or 100)))
    cfg['slotWinPercent']=max(0,min(100,int(cfg.get('slotWinPercent',35) or 0)))
    cfg['redemptions']=[p for p in (cfg.get('redemptions') or []) if isinstance(p,dict) and int(p.get('costPoints',0) or 0)>0]
    for p in cfg['redemptions']:
        if str(p.get('code','')).upper()=='REEL1':p['costPoints']=cfg['pointsSpinCost']
    return cfg

def reward_state(c,phone):
    r=c.execute('select spins,spend_remainder_pence,points,points_remainder_pence from customers where phone=?',(phone,)).fetchone();cfg=loyalty_config(c)
    v35=c.execute('select points,source_rev,updated_at from v35_loyalty where phone=?',(phone,)).fetchone()
    points=int(v35['points']) if v35 else (r['points'] if r else 0)
    return {'spins':r['spins'] if r else 0,'spendRemainderPence':r['spend_remainder_pence'] if r else 0,'points':points,'pointsRemainderPence':0 if v35 else (r['points_remainder_pence'] if r else 0),'pointsPerPound':cfg['pointsPerPound'],'pointsSpinCost':cfg['pointsSpinCost'],'pointsSource':'V35' if v35 else 'LOCAL','pointsSourceRev':str(v35['source_rev']) if v35 else None}

def loyalty_public(c):
    cfg=loyalty_config(c)
    red=[{'code':str(p.get('code',''))[:24],'label':str(p.get('label','Reward'))[:80],'icon':str(p.get('icon','🎁'))[:8],'costPoints':int(p.get('costPoints',0) or 0)} for p in cfg['redemptions']]
    return red

def add_points(c,phone,delta,reason,external_ref=None):
    r=c.execute('select points from customers where phone=?',(phone,)).fetchone();old=int(r['points'] if r else 0);new=old+int(delta)
    if new<0: raise ValueError('Not enough Rocket Points')
    c.execute('update customers set points=? where phone=?',(new,phone))
    c.execute('insert into points_ledger(phone,delta,balance_after,reason,external_ref,created_at) values(?,?,?,?,?,?)',(phone,int(delta),new,str(reason)[:120],external_ref,now()))
    return new

def apply_loyalty_prize(c,phone,p,ref_prefix):
    kind=str(p.get('kind','NONE')).upper();value=max(0,int(p.get('value',0) or 0));label=str(p.get('label','Reward'))[:80];icon=str(p.get('icon','🎁'))[:8];code=str(p.get('code','REWARD'))[:24]
    if kind=='POINTS' and value:add_points(c,phone,value,label,ref_prefix+':points')
    elif kind=='SPINS' and value:c.execute('update customers set spins=spins+? where phone=?',(value,phone))
    elif kind=='VAULT':c.execute('insert into vault(phone,code,label,icon,status,won_at) values(?,?,?,?,?,?)',(phone,code,label,icon,'ACTIVE',now()))
    return {'code':code,'label':label,'icon':icon,'kind':kind,'value':value}

def credit_state(c,phone):
    r=c.execute('select * from credit_accounts where phone=?',(phone,)).fetchone()
    if not r:return {'available':False}
    owed=max(0,int(r['owed_pence'] or 0));limit=max(0,int(r['credit_limit_pence'] or 0));due=int(r['due_at'] or 0)
    return {'available':True,'owedPence':owed,'creditLimitPence':limit,'availableCreditPence':max(0,limit-owed),'dueAt':due or None,'overdue':bool(due and due<now() and owed>0),'blocked':bool(r['blocked']),'statusLabel':str(r['status_label'] or 'OK')[:40],'updatedAt':int(r['updated_at'] or 0)}

# Internal order status (set by customer-relay/'s /api/integration/ack and
# /api/integration/order-complete calls) -> the customer-safe label set the
# developer prompt asked for. Never a raw rocket-dispatch state name, never
# a driver identity, never a coordinate.
ORDER_STATUS_LABELS={
    'PENDING_DISPATCH':'Order received','FORWARDED':'Waiting for a driver',
    'ASSIGNED':'Driver accepted - on the way','FIVE_MIN':'About 5 minutes away',
    'HERE':'Your driver is here','COMPLETE':'Completed','CANCELLED':'Cancelled',
    'REJECTED':'Cancelled','REVIEW_REQUIRED':'Waiting for a driver',
}
def order_public(o):
    if not o:return None
    items=json.loads(o['items_json']);pm=product_map();lines=[{'code':it['code'],'qty':it['qty'],'name':(pm.get(it['code']) or {}).get('name',it['code'])} for it in items]
    return {'orderId':o['id'],'status':ORDER_STATUS_LABELS.get(o['status'],'Order received'),'items':lines,'totalPence':o['total_pence'],'location':o['location'],'createdAt':o['created_at'],'final':o['status'] in ('COMPLETE','CANCELLED','REJECTED')}

def vault_state(c,phone):
    return [dict(label=r['label'],icon=r['icon'],status=r['status'],wonLabel='Won '+time.strftime('%d %b',time.localtime(r['won_at']))) for r in c.execute('select * from vault where phone=? order by id desc limit 30',(phone,))]

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        origin=(self.headers.get('Origin') or '').strip()
        if origin in ('https://localhost','http://localhost','capacitor://localhost'):
            self.send_header('Access-Control-Allow-Origin',origin)
            self.send_header('Vary','Origin')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        super().end_headers()
    def translate_path(self,path):
        p=urlparse(path).path
        target=(ROOT / p.lstrip('/')).resolve()
        if p=='/': target=ROOT/'index.html'
        if ROOT not in target.parents and target!=ROOT: return str(ROOT/'index.html')
        return str(target)
    def log_message(self,fmt,*args): print(time.strftime('%F %T'),fmt%args,flush=True)
    def do_OPTIONS(self):
        origin=(self.headers.get('Origin') or '').strip()
        if origin not in ('https://localhost','http://localhost','capacitor://localhost'):
            return self.send_error(403)
        self.send_response(204)
        self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type')
        self.send_header('Access-Control-Max-Age','600')
        self.end_headers()

    def do_POST(self):
        path=urlparse(self.path).path
        try:
            if path=='/api/integration/menu':
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
                body=json_body(self);menu=body.get('menu')
                if not isinstance(menu,list) or not menu or len(menu)>250:return send(self,400,{'error':'invalid menu'})
                clean=[]
                for pp in menu:
                    code=str(pp.get('code','')).strip().upper();name=str(pp.get('name','')).strip()
                    if not re.fullmatch(r'[A-Z0-9_-]{1,16}',code) or not name or len(name)>80:continue
                    q={'code':code,'name':name,'size':str(pp.get('size',''))[:30],'category':str(pp.get('category','Other'))[:30],'emoji':str(pp.get('emoji','🥤'))[:8],'pricePence':max(0,int(pp.get('pricePence',0) or 0)),'aliases':[str(x)[:50] for x in (pp.get('aliases') or [])[:20]],'active':bool(pp.get('active',True)),'stock':pp.get('stock',None)}
                    d=pp.get('deal')
                    if isinstance(d,dict) and int(d.get('qty',0) or 0)>1 and int(d.get('totalPence',0) or 0)>0:q['deal']={'qty':int(d['qty']),'totalPence':int(d['totalPence']),'label':str(d.get('label',''))[:30]}
                    clean.append(q)
                if not clean:return send(self,400,{'error':'menu empty'})
                c=db();c.execute("insert into settings(key,value) values('menu_json',?) on conflict(key) do update set value=excluded.value",(json.dumps(clean,separators=(',',':')),));c.commit();c.close()
                return send(self,200,{'ok':True,'count':len(clean)})
            if path=='/api/integration/credit':
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
                body=json_body(self);phone=normalize_phone_input(body.get('phone'));owed=max(0,int(body.get('owedPence',0) or 0));limit=max(0,int(body.get('creditLimitPence',0) or 0));due=int(body.get('dueAt',0) or 0);blocked=1 if bool(body.get('blocked',False)) else 0;status=str(body.get('statusLabel','OK')).strip()[:40] or 'OK';rev=int(body.get('sourceRev',0) or 0)
                if not phone or owed>100000000 or limit>100000000 or due<0 or rev<0:return send(self,400,{'error':'invalid credit snapshot'})
                c=db();old=c.execute('select source_rev from credit_accounts where phone=?',(phone,)).fetchone()
                if old:
                    try:old_rev=int(old['source_rev'] or 0)
                    except Exception:old_rev=0
                    if rev and old_rev and rev<old_rev:c.close();return send(self,409,{'error':'stale credit snapshot'})
                c.execute('insert into credit_accounts(phone,owed_pence,credit_limit_pence,due_at,blocked,status_label,updated_at,source_rev) values(?,?,?,?,?,?,?,?) on conflict(phone) do update set owed_pence=excluded.owed_pence,credit_limit_pence=excluded.credit_limit_pence,due_at=excluded.due_at,blocked=excluded.blocked,status_label=excluded.status_label,updated_at=excluded.updated_at,source_rev=excluded.source_rev',(phone,owed,limit,(due or None),blocked,status,now(),str(rev)))
                c.commit();out=credit_state(c,phone);c.close();return send(self,200,{'ok':True,'credit':out})
            if path=='/api/integration/loyalty':
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
                body=json_body(self);phone=normalize_phone_input(body.get('phone'));points=body.get('points');rev=str(body.get('sourceRev',''))[:80]
                if not phone or isinstance(points,bool) or not isinstance(points,int) or points<0 or points>100000000:return send(self,400,{'error':'invalid loyalty snapshot'})
                c=db();c.execute('insert into v35_loyalty(phone,points,source_rev,updated_at) values(?,?,?,?) on conflict(phone) do update set points=excluded.points,source_rev=excluded.source_rev,updated_at=excluded.updated_at',(phone,points,rev,now()));c.commit();out=reward_state(c,phone);c.close();return send(self,200,{'ok':True,'reward':out})
            if path=='/api/integration/ack':
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                test_key=self.headers.get('X-Rocket-Test-Bridge','').strip()
                test_auth=bool(test_key and secrets.compare_digest(sha(test_key),TEST_BRIDGE_SHA256))
                if key!=INTEGRATION_KEY_FILE.read_text().strip() and not test_auth:return send(self,403,{'error':'integration key'})
                body=json_body(self);oid=str(body.get('orderId','')).strip();st=str(body.get('status','FORWARDED')).strip().upper()
                if test_auth:
                    c0=db();owned=c0.execute('select 1 from orders where id=? and phone=?',(oid,TEST_BRIDGE_PHONE)).fetchone();c0.close()
                    if not owned:return send(self,403,{'error':'test bridge scope'})
                if st not in ('FORWARDED','ASSIGNED','FIVE_MIN','HERE','CANCELLED','REJECTED','COMPLETE','REVIEW_REQUIRED'):return send(self,400,{'error':'invalid status'})
                c=db();o=c.execute('select id from orders where id=?',(oid,)).fetchone()
                if not o:c.close();return send(self,404,{'error':'order not found'})
                rocket=str(body.get('rocketOrderId','')).strip().upper()
                c.execute("update orders set status=?,rocket_order_id=coalesce(nullif(?,''),rocket_order_id) where id=?",(st,rocket,oid));c.commit();c.close();return send(self,200,{'ok':True})
            if path=='/api/integration/order-complete':
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
                body=json_body(self);oid=str(body.get('orderId','')).strip();paid=max(0,int(body.get('paidPence',0) or 0));c=db();c.execute('begin immediate');o=c.execute('select * from orders where id=?',(oid,)).fetchone()
                if not o:c.rollback();c.close();return send(self,404,{'error':'order not found'})
                phone=o['phone'];points_earned=0
                if not o['reward_applied'] and paid>0:
                    cust=c.execute('select * from customers where phone=?',(phone,)).fetchone();gross=cust['spend_remainder_pence']+paid;earned=(gross//500)*2;rem=gross%500
                    # rocket-dispatch is the order authority for this build (the V35
                    # mirror that used to own Rocket Points was removed - see
                    # docs/CUSTOMER_APP.md). Points are only awarded here when no
                    # external (V35) points balance exists for this phone, so we
                    # never run two points authorities at once (reward_state()
                    # applies the same v35-row-wins precedence when reading).
                    v35=c.execute('select 1 from v35_loyalty where phone=?',(phone,)).fetchone()
                    pgross=int(cust['points_remainder_pence'])+paid;cfg=loyalty_config(c);ppp=cfg['pointsPerPound']
                    if v35 or ppp<=0:
                        points_earned=0;prem=int(cust['points_remainder_pence'])
                    else:
                        pearn=(pgross//100)*ppp;prem=pgross%100
                        points_earned=pearn;add_points(c,phone,pearn,'Order '+oid,oid)
                    c.execute('update customers set spins=spins+?,spend_remainder_pence=?,points_remainder_pence=? where phone=?',(earned,rem,prem,phone))
                    c.execute('update orders set reward_applied=1,status=? where id=?',('COMPLETE',oid))
                c.commit();out=reward_state(c,phone);c.close();return send(self,200,{'ok':True,'reward':out,'pointsEarned':points_earned})
            if path=='/api/integration/points-credit':
                # Credits Rocket Points for an order that never existed as a
                # row in THIS app's own orders table - i.e. a customer who
                # ordered by real SMS/Tasker, not through the app. See
                # CHANGELOG_POINTS_UNIFICATION.md. /api/integration/order-
                # complete above requires an app-side order row to look up
                # (it 404s otherwise), so that endpoint can't be reused for
                # this - it's the app-originated path only.
                #
                # Takes paidPence, NOT a pre-computed point count - runs the
                # exact same remainder-carry points math as order-complete
                # above (points_remainder_pence), so an SMS order and an
                # app order earn identically under one formula. Computing
                # points in the caller (customer-relay) and just passing a
                # number would silently drift from that formula.
                #
                # externalRef is rocket-dispatch's own order id (e.g.
                # "R1234"), used purely as an idempotency key: the unique
                # index on points_ledger(phone, external_ref) makes a second
                # call with the same ref a safe no-op (customer-relay polls
                # repeatedly and does not itself track "already credited"),
                # not a double-credit.
                key=self.headers.get('X-Rocket-Integration-Key','').strip()
                if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
                body=json_body(self)
                phone=normalize_phone_input(body.get('phone'))
                paid=body.get('paidPence')
                ref=str(body.get('externalRef','')).strip()[:120]
                if not phone or not ref or isinstance(paid,bool) or not isinstance(paid,int) or paid<0 or paid>100000000:
                    return send(self,400,{'error':'invalid points credit'})
                c=db();c.execute('begin immediate')
                # Auto-create the account row: an SMS-only customer may never
                # have opened the app. Their points sit here waiting for
                # them, same as an app customer's would - see the "should a
                # points record be created automatically" decision in
                # CHANGELOG_POINTS_UNIFICATION.md.
                c.execute('insert or ignore into customers(phone) values(?)',(phone,))
                v35=c.execute('select 1 from v35_loyalty where phone=?',(phone,)).fetchone()
                points_earned=0;credited=False
                if not v35 and paid>0:
                    cust=c.execute('select * from customers where phone=?',(phone,)).fetchone()
                    pgross=int(cust['points_remainder_pence'])+paid;cfg=loyalty_config(c);ppp=cfg['pointsPerPound']
                    if ppp>0:
                        pearn=(pgross//100)*ppp;prem=pgross%100
                        try:
                            add_points(c,phone,pearn,'SMS order '+ref,ref)
                            c.execute('update customers set points_remainder_pence=? where phone=?',(prem,phone))
                            points_earned=pearn;credited=True
                        except sqlite3.IntegrityError:
                            # Already credited for this exact rocket-dispatch
                            # order (a repeat poll, or the adapter retrying
                            # after a dropped response) - not an error, and
                            # the remainder is deliberately NOT re-applied
                            # here (it already was, the first time).
                            c.rollback();c=db();c.execute('begin immediate')
                c.commit();out=reward_state(c,phone);c.close()
                return send(self,200,{'ok':True,'reward':out,'pointsEarned':points_earned,'credited':credited})
            if path=='/api/invite/redeem':
                if login_limited(self):return send(self,429,{'error':'Too many attempts. Try again later.'})
                body=json_body(self);code=str(body.get('code','')).strip().upper()
                if not re.fullmatch(r'[A-Z0-9-]{8,40}',code):login_fail(self);return send(self,400,{'error':'Invalid invite code'})
                c=db();r=c.execute('select * from invites where code_hash=?',(sha(code),)).fetchone()
                if not r or not r['active'] or r['used_count']>=r['max_uses'] or (r['expires_at'] and r['expires_at']<now()):c.close();login_fail(self);return send(self,403,{'error':'Invite code is invalid or already used'})
                tok=secrets.token_urlsafe(32);c.execute('update invites set used_count=used_count+1 where code_hash=?',(sha(code),));c.execute('insert into sessions(token_hash,phone,created_at,expires_at) values(?,?,?,?)',(sha(tok),r['phone'],now(),now()+30*86400));c.execute('insert or ignore into customers(phone) values(?)',(r['phone'],));needs_pin=not bool(c.execute('select pin_hash from customers where phone=?',(r['phone'],)).fetchone()['pin_hash']);c.commit();c.close();login_success(self);return send(self,200,{'token':tok,'needsPin':needs_pin,'phone':r['phone']})
            if path=='/api/pin/login':
                if login_limited(self):return send(self,429,{'error':'Too many attempts. Try again later.'})
                body=json_body(self);phone=normalize_phone_input(body.get('phone'));pin=str(body.get('pin','')).strip()
                last4=re.sub(r'\D','',str(body.get('last4','')))[-4:]
                c=db()
                if not phone and re.fullmatch(r'\d{4}',last4):
                    hits=[r['phone'] for r in c.execute('select phone from customers') if re.sub(r'\D','',r['phone'])[-4:]==last4]
                    if len(hits)==1: phone=hits[0]
                if not phone or not re.fullmatch(r'\d{4,6}',pin):c.close();login_fail(self);return send(self,400,{'error':'Enter your mobile details and PIN'})
                r=c.execute('select pin_salt,pin_hash from customers where phone=?',(phone,)).fetchone()
                ok=bool(r and r['pin_salt'] and r['pin_hash'])
                if ok:
                    try:ok=secrets.compare_digest(pin_digest(pin,r['pin_salt']),r['pin_hash'])
                    except Exception:ok=False
                if not ok:c.close();login_fail(self);return send(self,403,{'error':'Phone number or PIN is incorrect'})
                tok=secrets.token_urlsafe(32);c.execute('insert into sessions(token_hash,phone,created_at,expires_at) values(?,?,?,?)',(sha(tok),phone,now(),now()+30*86400));c.commit();c.close();login_success(self);return send(self,200,{'token':tok,'phone':phone})
            phone=token_phone(self)
            if not phone:return send(self,401,{'error':'Invite session required'})
            if path=='/api/pin/set':
                body=json_body(self);pin=str(body.get('pin','')).strip()
                if not re.fullmatch(r'\d{4,6}',pin):return send(self,400,{'error':'Choose a 4 to 6 digit PIN'})
                salt=secrets.token_hex(16);digest=pin_digest(pin,salt);c=db();c.execute('update customers set pin_salt=?,pin_hash=?,pin_set_at=? where phone=?',(salt,digest,now(),phone));c.commit();c.close();return send(self,200,{'ok':True})
            if path=='/api/session/logout':
                tok=bearer_value(self);c=db();c.execute('delete from sessions where token_hash=?',(sha(tok),));c.commit();c.close();return send(self,200,{'ok':True})
            if path=='/api/orders':
                body=json_body(self);cc=db();acct=credit_state(cc,phone);cc.close()
                if acct.get('available') and acct.get('blocked'):return send(self,403,{'error':'Your Rocket account is on hold. Please settle the outstanding balance before placing another order.','credit':acct})
                if body.get('paymentMethod')!='CASH':return send(self,400,{'error':'Rocket is cash only'})
                client_request_id=str(body.get('requestId','')).strip()
                if client_request_id and not re.fullmatch(r'[A-Za-z0-9_-]{8,80}',client_request_id):return send(self,400,{'error':'Invalid order request'})
                if client_request_id:
                    c0=db();old=c0.execute('select id,total_pence,payment_method from orders where client_request_id=? and phone=?',(client_request_id,phone)).fetchone()
                    if old:
                        reward=reward_state(c0,phone);out={'orderId':old['id'],'totalPence':old['total_pence'],'paymentMethod':old['payment_method'],'reward':reward,'duplicate':True};c0.close();return send(self,200,out)
                    c0.close()
                else:
                    client_request_id='srv_'+secrets.token_urlsafe(18)
                location=str(body.get('location','')).strip();note=str(body.get('note','')).strip()
                if not 3<=len(location)<=120:return send(self,400,{'error':'Add a clear meeting location'})
                if len(note)>180:return send(self,400,{'error':'Note is too long'})
                # Structured location, additive - all optional. rocket-dispatch's
                # own location resolution (postcode/street/venue/pin) runs
                # server-side in customer-relay/, never trusting a client-supplied
                # coordinate as "the" meeting point without going through it.
                postcode=str(body.get('postcode','')).strip().upper()[:10]
                if postcode and not re.fullmatch(r'[A-Z0-9 ]{2,10}',postcode):return send(self,400,{'error':'Invalid postcode'})
                street=str(body.get('street','')).strip()[:60]
                venue=str(body.get('venue','')).strip()[:80]
                pin_lat=body.get('pinLat');pin_lng=body.get('pinLng')
                try:
                    pin_lat=float(pin_lat) if pin_lat is not None else None
                    pin_lng=float(pin_lng) if pin_lng is not None else None
                except (TypeError,ValueError):
                    return send(self,400,{'error':'Invalid shared location pin'})
                if (pin_lat is None)!=(pin_lng is None):return send(self,400,{'error':'Invalid shared location pin'})
                if pin_lat is not None and not(-90<=pin_lat<=90 and -180<=pin_lng<=180):return send(self,400,{'error':'Invalid shared location pin'})
                items=body.get('items') or []
                if not isinstance(items,list) or not items or len(items)>20:return send(self,400,{'error':'Basket is invalid'})
                pm=product_map();clean=[];total=0;body_parts=[]
                for it in items:
                    code=str(it.get('code','')).upper();qty=int(it.get('qty',0) or 0);p=pm.get(code)
                    if not p or qty<1 or qty>30:return send(self,400,{'error':'One or more basket items are unavailable'})
                    clean.append({'code':code,'qty':qty});total+=price_line(p,qty);body_parts.append(str(qty)+' '+p['name'])
                c=db();oid='W'+secrets.token_hex(8).upper()
                try:
                    c.execute('insert into orders(id,phone,items_json,location,note,total_pence,payment_method,status,created_at,client_request_id,postcode,street,venue,pin_lat,pin_lng) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(oid,phone,json.dumps(clean,separators=(',',':')),location,note,total,'CASH','PENDING_DISPATCH',now(),client_request_id,postcode or None,street or None,venue or None,pin_lat,pin_lng))
                    c.commit()
                except sqlite3.IntegrityError:
                    c.rollback();old=c.execute('select id,total_pence,payment_method from orders where client_request_id=? and phone=?',(client_request_id,phone)).fetchone()
                    if not old: c.close();raise
                    reward=reward_state(c,phone);out={'orderId':old['id'],'totalPence':old['total_pence'],'paymentMethod':old['payment_method'],'reward':reward,'duplicate':True};c.close();return send(self,200,out)
                # Dispatch pickup reads the encrypted orders table via /api/integration/pending.
                # Do not duplicate customer/order data into a plaintext outbox file.
                reward=reward_state(c,phone);c.close();return send(self,200,{'orderId':oid,'totalPence':total,'paymentMethod':'CASH','reward':reward})
            if path=='/api/loyalty/redeem':
                # rocket-dispatch's own local points ledger IS the authority now
                # (see docs/CUSTOMER_APP.md "Rewards / points / Frenzy") - this
                # was disabled in the vendored original pending an "atomic V35
                # points-spend bridge" that was never finished; that
                # V35-specific blocker no longer applies. Still: atomic
                # (single transaction, points checked and debited under the
                # same connection that awards the prize), still idempotent on
                # requestId (never debit the same redemption twice on retry),
                # and the cost is read from server-side config, never from
                # the client.
                body=json_body(self);code=str(body.get('code','')).strip().upper()
                request_id=str(body.get('requestId','')).strip()
                if not re.fullmatch(r'[A-Za-z0-9_-]{8,80}',request_id):return send(self,400,{'error':'Invalid redemption request'})
                c=db()
                old=c.execute('select result_json from loyalty_redemptions where phone=? and request_id=?',(phone,request_id)).fetchone()
                if old:
                    out=json.loads(old['result_json']);out['duplicate']=True;c.close();return send(self,200,out)
                cfg=loyalty_config(c);entry=next((p for p in cfg['redemptions'] if str(p.get('code','')).upper()==code),None)
                if not entry:c.close();return send(self,400,{'error':'Unknown reward'})
                cost=int(entry['costPoints'])
                cust=c.execute('select points from customers where phone=?',(phone,)).fetchone()
                if not cust or int(cust['points'])<cost:
                    rw=reward_state(c,phone);c.close();return send(self,400,{'error':'Not enough Rocket Points','reward':rw})
                try:
                    c.execute('begin immediate')
                    add_points(c,phone,-cost,'Redeemed: '+str(entry.get('label','Reward'))[:80],request_id)
                except ValueError:
                    c.rollback();c.close();return send(self,400,{'error':'Not enough Rocket Points'})
                try:
                    prize=apply_loyalty_prize(c,phone,entry,request_id)
                    reward=reward_state(c,phone);vault=vault_state(c,phone)
                    out={'prize':prize,'reward':reward,'vault':vault}
                    c.execute('insert into loyalty_redemptions(phone,request_id,code,cost_points,label,result_json,at) values(?,?,?,?,?,?,?)',(phone,request_id,code,cost,str(entry.get('label','Reward'))[:80],json.dumps(out,separators=(',',':')),now()))
                    c.commit()
                except Exception:
                    c.rollback();c.close();raise
                c.close();return send(self,200,out)
            if path=='/api/scratch/reveal':
                c=db();day=time.strftime('%Y-%m-%d',time.localtime())
                old=c.execute('select * from scratch_claims where phone=? and day_key=?',(phone,day)).fetchone()
                if old:
                    out={'winner':bool(old['winner']),'label':old['label'],'icon':old['icon'],'kind':old['kind'],'value':old['value'],'reward':reward_state(c,phone),'vault':vault_state(c,phone)}
                    c.close();return send(self,200,out)
                roll=secrets.randbelow(100)
                winner=False;label='Better luck next time';icon='🚀';kind='NONE';value=0
                if roll<15:
                    winner=True;label='2 Bonus Spins';icon='🚀';kind='SPINS';value=2
                    c.execute('update customers set spins=spins+2 where phone=?',(phone,))
                elif roll<25:
                    winner=True;label='Free Snack';icon='🍬';kind='VAULT';value=1
                    c.execute('insert into vault(phone,code,label,icon,status,won_at) values(?,?,?,?,?,?)',(phone,'SCRATCH_SNACK',label,icon,'ACTIVE',now()))
                elif roll<30:
                    winner=True;label='10% Off Next Order';icon='🏷️';kind='VAULT';value=10
                    c.execute('insert into vault(phone,code,label,icon,status,won_at) values(?,?,?,?,?,?)',(phone,'SCRATCH10',label,icon,'ACTIVE',now()))
                c.execute('insert into scratch_claims(phone,day_key,winner,label,icon,kind,value,created_at) values(?,?,?,?,?,?,?,?)',(phone,day,1 if winner else 0,label,icon,kind,value,now()))
                c.commit();out={'winner':winner,'label':label,'icon':icon,'kind':kind,'value':value,'reward':reward_state(c,phone),'vault':vault_state(c,phone)}
                c.close();return send(self,200,out)
            if path=='/api/spins':
                c=db();cust=c.execute('select * from customers where phone=?',(phone,)).fetchone()
                if not cust or cust['spins']<1:c.close();return send(self,400,{'error':'No free spins ready'})
                c.execute('update customers set spins=spins-1 where phone=?',(phone,))
                pools=list(c.execute('select * from prize_pool where remaining>0'));cfg=loyalty_config(c)
                winner=bool(pools) and secrets.randbelow(100)<cfg['slotWinPercent']
                label='No prize this spin';pattern=['⭐','🐟','🪙','🐚','🚀']
                if winner:
                    total_rem=sum(r['remaining'] for r in pools);pick=secrets.randbelow(total_rem);acc=0;chosen=pools[0]
                    for r in pools:
                        acc+=r['remaining']
                        if pick<acc:chosen=r;break
                    c.execute('update prize_pool set remaining=remaining-1 where code=?',(chosen['code'],))
                    label=chosen['label'];pattern=['🚀','🚀','🎁','🚀','🚀'];c.execute('insert into vault(phone,code,label,icon,status,won_at) values(?,?,?,?,?,?)',(phone,chosen['code'],chosen['label'],chosen['icon'],'ACTIVE',now()))
                    if chosen['kind']=='SPINS':c.execute('update customers set spins=spins+2 where phone=?',(phone,))
                result={'winner':winner,'label':label,'pattern':pattern}
                c.execute('insert into spins(phone,at,winner,prize_code,result_json) values(?,?,?,?,?)',(phone,now(),1 if winner else 0,(chosen['code'] if winner else None),json.dumps(result,separators=(',',':'))))
                c.commit();out={'winner':winner,'label':label,'pattern':pattern,'reward':reward_state(c,phone),'vault':vault_state(c,phone),'weeklyPrizes':weekly_prizes(c)};c.close();return send(self,200,out)
            return send(self,404,{'error':'not found'})
        except Exception as e:
            print('POST_ERROR',repr(e),flush=True);return send(self,500,{'error':'Server error'})
    def do_GET(self):
        path=urlparse(self.path).path
        if path.startswith(('/data/','/integration/','/tools/')) or path in ('/server.py','/FIRST_INVITE.txt','/INTEGRATION_KEY.txt','/README.txt'):
            return send(self,404,{'error':'not found'})
        if path=='/api/health':return send(self,200,{'ok':True,'service':'rocket-customer-staging','cashOnly':True,'inviteOnly':True})
        if path=='/api/integration/pending':
            key=self.headers.get('X-Rocket-Integration-Key','').strip()
            test_key=self.headers.get('X-Rocket-Test-Bridge','').strip()
            test_auth=bool(test_key and secrets.compare_digest(sha(test_key),TEST_BRIDGE_SHA256))
            if key!=INTEGRATION_KEY_FILE.read_text().strip() and not test_auth:return send(self,403,{'error':'integration key'})
            c=db();rows=[]
            query="select * from orders where status='PENDING_DISPATCH'"
            args=()
            if test_auth: query+=" and phone=?";args=(TEST_BRIDGE_PHONE,)
            query+=" order by created_at,id limit 20"
            for o in c.execute(query,args):
                items=json.loads(o['items_json']);pm=product_map(c);parts=[]
                for it in items:
                    p=pm.get(it['code']);parts.append(str(it['qty'])+' '+(p['name'] if p else it['code']))
                rows.append({'orderId':o['id'],'phone':o['phone'],'body':' and '.join(parts)+' '+o['location'],'note':o['note'] or '','totalPence':o['total_pence'],'paymentMethod':'CASH','createdAt':o['created_at'],'rocketOrderId':o['rocket_order_id'] or '',
                             'items':[{'code':it['code'],'qty':it['qty'],'name':(pm.get(it['code']) or {}).get('name',it['code'])} for it in items],
                             'location':{'text':o['location'],'postcode':o['postcode'],'street':o['street'],'venue':o['venue'],'pinLat':o['pin_lat'],'pinLng':o['pin_lng']}})
            c.close();return send(self,200,{'orders':rows})
        if path=='/api/integration/mappings':
            key=self.headers.get('X-Rocket-Integration-Key','').strip()
            if key!=INTEGRATION_KEY_FILE.read_text().strip():return send(self,403,{'error':'integration key'})
            c=db();rows=[{'orderId':r['id'],'rocketOrderId':r['rocket_order_id'],'status':r['status'],'phone':r['phone']} for r in c.execute("select id,rocket_order_id,status,phone from orders where rocket_order_id is not null and rocket_order_id!='' and status not in ('COMPLETE','CANCELLED','REJECTED') order by created_at,id limit 100")];c.close();return send(self,200,{'orders':rows})
        if path=='/api/bootstrap':
            phone=token_phone(self)
            if not phone:return send(self,401,{'error':'Invite session required'})
            c=db();inv=c.execute('select label,area_label from invites where phone=? order by rowid desc limit 1',(phone,)).fetchone();red=loyalty_public(c)
            cur=c.execute("select * from orders where phone=? order by created_at desc limit 1",(phone,)).fetchone()
            out={'profile':{'name':inv['label'] if inv else 'Customer','areaLabel':inv['area_label'] if inv else 'Nailsea, BS48'},'menu':effective_menu(c),'reward':reward_state(c,phone),'weeklyPrizes':weekly_prizes(c),'vault':vault_state(c,phone),'credit':credit_state(c,phone),'loyaltyRedemptions':red,'cashOnly':True,'currentOrder':order_public(cur) if cur and not order_public(cur)['final'] else None}
            c.close();return send(self,200,out)
        if path=='/api/account':
            phone=token_phone(self)
            if not phone:return send(self,401,{'error':'Invite session required'})
            c=db();cur=c.execute("select * from orders where phone=? order by created_at desc limit 1",(phone,)).fetchone()
            cp=order_public(cur)
            out={'menu':effective_menu(c),'reward':reward_state(c,phone),'credit':credit_state(c,phone),'currentOrder':cp if cp and not cp['final'] else None,'cashOnly':True}
            c.close();return send(self,200,out)
        if path=='/api/orders/current':
            phone=token_phone(self)
            if not phone:return send(self,401,{'error':'Invite session required'})
            c=db();cur=c.execute("select * from orders where phone=? order by created_at desc limit 1",(phone,)).fetchone();c.close()
            return send(self,200,{'order':order_public(cur)})
        return super().do_GET()

# The V35-specific binding module and the external points_runtime module
# (both from the original vendored handover) are intentionally not imported
# here. rocket-dispatch is the new order/dispatch authority per the
# developer prompt ("do not make V35/old Tasker the new authority") - the
# handlers above already implement a complete, non-V35 local order/menu/
# reward flow, which is what actually runs now. See docs/CUSTOMER_APP.md.

if __name__=='__main__':
    init_db();port=int(os.environ.get('PORT','8930'));print('Rocket Customer staging listening on',port,flush=True);ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
