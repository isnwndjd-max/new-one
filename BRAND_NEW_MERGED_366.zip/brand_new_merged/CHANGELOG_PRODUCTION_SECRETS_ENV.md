# Production secret environment wiring

This build keeps real production secrets out of `data/config.json` and allows the server process to provide them at runtime.

Environment variables:

- `ROCKET_BOSS_TOKEN` -> overrides `config.boss.token`
- `ROCKET_GATEWAY_TOKEN` -> overrides `config.gateway.token`
- `ROCKET_GPS_FORWARD_TOKEN` -> overrides `config.gps.forwardToken`
- `ROCKET_STATE_KEY` -> 64 hexadecimal characters / 32 bytes for AES-256-GCM state encryption

`ROCKET_ENV=staging` or `ROCKET_ENV=production` keeps the existing startup guard active. Placeholder API tokens or the public development state key cause startup to be refused.

`ROCKET_STATE_KEY` must remain stable for an installation. Changing it without migrating/re-encrypting `state.json` makes the existing encrypted state unreadable.

Verification: `node --test test/*.test.js` -> 366 passing, 0 failing, 0 skipped.
