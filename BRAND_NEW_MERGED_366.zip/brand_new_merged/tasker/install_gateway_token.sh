#!/usr/bin/env bash
set -euo pipefail

# Creates a local deployment env file for Rocket Dispatch.
# It does NOT edit data/config.json, restart services, or deploy anything.
OUT="${1:-.rocket-gateway.env}"
TOKEN="${ROCKET_GATEWAY_TOKEN:-b33457856e0cef1db5f0e910cead3074dbc22348e990b26c}"
umask 077
printf 'export ROCKET_GATEWAY_TOKEN=%q\n' "$TOKEN" > "$OUT"
chmod 600 "$OUT"
echo "Wrote $OUT with mode 600."
echo "Source it (or copy the value into your systemd/PM2 service environment) before starting Rocket."
echo "You still need ROCKET_BOSS_TOKEN, ROCKET_GPS_FORWARD_TOKEN, ROCKET_STATE_KEY and ROCKET_ENV=production."
