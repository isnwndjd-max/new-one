# Tasker setup — read this before trusting the import

## Why this exists as a separate document

The build's own README explicitly declined to hand over Tasker XML earlier,
because this sandbox has no Android to actually test an import against —
handing over unverified XML risks it silently doing the wrong thing on a
real phone. That constraint hasn't changed. What's different now: instead
of leaving it undone, I researched Tasker's actual (largely
community-reverse-engineered, not officially published) XML format against
primary sources — Tasker's own developer documentation and the developer's
own posts in Tasker's official Google Group — rather than generating XML
from memory. Sources are listed at the bottom.

That research got most of this file on solid ground. One piece stayed a
genuine guess even after that research, and rather than ship a guess
dressed up as verified, it's cut from the XML entirely and replaced with a
manual step below (bullet 4). Go through this whole document — with the
Tasker app open — before turning either profile on for real.

## What's in `RocketDispatchSMSGateway.prj.xml`

- **Profile "RD - SMS In"** → **Task "RD - SMS In"**: fires on every
  received SMS, forwards `{from, text, messageId}` to `POST /sms/inbound`.
  Captures the SMS variables as the very first action (not after some other
  setup work) and skips forwarding if the message body is empty, rather
  than send a blank message.
- **Task "RD - SMS Out Poll"** (no profile attached yet — see step 4):
  polls `GET /sms/outbound/pending`, sends each message with Tasker's own
  `sendSMS()`, checks its actual return value before acknowledging, then
  acknowledges with `POST /sms/outbound/ack`.

It imports as its own project, **"Rocket Dispatch SMS Gateway"**, so it
can't overwrite or collide with anything already in your Tasker config.

## New this session: three real fixes

1. **Reliable incoming SMS variables.** `%SMSRF`/`%SMSRB` are Tasker's own
   *global* "last received text" variables, not values scoped to one event
   firing — if another text arrives while this task is still mid-run, those
   globals can be overwritten before this run finishes reading them. Task 1
   now captures them into *local* variables as its very first action,
   before any network call, which is the standard mitigation (it narrows
   the window to as small as Tasker allows; it can't close it to zero —
   that's a real, if narrow, Android-side race, not a bug in this file). It
   also now explicitly skips forwarding when the body is empty — a
   documented, confirmed case (`%SMSRB` is only set for SMS, not MMS), so
   an MMS that mis-triggers "Received Text" doesn't get forwarded as a
   blank message.
2. **Confirm the SMS actually sent before acknowledging it.** Tasker's
   `sendSMS()` returns a boolean, but the previous version of this file
   only checked whether the call *threw* — it never read that return
   value. So a call that returned `false` without throwing would have been
   silently acknowledged as sent. Fixed: the return value is now checked.
   Tasker's own docs are explicit, though, that this return value "reflects
   whether the function executed without errors, not whether the SMS
   reached its recipient" — there's no stronger delivery confirmation
   available from JavaScript. A real send/fail confirmation exists in
   Tasker (the "SMS Success"/"SMS Failure" events), but only for its native
   Send SMS action, and this session couldn't verify that action's or those
   events' exact field layout against a real device — see **"5a. Stronger
   send confirmation (optional, recommended)"** below for how to add it by
   hand, the same reasoning already applied to the polling schedule.
3. **Secured the phone↔server connection.** `/sms/inbound`, `/sms/outbound/*`
   and every `/driver/*` endpoint previously had **no authentication at
   all** — anyone who could reach the server's port could inject a fake
   customer order or a fake driver reply. Both tasks now send an
   `X-Gateway-Token` header on every request, checked against
   `config.gateway.token` in the server's `data/config.json`. **This is a
   shared secret, not encryption** — see step 2a below for making the
   connection itself private.

## 1. Import

In Tasker: the project list → long-press (or the menu, depending on your
layout) → **Import** → point it at `RocketDispatchSMSGateway.prj.xml`. On
6.7.6 beta the exact menu wording may differ slightly from stable — if
"Import" isn't where you expect it, Tasker's own project-list overflow menu
is the place to look.

If the import is rejected outright (not just "looks wrong once open," but
refused to import at all), that means something in the XML structure itself
is invalid — tell me the exact error and I'll fix the file. That would be a
real mistake on my part, not the "double-check this" caveats below.

## 2. Set your server address and gateway token (required, in both tasks)

Each task has two `Variable Set` actions near the top:

- **`%rd_url`**, set to `http://127.0.0.1:8787`. That's a placeholder —
  `127.0.0.1` from the phone's own perspective is the phone itself, not
  wherever `server/index.js` is actually running. Change it in **both**
  tasks to:
  - the machine's LAN IP if the server runs on a computer on the same
    Wi-Fi (e.g. `http://192.168.1.50:8787`),
  - a Tailscale/VPN address if it's remote (see 2a below — recommended),
  - or `http://127.0.0.1:8787` really is correct only if the server runs
    **on the phone itself** via Termux.
- **`%rd_token`**, set to `CHANGE_ME_BEFORE_GOING_LIVE`. Change it in
  **both** tasks to match `config.gateway.token` in the server's
  `data/config.json` — and change *that* from its own placeholder first.
  If these don't match, the server refuses every request with HTTP 401 and
  Tasker will flash a "could not forward SMS" / "could not fetch pending"
  warning. This is what closes the gap described above — without a real
  token here, the fix on the server side is just refusing Tasker too.

### 2a. Securing the connection itself

The token above stops someone from *impersonating* Tasker once they can
reach the server; it does nothing to stop someone *reading* the traffic in
between if it travels as plain `http://` over a network you don't fully
trust (e.g. the open internet to a VPS). Two real options, either is fine:

- **Tailscale (simplest):** put the phone and the server on the same
  Tailscale network and use the server's Tailscale address for `%rd_url`.
  Tailscale traffic is already encrypted point-to-point, so plain `http://`
  over it is fine — you're not exposing anything to the open internet at
  all, and there's no certificate to manage.
- **A real `https://` URL:** put a reverse proxy in front of
  `server/index.js` (e.g. Caddy, which gets a free Let's Encrypt
  certificate automatically for a real domain name) and point `%rd_url` at
  `https://your-domain:port`. Tasker's HTTP Request action and
  `XMLHttpRequest` both handle `https://` URLs with no extra configuration
  needed on the Tasker side.

Running plain `http://` to a public IP with only the gateway token for
protection is the one combination to avoid — the token would then be
visible to anything between the phone and the server.

## 3. Verify each action against this checklist

This is the important part, and it's exactly what you said you'd do —
go over it before trusting it. For each action below, tap it open in the
Tasker UI and confirm it shows what's described. Tasker renders the
*actual* field it parsed using its own real field names, so if something
landed in the wrong slot, it'll be visibly wrong here — an empty Method
field, a URL in the Headers box, etc. — not a hidden bug you'd only find
once it's live.

**Confidence key:** ✅ = confirmed against Tasker's own docs or the
developer's own words (linked at the bottom). ⚠️ = my best-grounded
construction, not independently confirmed — check this one first.

| Action | What it should show | Confidence |
|---|---|---|
| Task "RD - SMS In", action 1 | JavaScriptlet capturing `SMSRF`/`SMSRB` into locals, with the empty-body guard | ✅ |
| Task "RD - SMS In", action 2 | Variable Set: Name `rd_url`, To your server URL | ✅ |
| Task "RD - SMS In", action 3 | Variable Set: Name `rd_token`, To your gateway token | ✅ |
| Task "RD - SMS In", action 4 | JavaScriptlet with the `XMLHttpRequest` POST to `/sms/inbound`, including `X-Gateway-Token` | ✅ (same `XMLHttpRequest`/`setRequestHeader` mechanism the outbound ack already used) |
| Task "RD - SMS Out Poll", action 1 | Variable Set: Name `rd_url`, To your server URL | ✅ |
| Task "RD - SMS Out Poll", action 2 | Variable Set: Name `rd_token`, To your gateway token | ✅ |
| Task "RD - SMS Out Poll", action 3 | HTTP Request: Method `GET`, URL `%rd_url/sms/outbound/pending`, Headers `X-Gateway-Token:%rd_token`, Timeout `15` | ⚠️ field *names* and output variables (`%http_data`, `%http_response_code`) are confirmed; exactly which value landed in which field is the one thing to eyeball here |
| Task "RD - SMS Out Poll", action 4 | JavaScriptlet with `sendSMS(...)` (return value checked), and the `XMLHttpRequest` ack with `X-Gateway-Token` | ✅ |
| Profile "RD - SMS In" | Event: Received Text, Sender blank, Content blank | ✅ (blank fields = match any sender/content) |

If the HTTP Request action shows a field empty or in the wrong place: it's
a one-field fix, not a rebuild — retype that field with the value shown in
the XML comment above it (the action is commented in the file itself with
what each argument is for).

## 4. The one thing left to build by hand: the polling schedule

`RD - SMS Out Poll` imports as a plain task with **no profile** attached —
deliberately. A repeating "every N minutes" trigger is a Profile *context*
in Tasker (Time state), and its internal XML shape is genuinely not
something I found a reliable source for. Guessing that risked a profile
that looks fine, imports fine, but never actually fires — worse than
leaving it out, since it wouldn't fail loudly. Two ways to wire it up,
depending on how fast you need replies to go out:

### 4a. Simple (1-minute floor) — Time-context profile

This is the standard, well-documented way anyone sets up polling in
Tasker. **Confirmed limitation, not a guess on my part:** Tasker's Time
context only supports **1-minute granularity** on the "Every" field — there
is no seconds option, and this is a known, long-standing gap (there's even
an [open Tasker feature request](https://tasker.helprace.com/i365-increase-granularity-of-state-time-every-to-seconds)
asking for second-level granularity that has never been implemented). So
"every 1 Minute" is the fastest this method can go — you can't type a
smaller number and get anything faster.

1. New profile → **State** → **Time**.
2. From `00:00`, To `23:59`.
3. Turn on **Repeat**, set it to every **1 Minutes** (the minimum).
4. Attach it to the existing **"RD - SMS Out Poll"** task (don't create a
   new one — pick the imported task from the list).

Worst-case delay on a reply going out: just under 60 seconds.

### 4b. Faster — self-looping task (poll every few seconds)

If a minute is too slow, the standard Tasker workaround for sub-minute
polling isn't a Time profile at all — it's a task that calls itself in a
loop with a short **Wait** in between, kicked off once rather than
re-triggered on a schedule. This is a well-known, widely-documented Tasker
pattern (not something specific to this project), built entirely from the
Tasker UI so there's no XML to get wrong:

1. Open the imported **"RD - SMS Out Poll"** task and go to its end (after
   the existing JavaScriptlet action).
2. Add action **Task → Wait**. Set it to however often you want to check —
   **5–10 seconds** is a reasonable floor; going much lower burns battery
   for little practical benefit, since the server itself only ticks every
   2 seconds internally.
3. Add action **Task → Perform Task**, and set it to call **"RD - SMS Out
   Poll"** — itself. This is what turns "run once" into "run forever":
   each run waits, then hands off to a fresh run of itself.
4. Now give it exactly one way to start: create a new profile with
   whatever trigger you want the loop to begin on — **Event → System →
   Device Boot** (so it restarts automatically after every reboot) is the
   usual choice — and attach it to **"RD - SMS Out Poll"**. Do **not** also
   attach a Time-repeat profile to it as well, or you'll get two loops
   running in parallel, double-polling and double-sending.
5. To stop it (e.g. before editing the task further), either reboot the
   phone or add a second small task with a **Kill Perform Task Chain** or
   **Stop** action, run manually, that kills this task's chain — otherwise
   it keeps running until the phone restarts.

**One real tradeoff to know about:** Android's battery-saving "Doze" mode
can pause background loops like this one when the screen's been off a
while, the same way it can delay plain SMS broadcast delivery (see "What
this still doesn't cover" below). A Time-context profile (4a) is generally
more Doze-resistant than a self-looping Wait chain, because Tasker
registers it as a proper alarm with Android rather than a task sitting in
a Wait. If you go this route, exempt Tasker from battery optimization
(Android Settings → Battery → Tasker → Unrestricted) or the "faster" loop
can end up slower than the 1-minute profile once the screen's been off for
a while.

You'll see either version fire in Tasker's own run log, which is a better
check than anything I could put in the XML.

## 4a. Stronger send confirmation (optional, recommended)

What ships in the XML acks a message once `sendSMS()` returns `true` -
which Tasker's own docs say means "executed without errors," not
"delivered." For most setups that's a reasonable line to stop at, and it's
already better than the previous version of this file (which didn't even
check that). If you want the real thing - genuine send/fail confirmation
from Android itself - Tasker has it, but only for its **native** Send SMS
action, and only I couldn't verify the exact field layout of that action or
the two events below against a real device, so rather than guess it into
the XML, here's how to add it yourself, the same way as the polling
schedule above:

1. In `RD - SMS Out Poll`, after the JavaScriptlet that parses the pending
   messages, add a **native "Send SMS"** action (search for it when adding
   a new action - it's a built-in Tasker action, not one from this
   project). Set its Number and Message fields to `%m_to` / `%m_text` (or
   whatever variable names you use if you adapt the loop to set them per
   message - the shipped JS loop calls `sendSMS()` directly per message
   rather than setting per-message variables, so wiring this in means
   adjusting that loop to send one message per task run instead, storing
   the current message's `to`/`text`/`id` in variables the native action
   and the two profiles below can all see).
2. New profile → **Event** → search for **"SMS Success"**. If it offers an
   optional phone-number field, set it to match the number you just sent
   to, so this doesn't fire for unrelated texts. Attach it to a small new
   task that acks the message (reads the id you stored, POSTs
   `{id, ok: true}` to `/sms/outbound/ack` with the gateway token header,
   same shape as the existing ack call).
3. New profile → **Event** → search for **"SMS Failure"**. Same idea,
   acking `{id, ok: false}` instead.
4. Tap each new action/event open and confirm the fields match what you
   set, the same as step 3's checklist above - this is exactly the
   situation that checklist exists for.

This is real, native-Android send confirmation once wired up - just not
something this session could responsibly hand you as pre-built XML without
ever having seen it rendered on a device.

## 5. Test before going live

1. Start `server/index.js` (`ROCKET_PORT` defaults to 8787) somewhere
   reachable at the URL you set in step 2, with `config.gateway.token` in
   `data/config.json` changed from its placeholder.
2. Register and bring on a driver so there's somewhere for a test order to
   go: `curl -X POST http://<server>/driver/register -d '{"id":"D1"}' -H 'Content-Type: application/json' -H 'X-Gateway-Token: <your token>'`
   then send `ON` from the driver channel (`POST /driver/inbound`, same
   header).
3. Text the phone running Tasker: `hi`. Within a few seconds you should
   see `RD - SMS In` fire in Tasker's run log, and `GET /health` on the
   server should show `pendingSms` go up then back to 0 once the reply
   comes back through `RD - SMS Out Poll`. You should receive the menu
   text back on the phone.
4. Walk through a full order (as in the project's own
   `test/server.e2e.test.js`) with a real test phone number before
   pointing this at real customers.

## What this still doesn't cover

- **No driver-side automation.** The driver channel (`/driver/*`) has no
  Tasker profile here — per the original build, that's meant for a future
  Signal adapter, not SMS, so there's nothing to automate on this side yet.
- **Battery/background restrictions.** Some Android builds aggressively
  kill background apps or delay SMS broadcast delivery to save battery.
  If `RD - SMS In` doesn't fire reliably, check Tasker's battery
  optimization exemption and notification-listener permissions — standard
  Tasker setup, not specific to this project.
- **Send SMS default-app requirements.** Some Android versions restrict
  programmatic SMS sending unless Tasker (or an app it delegates to) is
  the default SMS app, or unless `SEND_SMS` permission is granted
  explicitly. If `sendSMS()` silently does nothing, check Tasker's SMS
  permission under Android Settings first.
- **Send delivery is "submitted OK," not "carrier-confirmed delivered."**
  Even with the return-value fix this session made, `sendSMS()` can only
  tell you Android accepted the send request, never that the carrier
  actually delivered it - no Tasker JS function exposes that. Section 4a
  above covers the stronger (but manual) native-action path if you need it.
- **The gateway token is a shared secret, not encryption.** It stops
  impersonation once someone can reach the server; it does nothing for
  eavesdropping on plain `http://` over an untrusted network. See step 2a.
- **Still not run against a real phone.** Same honesty as the GPS
  integration: this is grounded in real documentation, not a real test.
  Section 5 above is that real test — do it before anything touches a real
  customer.

## Sources used while building this

- [Tasker: HTTP Request action](https://tasker.joaoapps.com/userguide/en/help/ah_http_request.html) — field names, `%http_data`, Headers field format (one `Key:Value` per line)
- [Tasker Google Group: HTTP Request field order and `%http_response_code`](https://groups.google.com/g/tasker/c/mmVBsQoi1Pg) — confirmed by the Tasker developer
- [Tasker: Send SMS action](https://tasker.joaoapps.com/userguide/en/help/ah_send_sms.html) — no built-in delivery confirmation; "success or failure can be caught by creating an Event context SMS Success/Failure"
- [Tasker: "SMS Success" event](https://tasker.joaoapps.com/userguide/en/help/eh_sms_success.html) and [Tasker Google Group: `sendSMS()` return value semantics](https://groups.google.com/d/topic/tasker/qWTXO1o6EoY) — confirms the event exists and applies to the native Send SMS action; confirms `sendSMS()`'s return value means "executed without error," not delivery
- [Tasker: JavaScript support](https://tasker.joaoapps.com/userguide/en/javascript.html) — `local()`/`global()`/`setLocal()`/`setGlobal()`, `sendSMS()`, `flash()`, JSON/XMLHttpRequest availability
- [Tasker: Variables reference](https://tasker.joaoapps.com/userguide/en/variables.html) — `%SMSRF`, `%SMSRN`, `%SMSRB`, `%SMSRD`, `%SMSRT`, and that these are global, not per-event-scoped
- [Tasker Google Group: "%SMSRB isn't set every time"](https://groups.google.com/g/tasker/c/zRtYlKaFkeg) — confirms `%SMSRB` is only set for SMS, not MMS, motivating this session's empty-body guard
- [Tasker: Time Context](https://tasker.joaoapps.com/userguide/en/timecontext.html) — confirms the repeat/polling feature exists (From/To/Every)
- [Tasker-XML-Info (Taskomater)](https://github.com/Taskomater/Tasker-XML-Info/blob/master/Tasker_XML_Codes.md) — action/event numeric codes (`339` HTTP Request, `41` Send SMS - referenced in 4a, not used in the shipped XML, `129` JavaScriptlet, `547` Variable Set, `7` Received Text event, `2005`/`2010` SMS Success/Failure events - referenced in 4a only, field layout unverified)
- [Tasker forum: using Tasker to text an ETA](https://groups.google.com/g/tasker/c/R8hexexzPvM) — confirmed `sendSMS()` is callable directly from a JavaScriptlet, which is why this design uses it instead of guessing the native Send SMS action's field layout
