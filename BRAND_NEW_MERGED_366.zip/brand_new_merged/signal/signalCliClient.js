'use strict';

/*
 * A thin client for signal-cli's OWN JSON-RPC daemon mode - not the
 * bbernhard/signal-cli-rest-api wrapper this project used before. Talks
 * directly to `signal-cli -a <number> daemon --socket <path>` (or
 * `daemon --tcp`) over a persistent newline-delimited JSON-RPC 2.0
 * connection, per signal-cli's own documentation
 * (github.com/AsamK/signal-cli/blob/master/man/signal-cli-jsonrpc.5.adoc):
 *
 *   - Every request/notification is exactly one JSON object per line.
 *   - A "send" request looks like:
 *     {"jsonrpc":"2.0","method":"send","params":{"recipient":["+123..."],"message":"hi"},"id":4}
 *     and gets a matching {"jsonrpc":"2.0","id":4,"result":{...}} response.
 *   - Incoming messages arrive UNSOLICITED as JSON-RPC notifications (no
 *     id), method "receive", with the same envelope shape (source,
 *     sourceNumber, timestamp, dataMessage.message) signal-cli-rest-api's
 *     own /v1/receive endpoint mirrors - which is why signal/adapter.js's
 *     envelope-parsing logic didn't need to change, only the transport
 *     underneath it.
 *
 * This is a persistent connection, not a poll loop - "receiving" here
 * means "the daemon already pushed it to us," so the adapter just drains
 * whatever arrived since the last check, via the onReceive callback.
 */

const net = require('net');

function createSignalCliClient({
  socketPath,
  host,
  port,
  account,
  onReceive = () => {},
  log = () => {},
  connectImpl, // test hook: () => a net.Socket-like duplex stream, already connecting
} = {}) {
  if (!connectImpl && !socketPath && !(host && port)) {
    throw new Error('createSignalCliClient needs socketPath, or host+port, for the signal-cli daemon (or connectImpl for tests)');
  }

  let socket = null;
  let buffer = '';
  let nextId = 1;
  let connected = false;
  const pending = new Map(); // id -> { resolve, reject, timer }

  function handleLine(line) {
    if (!line.trim()) return;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch (e) {
      log(`signal-cli sent a line that isn't valid JSON, ignored: ${e.message}`);
      return;
    }
    if (msg.method === 'receive') {
      onReceive(msg.params || {});
      return;
    }
    if (msg.id != null && pending.has(msg.id)) {
      const p = pending.get(msg.id);
      pending.delete(msg.id);
      clearTimeout(p.timer);
      if (msg.error) p.reject(new Error((msg.error && msg.error.message) || 'signal-cli JSON-RPC error'));
      else p.resolve(msg.result);
      return;
    }
    // Any other notification (e.g. a future method this client doesn't
    // know about) or a response to a request we already gave up on - not
    // an error, just nothing to do with it.
  }

  function attach(sock) {
    socket = sock;
    socket.setEncoding('utf8');
    socket.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 1);
        handleLine(line);
      }
    });
    socket.on('close', () => {
      connected = false;
      // Anything still waiting on a response when the connection drops
      // gets told so explicitly, rather than hanging until its own
      // timeout - the caller (adapter) treats a rejected send the same as
      // any other failed send: acked to the rocket server as failed, never
      // silently resent.
      for (const [id, p] of pending) {
        clearTimeout(p.timer);
        p.reject(new Error('signal-cli connection closed'));
        pending.delete(id);
      }
    });
    socket.on('error', (e) => log(`signal-cli connection error: ${e.message}`));
  }

  function connect() {
    if (connected) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const sock = connectImpl
        ? connectImpl()
        : socketPath
          ? net.createConnection({ path: socketPath })
          : net.createConnection({ host, port });
      const onError = (e) => reject(e);
      sock.once('error', onError);
      sock.once('connect', () => {
        sock.removeListener('error', onError);
        connected = true;
        attach(sock);
        resolve();
      });
    });
  }

  function close() {
    if (socket) socket.destroy();
    connected = false;
  }

  function isConnected() {
    return connected;
  }

  function call(method, params, { timeoutMs = 10000 } = {}) {
    if (!connected || !socket) return Promise.reject(new Error('not connected to signal-cli'));
    const id = nextId++;
    const fullParams = account ? Object.assign({ account }, params) : params;
    const requestLine = JSON.stringify({ jsonrpc: '2.0', method, params: fullParams, id }) + '\n';
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error(`signal-cli "${method}" call timed out after ${timeoutMs}ms`));
      }, timeoutMs);
      pending.set(id, { resolve, reject, timer });
      socket.write(requestLine, (err) => {
        if (err) {
          pending.delete(id);
          clearTimeout(timer);
          reject(err);
        }
      });
    });
  }

  function send(recipient, message) {
    return call('send', { recipient: [recipient], message });
  }

  return { connect, close, isConnected, call, send };
}

module.exports = { createSignalCliClient };
