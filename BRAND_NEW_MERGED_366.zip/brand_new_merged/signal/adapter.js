'use strict';

/*
 * Signal transport adapter for the driver channel.
 *
 * The engine's driver side is transport-agnostic - it just needs
 * {driverId, text} in (server/index.js's POST /driver/inbound) and
 * produces {to, text} out (GET /driver/outbound/pending). This adapter is
 * the transport, talking to signal-cli's OWN JSON-RPC daemon mode directly
 * (see signal/signalCliClient.js) - not the bbernhard/signal-cli-rest-api
 * wrapper this project used in an earlier session. Adapted rather than
 * rebuilt from scratch: signal-cli-rest-api's own /v1/receive endpoint
 * mirrors signal-cli's real JSON-RPC envelope shape (both documented by
 * the same upstream project), so the envelope-parsing and message-id/dedup
 * logic below is unchanged from the REST-wrapper version - only the two
 * places that actually talk to Signal (receiving, sending) were swapped
 * for calls into signalCliClient.
 *
 * A driver's Signal phone number IS their driverId - registerDriver(id, ...)
 * is called with the same number the driver messages from, so there's no
 * separate mapping table to keep in sync.
 *
 * Inbound is now push, not poll: signal-cli's daemon sends "receive"
 * notifications unsolicited over the persistent connection the moment a
 * message arrives; signalCliClient buffers them, and pollInboundOnce()
 * (kept under that name for continuity with the rest of this file and its
 * tests) just drains whatever has arrived since the last drain.
 *
 * This has been tested against a MOCKED signal-cli JSON-RPC daemon (a real
 * TCP server speaking the documented newline-delimited protocol - see
 * test/signalCliClient.test.js and test/signalAdapter.test.js), not
 * against a real signal-cli process - that's real remaining verification
 * work, the same honest line drawn for the Tasker and Traccar integrations.
 */

const { createSignalCliClient } = require('./signalCliClient');

function createSignalAdapter({
  // signal-cli daemon connection - one of socketPath, or host+port. See
  // docs/SIGNAL_INTEGRATION.md for how to start `signal-cli daemon`.
  signalCliSocketPath,
  signalCliHost,
  signalCliPort,
  signalCliAccount, // only needed in multi-account daemon mode
  connectImpl, // test hook, passed straight through to signalCliClient
  client, // test/advanced hook: a pre-built signalCliClient-shaped object, bypasses the options above entirely
  rocketApiBase,
  rocketApiToken,
  pollIntervalMs = 3000,
  fetchImpl = fetch,
  log = () => {},
}) {
  if (!rocketApiBase) throw new Error('rocketApiBase is required');
  if (!client && !connectImpl && !signalCliSocketPath && !(signalCliHost && signalCliPort)) {
    throw new Error('createSignalAdapter needs signalCliSocketPath, or signalCliHost+signalCliPort, for the signal-cli daemon (or client/connectImpl for tests)');
  }

  const inbox = []; // envelopes pushed here by signalCliClient's onReceive as they arrive

  // Signal timestamp (of OUR OWN sent message) -> orderId, so a driver
  // replying to a specific JOB offer by swiping-to-quote it (instead of
  // typing "ACCEPT R1234") can still be resolved to the right order - see
  // Engine.handleDriverMessage's opts.quotedOrderId. Only messages that
  // came with an orderId (job offers, status prompts) are recorded; a
  // driver replying to "You're ON duty" has nothing useful to quote into.
  // Bounded and time-pruned so a long-running daemon doesn't grow this
  // forever - a quote past sentTimestampMaxAgeMs is stale enough that
  // resolving it to a possibly-since-reassigned order would be a worse
  // guess than just asking the driver for the id (Engine's own
  // driver_need_id fallback).
  const sentTimestampToOrderId = new Map();
  const sentTimestampMaxAgeMs = 2 * 60 * 60 * 1000; // 2 hours - well past any realistic job lifetime
  function rememberSentTimestamp(ts, orderId) {
    if (!ts || !orderId) return;
    sentTimestampToOrderId.set(ts, { orderId, at: Date.now() });
    if (sentTimestampToOrderId.size > 1000) {
      const oldestKey = sentTimestampToOrderId.keys().next().value;
      sentTimestampToOrderId.delete(oldestKey);
    }
  }
  function resolveQuotedOrderId(quoteId) {
    if (!quoteId) return null;
    const hit = sentTimestampToOrderId.get(quoteId);
    if (!hit) return null;
    if (Date.now() - hit.at > sentTimestampMaxAgeMs) {
      sentTimestampToOrderId.delete(quoteId);
      return null;
    }
    return hit.orderId;
  }
  const signalCli = client || createSignalCliClient({
    socketPath: signalCliSocketPath,
    host: signalCliHost,
    port: signalCliPort,
    account: signalCliAccount,
    connectImpl,
    onReceive: (params) => { if (params && params.envelope) inbox.push(params.envelope); },
    log,
  });

  const rocketHeaders = () => (rocketApiToken
    ? { 'Content-Type': 'application/json', 'X-Gateway-Token': rocketApiToken }
    : { 'Content-Type': 'application/json' });

  async function ensureConnected() {
    if (signalCli.isConnected()) return;
    await signalCli.connect();
  }

  async function pollInboundOnce() {
    try {
      await ensureConnected();
    } catch (e) {
      log(`could not connect to signal-cli: ${e.message}`);
      return { received: 0, errors: 1 };
    }
    const envelopes = inbox.splice(0, inbox.length); // drain what's arrived since the last check
    let received = 0;
    let errors = 0;
    for (const env of envelopes) {
      const dm = env && env.dataMessage;
      // Not every envelope is a text message - receipts, typing
      // indicators and sync messages all come through the same channel
      // and must be silently skipped, not treated as malformed input.
      if (!env || !dm || typeof dm.message !== 'string') continue;
      const driverId = env.sourceNumber || env.source;
      if (!driverId) continue;
      // Signal's own per-message timestamp is a real, stable dedup key -
      // reusing it (rather than inventing one) means a redelivered
      // envelope from Signal's own retry logic still de-duplicates
      // correctly against the engine's firstSeen() check.
      const messageId = `sig_${driverId}_${dm.timestamp || env.timestamp}`;
      // dm.quote.id is the Signal timestamp of the message this reply
      // swiped-to-quote (signal-cli's documented JSON-RPC envelope shape).
      // Only meaningful if it's one of OUR sent messages we recorded below -
      // a driver could in principle quote something else (another driver's
      // message, small chance in a group, or their own earlier text), and
      // resolveQuotedOrderId() returns null for anything we don't recognise.
      const quotedOrderId = resolveQuotedOrderId(dm.quote && dm.quote.id);
      try {
        const r = await fetchImpl(`${rocketApiBase}/driver/inbound`, {
          method: 'POST',
          headers: rocketHeaders(),
          body: JSON.stringify({ driverId, text: dm.message, messageId, quotedOrderId }),
        });
        if (!r.ok) { log(`forwarding Signal message from ${driverId} failed: HTTP ${r.status}`); errors++; }
        else received++;
      } catch (e) {
        log(`forwarding Signal message from ${driverId} threw: ${e.message}`);
        errors++;
      }
    }
    return { received, errors };
  }

  async function pollOutboundOnce() {
    let res;
    try {
      res = await fetchImpl(`${rocketApiBase}/driver/outbound/pending`, { headers: rocketHeaders() });
    } catch (e) {
      log(`could not reach Rocket Dispatch to fetch outbound driver messages: ${e.message}`);
      return { sent: 0, errors: 1 };
    }
    if (!res.ok) {
      log(`fetching outbound driver messages failed: HTTP ${res.status}`);
      return { sent: 0, errors: 1 };
    }
    const body = await res.json();
    const messages = (body && body.messages) || [];
    let sent = 0;
    let errors = 0;
    for (const m of messages) {
      let ok = false;
      let error = null;
      try {
        await ensureConnected();
        const sendResult = await signalCli.send(m.to, m.text);
        rememberSentTimestamp(sendResult && sendResult.timestamp, m.orderId);
        ok = true;
      } catch (e) {
        error = e.message;
        log(`signal-cli send to ${m.to} failed: ${error}`);
      }
      // Ack either way, honestly reporting ok/error - never silently
      // resend on failure (that risks a duplicate message to a driver);
      // a failed send surfaces through the engine's own outbox-lease
      // review flag (Engine.tick()), same failure-visibility pattern as
      // the Tasker SMS gateway.
      try {
        await fetchImpl(`${rocketApiBase}/driver/outbound/ack`, {
          method: 'POST',
          headers: rocketHeaders(),
          body: JSON.stringify({ id: m.id, ok, error }),
        });
      } catch (e) {
        log(`could not ack message ${m.id} to Rocket Dispatch: ${e.message}`);
        errors++;
        continue;
      }
      if (ok) sent++; else errors++;
    }
    return { sent, errors };
  }

  async function tick() {
    const inbound = await pollInboundOnce().catch((e) => { log(`inbound poll crashed: ${e.message}`); return { received: 0, errors: 1 }; });
    const outbound = await pollOutboundOnce().catch((e) => { log(`outbound poll crashed: ${e.message}`); return { sent: 0, errors: 1 }; });
    return { inbound, outbound };
  }

  let timer = null;
  function start() {
    if (timer) return;
    ensureConnected().catch((e) => log(`initial connection to signal-cli failed, will retry on next tick: ${e.message}`));
    timer = setInterval(() => { tick(); }, pollIntervalMs);
    if (timer.unref) timer.unref();
  }
  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
    signalCli.close();
  }

  return { start, stop, tick, pollInboundOnce, pollOutboundOnce, connect: ensureConnected };
}

module.exports = { createSignalAdapter };
