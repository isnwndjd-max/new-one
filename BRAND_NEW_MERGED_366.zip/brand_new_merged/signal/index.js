'use strict';

/*
 * Runs the Signal adapter as a standalone process, connecting to a
 * signal-cli daemon on one side and polling Rocket Dispatch's own server
 * on the other. Run this alongside server/index.js (they're separate
 * processes - the adapter is just another HTTP client of server/index.js,
 * exactly like Tasker is for SMS) and alongside signal-cli itself, started
 * as a daemon: `signal-cli -a +<business number> daemon --socket` (or
 * `--tcp=HOST:PORT`).
 *
 * Env vars:
 *   SIGNAL_CLI_SOCKET  path to signal-cli's daemon socket, e.g.
 *                      /var/run/signal-cli/socket (matches `daemon --socket`
 *                      pointed at that path). Preferred when signal-cli
 *                      runs on the same host as this adapter.
 *   SIGNAL_CLI_HOST,
 *   SIGNAL_CLI_PORT    used instead of SIGNAL_CLI_SOCKET if signal-cli runs
 *                      as `daemon --tcp=HOST:PORT` (e.g. a separate
 *                      container/host). SIGNAL_CLI_SOCKET wins if both are set.
 *   SIGNAL_CLI_ACCOUNT the business's Signal number, only needed if
 *                      signal-cli's daemon is running in multi-account mode
 *                      (no -a on its own command line).
 *   ROCKET_API_BASE    base URL of server/index.js, e.g. http://localhost:8787
 *   ROCKET_API_TOKEN   must match config.gateway.token in server/index.js's
 *                      data/config.json - every /driver/* call this adapter
 *                      makes is refused (HTTP 401) without it once that
 *                      token is set to anything other than the placeholder.
 *   SIGNAL_POLL_MS     how often to check for outbound driver messages and
 *                      drain the inbound queue, in ms (default 3000). Note
 *                      this is not how "fast" incoming messages arrive -
 *                      signal-cli pushes those the instant they're
 *                      received over the daemon connection; this interval
 *                      only controls how promptly they're then drained and
 *                      forwarded, and how often outbound messages are sent.
 *
 * See docs/SIGNAL_INTEGRATION.md for how to actually get signal-cli's
 * daemon running and the business number registered.
 */

const { createSignalAdapter } = require('./adapter');

if (require.main === module) {
  const signalCliSocketPath = process.env.SIGNAL_CLI_SOCKET || undefined;
  const signalCliHost = signalCliSocketPath ? undefined : (process.env.SIGNAL_CLI_HOST || undefined);
  const signalCliPort = signalCliSocketPath ? undefined : (process.env.SIGNAL_CLI_PORT ? Number(process.env.SIGNAL_CLI_PORT) : undefined);
  const signalCliAccount = process.env.SIGNAL_CLI_ACCOUNT || undefined;
  const rocketApiBase = process.env.ROCKET_API_BASE || 'http://localhost:8787';
  const rocketApiToken = process.env.ROCKET_API_TOKEN || null;
  const pollIntervalMs = Number(process.env.SIGNAL_POLL_MS || 3000);

  if (!signalCliSocketPath && !(signalCliHost && signalCliPort)) {
    console.error('Either SIGNAL_CLI_SOCKET or SIGNAL_CLI_HOST+SIGNAL_CLI_PORT is required - point this at a running `signal-cli daemon`.');
    process.exit(1);
  }
  if (!rocketApiToken) {
    console.warn('[signal-adapter] ROCKET_API_TOKEN not set - every call to server/index.js will be refused once config.gateway.token is set to a real value (it should be).');
  }

  const adapter = createSignalAdapter({
    signalCliSocketPath,
    signalCliHost,
    signalCliPort,
    signalCliAccount,
    rocketApiBase,
    rocketApiToken,
    pollIntervalMs,
    log: (msg) => console.log(`[signal-adapter] ${msg}`),
  });

  adapter.start();
  console.log(`[signal-adapter] connecting to signal-cli (${signalCliSocketPath || `${signalCliHost}:${signalCliPort}`}), forwarding to ${rocketApiBase}, checking every ${pollIntervalMs}ms`);

  const shutdown = () => { adapter.stop(); process.exit(0); };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

module.exports = { createSignalAdapter };
