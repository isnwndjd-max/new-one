# Rocket Dispatch — Alleyway Local Alias / Landmark Matching

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS. Waiting for explicit authorisation
before any production integration, exactly as instructed.

This is a follow-up to `CHANGELOG_ROAD_ALLEY_INTEGRATION.md` and
`CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md`. It adds a way for a
customer to describe an unnamed/generated-label alley by a nearby verified
venue or road ("Kenn Road alley", "alley by the Bridge Inn"), derived from
real geometry, never from text-name guessing.

---

## 1. Exactly which files changed

### New files
| File | What it is |
|---|---|
| `data/alleyAliases.json` | 7,203 geometry-derived local aliases (alley_id, alias text, anchor, strength, auto_resolve_allowed). Loaded by the server if present. |
| `test/alleyLocalAlias.test.js` | 25 new automated tests. |
| `CHANGELOG_ALLEY_LOCAL_ALIAS.md` | This file. |

### Modified files
| File | What changed |
|---|---|
| `src/roadIndex.js` | `RoadIndex` constructor takes an optional 4th argument, `alleyAliasData` (`data/alleyAliases.json`). Registers each alias phrase into the same `alleyPhrases`/`alleyFirstWord` index used for alley names, tagged `kind: 'local_alias'`, with per-(phrase, alley) metadata in a new `alleyAliasMeta` map (anchor strength, whether it's allowed to auto-resolve). `findMatch()` gained one narrow exception to "roads always outrank alleys": a `local_alias` phrase wins over a road match **only** when it is strictly longer (more words) than the road's matched phrase - e.g. "zig zag alley" (a local alias, 3 words) correctly resolves the alley even though a *different, real* road is also named "Zig Zag" (2 words) - see §4. |
| `src/locationConversation.js` | `roadLocation()` gained a `localAlias` field (`{anchorType, anchorName, relationship}` or `null`) - who/what the customer actually named, never replacing the alley's own real name/id. `handle()`'s venue-vs-road override logic extended: previously a road/alley match could only override a *weak* venue match; now a **local-alias** road/alley match (the customer explicitly said "alley"/"alleyway"/"off"/"near"/"by") can also override a **strong** venue match, but only when its matched phrase is strictly longer than the venue's - see §4. `_resolveRoad()`'s auto-resolve gate now checks the alias's own `auto_resolve_allowed` (via `aliasMeta`) when a local alias matched, instead of only the alley's own default `anchor_strength`, since the SAME alley can have both a strong alias ("kenn road alley") and a weak one ("alley near church road"). `pendingRoad` state now also carries `aliasMetaById` so a follow-up town message doesn't lose this. |
| `server/index.js` | Loads `data/alleyAliases.json` if present and passes it to `RoadIndex`. Optional - its absence changes nothing (alleys still match by their own OSM name/generated label only, same as before this layer existed). |

### Explicitly NOT changed
- `data/locations.json` - read-only throughout, as always.
- `data/roads.json` / `data/alleys.json` - no alley or road record was renamed. A customer alias is a separate lookup entry, never written into an alley's own `name` field (test #10/#11 in `alleyLocalAlias.test.js` prove this directly).
- Every existing test file - unmodified, all still pass (§6).

---

## 2. How the geometry test works

For every alley, this build measured the real distance (metres, via the
alley's/road's/venue's actual OSM/venue coordinates) to every nearby
verified road and venue, and classified the relationship:

| | connects_to (road only) | adjacent_to | entrance_beside (venue only) | near_only |
|---|---|---|---|---|
| Road | ≤12m from an alley **endpoint** | ≤35m from any point | — | ≤80m |
| Venue | — | ≤45m | ≤20m | ≤70m |

Nothing is a text-name guess. There is no verified Wetherspoons venue
anywhere in Rocket's data, for example, so no "Spoons alleyway" alias was
generated for anything - that would have been fabricated, not evidence
(see `README_alley_aliases.txt` in the delivered package for the full
worked-example list).

## 3. Priority / auto-resolve rules, as implemented

Match priority (unchanged from the prior integration, this layer only adds
a sub-case within step 5): 1 postcode, 2 venue (**with the one exception in
§4**), 3 road name, 4 road alias, 5 alley name **or local alias**, 6
normalised-exact match, 7 ambiguous → ask.

`anchor_strength` → auto-resolve behaviour:
- `road_and_venue`, `two_roads`, `road_direct`, `venue_direct` (each
  **unique**) → allowed to auto-resolve.
- `ambiguous`, `locality_only`, `district_only` → always `CONFIRM_REQUIRED`.
- **Demoted to `CONFIRM_REQUIRED` even from a strong tier** whenever (a)
  more than one alley shares the exact same anchor (e.g. three footpaths
  all connect to "Church Lane"), or (b) the generated alias **text** is
  identical for two alleys with *different* anchors (e.g. two unrelated
  "Zig Zag" paths in different towns) - the brief's "multiple alleys near
  the same anchor" rule, extended to cover text-level, not just anchor-id,
  collisions, because the resolver looks up by the text a customer types.

A full postcode always wins outright (checked before any road/alley
matching is even attempted, unchanged from the prior integration).

## 4. Two edge cases found and fixed during testing

**A road can share a name with an unrelated real road/alley elsewhere.**
`PATH-BS21-0002` is a real alley literally named "Zig Zag", directly
connected to a real road *also* named "Zig Zag" - and there turned out to
be two *other*, unrelated "Zig Zag"-named paths/roads elsewhere in the
dataset too. Typing "zig zag alley" must resolve the intended alley, not
the shorter, coincidentally-matching road. Fixed in `roadIndex.js`'s
`findMatch()`: a `local_alias` phrase is allowed to win over a road match
only when it is strictly longer (more specific) than the road's own match
- the same "longest/most specific phrase wins" principle already used
elsewhere in this codebase, applied narrowly so it never affects the
existing, tested "roads always outrank alleys" rule for an alley's *own*
name (`roadAlleyIntegration.test.js`'s embedded-road-name tests still
pass unchanged).

**A real venue name embedded in an explicit "alley by X" phrase.**
"alley by Strode Leisure Centre" contains a genuine, strong venue match
("Strode Leisure Centre" is a real, verified venue) - under the prior
rules, venue matching always wins over road/alley matching unless the
venue match is *weak*, so this would have resolved to the venue itself,
silently ignoring the customer's explicit "alley by...". Fixed in
`locationConversation.js`'s `handle()`: a local-alias road/alley match is
now also allowed to override a **strong** venue match, but only when its
phrase is strictly longer than the venue's matched phrase - i.e. only when
the customer said something more specific than the bare venue name. A
bare venue name on its own is completely unaffected (still resolves to the
venue, as before).

Both fixes were caught by this build's own test suite (initial draft:
9/25 new tests failing on the "Zig Zag"/"Strode Leisure Centre" cases)
before being corrected - not discovered after the fact.

## 5. Before / after examples

| Customer text | Before this layer | After this layer |
|---|---|---|
| `rock road alleyway` | NOT_FOUND/NONE (only the road itself matched "rock road") | RESOLVED → `PATH-BS49-0008` (the connected alley) |
| `alley by strode leisure centre` | RESOLVED → the venue itself | RESOLVED → `PATH-BS21-0155` (the adjacent alley, road_and_venue) |
| `church lane alley` | NOT_FOUND/NONE | ASK_WHICH (3 alleys share this anchor - never guessed) |
| `alley near stock way north` | NOT_FOUND/NONE | CONFIRM (weak anchor - always asks, never silently sent) |
| `zig zag alley` | Whatever the shorter "zig zag" *road* match gave | ASK_WHICH (3 different "Zig Zag" paths/roads exist - correctly ambiguous, never guessed) |

## 6. Test results

**228 / 228 passing**, two consecutive full clean runs (`node --test
test/*.js`), zero failures. Breakdown:
- 203 pre-existing tests (unmodified - includes the prior road/alley and
  locality-context phases)
- **25 new tests** in `test/alleyLocalAlias.test.js`, covering the brief's
  scenarios 1–11 (venue+one-alley auto-resolve, road+one-alley
  auto-resolve, venue+two-alleys confirm, road+several-alleys confirm,
  locality/district-only never auto-resolving, wrong town, postcode beats
  alias, unassociated-venue no-alias, OSM-named alley untouched, alias
  never overwrites the record) plus edge cases found during development
  (the two collisions in §4), backward compatibility (no `alleyAliasData`
  argument at all), and two end-to-end tests through the real `Engine`.

One pre-existing test (`fullSystem.e2e.test.js`'s full end-to-end proof)
is independently flaky on timing under full-suite load (confirmed via
three isolated re-runs, all passing, and two full-suite re-runs before and
after this change, both 100% clean) - not related to this change; noted
here for transparency rather than quietly ignored.

Run it yourself: `node --test test/*.js` from the project root.

## 7. Known ambiguous / risky areas

- **655 alleys** (of 1,873) have more than one candidate anchor of their
  own and are marked `ambiguous` - always `CONFIRM_REQUIRED`, never
  guessed. See `alley_alias_conflicts.csv` in the delivered package.
- **1,821 shared-anchor/shared-text conflicts** across the alias rows -
  same treatment, always asks.
- **No venue_direct alias exists anywhere in this dataset** - every strong
  venue relationship found also had a strong road relationship at the same
  alley (landing it in `road_and_venue` instead). Not a bug; just how the
  geometry came out for BS20/BS21/BS48/BS49's verified venues. If a future
  venue-only case does exist, the code path is there and tested
  (`_resolveRoad`'s handling is anchor-agnostic).
- The two edge cases in §4 (name collisions, and a strong venue vs an
  explicit "alley by" phrase) are the kind of case most likely to recur as
  this layer is extended to more districts - worth a second look before
  any production integration.

## 8. Rollback

Fully additive and optional, same pattern as the prior two phases:
- Delete `data/alleyAliases.json` (or don't deploy it) - `server/index.js`'s
  `fs.existsSync` check means the server starts with the road/alley layer
  working exactly as it did before this layer, no code changes need
  reverting.
- Or, for a full source rollback: revert `src/roadIndex.js`,
  `src/locationConversation.js`, `server/index.js` to their pre-this-fix
  versions and delete `data/alleyAliases.json` + the new test file.

No changes here touch `data/locations.json`, the postcode matching path,
venue matching (beyond the one narrow, tested override in §4), or the
road/alley layer's own name/alias matching.
