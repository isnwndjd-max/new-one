# Rocket Dispatch — House Number Dropped on Road/Alley Match Fix

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS.

Found via a live role-play: "1 item a 33 Greenfield Crescent" resolved the
road correctly (Greenfield Crescent is real, in Nailsea), but the "33" was
silently dropped everywhere - not on the customer's confirmation text, not
on the driver's job card, not even in the stored order data.

---

## 1. What was found

The postcode layer already has a mechanism for this: `findStreet()`
(`src/locationIndex.js`) recognises a street name with an optional house
number alongside a **full postcode**, and keeps it as a label
(`location.street`) - it never moves the coordinate, just refines what the
driver reads. But it was never wired into the road/alley layer at all. A
bare road name with a number ("33 Greenfield Crescent", no postcode) goes
through `RoadIndex.findMatch()` instead, which only matches the road's own
registered name/alias text - the leading "33 " isn't part of any
registered phrase, so it's just... not there. Not stored, not shown, not
logged.

## 2. The fix

`src/locationIndex.js`: `findStreet()` now also returns `houseNumber` -
just the leading house/flat number portion ("33", "Flat 2, 33"), split out
from the full `phrase` (which still includes the street name, unchanged,
for the postcode path).

`src/locationConversation.js`: `roadLocation()` gained a `houseNumber`
field (label only, `null` when not given). `_resolveRoad()` now takes and
threads through a `houseNumber` argument from the same original message
(or carried over via `state.pendingRoad.houseNumber` through a
town-clarification follow-up, e.g. "5 station road" → "which town?" →
"Nailsea" still remembers the "5"). The existing "street arrives as its
own follow-up message" branch is now type-aware: for a postcode/venue
location it behaves exactly as before (`location.street`); for a
road/alley location it sets `location.houseNumber` instead, since the
road's own `name` field already carries the street name and duplicating
it would look wrong ("33, Greenfield Crescent, Greenfield Crescent").

`src/engine.js`: `_placeLabel()` for a road/alley location now shows
`"33 Greenfield Crescent"` instead of just `"Greenfield Crescent"` when a
house number is present - same principle as the postcode path's `street`
label, just formatted without a duplicate street name.

### Not changed
- The postcode+street path (`location.street`) - completely untouched,
  same field, same shape, same behaviour.
- The coordinate a driver is actually routed to - a house number is
  always label-only, exactly like the postcode layer's `street` field
  already was. Rocket has no house-level address gazetteer; this doesn't
  add one, it just stops throwing away a number the customer already gave.
- A known pre-existing limitation, unchanged by this fix: a house number
  sent as its own follow-up message **after the order is already
  CONFIRMED** doesn't currently persist (this was already true for the
  postcode/venue `street` label too - `_afterConfirmation()`'s probe
  conversation never writes back into the real order). Giving the number
  in the **same message** as the order (the common case, and the one the
  role-play hit) works correctly.

## 3. Before / after

```
Before:
  customer> 1 item a 33 Greenfield Crescent
  Rocket>   Order confirmed: 1 x Item A. Total £10.00 cash.
            Meeting point: Greenfield Crescent, Nailsea, (BS48 1HR).
  driver>   JOB R.... Meet: Greenfield Crescent, Nailsea, (BS48 1HR)
  (the "33" is gone, nowhere in the order at all)

After:
  customer> 1 item a 33 Greenfield Crescent
  Rocket>   Order confirmed: 1 x Item A. Total £10.00 cash.
            Meeting point: 33 Greenfield Crescent, Nailsea, (BS48 1HR).
  driver>   JOB R.... Meet: 33 Greenfield Crescent, Nailsea, (BS48 1HR)
```

## 4. Test results

**241 / 241 passing** (`node --test test/*.js`), zero failures. 9 new
tests in `test/houseNumberOnRoad.test.js`: house number captured on a
bare road match, a flat number, no-number case still `null`, the
coordinate is provably unchanged either way, a house number on a local
alley alias match, preserved through an ambiguous-road town-clarification
follow-up, end-to-end on both the customer text and the driver job card,
no-regression for a bare road name, and the postcode+street path proven
completely untouched.

## 5. Rollback

Three files, all additive (new field, new optional parameter with a
default of `undefined`/`null`): revert `findStreet()` in
`src/locationIndex.js`, `roadLocation()`/`_resolveRoad()` in
`src/locationConversation.js`, and `_placeLabel()` in `src/engine.js` to
their pre-fix versions. No data files changed.
