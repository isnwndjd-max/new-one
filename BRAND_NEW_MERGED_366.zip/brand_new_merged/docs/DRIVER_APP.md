# Driver app ("Rocket Driver Private")

## What this is

A separate, already-built native Android app (`driver-app/`), vendored into
this repo as documented source — **not written in this session, and not
rebuilt here.** It is the production driver channel: a proper installable
app with a pairing flow, an encrypted local vault, gated GPS reporting, and
a live event stream, talking to its own dispatch relay at
`https://100.103.3.32:8911` (a private Tailscale address — the same
approach this project's own `tasker/TASKER_SETUP.md` recommends for
securing the phone↔server connection). That relay is a separate system,
already built and running outside this repo; this project does not
implement it and this doc does not attempt to guess its internals from the
Android client's expectations.

**This is intentionally not merged into `server/index.js`.** The relay
already exists and is presumably already enforcing its own rules
server-side (the client code repeatedly notes "the future trusted dispatch
adapter must also enforce every rule" — client-side validation is a UX
convenience, never the security boundary). Reimplementing that protocol
here, without the relay's own source or a verified spec, would risk a
second, drifting copy of a security-critical component — exactly the kind
of rebuilding-a-working-part this project's own conventions avoid.

## Two separate driver channels now exist

- **Signal** (`signal/`, `docs/SIGNAL_INTEGRATION.md`) — built and tested in
  this repo, talks directly to `server/index.js`'s engine
  (`/driver/inbound`, `/driver/outbound/*`). Text-command based, no app
  install required.
- **This app** (`driver-app/`) — a real installable app with a proper UI,
  talks to its own separate relay, not to `server/index.js`. Independent of
  the engine in this repo.

Per the decision to keep both running side by side: Signal remains a valid
fallback if a driver's phone or the app has a problem; this app is the
richer, production-intended interface. Nothing in `src/engine.js` or
`server/index.js` currently knows this app exists — the engine's driver
contract (`handleDriverMessage`, the outbox) is unaware of it, because it
talks to its own relay instead.

## What's in `driver-app/`

- `source/` — the Android app source (`com.rocket.driverprivate`): pairing
  (`RD2.` pairing codes carrying a room id, driver id, root key, bearer
  token, and a pinned TLS certificate's SPKI hash), an encrypted
  Android-Keystore-backed local vault (`Vault.java`), HKDF-derived
  per-purpose channel keys (`Crypto.derive`, keyed by room + `command` /
  `snapshot` / `receipt` / `gps`), a gated foreground GPS service that only
  reports while a job is actually active (`DriverLocationService.java`),
  and an SSE event listener for live push updates (`EventService.java`).
  The UI (`assets/shell.html` + `ui.js` + `rules.js`) is plain-JS logic the
  app's WebView shell runs; `rules.js` has no network or storage access of
  its own (deliberately, per its own header comment) — it's pure
  client-side validation, mirrored (per the code's own comments) by the
  relay's own server-side checks.
- `rollback/Rocket_Driver_Full_1.1.4.apk` — the previous signed build, kept
  for recovery. Per `RELEASE_NOTES.txt`: **do not uninstall 1.1.5 to force
  a rollback to this** — Android normally blocks version downgrades, and
  uninstalling would lose the device's pairing. Roll back only via a
  freshly source-rebuilt APK with a higher `versionCode`.
- `build_driver.py` — the build/sign script. **Cannot be run from this
  sandbox as-is**: it hardcodes an Android SDK/JDK and a private signing
  keystore path (`/home/jeffnew2026/rocket-driver-private-...`) that don't
  exist here, and rightly so — a production signing key should never live
  in a throwaway cloud sandbox. Building a real update means running this
  script in whatever environment already holds that keystore.
- `test-driver-fast.cjs` — a fast Node-based logic test for the UI's
  polling/queueing behaviour (fast pending-check cadence, retained
  refreshes during in-flight submits). Verified passing against the
  vendored source in this session. It expects the source at
  `driver115/source/assets/ui.js` relative to wherever it's run — e.g.:
  ```
  mkdir -p driver115 && cp -r source driver115/source
  node test-driver-fast.cjs
  rm -rf driver115
  ```

## Offline prep for connecting this app to the engine: `driver-relay/`

An offline, tested integration layer now exists at `driver-relay/` that
would let this app work against rocket-dispatch's own engine as the
business-logic processor **behind the existing relay** (Driver APK ->
existing pinned relay `:8911` -> existing relay -> backend/adapter
interface `:8912` -> `driver-relay/` -> the engine) — without replacing the
relay, without touching this app, and without the private signing key or a
real pairing bundle, none of which this project has ever had or asked for.
Built and tested entirely offline against a protocol-faithful mock of the
`:8912` interface (`driver-relay/adapter.js` + 15 tests in
`test/driverRelay.adapter.test.js`) — see `driver-relay/README.md` for
exactly what it does, its command mapping, its gap list, and what would
still need confirming against the real relay before any of it is deployed.

## What's explicitly not verified in this session

- **The relay's actual server-side behaviour**, including the real JSON
  shapes of its `:8912` backend interface. Only the Android client's own
  expectations of the relay (from reading the client source) are known
  here — not its real implementation, so nothing about its correctness,
  security, or its backend-side API contract was checked in this session.
  `driver-relay/README.md` is explicit about which parts of its own design
  are assumptions rather than confirmed fact.
- **A real device install/pairing.** Nothing here was installed on a phone
  or paired against the real relay from this sandbox (no network route to
  a private Tailscale address exists from here regardless), and
  `driver-relay/`'s own tests use fabricated example pairing data, never a
  real pairing bundle.
- **`driver-relay/` has not been deployed or pointed at anything real.**
  It exists as tested, offline code only — see its own README for the
  concrete list of what connecting it for real would still require.
