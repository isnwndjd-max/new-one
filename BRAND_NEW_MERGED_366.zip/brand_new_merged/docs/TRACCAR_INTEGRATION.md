# GPS / Traccar integration

## What this is

Live driver position, fed from [Traccar](https://www.traccar.org/) into the
order engine, so a live ETA can be computed and a future customer-facing
"driver is X minutes away" tracking link has real data to show. Traccar is
the GPS platform (it talks to the phone, does the map, handles device
provisioning); Rocket Dispatch never talks to a phone's GPS directly — it
only consumes what Traccar forwards.

**Tested and working, in this sandbox, against synthetic data:**

- `src/gps.js` — parses Traccar's JSON position-forwarding payload, converts
  its speed (knots) to km/h, and computes straight-line distance (haversine)
  and a rough ETA from distance + current speed, with a sane fallback speed
  when the phone is stopped or not reporting motion.
- `Engine.registerDriver(id, name, { traccarId })` / `linkTraccarDevice` —
  maps a Traccar device's `uniqueId` to an internal driver id. A device can
  only ever point at one driver.
- `Engine.updateDriverLocation(fix)` — applies one position fix. Unknown or
  unlinked devices are ignored, not errors (this endpoint is going to be hit
  by anything on the same Traccar account, including devices nobody has
  linked yet).
- `Engine.liveTracking(orderId)` — last known driver fix, distance and ETA to
  the order's confirmed meeting point, plus how stale the fix is.
- `Engine.tick()` now flags an order for review if its assigned driver's GPS
  goes stale (default 8 minutes, `config.gps.staleAfterMinutes`) or never
  arrives at all — but only for drivers who have actually linked a Traccar
  device; a driver who never linked one isn't treated as having a GPS fault.
- `POST /gps/traccar` — the webhook target Traccar's "position forwarding"
  feature POSTs to. Requires the `X-Gps-Token` header to match
  `config.gps.forwardToken`. **Not accepted as `?token=...` in the URL** —
  a query-string token ends up in server access logs, any reverse proxy's
  logs, and Traccar's own request history, so this endpoint only checks
  the header (`gpsTokenOk()` in `server/index.js`); a URL-token request is
  refused with 401 even if the value is correct.
- `GET /track/:orderId` — read-only JSON snapshot (position, distance, ETA,
  staleness) for one order. Requires a per-order `trackingToken` (a random
  secret generated when the order is created, not the guessable 4-digit
  order id) via `?token=...` or an `X-Tracking-Token` header — see
  "Auth on /track/:orderId" below.

37 pre-existing tests plus 15 new ones (`test/gps.test.js`, plus additions to
`test/engine.test.js` and `test/server.e2e.test.js`) all pass:
`node --test test/*.test.js`.

## How it fits together

```
driver's phone (Traccar Client app)
        |  reports position over the standard OsmAnd/Traccar protocol
        v
Traccar server (self-hosted, or traccar.org's hosted plan)
        |  "position forwarding" (Settings -> a device or globally),
        |  type = json, forwards every new position as an HTTP POST
        v
POST https://<your-server>/gps/traccar
        |  header: X-Gps-Token: <config.gps.forwardToken>
        |
        v
Engine.updateDriverLocation(fix)  -->  state.drivers[id].location
                                        state.orders[id] (GPS_UPDATE event)
```

Traccar owns device provisioning, the map, and the historical trail; Rocket
Dispatch only keeps the *current* fix per driver (not a track history) and
the derived ETA, because that's the only part the engine's own logic (offer
routing, review flags, customer messaging) needs.

## Setting it up for real

1. **Run a Traccar server**, or use a hosted one. Self-hosted is one Docker
   container (`traccar/traccar`) plus its default SQLite/Postgres storage —
   not evaluated here in detail, that's a normal Traccar deployment, not
   specific to this codebase.
2. **Install Traccar Client** on each driver's phone (Android/iOS app from
   Traccar, not this project) and register it as a device in the Traccar
   server. Note the device's **unique ID** you set there — some
   Traccar Client builds default to something like the IMEI or a
   random hex string; anything is fine as long as you know it.
3. **Link that unique ID to the driver** in Rocket Dispatch:
   `POST /driver/register { "id": "D1", "name": "Dave", "traccarId": "<that unique ID>" }`
   (or call `engine.linkTraccarDevice('D1', '<unique ID>')` directly if the
   driver is already registered).
4. **Set a real forwarding token.** `data/config.json` ships with
   `gps.forwardToken` set to a placeholder — it is the only thing stopping
   anyone who finds the URL from POSTing fake driver positions. Generate a
   long random string and put it in both the config and the Traccar
   forwarding URL.
5. **Turn on position forwarding in Traccar**, either globally
   (Settings → Server → Forwarding) or per-device, with:
   - URL: `https://<your-server>/gps/traccar`
   - Type: `json`
   - Header: `X-Gps-Token: <the same token>`

   Traccar's forwarding settings support adding custom headers
   (`forward.header.*` / the "Additional Headers" field in the UI,
   depending on version) — this has not been verified against a real
   Traccar instance in this session (see "Not done" below), so double-check
   your Traccar version actually applies the header before relying on it.
   If your Traccar version genuinely cannot send a custom header, the
   `/gps/traccar` endpoint would need a narrow, explicitly-scoped exception
   to accept `?token=...` again for this one route — don't work around it
   by reverting `gpsTokenOk()` to accept both.

   Traccar will then POST every new position for every device to that URL.
   Positions for devices nobody has linked (`linkTraccarDevice`) are
   accepted (HTTP 202) and silently dropped — check `/health`'s
   `driversReportingGps` count, or the engine's audit log
   (`GPS_FIX_INVALID`, `GPS_DEVICE_LINKED`), if a driver's positions aren't
   showing up.

## Auth on /track/:orderId

Each order now gets a random `trackingToken` (16 bytes, hex-encoded) the
moment it's created (`Engine._createDraft`) — a real secret, not the
guessable 4-digit `R####` order id. `GET /track/:orderId` requires it via
either `?token=<trackingToken>` (fine for this one endpoint, since it's
meant to be shared as a customer-facing link — unlike the Boss/gateway/GPS
tokens, which are server-to-server secrets and never belong in a URL) or an
`X-Tracking-Token` header. A missing, wrong, or unknown-order request all
get the identical 404 response, so the endpoint itself can't be used to
enumerate which order ids exist. When the customer-facing tracking page
(below) is built, it should be linked with `?token=...` baked in so the
customer never has to type or see the raw token.

## Not done

- **No customer-facing tracking page.** `GET /track/:orderId` returns JSON,
  not a map. Building the actual "here's your driver" web page — and
  deciding whether it's a link texted to the customer, a hosted page, or
  routed through the Boss app — is separate work.
- **No position history / replay.** Only the latest fix is kept per driver;
  there's no trail to show "where they've been" or to audit a dispute about
  where a driver actually went.
- **ETA is straight-line, not routed.** It does not know about roads, one-way
  streets, or the Severn crossings — it is a floor estimate from distance
  and current speed, not a maps-API route ETA. Good enough to say "about 6
  minutes", not to promise it.
- **Traccar's own REST API is unused.** This only consumes Traccar's outbound
  position-forwarding webhook. Traccar also has a full REST API (device
  management, historical reports, geofences) — none of that is wired up;
  device linking here is manual (`traccarId` at registration).
- **Not tested against a real Traccar server or a real phone.** `src/gps.js`
  is tested against the JSON shape Traccar's own documentation describes for
  its `json` forwarding type — this has not been run against an actual
  Traccar instance or an actual driver's phone with real GPS drift, patchy
  signal, or the app being killed in the background. That's the next thing
  to verify before trusting this with a live driver.
