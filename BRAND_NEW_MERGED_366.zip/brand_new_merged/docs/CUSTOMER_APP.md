# Customer app ("Rocket V35 Test") -> rocket-dispatch

## What this is

The customer's own real app - package `co.rocket.customer.v35test`, display
name "Rocket V35 Test" - connected to rocket-dispatch as its order/dispatch
backend, **without starting over**. Per the developer prompt that asked for
this work: keep the existing UI, keep SMS ordering working in parallel, make
rocket-dispatch (not V35) authoritative for orders and dispatch state.

## Where the real source came from

The first handover pack (`Rocket_V35_Customer_App_Developer_Pack`) turned
out to contain only project-history documents and one honestly-labelled
client-side-only *prototype* (`invite_secure_v2`) - not the real app. A
second upload
(`Rocket_V35_Customer_Full_Developer_Source_2026-09-24.zip`) contained the
**actual** current source: a signed, verified APK
(`APK/Rocket_V35_Test_CORRECTED.apk`, SHA-256 verified to match the
handover's own notes), the real Capacitor Android/iOS wrapper
(`Exact_V35_Native_Source/`), and - most importantly - the real working
Python backend + web UI (`Current_Customer_Web_PWA/`). That is what
`customer-app/` in this repo is: a copy of that real backend, adapted to
point at rocket-dispatch instead of V35, not a rewrite.

The vendored source was scanned for secrets before use; none were found
(the handover's own README says private keys/credentials/live tokens were
deliberately excluded, and that held up).

## What changed in `customer-app/server.py`, and why

1. **The V35-specific binding module (`v35_customer_sync.py`) and the
   external `points_runtime` module are no longer imported.** Both were
   V35-authority glue from the original vendored handover. The developer
   prompt is explicit: "do not make V35/old Tasker the new authority."
   `server.py`'s own base handlers - unmodified - already implement a
   complete, non-V35 local order/menu/reward flow; that is what runs now.
2. **The SQLCipher import is now a soft dependency.** The real vendored
   `sqlcipher3` build (`/home/jeffnew2026/rocket-customer-sqlcipher-vendor/`)
   was deliberately excluded from the handover and does not exist in this
   sandbox. `server.py` falls back to plain `sqlite3` when `sqlcipher3` is
   unavailable, logging nothing silently wrong - **this is a staging-only
   substitution**. A real deployment must restore the real vendored
   `sqlcipher3` build and a real 32-byte key file (`ROCKET_CUSTOMER_DB_KEY`);
   without it, `customer.db` is not encrypted at rest. See "Staging
   substitutions" below.
3. **Structured location, additive.** `POST /api/orders` now accepts
   optional `postcode`/`street`/`venue`/`pinLat`/`pinLng` fields alongside
   the existing free-text `location` (still required, unchanged validation).
   `GET /api/integration/pending` now includes them, structured, for
   `customer-relay/` to consume.
4. **A customer-safe order-status endpoint.** `GET /api/orders/current` and
   an `currentOrder` field on `/api/bootstrap`/new `/api/account`, both
   returning `ORDER_STATUS_LABELS`-mapped text (`"About 5 minutes away"`,
   never a raw internal state name, coordinate, or driver identity).
5. **`/api/account` was added** (the original only existed inside the
   V35-mirror module, which is no longer used) - same shape a returning
   customer's "More" tab needs (menu/reward/credit/currentOrder), without
   `profile`/`weeklyPrizes` (still on `/api/bootstrap`).

Nothing else in `server.py`'s request handling changed: cash-only
enforcement, PIN hashing (scrypt), session tokens (header-only, never a
query param), rate limiting, CORS/CSP headers, server-side price
re-validation from the product map, and the existing `requestId` /
`client_request_id` idempotency are all the original, unmodified code.

## What changed in the UI (`customer-app/js/app.js`, `index.html`)

- A postcode/street/venue `<details>` block and a "Share my exact location"
  button (browser Geolocation API) were added to the basket page, additive
  to the existing free-text meeting-location field. Nothing about
  Menu/Basket/Frenzy/Rewards/More navigation, cash-only checkout, or the
  existing basket/quantity logic changed.
- A small order-status banner was added to the basket page, polled via the
  new `/api/orders/current` (and refreshed every 15s alongside the existing
  account refresh).
- `js/v35_account_view.js` was replaced with `js/account_view.js` - same
  pure-presentation contract, no more V35-specific "stale"/"AWAITING_V35"
  states (rocket-dispatch has no external sync status to reflect; local
  order/reward data is either there or it isn't).
- The old `canCheckout=false` hardcoding (which depended on a V35 mirror
  module that no longer runs, and would otherwise permanently disable the
  checkout button) was fixed to reflect local order availability.
- `index.html`'s script tag was repointed from the old dated
  `/js/releases/customer-20260923T000530Z/app.js` path to `/js/app.js`
  directly, and `sw.js`'s cache list was updated to match the files that
  actually exist now.
- Points-*redemption* (`/api/loyalty/redeem`) is now implemented (was a
  hard 503 stub). It spends the same local points balance that order
  completion now earns (see the Rewards section below) - one authority,
  not two - so it does not conflict with the developer prompt's "never
  invent a second rewards authority" instruction.
- `POST /api/integration/order-complete` now also credits Rocket Points
  (`pointsPerPound` from server-side loyalty config), whenever no V35
  points record exists for that phone. Previously this call site was
  hardcoded to `points_earned=0` with a comment saying V35/Tasker owned
  points; since the V35 mirror is removed in this build, rocket-dispatch's
  local ledger is the sole points authority end-to-end (earn on order
  completion, spend on redemption), matching how `reward_state()` already
  read points (V35 row wins if present, else the local column).

## `customer-relay/`: the adapter, not a rewrite of either side

`customer-relay/adapter.js` bridges the customer app's own
`/api/integration/*` surface to rocket-dispatch, **without modifying
`server/index.js` or `src/engine.js`**. Full detail in
`customer-relay/README.md`; in short, it:

- turns a pending web order into the exact same plain-text burst a real
  SMS customer would send (`POST /sms/inbound` - the same endpoint Tasker
  already uses), so it goes through the real, tested `parseItems()` /
  `LocationConversation` code, not a second copy of it;
- re-prices every order against rocket-dispatch's own menu before
  forwarding it (never trusts the app's own total);
- reflects order state back to the app (`FORWARDED`/`ASSIGNED`/`FIVE_MIN`/
  `HERE`/`COMPLETE`/`CANCELLED`/`REVIEW_REQUIRED`) via the app's own ack
  endpoints;
- pushes the Boss app's own customer-safe menu projection
  (`data/menu.sync.json` - already an allowlist, see `src/menuSync.js`)
  into the customer app's menu.

Because it uses the customer's real phone number as rocket-dispatch's
`phone` key, "Customer App OR SMS" is literally enforced by the engine's
own existing per-phone dedup (`activeByPhone`) - not a new rule.

## Menu

The Boss app remains the master menu owner (per Thread A's architecture -
the master lives only in the Boss app's own browser `localStorage`, never
on the VPS). `customer-relay/`'s `menuBridge.js` converts rocket-dispatch's
existing minimal synced projection (`data/menu.sync.json` - already
code/name/aliases/price/tiers only, no cost/margin/admin field ever reaches
it) into the customer app's menu shape and pushes it via
`POST /api/integration/menu`.

This project's own test suite uses a placeholder catalog (Item A/B/C) as a
fixture and that fixture was **not** changed (many existing tests depend on
its exact prices). For staging against the *customer app's* real product
catalog (Energy Drink, Cola, etc. - `customer-app/data/menu.json`), import
`boss/EXAMPLE_STAGING_MENU.json` through the Boss app's own "Import
backup..." button, or `PUT /boss/menu` directly in a throwaway/staging data
directory. **Never point this at the same `data/` directory the automated
test suite runs against** - see `customer-relay/README.md`'s "Restart /
recovery" section for how the live staging run in this session avoided
that (an isolated `dataDir` copy, not the repo's own `data/`).

The customer app's own placeholder Item A/B/C, referenced in the developer
prompt's "remove placeholder Item A/B/C from staging build" instruction,
never existed in the real source once recovered - `customer-app/data/menu.json`
already had a real product catalog before this session touched anything.

## Location

`POST /api/orders` accepts postcode, street, venue and a shared GPS pin
(`pinLat`/`pinLng`), all optional, alongside the existing free-text
location. `customer-relay/orderText.js#locationLine()` prefers them in the
same order the developer prompt listed: an exact pin first (formatted as
`"lat, lng"`, which `src/locationIndex.js#findPin` already parses), then
postcode+street (both already tested in
`src/locationConversation.js`/`src/locationIndex.js#findStreet`, added in
an earlier session), then venue, then the free-text fallback. The final
order's meeting point is whatever `LocationConversation` resolves to
(`order.location.confirmed`) - the same field the automatic Traccar 5-min/
HERE logic already keys off (`src/engine.js#_maybeAutoGpsEvents`), not
re-derived at trigger time. This was proven live in this session's staging
run with a real shared pin (see the test log below).

## Order status

Customer-safe states only (`server.py`'s `ORDER_STATUS_LABELS`): "Order
received", "Waiting for a driver", "Driver accepted - on the way", "About 5
minutes away", "Your driver is here", "Completed", "Cancelled". Never a raw
`rocket-dispatch` state name, a driver id, or a coordinate - proven in this
session's privacy tests (see below).

## Automatic GPS messages

The app never implements its own GPS thresholds. `customer-relay/statusMap.js`
derives the customer-safe status purely from the same `order.state` and
`order.sent.FIVE_MIN` / `order.sent.ARRIVED` fields the engine's own
tested auto-GPS logic (`_maybeAutoGpsEvents`, unmodified) already sets -
whichever fires first, a real Traccar fix or a driver's manual text, the
customer app sees the same one-shot transition SMS customers already get.

## Signal / driver

No customer-app code talks to Signal. The Signal adapter (`signal/`)
already talks only to `server/index.js`'s `/driver/*` routes - nothing in
this work changes that, and nothing in `customer-relay/` reads or forwards
Signal-related data. The driver offer message (`Engine._offerTo`, unchanged)
never includes a customer phone number - verified in this session's live
staging run (see below).

## Rewards / points / Frenzy

Spins from qualifying spend, a daily scratch card, and a weekly prize pool
are unchanged from the vendored source's own base (non-V35) behaviour -
all local to `customer-app/server.py`'s own SQLite tables.

Points are now a complete local loop, end to end:

- **Earn**: `POST /api/integration/order-complete` credits
  `floor(pounds_paid) * pointsPerPound` (server-side config, default 10)
  to the customer's local points balance, using the same remainder-carry
  pattern the existing spins logic already used for spend under a whole
  pound. This only runs when no V35 points record exists for that phone
  (checked against `v35_loyalty`), so a phone still being mirrored from
  V35 (if that mirror were ever re-enabled) never gets a second, competing
  points balance - it stays read-only from V35 in that case, exactly as
  `reward_state()` already prioritised it.
- **Spend**: `POST /api/loyalty/redeem {requestId, code}` (was a hard 503
  stub) debits the cost of a server-configured redemption
  (`loyalty_config().redemptions`, e.g. `REEL1`/`SNACK`/`OFF10`) atomically
  in a single `begin immediate` transaction, rejects with 400 if the
  balance is short, and is idempotent on `requestId` via the existing
  `loyalty_redemptions` table's unique index - a retried request returns
  the original result (`duplicate:true`) without debiting twice. The cost
  is always read from server config, never from the client.
- The UI (`js/app.js`'s `renderLoyalty()`/`renderSpinCounts()`) now shows
  the real redemption list and balance instead of "not available yet"
  copy, and its `redeemPoints()` call (already correctly wired in an
  earlier pass) is live.

Live-tested in this session end to end on a fresh staging customer: two
orders placed and completed (150 points earned total), an insufficient-
balance redemption correctly rejected (70 < 100), a successful redemption
(100 points -> 1 Reel Frenzy Spin, balance 150 -> 50), a same-`requestId`
retry returning the identical result with `duplicate:true` and no further
debit, and an unknown reward code rejected. A server-restart was also
performed mid-test and the points balance was confirmed to survive it
(same SQLite persistence the rest of the app already relies on).

One bug was found and fixed during this live test: the insufficient-
balance path closed the database connection before reading the reward
state to include in the error response, causing a 500 instead of a clean
400 (`Cannot operate on a closed database`). Fixed by reading the reward
state before closing.

## Security

Everything in the developer prompt's SECURITY section was already true of
the real, vendored `server.py` before this session touched it (HTTPS is a
deployment-time concern - this dev server is plain HTTP on localhost, same
as `server/index.js`): PIN hashing is `scrypt` with a random salt; session
tokens are random 32-byte URL-safe strings, header-only (`Authorization:
Bearer ...`), never in a URL; login/invite endpoints are rate-limited per
IP; CORS is locked to the app's own origins; CSP/`X-Frame-Options`/
`X-Content-Type-Options` headers are set on every response; every
`/api/*` route (other than login/invite/health) requires
`token_phone(self)` to resolve a session, which is how ownership is
enforced server-side on every request. **The one substitution this session
made is documented above (SQLCipher -> plain sqlite3, staging only)** -
that is the only place this build is weaker than the vendored original.

## Staging substitutions (do not deploy as-is)

1. **`customer.db` is not encrypted at rest** in this sandbox
   (`sqlcipher3`'s real vendor build is unavailable here - see point 2 in
   "What changed" above). Restore the real vendored build and a real key
   file before any real customer data touches this.
2. **`rocket-dispatch`'s own `state.json`** uses the same "fixed, publicly
   known development key" fallback `src/store.js` has always warned about
   when `ROCKET_STATE_KEY` isn't set (unchanged from Thread A/B) - set a
   real key before this holds real data.
3. **All tokens used in this session's staging run were the shipped
   placeholders** (`data/config.json`'s `gateway.token`/`boss.token` =
   `CHANGE_ME_BEFORE_GOING_LIVE`) - change every one of them, and put the
   customer app's own `INTEGRATION_KEY.txt` (generated fresh on first run)
   into `customer-relay`'s config, before this is reachable from anywhere
   but `127.0.0.1`.
4. **No real device, no real Cloudflare tunnel, no real Android build**
   were used - see "APK" below.

## APK

The real Capacitor wrapper (`Exact_V35_Native_Source/`, vendored into this
handover) was inspected: `capacitor.config.json`'s `server.url` points at a
Cloudflare quick-tunnel (`https://opinions-heads-criticism-safe.trycloudflare.com`)
- meaning the real APK is a thin WebView shell that loads its UI live from
that tunnel, not from bundled local assets. This sandbox has no Android
SDK (`ANDROID_HOME` unset, no `sdkmanager`/`apksigner`) and, as with the
Driver app in an earlier session, no access to the real signing keystore -
rebuilding and re-signing a real APK was not possible here, consistent
with this project's standing rule of never asking for or handling a
private signing key. The deliverable is therefore the adapted PWA source
(`customer-app/`) plus the unmodified native wrapper source, ready for
whoever holds the Capacitor toolchain + keystore to point `server.url` (or
switch to bundled `webDir` assets) at a staging build of `customer-app/`
and produce a real staging APK. See the final report for the exact
resulting SHA-256 of everything that *was* produced in this session.
