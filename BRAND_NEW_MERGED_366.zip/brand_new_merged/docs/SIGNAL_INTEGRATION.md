# Signal integration

## What this is

The driver-side transport. The engine's driver side was always
transport-agnostic (`handleDriverMessage(driverId, text)` in,
`claimOutbox('driver', ...)` / `ackOutbox(...)` out) - this is the piece
that actually moves text between a driver's Signal app and that contract.

**This talks to [signal-cli](https://github.com/AsamK/signal-cli) directly**
(the unofficial but long-established Signal command-line client), using its
own JSON-RPC daemon mode - not the third-party `signal-cli-rest-api` Docker
wrapper an earlier draft of this integration was built against. That earlier
draft was thrown away and replaced, not layered on top of: the existing
production setup already runs signal-cli itself, so adding a second Signal
system (the REST wrapper, its own container, its own linked-device slot on
the account) would have been unnecessary risk and operational surface for
no real benefit. The one thing worth knowing about that swap: signal-cli's
native JSON-RPC envelope shape is the same shape the REST wrapper always
mirrored (`source`, `sourceNumber`, `timestamp`, `dataMessage.message`), so
the adapter's dedup/parsing/ack logic needed no changes - only the transport
underneath it (`signal/signalCliClient.js`, new) changed.

**Tested against a mocked signal-cli daemon, not a real Signal account.**
`test/signalCliClient.test.js` and `test/signalAdapter.test.js` run a real
TCP server that speaks the documented newline-delimited JSON-RPC protocol
(not a stub of the client's own internals) - but nobody has sent a real
Signal message through this yet.

## How it fits together

```
driver's phone (real Signal app - no separate driver app needed)
        |
        v
signal-cli daemon  (the existing signal-cli setup, run as
        |            `signal-cli -a <business number> daemon --socket <path>`
        |            or `daemon --tcp=HOST:PORT`)
        |  newline-delimited JSON-RPC 2.0 over a Unix socket or TCP:
        |  "send" is a request/response call; "receive" arrives as an
        |  unsolicited notification the instant a message comes in - a
        |  persistent push connection, not polling.
        v
signal/signalCliClient.js  (low-level JSON-RPC client: connect, send,
        |                    correlate responses by id, surface receives)
        v
signal/adapter.js  (drains received envelopes, translates both directions)
        |
        |  POST /driver/inbound        GET /driver/outbound/pending
        |                              POST /driver/outbound/ack
        v
server/index.js  ->  Engine.handleDriverMessage / claimOutbox / ackOutbox
```

A driver's Signal phone number *is* their driver id in the engine
(`registerDriver('+447700900123', 'Dave')`) - there's no separate mapping
table between "driver id" and "Signal number" to keep in sync.

## What's real and tested

`test/signalCliClient.test.js` (the JSON-RPC client, against a real TCP
mock daemon):
- connect/close, and `isConnected()` tracking the real socket state.
- `send()` writes a well-formed `{jsonrpc, method: "send", params, id}`
  request and resolves on the matching `id` response, including several
  concurrent sends correlated by id rather than arrival order.
- An error response from the daemon rejects the call; a call that never
  gets a response times out rather than hanging forever; a dropped
  connection rejects any still-pending call.
- Unsolicited `receive` notifications (no `id`) are delivered to the
  adapter as they arrive.
- `account` is included in every request when the daemon runs
  multi-account (`SIGNAL_CLI_ACCOUNT`).

`test/signalAdapter.test.js` (the adapter, against the same kind of mock
daemon plus a real `server/index.js` + engine):
- An inbound Signal message is forwarded to the real engine and actually
  processed (a driver going `ON` duty via a mocked envelope updates real
  engine state).
- Non-text envelopes (receipts, typing indicators) are skipped, not
  treated as errors.
- Outgoing driver messages are sent via signal-cli's documented `send`
  method shape and then acknowledged.
- A failed send is acked as failed, not silently resent - the engine's own
  outbox-lease logic turns it into a review flag.
- **Signal retry/duplicate handling**: a redelivered envelope (Signal's
  own retry behaviour, not this code's) with the same source+timestamp is
  forwarded again (still HTTP 200 from the adapter's point of view) but the
  engine's own `firstSeen()` dedup recognises it and no-ops it rather than
  reprocessing - the messageId the adapter derives is stable across
  redeliveries specifically so this works.
- A full round trip: a driver goes on duty and accepts an order over
  (mocked) Signal, and gets the real "it's yours" reply back over Signal.
- **Swipe-to-quote-reply accept**: a driver can reply to a quoted JOB offer
  message (e.g. just "ACCEPT", no order id typed) and it resolves to the
  right order - the adapter records the Signal timestamp of every sent
  message that carries an `orderId` (job offers, status prompts), and when
  an inbound envelope's `dataMessage.quote.id` matches one of those
  timestamps, it's passed through to the engine as `quotedOrderId`. Tested
  end to end: a real JOB offer is actually sent via `pollOutboundOnce()`,
  then a driver's quoted "ACCEPT" reply (with `quote.id` set to that real
  recorded timestamp) is shown to resolve to `ASSIGNED` with no order id in
  the message text. Quotes are only tracked for messages that had an
  orderId, and expire after 2 hours - a stale or unrecognised quote falls
  back to the engine's normal `driver_need_id` prompt, same as replying
  with no quote at all.

## Setting it up for real

This assumes signal-cli is already set up and linked to the business's
Signal account, per the existing setup already in place - this doc only
covers pointing this adapter at it.

1. **Run signal-cli in daemon mode**, if it isn't already:
   ```
   signal-cli -a +44<business number> daemon --socket /var/run/signal-cli/socket
   ```
   or, for a TCP daemon (e.g. signal-cli running on a different host or
   container than this adapter):
   ```
   signal-cli -a +44<business number> daemon --tcp=127.0.0.1:7583
   ```
   `--socket` is preferred when the adapter runs on the same host - no
   network exposure at all for this connection.
2. **Register each driver** with their Signal number as their driver id:
   `POST /driver/register {"id": "+447700900123", "name": "Dave"}` against
   `server/index.js`, with the `X-Gateway-Token` header set to
   `config.gateway.token`.
3. **Run the adapter** alongside `server/index.js` and alongside
   signal-cli's daemon (three separate processes):
   ```
   SIGNAL_CLI_SOCKET=/var/run/signal-cli/socket \
   ROCKET_API_BASE=http://localhost:8787 \
   ROCKET_API_TOKEN=<config.gateway.token> \
   node signal/index.js
   ```
   or, for the TCP form:
   ```
   SIGNAL_CLI_HOST=127.0.0.1 SIGNAL_CLI_PORT=7583 \
   ROCKET_API_BASE=http://localhost:8787 \
   ROCKET_API_TOKEN=<config.gateway.token> \
   node signal/index.js
   ```
   Set `SIGNAL_CLI_ACCOUNT` too if signal-cli's daemon is running in
   multi-account mode (no `-a` on its own command line).

## What this still doesn't cover

- **Not run against a real Signal account.** Section above, repeated here
  because it's the important line: the request/response shapes are
  documented and tested against a faithful mock of the JSON-RPC protocol,
  not proven against Signal itself. Do that before a real driver relies on
  it.
- **No group messages, attachments, or read receipts back to the driver.**
  The adapter only looks at `dataMessage.message` (plain text) and only
  sends plain text - a driver sending a photo or voice note is silently
  ignored (not an error, just nothing the engine can use).
- **No delivery confirmation from Signal itself.** A successful `send`
  response only means signal-cli accepted and processed the send request,
  not proof of final delivery to the driver's device - the same
  "acked at the gateway" limitation the Tasker SMS side has.
- **Reconnection is not automatic.** If the daemon connection drops mid-run
  (signal-cli restarts, a network blip on the TCP form), the adapter's
  `ensureConnected()` reconnects lazily on the next tick, but there's no
  backoff/retry tuning - fine for a single-driver-fleet pilot, worth
  revisiting before scaling up.

## Sources used while building this

- [signal-cli's own man page for JSON-RPC mode](https://github.com/AsamK/signal-cli/blob/master/man/signal-cli-jsonrpc.5.adoc) — the verbatim request/response/notification shapes (`send` as a request/response method, `receive` as an unsolicited notification) and the incoming-envelope fields (`envelope.source`, `sourceNumber`, `timestamp`, `dataMessage.message`) this adapter parses
- [signal-cli's daemon mode documentation](https://github.com/AsamK/signal-cli/blob/master/man/signal-cli.1.adoc) — `daemon --socket` / `daemon --tcp` invocation and multi-account behaviour
