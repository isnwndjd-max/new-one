# Rocket Dispatch — Inbound SMS Durability Fix

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS.

Reported by the user directly: `POST /sms/inbound` could tell Tasker
"message accepted" (202) before that SMS had been permanently saved. If
the engine crashed in the gap between accepting it and actually
persisting it, the customer's message could be lost even though their
phone shows it as sent.

---

## 1. What was found

`POST /sms/inbound` put the message straight into `BurstBuffer` - a
plain in-memory `Map` (`src/burst.js`) used to group a customer's quick
successive texts into one reply - and returned 202 immediately. Nothing
in that handler called `markDirty()`/`flush()`.

The message only became durable (written to `state.json`) later, once:
1. the burst window elapsed (several seconds, `config.burstWindowSeconds`)
   with no further text from that phone, **and**
2. the server's tick timer next ran and processed it into an order via
   `engine.handleCustomerBurst()`, **and**
3. that tick's `flush()` call actually wrote `state.json` to disk.

A crash at any point before step 3 - which could be several seconds after
the 202 was already sent - lost the message with no trace of it ever
having arrived, even though the gateway (and the customer) believed it
had been accepted.

## 2. The fix

Exactly what the user asked for: **save first, then 202, then process.**

`src/engine.js`:
- `emptyEngineState()` gains a new field, `pendingInboundSms: []`.
- New method `recordPendingInboundSms(from, text, messageId)` - appends a
  raw record `{ id, from, text, messageId, receivedAt }` and returns the
  generated `id`. Does not touch the burst buffer, orders, or anything
  else - purely a durable "this arrived" record.
- New method `clearPendingInboundSms(ids)` - removes records by id once
  they've actually been folded into a processed (or correctly
  recognised-as-duplicate) burst.

`server/index.js`'s `POST /sms/inbound` handler:
```js
const pendingId = engine.recordPendingInboundSms(b.from, b.text, b.messageId || null);
markDirty();
flush();                                    // synchronous, fsync'd, atomic - see src/store.js
burst.add(b.from, b.text, b.messageId || null, now(), pendingId);
return json(res, 202, { ok: true, buffered: true });
```
`flush()` calls `Store.save()`, which writes to a temp file, `fsync`s it,
then atomically renames it over `state.json` (this was already how
`Store` worked - see its own file-level comment - just not called from
this handler before). The 202 response is only ever sent after that
write has genuinely completed.

`src/burst.js`: `BurstBuffer.add()`/`flushReady()` now also carry the
`pendingId` alongside the existing `ids` (messageId) array, so
`processBurst()` in `server/index.js` knows which durable records to
clear once a burst has actually been processed:
```js
function processBurst(phone, texts, ids, pendingIds) {
  if (ids.some((id) => engine.alreadySeen(id))) {
    engine.clearPendingInboundSms(pendingIds); // already handled earlier - redundant now
    markDirty();
    return;
  }
  for (const id of ids) engine.firstSeen(id);
  engine.handleCustomerBurst(phone, texts);
  engine.clearPendingInboundSms(pendingIds);   // only cleared once actually processed
  markDirty();
}
```

### Crash recovery on restart

If the process DOES die between the durable save and the burst being
processed, the record simply sits in `state.pendingInboundSms` on disk
until the next startup. `server/index.js` now checks for exactly that at
boot, right after the engine and burst buffer are created:
```js
if (state.pendingInboundSms.length) {
  console.warn(`[startup] recovering ${state.pendingInboundSms.length} inbound SMS not confirmed processed before the last shutdown`);
  for (const p of state.pendingInboundSms) burst.add(p.from, p.text, p.messageId, now(), p.id);
}
```
Each leftover record is fed back into the normal in-memory burst buffer,
so it goes through the *exact same* `processBurst()` path a brand-new
message would - including the existing `messageId` dedup
(`alreadySeen`/`firstSeen`). That matters for the edge case where the
crash actually happened *after* `handleCustomerBurst()` ran but *before*
the pending record was cleared and flushed: on replay, `alreadySeen()`
recognises the messageId and the burst is skipped as a duplicate rather
than reprocessed - see `processBurst`'s dedup branch above, which now
also clears the (redundant) pending record in that case. A message with
no `messageId` at all has no such protection - same pre-existing
limitation the driver-channel dedup already had, not something this fix
changes either way.

### Backward compatibility

A `state.json` written by a build from before this change won't have
`pendingInboundSms` (or the separately-added `venueConfirmations` /
`promotionCandidates` fields from the same session). `server/index.js`
now defaults all three to their empty value right after loading state,
before anything tries to use them:
```js
if (!state.pendingInboundSms) state.pendingInboundSms = [];
if (!state.venueConfirmations) state.venueConfirmations = {};
if (!state.promotionCandidates) state.promotionCandidates = [];
```

## 3. Not changed

- The burst-window batching behaviour itself (grouping a customer's
  quick successive texts into one reply) is unchanged - this only adds a
  durability step before and alongside it, not a new processing path.
- The existing `seenInbound`/`firstSeen`/`alreadySeen` dedup, which
  protects against the *gateway* retrying and double-sending the same
  message - untouched. This fix is about never losing a message that was
  never retried at all, a different failure mode.
- `/driver/inbound` was not touched - it already has its own dedup, and
  a driver connection (once the Signal adapter exists) is a different
  reliability shape from a stateless webhook POST; the user's report was
  specifically about the customer SMS path.

## 4. Test results

**261 / 261 passing** (`node --test test/*.js`), zero failures. 4 new
tests in `test/smsInboundDurability.test.js`:
- an inbound SMS is provably on disk (read back with a completely
  separate `Store` instance) before the 202 response is even sent, and
  without waiting for the burst window to elapse;
- once a burst is actually processed, its pending record is cleared from
  disk;
- a message saved but never processed before a simulated crash (a second
  server instance never got to tick) is recovered and correctly
  processed on the next startup against the same state file;
- an old state file saved before these fields existed loads cleanly
  under the new code, proving the migration defaults work.

## 5. Rollback

Three files, all additive (a new state field with an empty default, a
new pair of Engine methods, an optional extra parameter on
`BurstBuffer.add`/`flushReady`): revert the `/sms/inbound` handler,
`processBurst`/`tick`, and the startup-recovery block in
`server/index.js`; revert `recordPendingInboundSms`/
`clearPendingInboundSms` and the `pendingInboundSms` field in
`src/engine.js`; revert the `pendingId` parameter in `src/burst.js`. No
change to the shape of `state.json` for anything that already existed -
only a new, optional array.
