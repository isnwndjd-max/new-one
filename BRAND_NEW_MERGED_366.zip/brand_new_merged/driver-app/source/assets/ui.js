'use strict';
const R=DriverRules,$=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state={ok:true,paired:false,pending:false,connected:false},view='dashboard',paused=false,loading=false,submitting=false,message='',seq=0,callbacks=new Map(),gpsState=null,refreshTimer=null,refreshQueued=false,pendingSince=0,pendingLabel='Action pending';

function call(op,data={}){
 return new Promise(resolve=>{
  const id=String(++seq);let timer;
  const done=r=>{clearTimeout(timer);callbacks.delete(id);resolve(r);};
  callbacks.set(id,done);
  timer=setTimeout(()=>done({ok:false,pending:!!state.pending||op==='submit'||op==='retry',error:'The secure connection is still working. The saved action will be checked automatically.'}),30000);
  if(window.RocketDriver)window.RocketDriver.call(id,op,JSON.stringify(data));
  else done({ok:false,pending:!!state.pending,error:'Preview mode — Android bridge is not connected.'});
 });
}
window.driverReply=(id,raw)=>{
 const done=callbacks.get(String(id));if(!done)return;
 try{done(JSON.parse(raw));}catch(e){done({ok:false,pending:true,error:'Unverified reply. Do not repeat the action.'});}
};

function makePreview(){
 const now=Date.now(),s=R.demo(now);
 s.snapshot.driver={id:'DDEMO',name:'Dean',shift:'CAR',enabled:true};
 s.snapshot.jobs=[
  {id:'A005',customerLabel:'Customer',rev:1,status:'ASSIGNED',totalPence:2350,orderTotalPence:2000,owedPence:350,cashDuePence:2350,checksRequired:false,items:[{name:'Select 1',qty:1}],location:{label:'The Little Harp',address:'The Little Harp',town:'Clevedon',postcode:'BS21 7RH',lat:51.4374142,lon:-2.8652068,confirmed:true}},
  {id:'A006',customerLabel:'Customer',rev:1,status:'OFFERED',offerExpires:now+600000,totalPence:4000,orderTotalPence:4000,owedPence:0,cashDuePence:4000,checksRequired:false,items:[{name:'Select 1',qty:2}],location:{label:'The Glassmaker',town:'Nailsea',postcode:'BS48 1RD',lat:51.4333,lon:-2.7583,confirmed:true}}
 ];
 s.previewMetrics={totalWagesPence:2000,jobsCompleted:3};
 s.message='';
 return s;
}
function locked(){return submitting||state.pending||(!state.demo&&!R.fresh(state));}
function snap(){return state.snapshot||{};}
function driver(){return snap().driver||{};}
function jobs(){
 const a=[...(snap().jobs||[])];
 const rank={ARRIVED:0,ASSIGNED:1,OFFERED:2};
 return a.sort((x,y)=>(rank[x.status]??9)-(rank[y.status]??9));
}
function currentJob(){return jobs()[0]||null}
function nextJob(){return jobs()[1]||null}
function moneyOrDash(p){return Number.isSafeInteger(p)?R.money(p):'—'}
function itemCount(j){return (j?.items||[]).reduce((n,x)=>n+Number(x.qty||0),0)}
function statusName(j){
 return ({OFFERED:'NEW',ASSIGNED:'ACCEPTED',ARRIVED:'HERE'})[j?.status]||String(j?.status||'');
}
function connectionText(){
 if(state.demo)return 'Preview';
 if(R.fresh(state))return 'Online';
 if(state.snapshot)return 'Reconnecting';
 return 'Offline';
}
function updateHeader(){
 const pill=$('status-pill'),txt=$('status-text'),c=connectionText();
 txt.textContent=c;
 pill.className='status-pill '+(state.demo?'preview':R.fresh(state)?'':'offline');
}
function statCard(label,value,cls=''){return `<div class="stat"><div class="stat-label">${esc(label)}</div><div class="stat-value ${cls}">${value}</div></div>`}
function totalWages(){
 const m=state.previewMetrics||snap().metrics||{},d=driver();
 const p=m.totalWagesPence??d.totalWagesPence??m.todayEarningsPence??d.todayEarningsPence;
 return Number.isSafeInteger(p)?p:null;
}
function summaryStats(){
 const m=state.previewMetrics||snap().metrics||{},done=m.jobsCompleted??driver().jobsCompleted;
 return '<div class="stats">'+statCard('Bonus total',moneyOrDash(totalWages()),'green')+statCard('Completed jobs',Number.isSafeInteger(done)?String(done):'—')+statCard('Current jobs',String((snap().jobs||[]).length))+'</div>';
}
function cashBreakdown(j){
 const due=Number.isSafeInteger(j.cashDuePence)?j.cashDuePence:null;
 const debt=Number.isSafeInteger(j.owedPence)?j.owedPence:0;
 const order=Number.isSafeInteger(j.orderTotalPence)?j.orderTotalPence:due===null?null:Math.max(0,due-debt);
 return '<div class="cash-breakdown"><div><span>This order</span><b>'+moneyOrDash(order)+'</b></div><div><span>Previous debt</span><b>'+moneyOrDash(debt)+'</b></div><div class="cash-total"><span>Cash to collect</span><b>'+moneyOrDash(due)+'</b></div></div>';
}
function navigationReady(j){
 const l=j?.location;
 return !!j&&['ASSIGNED','ARRIVED'].includes(j.status)&&!!l?.confirmed&&Number.isFinite(l.lat)&&Number.isFinite(l.lon)&&(state.demo||R.fresh(state));
}
function destinationText(j){
 const l=j?.location||{};
 return [...new Set([l.label,l.address,l.town,l.postcode].filter(Boolean))].join(' · ');
}
function navigationButtons(j){
 if(!j)return '';
 const ready=navigationReady(j);
 return '<div class="navigation-row"><button class="navigate-job" data-nav="'+esc(j.id)+'" '+(ready?'':'disabled')+'>↗ Navigate</button><button class="copy-location" data-copy="'+esc(j.id)+'" '+(ready?'':'disabled')+'>Copy address</button></div>'+
 (!ready?'<p class="navigation-note">'+(j.status==='OFFERED'?'Accept the job to unlock navigation.':!R.fresh(state)&&!state.demo?'Reconnect to verify the latest meeting point.':'Waiting for a confirmed meeting pin.')+'</p>':'');
}
function jobCard(j,{next=false}={}){
 if(!j)return '<div class="job-card empty-job"><div class="job-id">'+(next?'No queued delivery':'Ready for your next delivery')+'</div><p class="muted">'+(driver().shift==='OFF'?'Go online to receive work.':'Dispatch will send the next job here.')+'</p></div>';
 return '<article class="job-card"><div class="job-top"><span class="job-id">'+esc(j.id)+'</span><span class="job-badge '+(j.status==='ARRIVED'?'blue':'')+'">'+esc(statusName(j))+'</span></div>'+
 '<h3 class="destination-title">'+esc(j.location?.label||'Awaiting meeting point')+'</h3>'+
 '<p class="destination-address">'+esc([j.location?.address,j.location?.town,j.location?.postcode].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(' · ')||'Use the confirmed map pin for the meeting point.')+'</p>'+
 '<div class="order-items">'+(j.items||[]).map(x=>'<div><b>'+esc(x.qty)+' ×</b><span>'+esc(x.name)+'</span></div>').join('')+'</div>'+
 cashBreakdown(j)+navigationButtons(j)+'</article>';
}

function actionButton(cls,icon,label,enabled){
 return `<button class="action ${cls||''}" ${enabled?'':'disabled'}><span class="ico">${icon}</span><span>${label}</span></button>`;
}
function pendingPanel(){
 if(!state.pending&&!submitting)return '';
 return `<div class="pending"><b>${esc(pendingLabel)}…</b><span>Waiting for dispatch confirmation</span></div>`;
}
function dashboard(){
 const j=currentJob(),n=nextJob(),can=!locked();
 const accept=!!j&&j.status==='OFFERED'&&j.offerExpires>Date.now()&&['CAR','FOOT'].includes(driver().shift)&&can;
 const eta=!!j&&j.status==='ASSIGNED'&&can,here=eta,complete=!!j&&j.status==='ARRIVED'&&can;
 return `${state.demo?'<div class="preview-note">VISUAL PREVIEW · no live orders or customer messages</div>':''}
 ${summaryStats()}
 <div class="shift-controls" aria-label="Driver shift"><button data-shift="CAR" class="${driver().shift==='CAR'?'selected':''}" ${locked()?'disabled':''}>In car</button><button data-shift="FOOT" class="${driver().shift==='FOOT'?'selected':''}" ${locked()?'disabled':''}>On foot</button><button class="end-shift" ${locked()||driver().shift==='OFF'?'disabled':''}>End shift</button></div>
 <p class="shift-note">${driver().shift==='FOOT'?'On foot · Nailsea only':driver().shift==='CAR'?'In car · all service towns':driver().shift==='BREAK'?'On break · choose your mode to resume':'Off shift · choose your mode to start'}</p>
 <section class="section"><h2 class="section-title">Current Job</h2>${jobCard(j)}
 <div class="actions">
  ${actionButton('primary accept','✓','ACCEPT',accept)}
  ${actionButton('eta-action','▣','ETA',eta)}
  ${actionButton('here','⌖','HERE',here)}
  ${actionButton('complete','⚑','COMPLETE',complete)}
 </div>
 ${pendingPanel()}</section>
 <section class="section"><h2 class="section-title">Next Job</h2>${jobCard(n,{next:true})}</section>
 <div class="quick-grid">
  <button class="quick green" data-view="stock"><span class="ico">◇</span>My Stock</button>
  <button class="quick" data-view="earnings"><span class="ico">£</span>Bonus total</button>
  <button class="quick help-quick"><span class="ico">!</span>Help / Issue</button>
  <button class="quick break-quick"><span class="ico">☕</span>On Break</button>
  <button class="quick danger offline-quick"><span class="ico">⏻</span>End shift</button>
  <button class="quick" data-view="settings"><span class="ico">⚙</span>App Settings</button>
 </div>
 ${message||state.message?`<p class="feedback">${esc(message||state.message)}</p>`:''}`;
}
function pageHead(title){return `<div class="page-head"><button class="back">‹</button><h1>${esc(title)}</h1></div>`}
function stockPage(){
 const stock=snap().stock;
 return `<div class="panel-page">${pageHead('My Stock')}<section class="card"><h2>Stock carried</h2>${Array.isArray(stock)&&stock.length?stock.map(x=>`<div class="stock-row"><b>${esc(x.name)}</b><span>${esc(x.held)} held · ${esc(x.free)} free</span></div>`).join(''):'<p class="muted">No tracked stock supplied.</p>'}</section></div>`;
}
function earningsPage(){
 return '<div class="panel-page">'+pageHead('Bonus total')+'<section class="card wages-card"><p class="eyebrow">YOUR DRIVER BONUS</p><div class="wages-total">'+moneyOrDash(totalWages())+'</div><p class="muted">'+(state.demo?'Preview figure only.':'Updated by dispatch after each completed delivery.')+'</p></section></div>';
}

function gpsText(){
 if(state.demo)return 'Preview only';
 if(!gpsState)return 'Checking…';
 const map={OFF:'Off',LIVE:'Live · encrypted GPS sent',TRACKING:'Tracking · waiting for good fix',WAITING_JOB:'Ready · no active delivery',RELAY_NOT_READY:'Ready · dispatch GPS endpoint pending',RECONNECTING:'Reconnecting',NEEDS_PERMISSION:'Location permission required'};
 return map[gpsState.state]||gpsState.state||'Unknown';
}
async function refreshGps(){
 if(state.demo||!state.paired){gpsState=null,refreshTimer=null,refreshQueued=false,pendingSince=0,pendingLabel='Action pending';return;}
 const r=await call('gpsStatus');
 gpsState=r&&typeof r==='object'?r:null;
 if(view==='settings')render();
}
function settingsPage(){
 const d=driver();
 let account='';
 if(state.demo){
  account=`<section class="card pairing-box"><h2>Connect this driver</h2><p class="muted">This preview makes no live changes. Pair the phone when you are ready.</p><label for="pair">Driver pairing code</label><input id="pair" type="password" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="RD2.…" maxlength="6000"><button id="paste-pair" class="btn text wide">Paste pairing code</button><button id="pair-button" class="btn primary wide">Pair driver account</button><p id="pair-error" class="error"></p></section>`;
 }else{
  account=`<section class="card"><h2>${esc(d.name||'Driver')}</h2><p class="muted">Paired to an individual encrypted driver channel.</p><button id="rotate" class="btn wide" ${state.pending?'disabled':''}>Rotate / re-enrol pairing</button><button id="unpair" class="btn text wide" ${state.pending?'disabled':''}>Remove local pairing</button></section>`;
 }
 const gps=`<section class="card"><h2>Delivery GPS</h2><div class="stock-row"><b>Status</b><span>${esc(gpsText())}</span></div><p class="small">GPS is only sent while dispatch reports an assigned/arrived delivery and the driver is CAR or FOOT. Position packets use the Driver app's encrypted channel.</p>${state.demo?'':'<button id="gps-enable" class="btn wide">Enable / fix GPS</button><button id="gps-refresh" class="btn text wide">Refresh GPS status</button>'}</section>`;
 return `<div class="panel-page">${pageHead('App Settings')}<section class="card"><h2>Connection</h2><p><b>${esc(connectionText())}</b></p><p class="small">Rocket Driver Full · 1.1.4</p></section>${gps}${account}<section class="card"><h2>Privacy</h2><p class="small">The driver app only receives its own jobs. Boss controls and other drivers' jobs stay outside this app.</p></section></div>`;
}
function render(){
 updateHeader();
 $('main').innerHTML=view==='stock'?stockPage():view==='earnings'?earningsPage():view==='settings'?settingsPage():dashboard();
 bind();
}
function closeModal(){$('modal').hidden=true}
function modal(title,body,button,action){
 $('dialog').innerHTML=`<h2>${esc(title)}</h2>${body}<p class="error" id="form-error"></p><div class="modal-buttons"><button id="cancel" class="cancel">Back</button><button id="confirm" class="confirm">${esc(button)}</button></div>`;
 $('modal').hidden=false;$('cancel').onclick=closeModal;$('confirm').onclick=action;
}
function etaModal(j){
 $('dialog').innerHTML=`<h2>Send ETA</h2><p class="muted">Choose the update for ${esc(j.id)}.</p><div class="eta-options">${[5,10,15,30].map(n=>`<button data-min="${n}">${n} min</button>`).join('')}</div><div class="modal-buttons"><button id="cancel" class="cancel" style="grid-column:1/3">Back</button></div>`;
 $('modal').hidden=false;$('cancel').onclick=closeModal;
 $('dialog').querySelectorAll('[data-min]').forEach(b=>b.onclick=()=>{closeModal();send({action:'ETA',orderId:j.id,expectedRev:j.rev,minutes:Number(b.dataset.min)});});
}
async function send(a){
 try{
  const validated=R.validate(state,a);submitting=true;pendingSince=Date.now();pendingLabel=({ACCEPT:'Accepting',COMPLETE:'Completing',SHIFT:'Updating shift',ETA:'Sending ETA',ARRIVED:'Confirming arrival'})[a.action]||'Sending action';closeModal();render();
  if(state.demo){state=R.applyDemo(state,validated);state.previewMetrics=state.previewMetrics||{totalWagesPence:2000,jobsCompleted:3};message='Preview updated. Nothing was sent.';closeModal();}
  else{
   const r=await call('submit',validated);
   if(r.ok){state={...state,...r};message=r.message||'';closeModal();}
   else{state.pending=!!r.pending;throw Error(r.error);}
  }
 }catch(e){
  const fe=$('form-error');if(fe&&!$('modal').hidden)fe.textContent=e.message;else message=e.message;
 }finally{
  submitting=false;render();if(state.paired&&!state.demo)await refresh();
 }
}
function completeModal(j){
 const owed=Number.isSafeInteger(j.owedPence)?j.owedPence:0;
 const orderTotal=Number.isSafeInteger(j.orderTotalPence)?j.orderTotalPence:Math.max(0,j.cashDuePence-owed);
 const age=j.overdueDays?(' · '+String(j.overdueDays)+' day'+(j.overdueDays===1?'':'s')+' old'):'';
 const debtLine=owed>0?('<p class="small"><b>Previous customer debt:</b> '+R.money(owed)+age+'</p>'):'';
 $('dialog').innerHTML='<h2>Complete delivery</h2><p>Current order: <b>'+R.money(orderTotal)+'</b></p>'+debtLine+'<p>Total cash due now: <b>'+R.money(j.cashDuePence)+'</b></p><label class="checkline"><input id="checks" type="checkbox">Required delivery checks completed</label><div class="eta-options"><button id="paid-full">PAID IN FULL</button><button id="owe-all">OWE</button></div><label for="cash">Part payment received (£)</label><input id="cash" inputmode="decimal" placeholder="0.00"><button id="part-pay" class="outline wide" type="button">RECORD PART PAYMENT</button><p class="small">PAID IN FULL records all cash due. OWE records no cash. Part payment records exactly what was handed over; V35 keeps the remainder on the customer debt ledger.</p><p class="error" id="form-error"></p><div class="modal-buttons"><button id="cancel" class="cancel" style="grid-column:1/3">Back</button></div>';
 $('modal').hidden=false;$('cancel').onclick=closeModal;
 const sendCash=(pence)=>send({action:'COMPLETE',orderId:j.id,expectedRev:j.rev,collectedPence:pence,checksConfirmed:$('checks').checked});
 $('paid-full').onclick=()=>sendCash(j.cashDuePence);
 $('owe-all').onclick=()=>sendCash(0);
 $('part-pay').onclick=()=>{try{const v=R.parseCash($('cash').value);if(v<=0||v>=j.cashDuePence)throw Error('For part payment, enter an amount above £0 and below the total due.');sendCash(v);}catch(e){$('form-error').textContent=e.message;}};
}
function helpModal(j){
 if(!j){modal('Help / Issue','<p>No current job is available. Contact dispatch directly for a general issue.</p>','OK',closeModal);return;}
 modal('Help / Issue',`<label for="reason">What is wrong?</label><select id="reason"><option value="CANNOT_FIND">Cannot find the customer</option><option value="PAYMENT_PROBLEM">Cash or payment problem</option><option value="DELIVERY_CHECK">Delivery checks failed</option><option value="OTHER">Something else</option></select><p class="small">This requests help. It does not cancel or complete the job.</p>`,'SEND',()=>send({action:'HELP',orderId:j.id,expectedRev:j.rev,reason:$('reason').value}));
}
function bind(){
 document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{view=b.dataset.view;render();if(view==='settings')refreshGps();});
 const back=document.querySelector('.back');if(back)back.onclick=()=>{view='dashboard';render()};
 $('status-pill').onclick=()=>{view='settings';render();refreshGps()};
 const j=currentJob();
 const a=document.querySelector('.accept');if(a&&!a.disabled)a.onclick=()=>modal('Accept delivery?','<p>'+esc(destinationText(j))+'</p>'+cashBreakdown(j),'ACCEPT',()=>send({action:'ACCEPT',orderId:j.id,expectedRev:j.rev}));
 const e=document.querySelector('.eta-action');if(e&&!e.disabled)e.onclick=()=>etaModal(j);
 const h=document.querySelector('.here');if(h&&!h.disabled)h.onclick=()=>modal('At the meeting point?','<p>Only confirm HERE when you have actually reached the agreed meeting point.</p>','HERE',()=>send({action:'HERE',orderId:j.id,expectedRev:j.rev}));
 const c=document.querySelector('.complete');if(c&&!c.disabled)c.onclick=()=>completeModal(j);
 const help=document.querySelector('.help-quick');if(help)help.onclick=()=>helpModal(j);
 const br=document.querySelector('.break-quick');if(br)br.onclick=()=>modal('Go on break?','<p>Set your driver status to <b>On Break</b>?</p>','CONFIRM',()=>send({action:'SHIFT',mode:'BREAK'}));
 document.querySelectorAll('[data-shift]').forEach(b=>b.onclick=()=>{const mode=b.dataset.shift;if(locked())return;modal(mode==='CAR'?'Work in car?':'Work on foot?',mode==='CAR'?'<p>Receive jobs across the service towns.</p>':'<p>On-foot jobs are limited to Nailsea.</p>','CONFIRM',()=>send({action:'SHIFT',mode}));});
 document.querySelectorAll('.offline-quick,.end-shift').forEach(b=>b.onclick=()=>{if(locked())return;if((snap().jobs||[]).length){modal('Finish your jobs first','<p>You still have jobs or offers. Complete them or ask dispatch to clear them before ending your shift.</p>','OK',closeModal);return;}modal('End your shift?','<p>You will stop receiving new offers. Your earned wages remain saved.</p>','END SHIFT',()=>send({action:'SHIFT',mode:'OFF'}));});
 if($('gps-enable'))$('gps-enable').onclick=async()=>{const r=await call('gpsEnable');message=r.message||r.error||'';await refreshGps();};
 if($('gps-refresh'))$('gps-refresh').onclick=refreshGps;
 if($('paste-pair'))$('paste-pair').onclick=async()=>{const r=await call('clipboard');if(r.ok&&r.text){$('pair').value=r.text.trim();$('pair-error').textContent='Pairing code pasted.';}else $('pair-error').textContent=r.error||'No pairing code found.';};
 if($('pair-button'))$('pair-button').onclick=async()=>{const code=$('pair').value.trim();$('pair-button').disabled=true;const r=await call('pair',{code});if(r.ok){state={...r,connected:false};message='';view='dashboard';await refresh();}else{$('pair-error').textContent=r.error||'Pairing failed.';$('pair-button').disabled=false;}};
 if($('rotate'))$('rotate').onclick=()=>modal('Rotate / re-enrol pairing?',`<label for="new-pair">New pairing code</label><input id="new-pair" type="password" autocomplete="off" placeholder="RD2.…">`,'REPLACE',async()=>{const r=await call('replace',{code:$('new-pair').value.trim()});if(r.ok){state={...state,...r,connected:false};closeModal();await refresh();}else $('form-error').textContent=r.error;});
 if($('unpair'))$('unpair').onclick=()=>modal('Remove local pairing?','<p>This clears this app’s local pairing. It does not revoke access at dispatch.</p>','REMOVE',async()=>{const r=await call('unpair');if(r.ok){state=makePreview();message='';view='dashboard';closeModal();render();}else $('form-error').textContent=r.error;});
 document.querySelectorAll('[data-nav],[data-copy]').forEach(b=>b.onclick=async()=>{
  const id=b.dataset.nav||b.dataset.copy,j=(snap().jobs||[]).find(x=>x.id===id);
  if(!navigationReady(j))return;
  if(state.demo){message='Preview only — navigation opens from the paired Android app.';render();return;}
  b.disabled=true;
  const r=await call(b.dataset.nav?'navigate':'copyLocation',{orderId:id});
  message=r.ok?(b.dataset.nav?'Opening your map app.':'Meeting point copied.'):r.error||'Could not open this meeting point.';
  render();
 });

}
function scheduleRefresh(delay){
 clearTimeout(refreshTimer);
 if(paused||state.demo||!state.paired)return;
 refreshTimer=setTimeout(()=>refresh(),delay);
}
async function refresh(){
 if(paused||state.demo||!state.paired)return;
 if(loading||submitting){refreshQueued=true;return;}
 clearTimeout(refreshTimer);loading=true;refreshQueued=false;
 try{
  const r=await call('status');
  if(r.ok){state={...state,...r};message=r.lastReceipt?.message||r.message||'';}
  else{state.connected=false;state.pending=r.pending!==undefined?!!r.pending:state.pending;message=r.error||'Connection unavailable.';}
  if(state.pending&&!pendingSince)pendingSince=Date.now();
  if(!state.pending)pendingSince=0;
  if($('modal').hidden)render();
 }finally{
  loading=false;
  scheduleRefresh(refreshQueued?0:state.pending?(Date.now()-pendingSince<15000?500:2000):5000);
 }
}
window.setAppPaused=v=>{paused=!!v;clearTimeout(refreshTimer);if(!paused){refresh();if(view==='settings')refreshGps();}};
window.driverBack=()=>{if(!$('modal').hidden)closeModal();else if(view!=='dashboard'){view='dashboard';render();}};
window.driverPush=async type=>{if(paused||state.demo||!state.paired)return;if(type==='revoked'){state.connected=false;message='Pairing revoked or rotated. Re-enrol this Driver account.';render();return;}await refresh();};
window.DriverPreview={start:()=>{state=makePreview();view='dashboard';render()},state:()=>JSON.parse(JSON.stringify(state)),act:a=>send(a)};
window.driverGpsPermissionChanged=()=>{refreshGps();};

(async()=>{
 if(window.RocketDriver){
  const r=await call('local');
  if(r.ok&&r.paired){state={...state,...r};render();await refresh();return;}
 }
 state=makePreview();render();
})();