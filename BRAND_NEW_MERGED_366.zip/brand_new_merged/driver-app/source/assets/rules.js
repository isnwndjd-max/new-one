/* Shared by the bundled UI and Node tests. No network or storage access. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.DriverRules=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const integer=(x,lo=0,hi=100000000)=>Number.isSafeInteger(x)&&x>=lo&&x<=hi;
function money(p){return integer(p)?'£'+(p/100).toFixed(2):'Unavailable';}
function parseCash(s){if(typeof s!=='string'||!/^\d{1,6}(?:\.\d{1,2})?$/.test(s.trim()))throw Error('Enter pounds and pence, for example 12.50.');const [p,d='']=s.trim().split('.');const n=Number(p)*100+Number(d.padEnd(2,'0'));if(!integer(n))throw Error('Amount is too large.');return n;}
function fresh(state,now=Date.now()){return !!(state&&state.connected&&state.snapshot&&integer(state.snapshot.at,1,Number.MAX_SAFE_INTEGER)&&state.snapshot.at<=now+30000&&now-state.snapshot.at<90000);}
function validate(state,a,now=Date.now()){
 if(!state||state.pending)throw Error('Wait for dispatch confirmation of the previous action.');
 if(!fresh(state,now))throw Error('Refresh the dispatch connection first.');
 const s=state.snapshot,d=s.driver;
 if(!d||!Array.isArray(s.jobs))throw Error('Dispatch data unavailable.');
 if(a.action==='SHIFT'){
  if(!['CAR','FOOT','BREAK','OFF'].includes(a.mode))throw Error('Choose a shift option.');
  if(!d.enabled&&a.mode!=='OFF')throw Error('Driver access is disabled.');
  if(a.mode==='OFF'&&s.jobs.length)throw Error('Clear jobs and offers before going off shift.');
  return {action:'SHIFT',mode:a.mode};
 }
 if(!d.enabled)throw Error('Driver access is disabled.');
 const j=s.jobs.find(j=>j.id===a.orderId);if(!j)throw Error('Job no longer available to this driver.');
 if(!integer(a.expectedRev,1)||a.expectedRev!==j.rev)throw Error('Job changed; refresh first.');
 const out={action:a.action,orderId:j.id,expectedRev:j.rev};
 switch(a.action){
  case 'ACCEPT': if(j.status!=='OFFERED'||!integer(j.offerExpires,1,Number.MAX_SAFE_INTEGER)||j.offerExpires<=now||!['CAR','FOOT'].includes(d.shift))throw Error('Offer expired or driver unavailable.');break;
  case 'HERE':if(j.status!=='ASSIGNED')throw Error('Job must be assigned before arrival.');break;
  case 'COMPLETE':if(j.status!=='ARRIVED')throw Error('Mark arrival before completion.');if(!integer(a.collectedPence)||a.collectedPence<0||a.collectedPence>j.cashDuePence)throw Error('Cash amount must be between £0 and the total due.');if(typeof a.checksConfirmed!=='boolean'||(j.checksRequired&&!a.checksConfirmed))throw Error('Confirm required delivery checks.');out.collectedPence=a.collectedPence;out.checksConfirmed=a.checksConfirmed;break;
  case 'ETA':if(j.status!=='ASSIGNED'||![5,10,15,30].includes(a.minutes))throw Error('Choose an ETA for an assigned job.');out.minutes=a.minutes;break;
  case 'HELP':if(!['CANNOT_FIND','PAYMENT_PROBLEM','DELIVERY_CHECK','OTHER'].includes(a.reason))throw Error('Choose a help reason.');out.reason=a.reason;break;
  default:throw Error('Unsupported driver action.');
 }
 return out;
}
function demo(now=Date.now()){
 return {ok:true,paired:false,connected:true,pending:false,demo:true,demoPendingPreview:true,message:'Preview only — nothing is sent.',snapshot:{
  v:1,seq:1,at:now,earningsTodayPence:4200,jobsCompletedToday:3,
  driver:{id:'DDEMO',name:'Demo Driver',shift:'CAR',enabled:true},
  jobs:[
   {id:'A1048',rev:1,status:'OFFERED',offerExpires:now+600000,totalPence:2500,cashDuePence:2500,checksRequired:true,customerLabel:'Jamie R.',owedPence:1750,overdueDays:8,overdue:true,debtLabel:'OWES £17.50 • 8 DAYS',items:[{name:'Select item',qty:2}],location:{label:'12 High Street, Rocketton',lat:51.4333,lon:-2.7583,confirmed:true}},
   {id:'A1049',rev:1,status:'OFFERED',offerExpires:now+600000,totalPence:1850,cashDuePence:1850,checksRequired:true,customerLabel:'Sarah K.',items:[{name:'Select item',qty:3}],location:{label:'11 Green Lane, Rocketton',lat:51.4341,lon:-2.7600,confirmed:true}}
  ],
  stock:[{name:'Select',held:8,free:6},{name:'Premium',held:5,free:4}]
 }};
}
function sampleJob(now){return {id:'A900',rev:1,status:'OFFERED',offerExpires:now+600000,totalPence:1250,cashDuePence:1250,checksRequired:true,items:[{name:'Lemonade',qty:2},{name:'Cookies',qty:1}],location:{label:'Demo meeting point · main entrance',lat:51.4333,lon:-2.7583,confirmed:true}};}
function applyDemo(state,input,now=Date.now()){
 if(!state?.demo)throw Error('Demo actions must not change a real account.');
 const current=JSON.parse(JSON.stringify(state));current.connected=true;current.snapshot.at=now;
 const a=validate(current,input,now),s=current.snapshot,j=s.jobs.find(j=>j.id===a.orderId);
 if(a.action==='SHIFT'){s.driver.shift=a.mode;if(['CAR','FOOT'].includes(a.mode)&&!s.jobs.length&&!current.demoFinished)s.jobs=[sampleJob(now)];}
 if(a.action==='ACCEPT'){j.status='ASSIGNED';j.rev++;}
 if(a.action==='HERE'){j.status='ARRIVED';j.rev++;}
 if(a.action==='COMPLETE'){s.jobs=s.jobs.filter(x=>x.id!==j.id);current.demoFinished=true;current.demoCash=1250;}
 current.message=a.action==='COMPLETE'?'Demo delivery completed. No real cash or stock was changed.':a.action==='HELP'?'Demo help request recorded. Nothing was sent.':a.action==='ETA'?'Demo ETA recorded. No customer text was sent.':'Demo updated. No live system was contacted.';
 s.seq++;return current;
}
return {money,parseCash,fresh,validate,demo,sampleJob,applyDemo};
});
