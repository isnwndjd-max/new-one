package com.rocket.driverprivate;

import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URI;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Driver-only client. The future trusted dispatch adapter must also enforce every rule. */
public final class DriverClient {
    public interface Storage { String get() throws Exception; void put(String value) throws Exception; }
    public interface Network { JSONObject get(JSONObject config,String path) throws Exception; JSONObject post(JSONObject config,String path,JSONObject data) throws Exception; }
    private final Storage storage; private final Network network;
    public DriverClient(Storage s,Network n){storage=s;network=n;}
    private JSONObject load() throws Exception{return new JSONObject(storage.get());}
    private void save(JSONObject s)throws Exception{storage.put(s.toString());}
    private JSONObject config(JSONObject s)throws Exception{JSONObject c=s.optJSONObject("config");if(c==null)throw new IllegalStateException("Pair this driver first");return c;}
    public static long whole(JSONObject j,String key,long low,long high)throws Exception{
        Object v=j.get(key);if(!(v instanceof Integer||v instanceof Long))throw new IllegalArgumentException("Invalid whole number");
        long n=((Number)v).longValue();if(n<low||n>high)throw new IllegalArgumentException("Number outside range");return n;
    }
    private static boolean bool(JSONObject j,String key)throws Exception{Object v=j.get(key);if(!(v instanceof Boolean))throw new IllegalArgumentException("Invalid flag");return (Boolean)v;}
    private static String string(JSONObject j,String key,int max)throws Exception{Object v=j.get(key);if(!(v instanceof String)||((String)v).length()>max)throw new IllegalArgumentException("Invalid text");return (String)v;}
    public static JSONObject encode(Protocol.Packet p)throws Exception{
        return new JSONObject().put("v",1).put("room",p.room).put("kind",p.kind).put("id",p.id).put("issued",p.issued).put("expires",p.expires).put("nonce",p.nonce).put("body",p.body);
    }
    public static Protocol.Packet decode(JSONObject e)throws Exception{
        if(e.length()!=8||whole(e,"v",1,1)!=1)throw new SecurityException("Wrong envelope");
        Protocol.Packet p=new Protocol.Packet(string(e,"room",32),string(e,"kind",8),string(e,"id",36),whole(e,"issued",1,9007199254740991L),whole(e,"expires",1,9007199254740991L),string(e,"nonce",16),string(e,"body",100000));
        Protocol.structure(p);return p;
    }
    public synchronized JSONObject pair(String value)throws Exception{
        JSONObject s=load();if(s.has("pending")||s.has("config"))throw new IllegalStateException("Resolve existing pairing first");
        if(value.length()>6000||!value.startsWith("RD2."))throw new IllegalArgumentException("Use a driver RD2 pairing code");
        JSONObject c=new JSONObject(Crypto.text(Crypto.un64(value.substring(4))));
        if(c.length()!=8||whole(c,"v",1,1)!=1)throw new IllegalArgumentException("Invalid pairing");
        String room=string(c,"room",32),driver=string(c,"driverId",40),root=string(c,"root",43),token=string(c,"token",128),pin=string(c,"tlsPin",64),url=string(c,"url",300),pinMode=string(c,"pinMode",8);
        if(!room.matches("[a-f0-9]{32}")||!driver.matches("D[A-Za-z0-9_-]{1,39}")||!root.matches("[A-Za-z0-9_-]{43}")||Crypto.un64(root).length!=32||!token.matches("[A-Za-z0-9_-]{32,128}")||!pin.matches("[a-f0-9]{64}")||!"SPKI".equals(pinMode))throw new IllegalArgumentException("Invalid pairing fields");
        URI u=new URI(url);if(!"https".equals(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null||!(u.getPath().isEmpty()||u.getPath().equals("/")))throw new IllegalArgumentException("HTTPS relay origin required");
        if(!"100.103.3.32".equals(u.getHost())||u.getPort()!=8911)throw new IllegalArgumentException("Private Driver relay required");
        c.put("url",url.replaceAll("/+$",""));s.put("config",c);save(s);return local();
    }
    public synchronized JSONObject replacePairing(String value)throws Exception{
        JSONObject s=load();if(s.has("pending"))throw new IllegalStateException("Resolve the pending action before rotating pairing");save(new JSONObject());return pair(value);
    }
    public synchronized JSONObject local()throws Exception{
        JSONObject s=load();return new JSONObject().put("ok",true).put("paired",s.has("config")).put("pending",s.has("pending"));
    }
    public synchronized JSONObject unpair()throws Exception{
        JSONObject s=load();if(s.has("pending"))throw new IllegalStateException("Cannot remove a pairing with an uncertain action");
        save(new JSONObject());return local();
    }
    private JSONObject view(JSONObject s,boolean connected,String message)throws Exception{
        JSONObject out=new JSONObject().put("ok",true).put("paired",s.has("config")).put("pending",s.has("pending")).put("connected",connected).put("message",message);
        out.put("snapshot",s.optJSONObject("snapshot")==null?JSONObject.NULL:s.getJSONObject("snapshot"));
        if(s.has("lastReceipt"))out.put("lastReceipt",s.getJSONObject("lastReceipt"));
        return out;
    }
    private static void validateSnapshot(JSONObject snap,JSONObject c,long now)throws Exception{
        whole(snap,"v",1,1);whole(snap,"seq",1,9007199254740991L);long at=whole(snap,"at",1,9007199254740991L);
        if(at>now+30000||now-at>Protocol.SNAPSHOT_TTL)throw new SecurityException("Stale dispatch state");
        JSONObject d=snap.getJSONObject("driver");if(!string(d,"id",40).equals(c.getString("driverId")))throw new SecurityException("Wrong driver");
        string(d,"name",60);bool(d,"enabled");if(!string(d,"shift",8).matches("OFF|CAR|FOOT|BREAK"))throw new SecurityException("Invalid shift");
        JSONArray jobs=snap.getJSONArray("jobs");if(jobs.length()>10)throw new SecurityException("Too many jobs");Set<String> ids=new HashSet<>();
        for(int i=0;i<jobs.length();i++){
            JSONObject j=jobs.getJSONObject(i);String id=string(j,"id",12);if(!id.matches("A[0-9]{3,8}")||!ids.add(id))throw new SecurityException("Invalid job");
            whole(j,"rev",1,1000000000);if(!string(j,"status",10).matches("OFFERED|ASSIGNED|ARRIVED"))throw new SecurityException("Invalid job state");
            long total=whole(j,"totalPence",0,100000000);whole(j,"cashDuePence",0,total);bool(j,"checksRequired");
            if(j.getString("status").equals("OFFERED"))whole(j,"offerExpires",1,9007199254740991L);
            JSONArray items=j.getJSONArray("items");if(items.length()>30)throw new SecurityException("Too many items");
            for(int k=0;k<items.length();k++){JSONObject item=items.getJSONObject(k);string(item,"name",80);whole(item,"qty",1,1000);}
            JSONObject l=j.getJSONObject("location");string(l,"label",200);bool(l,"confirmed");
            Object lat=l.opt("lat"),lon=l.opt("lon");boolean present=lat!=null&&lat!=JSONObject.NULL||lon!=null&&lon!=JSONObject.NULL;
            if(present&&(!(lat instanceof Number)||!(lon instanceof Number)||!Double.isFinite(((Number)lat).doubleValue())||!Double.isFinite(((Number)lon).doubleValue())||Math.abs(((Number)lat).doubleValue())>90||Math.abs(((Number)lon).doubleValue())>180))throw new SecurityException("Invalid destination");
        }
        JSONArray stock=snap.optJSONArray("stock");if(stock!=null){if(stock.length()>100)throw new SecurityException("Too much stock");for(int i=0;i<stock.length();i++){JSONObject x=stock.getJSONObject(i);string(x,"name",80);whole(x,"held",0,1000000);whole(x,"free",0,x.getLong("held"));}}
    }
    public synchronized JSONObject status()throws Exception{
        JSONObject s=load(),c=config(s);long now=System.currentTimeMillis();JSONObject response;
        try{response=network.get(c,"/v1/driver/status");}catch(Exception e){return view(s,false,"Connection unavailable. Pending actions remain saved.");}
        byte[] root=Crypto.un64(c.getString("root"));boolean connected=false;
        JSONObject envelope=response.optJSONObject("snapshot");
        if(envelope!=null){
            Protocol.Packet p=decode(envelope);String raw=Protocol.open(root,c.getString("room"),"snapshot",p);
            // Expired, correctly authenticated snapshots may not re-enable controls.
            if(p.expires>=now){Protocol.fresh(p,now,Protocol.SNAPSHOT_TTL);JSONObject snap=new JSONObject(raw);validateSnapshot(snap,c,now);
                long seq=snap.getLong("seq"),floor=s.optLong("snapshotSeq",0);String hash=Crypto.hash(raw);
                if(seq<floor||(seq==floor&&!hash.equals(s.optString("snapshotHash"))))throw new SecurityException("Snapshot replay rejected");
                s.put("snapshotSeq",seq).put("snapshotHash",hash).put("snapshot",snap).put("snapshotExpiry",p.expires);connected=true;
            }
        }
        JSONObject pending=s.optJSONObject("pending");JSONArray receipts=response.optJSONArray("receipts");
        if(pending!=null&&receipts!=null){
            if(receipts.length()>32)throw new SecurityException("Too many receipts");Protocol.Packet request=decode(pending.getJSONObject("envelope"));
            for(int i=0;i<receipts.length();i++){
                JSONObject e=receipts.getJSONObject(i);if(!request.id.equals(e.optString("id")))continue;
                Protocol.Packet p=decode(e);JSONObject r=new JSONObject(Protocol.open(root,c.getString("room"),"receipt",p));Protocol.fresh(p,now,Protocol.RECEIPT_TTL);
                if(!request.id.equals(r.getString("id"))||!Protocol.fingerprint(request).equals(r.getString("commandHash"))||!string(r,"state",8).matches("applied|rejected"))throw new SecurityException("Wrong confirmation");
                string(r,"message",300);long after=whole(r,"snapshotSeq",1,9007199254740991L);
                s.remove("pending");s.put("lastReceipt",new JSONObject().put("state",r.getString("state")).put("message",r.getString("message")));
                if(s.optLong("snapshotSeq",0)<after){connected=false;}break;
            }
        }
        save(s);return view(s,connected,connected?"Verified dispatch connection":"Waiting for fresh dispatch data");
    }
    private JSONObject freshSnapshot(JSONObject s,long now)throws Exception{
        JSONObject snap=s.optJSONObject("snapshot");if(snap==null||s.optLong("snapshotExpiry",0)<now)throw new IllegalStateException("Refresh the dispatch connection first");
        validateSnapshot(snap,config(s),now);return snap;
    }
    private JSONObject job(JSONObject snap,String id)throws Exception{
        JSONArray a=snap.getJSONArray("jobs");for(int i=0;i<a.length();i++)if(a.getJSONObject(i).getString("id").equals(id))return a.getJSONObject(i);
        throw new IllegalStateException("Job is no longer assigned or offered to this driver");
    }
    private JSONObject validAction(JSONObject input,JSONObject snap,long now)throws Exception{
        String action=string(input,"action",12);JSONObject out=new JSONObject().put("action",action),d=snap.getJSONObject("driver");
        if(action.equals("SHIFT")){
            String mode=string(input,"mode",8);if(!mode.matches("CAR|FOOT|BREAK|OFF"))throw new IllegalArgumentException("Invalid shift");
            if(!d.getBoolean("enabled")&&!mode.equals("OFF"))throw new IllegalStateException("Driver access is disabled");
            if(mode.equals("OFF")&&snap.getJSONArray("jobs").length()>0)throw new IllegalStateException("Clear jobs and offers before going off shift");
            return out.put("mode",mode);
        }
        if(!d.getBoolean("enabled"))throw new IllegalStateException("Driver access is disabled");
        String id=string(input,"orderId",12);JSONObject j=job(snap,id);long rev=whole(input,"expectedRev",1,1000000000);
        if(rev!=j.getLong("rev"))throw new IllegalStateException("Job changed; refresh first");out.put("orderId",id).put("expectedRev",rev);
        String state=j.getString("status");
        switch(action){
            case "ACCEPT": if(!state.equals("OFFERED")||j.getLong("offerExpires")<=now||!d.getString("shift").matches("CAR|FOOT"))throw new IllegalStateException("Offer expired or driver unavailable");break;
            case "HERE": if(!state.equals("ASSIGNED"))throw new IllegalStateException("Job must be assigned before arrival");break;
            case "COMPLETE":
                if(!state.equals("ARRIVED"))throw new IllegalStateException("Mark arrival before completion");
                long cash=whole(input,"collectedPence",0,100000000);
                if(cash>j.getLong("cashDuePence"))throw new IllegalArgumentException("Cash amount is above the total due");
                boolean checks=bool(input,"checksConfirmed");if(j.getBoolean("checksRequired")&&!checks)throw new IllegalArgumentException("Confirm delivery checks first");
                out.put("collectedPence",cash).put("checksConfirmed",checks);break;
            case "ETA":
                if(!state.equals("ASSIGNED"))throw new IllegalStateException("Job must be assigned");
                int mins=(int)whole(input,"minutes",1,30);if(!Arrays.asList(5,10,15,30).contains(mins))throw new IllegalArgumentException("Choose an ETA button");out.put("minutes",mins);break;
            case "HELP":
                String reason=string(input,"reason",24);if(!reason.matches("CANNOT_FIND|PAYMENT_PROBLEM|DELIVERY_CHECK|OTHER"))throw new IllegalArgumentException("Choose a help reason");out.put("reason",reason);break;
            default: throw new IllegalArgumentException("Unsupported driver action");
        }
        return out;
    }
    public synchronized JSONObject submit(JSONObject input,boolean retry)throws Exception{
        JSONObject s=load(),c=config(s);JSONObject pending=s.optJSONObject("pending");
        if(!retry){
            if(pending!=null)throw new IllegalStateException("Wait for confirmation of the previous action");
            long now=System.currentTimeMillis();JSONObject command=validAction(input,freshSnapshot(s,now),now);
            Protocol.Packet p=Protocol.seal(Crypto.un64(c.getString("root")),c.getString("room"),"command",Protocol.id(),now,Protocol.COMMAND_TTL,command.toString());
            pending=new JSONObject().put("envelope",encode(p));s.put("pending",pending);save(s);
        }
        if(pending==null)throw new IllegalStateException("No pending action");
        try{network.post(c,"/v1/driver/commands",pending.getJSONObject("envelope"));}catch(Exception e){return view(s,false,"Not confirmed. Retry sends the SAME saved action.");}
        return view(s,s.optJSONObject("snapshot")!=null && s.optLong("snapshotExpiry",0)>=System.currentTimeMillis(),"Sent. Waiting for dispatch confirmation.");
    }
    public JSONObject gpsGate()throws Exception{
        JSONObject s=load(),c=config(s);long now=System.currentTimeMillis();
        JSONObject response=network.get(c,"/v1/driver/status"),envelope=response.optJSONObject("snapshot");
        if(envelope==null)return new JSONObject().put("ok",true).put("active",false).put("reason","NO_SNAPSHOT");
        Protocol.Packet p=decode(envelope);if(p.expires<now)return new JSONObject().put("ok",true).put("active",false).put("reason","STALE_SNAPSHOT");
        Protocol.fresh(p,now,Protocol.SNAPSHOT_TTL);
        JSONObject snap=new JSONObject(Protocol.open(Crypto.un64(c.getString("root")),c.getString("room"),"snapshot",p));
        validateSnapshot(snap,c,now);
        JSONObject d=snap.getJSONObject("driver");String shift=d.getString("shift");boolean active=false;
        if(d.getBoolean("enabled")&&shift.matches("CAR|FOOT")){
            JSONArray jobs=snap.getJSONArray("jobs");
            for(int i=0;i<jobs.length();i++){String st=jobs.getJSONObject(i).getString("status");if(st.equals("ASSIGNED")||st.equals("ARRIVED")){active=true;break;}}
        }
        return new JSONObject().put("ok",true).put("active",active).put("shift",shift).put("driverId",d.getString("id"));
    }
    public synchronized JSONObject submitGps(double lat,double lon,double accuracy,double speed,long fixAt)throws Exception{
        JSONObject s=load(),c=config(s);long now=System.currentTimeMillis();
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new IllegalArgumentException("Invalid GPS position");
        if(!Double.isFinite(accuracy)||accuracy<0||accuracy>50)throw new IllegalArgumentException("GPS accuracy too poor");
        if(!Double.isFinite(speed)||speed<0||speed>100)speed=0;
        if(fixAt<=0||fixAt>now+30000||now-fixAt>120000)throw new IllegalArgumentException("GPS fix is stale");
        JSONObject body=new JSONObject().put("v",1).put("driverId",c.getString("driverId")).put("at",fixAt)
            .put("lat",lat).put("lon",lon).put("accuracyM",accuracy).put("speedMps",speed);
        Protocol.Packet packet=Protocol.seal(Crypto.un64(c.getString("root")),c.getString("room"),"gps",Protocol.id(),now,Protocol.GPS_TTL,body.toString());
        JSONObject reply=network.post(c,"/v1/driver/gps",encode(packet));
        return new JSONObject().put("ok",reply.optBoolean("ok",true));
    }
    public synchronized JSONObject destination(String id)throws Exception{
        JSONObject s=load(),j=job(freshSnapshot(s,System.currentTimeMillis()),id);
        if(!j.getString("status").matches("ASSIGNED|ARRIVED"))throw new IllegalStateException("Accept and await confirmation first");
        JSONObject l=j.getJSONObject("location");if(!l.getBoolean("confirmed")||l.isNull("lat")||l.isNull("lon"))throw new IllegalStateException("No confirmed navigation pin");return l;
    }
}
