package com.rocket.driverprivate;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.IOException;

/** A single encrypted state record: pending request and replay floor commit together. */
public final class Vault {
    private final SharedPreferences p;
    private static final String ALIAS="rocket_driver_private_v1";
    public Vault(Context c){p=c.getSharedPreferences("driver_private_v1",Context.MODE_PRIVATE);}
    private SecretKey key() throws Exception {
        KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);
        if(!s.containsAlias(ALIAS)) {
            KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();
        }
        return (SecretKey)s.getKey(ALIAS,null);
    }
    public synchronized String get() throws Exception {
        String x=p.getString("state","");if(x.isEmpty())return "{}";
        String[] a=x.split(":",2);if(a.length!=2)throw new IOException("Local state unavailable");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Crypto.un64(a[0])));
        c.updateAAD(Crypto.utf("RocketDriverState/1"));return Crypto.text(c.doFinal(Crypto.un64(a[1])));
    }
    public synchronized void put(String value) throws Exception {
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
        c.updateAAD(Crypto.utf("RocketDriverState/1"));
        String x=Crypto.b64(c.getIV())+":"+Crypto.b64(c.doFinal(Crypto.utf(value)));
        if(!p.edit().putString("state",x).commit())throw new IOException("Local save failed");
    }
}
