package com.rocket.driverprivate;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.content.Context;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final int REQ_GPS_FOREGROUND=201,REQ_GPS_BACKGROUND=202;
    private WebView web;private DriverClient client;private final ExecutorService work=Executors.newSingleThreadExecutor();private BroadcastReceiver pushReceiver;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        Vault vault=new Vault(this);client=new DriverClient(new DriverClient.Storage(){public String get()throws Exception{return vault.get();}public void put(String value)throws Exception{vault.put(value);}},new Transport());
        FrameLayout frame=new FrameLayout(this);frame.setBackgroundColor(0xfff4f6f2);
        if(android.os.Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        frame.setOnApplyWindowInsetsListener((v,i)->{if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets x=i.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout()|android.view.WindowInsets.Type.ime());v.setPadding(x.left,x.top,x.right,x.bottom);}else v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});
        setContentView(frame);
        pushReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String type=i.getStringExtra("type");if(web!=null)web.evaluateJavascript("if(window.driverPush)window.driverPush("+JSONObject.quote(type==null?"event":type)+")",null);}};
        IntentFilter pf=new IntentFilter(EventService.ACTION_PUSH);if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(pushReceiver,pf,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(pushReceiver,pf);
        startForegroundService(new Intent(this,EventService.class));
        try{
            web=new WebView(this);WebView.setWebContentsDebuggingEnabled(false);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setBlockNetworkLoads(true);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);
            web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return true;}public boolean shouldOverrideUrlLoading(WebView w,String u){return true;}});
            web.addJavascriptInterface(new Bridge(),"RocketDriver");frame.addView(web,new FrameLayout.LayoutParams(-1,-1));
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getAssets().open("index.html")){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){if(out.size()+n>200000)throw new java.io.IOException("UI too large");out.write(buf,0,n);}}
            web.loadDataWithBaseURL("https://rocket-driver.invalid/",Crypto.text(out.toByteArray()),"text/html","UTF-8",null);
        }catch(Exception e){TextView t=new TextView(this);t.setPadding(24,24,24,24);t.setText("Rocket Driver cannot open its bundled interface. Check Android System WebView.");frame.removeAllViews();frame.addView(t);}
    }
    private final class Bridge {
        @JavascriptInterface public void call(String id,String op,String raw){
            if(id==null||!id.matches("[0-9]{1,12}")||raw==null||raw.length()>12000)return;
            work.execute(()->{JSONObject result;try{
                JSONObject data=new JSONObject(raw);
                switch(op){
                    case "local":result=client.local();break;
                    case "clipboard":android.content.ClipboardManager cb=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);android.content.ClipData clip=cb==null?null:cb.getPrimaryClip();String pasted=(clip!=null&&clip.getItemCount()>0)?String.valueOf(clip.getItemAt(0).coerceToText(MainActivity.this)):"";if(!pasted.startsWith("RD2."))throw new IllegalStateException("Copy the RD2 pairing code first");result=new JSONObject().put("ok",true).put("text",pasted);break;
                    case "pair":KeyguardManager k=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(k==null||!k.isDeviceSecure())throw new IllegalStateException("Set a device screen lock before pairing");result=client.pair(data.getString("code").trim());startForegroundService(new Intent(MainActivity.this,EventService.class));runOnUiThread(()->beginGpsPermissionFlow());android.content.ClipboardManager clear=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(clear!=null)clear.setPrimaryClip(android.content.ClipData.newPlainText("",""));break;
                    case "replace":result=client.replacePairing(data.getString("code").trim());startForegroundService(new Intent(MainActivity.this,EventService.class));runOnUiThread(()->beginGpsPermissionFlow());break;
                    case "unpair":DriverLocationService.disable(MainActivity.this);result=client.unpair();break;
                    case "status":result=client.status();break;
                    case "gpsStatus":result=DriverLocationService.status(MainActivity.this);break;
                    case "gpsEnable":result=gpsEnableResult();break;
                    case "gpsDisable":DriverLocationService.disable(MainActivity.this);result=DriverLocationService.status(MainActivity.this);break;
                    case "submit":result=client.submit(data,false);break;
                    case "retry":result=client.submit(new JSONObject(),true);break;
                    case "navigate":result=openDestination(client.destination(data.getString("orderId")),false);break;
                    case "copyLocation":result=openDestination(client.destination(data.getString("orderId")),true);break;
                    default:throw new IllegalArgumentException("Unsupported driver operation");
                }
            }catch(Exception e){result=new JSONObject();try{result.put("ok",false).put("error",e instanceof IllegalArgumentException||e instanceof IllegalStateException?e.getMessage():"No verified result. Refresh before retrying; do not repeat a cash action.").put("pending",client.local().optBoolean("pending"));}catch(Exception ignored){try{result.put("pending",true);}catch(Exception ignoredAgain){}}}
            final String reply=result.toString();runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.driverReply("+JSONObject.quote(id)+","+JSONObject.quote(reply)+")",null);});});
        }
    }
    private JSONObject openDestination(JSONObject loc,boolean copy)throws Exception{
        final double lat=loc.getDouble("lat"),lon=loc.getDouble("lon");
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new IllegalStateException("No confirmed navigation pin");
        final String coordinates=String.format(java.util.Locale.ROOT,"%.7f,%.7f",lat,lon);
        final String label=loc.optString("label","Meeting point");
        final String geo="geo:"+coordinates+"?q="+Uri.encode(coordinates+" ("+label+")");
        final String browser="https://www.google.com/maps/dir/?api=1&destination="+Uri.encode(coordinates);
        java.util.concurrent.FutureTask<JSONObject> action=new java.util.concurrent.FutureTask<>(()->{
            JSONObject reply=new JSONObject();
            try{
                if(copy){
                    String address=label;
                    for(String key:new String[]{"address","town","postcode"}){
                        String part=loc.optString(key,"");
                        if(!part.isEmpty()&&!address.contains(part))address+=", "+part;
                    }
                    address+="\n"+coordinates;
                    android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                    if(cm==null)throw new IllegalStateException("Clipboard unavailable");
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Meeting point",address));
                }else{
                    try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(geo)));}
                    catch(android.content.ActivityNotFoundException noMaps){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(browser)));}
                }
                return reply.put("ok",true);
            }catch(android.content.ActivityNotFoundException noBrowser){return reply.put("ok",false).put("error","No maps app or browser is available. Use Copy address.");}
            catch(Exception error){return reply.put("ok",false).put("error",copy?"Could not copy the meeting point.":"Could not open navigation. Use Copy address.");}
        });
        runOnUiThread(action);return action.get(10,java.util.concurrent.TimeUnit.SECONDS);
    }
    private void beginGpsPermissionFlow(){
        if(!DriverLocationService.hasForeground(this)){requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION},REQ_GPS_FOREGROUND);return;}
        if(!DriverLocationService.hasBackground(this)){if(android.os.Build.VERSION.SDK_INT>=29)requestPermissions(new String[]{android.Manifest.permission.ACCESS_BACKGROUND_LOCATION},REQ_GPS_BACKGROUND);return;}
        DriverLocationService.enable(this);
    }
    private JSONObject gpsEnableResult()throws Exception{runOnUiThread(()->beginGpsPermissionFlow());return DriverLocationService.status(this).put("ok",true).put("message","Delivery GPS setup opened.");}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_GPS_FOREGROUND&&DriverLocationService.hasForeground(this)){if(DriverLocationService.hasBackground(this))DriverLocationService.enable(this);else if(android.os.Build.VERSION.SDK_INT>=29)requestPermissions(new String[]{android.Manifest.permission.ACCESS_BACKGROUND_LOCATION},REQ_GPS_BACKGROUND);}
        else if(requestCode==REQ_GPS_BACKGROUND&&DriverLocationService.hasBackground(this))DriverLocationService.enable(this);
        if(web!=null)web.evaluateJavascript("if(window.driverGpsPermissionChanged)window.driverGpsPermissionChanged()",null);
    }
    @Override protected void onPause(){if(web!=null){web.evaluateJavascript("window.setAppPaused(true)",null);web.onPause();}super.onPause();}
    @Override protected void onResume(){super.onResume();startForegroundService(new Intent(this,EventService.class));try{if(DriverLocationService.status(this).optBoolean("enabled")&&DriverLocationService.hasForeground(this)&&DriverLocationService.hasBackground(this))DriverLocationService.enable(this);}catch(Exception ignored){}if(web!=null){web.onResume();web.evaluateJavascript("window.setAppPaused(false)",null);}}
    @Override public void onBackPressed(){if(web!=null)web.evaluateJavascript("window.driverBack()",null);else super.onBackPressed();}
    @Override protected void onDestroy(){work.shutdownNow();try{unregisterReceiver(pushReceiver);}catch(Exception ignored){}if(web!=null){web.removeJavascriptInterface("RocketDriver");web.destroy();web=null;}super.onDestroy();}
}
