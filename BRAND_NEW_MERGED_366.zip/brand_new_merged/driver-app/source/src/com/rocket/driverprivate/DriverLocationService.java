package com.rocket.driverprivate;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.*;
import org.json.JSONObject;
import java.util.concurrent.*;

public final class DriverLocationService extends Service implements LocationListener {
    private static final String PREF="driver_gps_v1", CH="driver-gps";
    private static final int NOTIFY_ID=63;
    private static final long GATE_MS=20000, SEND_MIN_MS=15000, RETRY_NOT_READY_MS=60000;
    private volatile boolean running,active;
    private Thread gateThread;
    private ExecutorService sendExec;
    private LocationManager lm;
    private DriverClient client;
    private volatile long nextSendAt=0;

    public static JSONObject status(Context c){
        android.content.SharedPreferences p=c.getSharedPreferences(PREF,MODE_PRIVATE);
        JSONObject j=new JSONObject();
        try{
            j.put("enabled",p.getBoolean("enabled",false));
            j.put("state",p.getString("state","OFF"));
            j.put("lastSuccessAt",p.getLong("last_success_at",0));
            j.put("foregroundPermission",hasForeground(c));
            j.put("backgroundPermission",hasBackground(c));
        }catch(Exception ignored){}
        return j;
    }
    public static boolean hasForeground(Context c){
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
            || c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    public static boolean hasBackground(Context c){
        return Build.VERSION.SDK_INT<29 || c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    public static void enable(Context c){
        c.getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("enabled",true).commit();
        if(hasForeground(c)&&hasBackground(c)){
            Intent i=new Intent(c,DriverLocationService.class);
            if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);
        }
    }
    public static void disable(Context c){
        c.getSharedPreferences(PREF,MODE_PRIVATE).edit().putBoolean("enabled",false).putString("state","OFF").commit();
        c.stopService(new Intent(c,DriverLocationService.class));
    }
    private void setState(String state){
        getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("state",state).apply();
        NotificationManager n=getSystemService(NotificationManager.class);
        if(n!=null)n.notify(NOTIFY_ID,notification(textFor(state)));
    }
    private String textFor(String s){
        if("LIVE".equals(s))return "Encrypted GPS active for current delivery";
        if("TRACKING".equals(s))return "GPS active — waiting for a good fix";
        if("WAITING_JOB".equals(s))return "GPS ready — no active delivery";
        if("RELAY_NOT_READY".equals(s))return "GPS ready — dispatch relay update pending";
        if("RECONNECTING".equals(s))return "GPS reconnecting to dispatch";
        if("NEEDS_PERMISSION".equals(s))return "GPS permission required";
        return "Rocket Driver GPS";
    }
    private Notification notification(String text){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);
        return b.setContentTitle("Rocket Driver").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build();
    }
    @Override public void onCreate(){
        super.onCreate();
        NotificationManager n=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26&&n!=null)n.createNotificationChannel(new NotificationChannel(CH,"Rocket Driver GPS",NotificationManager.IMPORTANCE_LOW));
        startForeground(NOTIFY_ID,notification("Rocket Driver GPS starting"));
        lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        Vault v=new Vault(this);
        client=new DriverClient(new DriverClient.Storage(){public String get()throws Exception{return v.get();}public void put(String x)throws Exception{v.put(x);}},new Transport());
        sendExec=Executors.newSingleThreadExecutor();
        running=true;
        gateThread=new Thread(this::gateLoop,"rocket-driver-gps-gate");gateThread.start();
    }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    private void gateLoop(){
        while(running&&!Thread.currentThread().isInterrupted()){
            try{
                if(!getSharedPreferences(PREF,MODE_PRIVATE).getBoolean("enabled",false)){stopSelf();return;}
                if(!hasForeground(this)||!hasBackground(this)){active=false;stopUpdates();setState("NEEDS_PERMISSION");}
                else{
                    JSONObject g=client.gpsGate();
                    boolean nowActive=g.optBoolean("active",false);
                    active=nowActive;
                    if(nowActive){startUpdates();setState("TRACKING");}
                    else{stopUpdates();setState("WAITING_JOB");}
                }
            }catch(Exception e){active=false;stopUpdates();setState("RECONNECTING");}
            try{Thread.sleep(GATE_MS);}catch(InterruptedException e){return;}
        }
    }
    private void startUpdates(){
        if(lm==null)return;
        try{
            if(lm.isProviderEnabled(LocationManager.GPS_PROVIDER))lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5f,this,Looper.getMainLooper());
        }catch(Exception ignored){}
        try{
            if(lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,10000,10f,this,Looper.getMainLooper());
        }catch(Exception ignored){}
    }
    private void stopUpdates(){try{if(lm!=null)lm.removeUpdates(this);}catch(Exception ignored){}}
    @Override public void onLocationChanged(Location l){
        if(!active||l==null)return;
        long now=System.currentTimeMillis(),fixAt=l.getTime();
        if(now<nextSendAt||fixAt<=0||now-fixAt>120000)return;
        float acc=l.hasAccuracy()?l.getAccuracy():9999f;
        if(!Float.isFinite(acc)||acc>50f)return;
        double lat=l.getLatitude(),lon=l.getLongitude(),speed=l.hasSpeed()?Math.max(0,l.getSpeed()):0;
        nextSendAt=now+SEND_MIN_MS;
        sendExec.execute(()->{
            try{
                client.submitGps(lat,lon,acc,speed,fixAt);
                getSharedPreferences(PREF,MODE_PRIVATE).edit().putLong("last_success_at",System.currentTimeMillis()).apply();
                setState("LIVE");
            }catch(Exception e){
                String m=String.valueOf(e.getMessage());
                if(m.contains("GPS_RELAY_NOT_READY")){nextSendAt=System.currentTimeMillis()+RETRY_NOT_READY_MS;setState("RELAY_NOT_READY");}
                else if(m.contains("GPS_UNAUTHORISED")){nextSendAt=System.currentTimeMillis()+RETRY_NOT_READY_MS;setState("RECONNECTING");}
                else setState("RECONNECTING");
            }
        });
    }
    @Override public void onProviderEnabled(String p){}
    @Override public void onProviderDisabled(String p){}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){
        running=false;active=false;stopUpdates();
        if(gateThread!=null)gateThread.interrupt();
        if(sendExec!=null)sendExec.shutdownNow();
        super.onDestroy();
    }
}
