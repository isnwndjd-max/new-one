package com.rocket.driverprivate;

import java.security.GeneralSecurityException;
import java.util.UUID;
import javax.crypto.Cipher;

/** Authenticated framing; independent of Android so the actual crypto can be JVM-tested. */
public final class Protocol {
    public static final long COMMAND_TTL = 120000, GPS_TTL = 120000, SNAPSHOT_TTL = 90000, RECEIPT_TTL = 86400000;
    public static final class Packet {
        public final String room, kind, id, nonce, body;
        public final long issued, expires;
        public Packet(String room, String kind, String id, long issued, long expires, String nonce, String body) {
            this.room=room; this.kind=kind; this.id=id; this.issued=issued; this.expires=expires;
            this.nonce=nonce; this.body=body;
        }
    }
    private Protocol() {}
    public static String id() { return UUID.randomUUID().toString(); }
    private static String header(Packet p) {
        return "RD1\n"+p.room+"\n"+p.kind+"\n"+p.id+"\n"+p.issued+"\n"+p.expires;
    }
    public static void structure(Packet p) throws GeneralSecurityException {
        if (!p.room.matches("[a-f0-9]{32}") || !p.kind.matches("command|snapshot|receipt|gps")
            || !p.id.matches("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")
            || p.issued<=0 || p.expires<=p.issued || p.expires-p.issued>RECEIPT_TTL
            || p.body.length()>100000 || !p.nonce.matches("[A-Za-z0-9_-]{16}")
            || !p.body.matches("[A-Za-z0-9_-]+")) throw new GeneralSecurityException("Invalid envelope");
        if (Crypto.un64(p.nonce).length!=12 || Crypto.un64(p.body).length<16 || Crypto.un64(p.body).length>65552)
            throw new GeneralSecurityException("Invalid ciphertext");
    }
    public static Packet seal(byte[] root, String room, String kind, String id, long now, long ttl, String plain)
            throws GeneralSecurityException {
        if (ttl<=0 || ttl>RECEIPT_TTL || Crypto.utf(plain).length>65536)
            throw new GeneralSecurityException("Payload too large or expired");
        byte[] n=Crypto.random(12);
        Packet p=new Packet(room,kind,id,now,now+ttl,Crypto.b64(n),"");
        String b=Crypto.b64(Crypto.crypt(Cipher.ENCRYPT_MODE,Crypto.derive(root,room,kind),n,Crypto.utf(header(p)),Crypto.utf(plain)));
        p=new Packet(room,kind,id,now,now+ttl,p.nonce,b); structure(p); return p;
    }
    public static String open(byte[] root, String room, String kind, Packet p) throws GeneralSecurityException {
        structure(p);
        if(!room.equals(p.room)||!kind.equals(p.kind)) throw new GeneralSecurityException("Wrong channel");
        return Crypto.text(Crypto.crypt(Cipher.DECRYPT_MODE,Crypto.derive(root,room,kind),Crypto.un64(p.nonce),Crypto.utf(header(p)),Crypto.un64(p.body)));
    }
    public static void fresh(Packet p,long now,long maxTtl) throws GeneralSecurityException {
        structure(p);
        if(p.issued>now+30000 || p.expires<now || p.expires-p.issued>maxTtl)
            throw new GeneralSecurityException("Expired or future envelope");
    }
    public static String fingerprint(Packet p) throws GeneralSecurityException {
        structure(p); return Crypto.hash(header(p)+"\n"+p.nonce+"\n"+p.body);
    }
}
