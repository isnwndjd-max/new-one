package com.rocket.driverprivate;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Platform primitives. This protocol is a development candidate, not an audited ratchet. */
public final class Crypto {
    private Crypto() {}
    private static final SecureRandom RNG = new SecureRandom();
    public static byte[] random(int n) { byte[] b = new byte[n]; RNG.nextBytes(b); return b; }
    public static byte[] utf(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    public static String text(byte[] b) { return new String(b, StandardCharsets.UTF_8); }
    public static String b64(byte[] b) { return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
    public static byte[] un64(String s) { return Base64.getUrlDecoder().decode(s); }
    public static byte[] mac(byte[] key, byte[] value) throws GeneralSecurityException {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(key, "HmacSHA256"));
        return m.doFinal(value);
    }
    public static byte[] derive(byte[] root, String room, String kind) throws GeneralSecurityException {
        if (root.length != 32 || !room.matches("[a-f0-9]{32}") || !kind.matches("command|snapshot|receipt|gps"))
            throw new GeneralSecurityException("Invalid channel");
        byte[] prk = mac(utf("RocketDriver/1/" + room), root);
        byte[] info = utf("RocketDriver/1/" + kind);
        byte[] block = Arrays.copyOf(info, info.length + 1); block[info.length] = 1;
        return mac(prk, block); // HKDF-SHA256, one 32-byte output block.
    }
    public static byte[] crypt(int mode, byte[] key, byte[] nonce, byte[] aad, byte[] value)
            throws GeneralSecurityException {
        if (key.length != 32 || nonce.length != 12) throw new GeneralSecurityException("Invalid key/nonce");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(mode, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        c.updateAAD(aad); return c.doFinal(value);
    }
    public static String hash(String s) throws GeneralSecurityException {
        return b64(MessageDigest.getInstance("SHA-256").digest(utf(s)));
    }
}
