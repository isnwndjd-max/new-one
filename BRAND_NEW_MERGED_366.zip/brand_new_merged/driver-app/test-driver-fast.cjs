const fs=require('fs'),vm=require('vm'),assert=require('assert');
let source=fs.readFileSync('driver115/source/assets/ui.js','utf8');source=source.slice(0,source.indexOf('(async()=>{'));
let timers=[],renders=0,calls=0,resolveStatus;const ctx={console,window:{},document:{getElementById:()=>({hidden:true})},DriverRules:{},setTimeout:(fn,ms)=>{timers.push({fn,ms});return timers.length},clearTimeout:()=>{},Date,Map};vm.createContext(ctx);vm.runInContext(source,ctx);
vm.runInContext("state={paired:true,demo:false,pending:true,connected:true};render=()=>{};call=()=>new Promise(r=>window.resolveStatus=r);",ctx);
(async()=>{
 const first=vm.runInContext('refresh()',ctx);vm.runInContext('refresh()',ctx);ctx.window.resolveStatus({ok:true,pending:true,connected:true});await first;assert.equal(timers.at(-1).ms,0,'push received during refresh must be retained');
 const second=vm.runInContext('refresh()',ctx);ctx.window.resolveStatus({ok:true,pending:true,connected:true});await second;assert.equal(timers.at(-1).ms,500,'pending checks promptly');
 const third=vm.runInContext('refresh()',ctx);ctx.window.resolveStatus({ok:true,pending:false,connected:true});await third;assert.equal(timers.at(-1).ms,5000,'normal polling resumes');
 vm.runInContext('submitting=true',ctx);await vm.runInContext('refresh()',ctx);assert.equal(vm.runInContext('refreshQueued',ctx),true,'submit cannot lose refresh request');
 console.log('PASS queued updates, fast pending checks, normal cadence, submit overlap');
})().catch(e=>{console.error(e);process.exit(1)});
