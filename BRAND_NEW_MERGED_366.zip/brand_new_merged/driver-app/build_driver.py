from pathlib import Path
import os,subprocess,shutil,zipfile,hashlib,json
SRC=Path('/home/jeffnew2026/rocket-driver-115-fast-20260921/source')
OUTROOT=Path('/home/jeffnew2026/rocket-driver-115-fast-20260921/output')
KEYROOT=Path('/home/jeffnew2026/rocket-driver-private-011-build-20260917T043500Z-5214f4/private-signing')
SDK=Path.home()/'rocket-bridge-build/android-sdk';JDK=Path.home()/'rocket-bridge-build/jdk17';BT=SDK/'build-tools/35.0.0';JAR=SDK/'platforms/android-35/android.jar'
env=os.environ.copy();env['JAVA_HOME']=str(JDK);env['PATH']=str(JDK/'bin')+os.pathsep+env.get('PATH','')
def run(a):
 r=subprocess.run([str(x) for x in a],env=env,text=True,capture_output=True)
 if r.returncode: raise SystemExit('FAIL '+str(a[0])+'\n'+r.stdout+'\n'+r.stderr)
 return r.stdout+r.stderr
shutil.rmtree(OUTROOT,ignore_errors=True)
for d in ['build/gen','build/classes','build/dex','build/assets','dist']: (OUTROOT/d).mkdir(parents=True,exist_ok=True)
html=(SRC/'assets/shell.html').read_text().replace('/* RULES */',(SRC/'assets/rules.js').read_text()).replace('/* UI */',(SRC/'assets/ui.js').read_text())
(OUTROOT/'build/assets/index.html').write_text(html)
run([BT/'aapt2','compile','--dir',SRC/'res','-o',OUTROOT/'build/resources.zip'])
run([BT/'aapt2','link','-I',JAR,'--manifest',SRC/'AndroidManifest.xml','--java',OUTROOT/'build/gen','-A',OUTROOT/'build/assets','-o',OUTROOT/'build/resources.apk',OUTROOT/'build/resources.zip'])
sources=list((SRC/'src').rglob('*.java'))+list((OUTROOT/'build/gen').rglob('*.java'))
run([JDK/'bin/javac','-source','8','-target','8','-encoding','UTF-8','-classpath',JAR,'-d',OUTROOT/'build/classes',*sources])
run([BT/'d8','--lib',JAR,'--min-api','28','--output',OUTROOT/'build/dex',*list((OUTROOT/'build/classes').rglob('*.class'))])
shutil.copyfile(OUTROOT/'build/resources.apk',OUTROOT/'build/unsigned.apk')
with zipfile.ZipFile(OUTROOT/'build/unsigned.apk','a') as z:
 for f in (OUTROOT/'build/dex').glob('*.dex'): z.write(f,f.name)
run([BT/'zipalign','-f','4',OUTROOT/'build/unsigned.apk',OUTROOT/'build/aligned.apk'])
apk=OUTROOT/'dist/Rocket_Driver_Full_1.1.5.apk'
run([BT/'apksigner','sign','--ks',KEYROOT/'driver.p12','--ks-key-alias','rocket-driver-private','--ks-pass','file:'+str(KEYROOT/'password.txt'),'--v1-signing-enabled','false','--v2-signing-enabled','true','--v3-signing-enabled','true','--out',apk,OUTROOT/'build/aligned.apk'])
verify=run([BT/'apksigner','verify','--verbose','--print-certs',apk]);badging=run([BT/'aapt','dump','badging',apk]);perms=run([BT/'aapt','dump','permissions',apk])
report={'apk':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'bytes':apk.stat().st_size,'verify':verify,'badging':badging,'permissions':perms}
(OUTROOT/'dist/build-report.json').write_text(json.dumps(report,indent=2))
print('APK',apk)
print('SHA',report['sha256'])
print(next(x for x in badging.splitlines() if x.startswith('package:')))
for x in verify.splitlines():
 if 'certificate SHA-256 digest' in x: print(x)
