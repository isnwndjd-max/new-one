# Rocket Dispatch — Post-Confirmation Silent Failure Fix

**Status: OFFLINE ONLY. Not deployed.** Nothing here has touched the VPS,
Tasker, phones, Signal, or sent an SMS.

Found via a live role-play walkthrough of the customer/driver flow (not a
theoretical review) - a customer trying to change an already-confirmed
order got no reply at all, on two of three phrasings tried.

---

## 1. What was found

Once an order is `CONFIRMED` (or later - `ASSIGNED`/`EN_ROUTE`/etc.), any
message that doesn't parse as a recognised command falls through to
`_afterConfirmation()`'s existing item-change check, which only fired when
`parseItems(text, this.menu)` successfully parsed a literal item line
(e.g. "item a 6"). Three real phrasings tried in the role-play:

| Customer text | Before this fix |
|---|---|
| `item a 6 of them please` | Replied correctly: "can't be changed here" |
| `add another one of them mucker` | **Silence** - no reply, nothing logged |
| `can i swap for extra item b instead` | **Silence** - no reply, nothing logged |

The two silent cases both clearly intend an order change, but neither
resolves to a real item code via `parseItems` ("them"/"mucker" aren't item
names). From the customer's phone, a message that gets no reply is
indistinguishable from one that never sent - worse than an explicit "no",
which at least tells them to try CANCEL or ask the driver.

## 2. The fix

`src/engine.js`: added `ORDER_CHANGE_RE`, a narrow, explicit regex for
change/addition language (`add`, `another one`, `more of`, `extra`,
`change (my/the/this) order`, `amend`, `swap`). `_afterConfirmation()`'s
existing check now fires on `parseItems(text, this.menu) ||
ORDER_CHANGE_RE.test(key)` instead of `parseItems(...)` alone - same
reply (`cannot_change_order_items`), same `POST_CONFIRM_ITEM_CHANGE_REJECTED`
event, same "never actually changes the order" guarantee.

Deliberately narrow, on purpose: the existing comment in this method
explains post-confirmation messages are otherwise left alone so the system
doesn't reply to every "thanks"/"cheers" - that's preserved. `ORDER_CHANGE_RE`
only matches explicit change/addition language, never general chat.

### Not changed
- `_cancel()`'s de-dup behaviour (a second "cancel" after a driver's
  already assigned correctly doesn't repeat the "passed to dispatch"
  notice) - this was judged correct anti-spam behaviour, not a bug, and
  is unchanged.
- No amend-order flow was added - items still cannot actually be changed
  once confirmed (the total's already locked in and offered to a driver);
  this fix only makes that limitation explicit every time, instead of
  sometimes.

## 3. Before / after (from the actual role-play)

```
Before:
  customer> add another one of them mucker
  <nothing sent back at all>

After:
  customer> add another one of them mucman
  Rocket> Sorry, your order's already confirmed and can't be changed here.
          Text CANCEL to cancel it, or ask your driver directly.
```

## 4. Test results

**232 / 232 passing** (`node --test test/*.js`), zero failures. 4 new
tests added to `test/engine.test.js`:
- the exact "add another one of them mucker" case now gets exactly one
  reply, and the order's items are provably unchanged
- the previously-working "item a 6 of them please" case still works
  identically (no regression)
- "thanks a lot" / "cheers mate" still get no reply (ORDER_CHANGE_RE
  stays narrow, doesn't start replying to idle chat)
- the same fix applies once a driver is `ASSIGNED`, not just `CONFIRMED`
  (the role-play hit this after a driver had already accepted)

## 5. Rollback

Single-file change, `src/engine.js` only: revert the `ORDER_CHANGE_RE`
constant and the `_afterConfirmation()` condition back to
`if (parseItems(text, this.menu))`. No data files changed.
