'use strict';

/*
 * FOOT mode accuracy (Remaining Offline Fixes brief, item 7): FOOT drivers
 * must receive Nailsea jobs only, and Rocket must NOT assume every BS48
 * postcode means Nailsea - BS48 also covers Backwell, Wraxall, Flax
 * Bourton and other real, different localities (see data/locations.json's
 * "towns" list and data/roads.json's per-road `town` field, both sourced
 * from real OSM/venue data, never guessed).
 *
 * See src/engine.js's _isNailseaLocation(): it now trusts ONLY a resolved
 * `location.town === 'Nailsea'` (from a venue/road match), never a bare
 * postcode's district. A bare BS48 postcode with no resolved town is
 * "cannot confidently establish this is Nailsea" - FOOT does not receive
 * it, CAR still does.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData);
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function driverOutbox(e, id) {
  return e.state.outbox.filter((m) => m.to === id).map((m) => m.text);
}
function twoStepOrder(e, phone, itemText, locationText) {
  e.handleCustomerBurst(phone, [itemText]);
  e.handleCustomerBurst(phone, [locationText]);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}

test('a FOOT driver receives a job resolved to real Nailsea (a Nailsea road)', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  const order = twoStepOrder(e, '+447700910001', '1 item a', 'colliers walk nailsea');
  assert.equal(order.location.confirmed.town, 'Nailsea');
  assert.equal(order.state, 'OFFERED');
  assert.ok(driverOutbox(e, 'D1').some((t) => t.includes(order.id)));
});

test('a FOOT driver does NOT receive a job resolved to Backwell, even though it is BS48', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  const order = twoStepOrder(e, '+447700910002', '1 item a', 'hilldale road backwell');
  assert.equal(order.location.confirmed.town, 'Backwell');
  assert.equal(order.location.confirmed.postcode.startsWith('BS48'), true);
  assert.equal(order.state, 'CONFIRMED'); // stuck - the only driver is FOOT and this is Backwell, not Nailsea
  assert.deepEqual(driverOutbox(e, 'D1').filter((t) => t.includes(order.id)), []);
});

test('a FOOT driver does NOT receive a job at a bare BS48 postcode with no resolved locality (ambiguous BS48)', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  const order = twoStepOrder(e, '+447700910003', '1 item a', 'BS48 1AB');
  assert.equal(order.location.confirmed.town, undefined); // genuinely unresolved - not assumed to be Nailsea
  assert.equal(order.state, 'CONFIRMED'); // stuck - Rocket won't guess this is Nailsea just because it's BS48
  assert.deepEqual(driverOutbox(e, 'D1').filter((t) => t.includes(order.id)), []);
});

test('other BS48 localities (Flax Bourton) are also excluded from FOOT, same as Backwell', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  // Flax Bourton has its own postcode district in this dataset (not BS48),
  // which is exactly the point: real locality data decides, not a district
  // guess. Any non-Nailsea resolved town must behave the same way.
  const order = twoStepOrder(e, '+447700910004', '1 item a', 'hilldale road backwell');
  assert.notEqual(order.location.confirmed.town, 'Nailsea');
  assert.equal(order.state, 'CONFIRMED');
});

test('a CAR driver receives all of the above (Nailsea, Backwell, and ambiguous BS48) without restriction', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON'); // defaults to CAR

  const nailsea = twoStepOrder(e, '+447700910005', '1 item a', 'colliers walk nailsea');
  assert.equal(nailsea.state, 'OFFERED');

  e.handleDriverMessage('D1', `ACCEPT ${nailsea.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${nailsea.id}`);

  const backwell = twoStepOrder(e, '+447700910006', '1 item a', 'hilldale road backwell');
  assert.equal(backwell.state, 'OFFERED');
  e.handleDriverMessage('D1', `ACCEPT ${backwell.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${backwell.id}`);

  const ambiguous = twoStepOrder(e, '+447700910007', '1 item a', 'BS48 1AB');
  assert.equal(ambiguous.state, 'OFFERED');
});

test('a FOOT driver switching to CAR mid-shift immediately becomes eligible for a waiting non-Nailsea order', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  const order = twoStepOrder(e, '+447700910008', '1 item a', 'hilldale road backwell');
  assert.equal(order.state, 'CONFIRMED'); // stuck while FOOT

  e.handleDriverMessage('D1', 'CAR');
  assert.equal(order.state, 'OFFERED');
  assert.ok(driverOutbox(e, 'D1').some((t) => t.includes(order.id)));
});
