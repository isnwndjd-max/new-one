'use strict';

/*
 * Tests for CHANGELOG_HOUSE_NUMBER_FIX.md: a house/flat number given
 * alongside a bare road/alley name ("33 Greenfield Crescent") used to be
 * silently dropped - the road resolved correctly, but the number never
 * appeared anywhere (not on the customer confirmation, not on the driver's
 * job card, not in the stored order data at all). Found via a live
 * role-play walkthrough. The postcode layer already had this (findStreet's
 * `street` label); this wires the same idea into the road/alley layer as
 * `houseNumber`, label-only - it never moves the coordinate.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');
const { Engine, emptyEngineState } = require('../src/engine');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const alleyAliasData = require('../data/alleyAliases.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeIndex() {
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData, alleyAliasData);
  return index;
}
const index = makeIndex();

function run(msgs, opts = { allowPartial: true }) {
  const conv = new LocationConversation(index, emptyState());
  const outs = [];
  for (const m of msgs) outs.push(conv.handle(m, opts));
  return { outs, last: outs[outs.length - 1], state: conv.state };
}

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}

test('a house number given with a bare road name is captured, not dropped', () => {
  const { last } = run(['33 greenfield crescent']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'road');
  assert.equal(last.location.id, 'ROAD-BS48-0434');
  assert.equal(last.location.houseNumber, '33');
  assert.equal(last.location.name, 'Greenfield Crescent'); // the road's own name is unchanged
});

test('a flat number is captured the same way', () => {
  const { last } = run(['flat 2, 33 greenfield crescent']);
  assert.equal(last.type, 'RESOLVED');
  assert.match(last.location.houseNumber, /flat 2/i);
});

test('no house number given still resolves normally with houseNumber: null', () => {
  const { last } = run(['greenfield crescent']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.houseNumber, null);
});

test('the house number never changes the resolved coordinate', () => {
  const withNum = run(['33 greenfield crescent']).last.location;
  const withoutNum = run(['greenfield crescent']).last.location;
  assert.equal(withNum.lat, withoutNum.lat);
  assert.equal(withNum.lng, withoutNum.lng);
});

test('a house number on an ALLEY local-alias match is captured too', () => {
  const { last } = run(['12 rock road alleyway']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'alley');
  assert.equal(last.location.id, 'PATH-BS49-0008');
  assert.equal(last.location.houseNumber, '12');
});

test('a house number given alongside an ambiguous road name is preserved through the town-clarification follow-up', () => {
  const conv = new LocationConversation(index, emptyState());
  const first = conv.handle('5 station road', { allowPartial: true });
  assert.notEqual(first.type, 'RESOLVED'); // Station Road exists in more than one town - asks
  assert.ok(conv.state.pendingRoad);
  assert.equal(conv.state.pendingRoad.houseNumber, '5');
  const town = conv.state.pendingRoad.candidateIds.length
    ? index.roadIndex.get(conv.state.pendingRoad.candidateIds[0]).town
    : null;
  if (town) {
    const out = conv.handle(town, { allowPartial: true });
    if (out.type === 'RESOLVED') assert.equal(out.location.houseNumber, '5');
  }
});

test('end-to-end: house number appears on both the customer confirmation text and the driver job card', () => {
  const e = makeEngine();
  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  const phone = '+447700900097';
  e.handleCustomerBurst(phone, ['1 item a 33 greenfield crescent']);
  const order = Object.values(e.state.orders)[0];
  assert.ok(['CONFIRMED', 'OFFERED'].includes(order.state)); // driver is ON, so dispatch may run in the same tick
  assert.equal(order.location.confirmed.houseNumber, '33');

  const customerMsg = e.state.outbox.find((m) => m.to === phone && m.text.startsWith('Order confirmed'));
  assert.ok(customerMsg.text.includes('33 Greenfield Crescent'));

  const driverMsg = e.state.outbox.find((m) => m.channel === 'driver' && m.text.startsWith('JOB'));
  assert.ok(driverMsg.text.includes('33 Greenfield Crescent'));
});

test('a bare road name with no number still works exactly as before (no regression)', () => {
  const e = makeEngine();
  const phone = '+447700900098';
  e.handleCustomerBurst(phone, ['1 item a greenfield crescent']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.location.confirmed.houseNumber, null);
  const customerMsg = e.state.outbox.find((m) => m.to === phone && m.text.startsWith('Order confirmed'));
  assert.ok(customerMsg.text.includes('Meeting point: Greenfield Crescent, Nailsea'));
});

test('a postcode + street message is completely unaffected by this change (legacy field name/shape unchanged)', () => {
  const pc = Object.keys(locationsData.activePostcodes)[0];
  const { last } = run([`${pc} 33 silver street`]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'postcode');
  assert.equal(last.location.street, '33 silver street');
  assert.equal(last.location.houseNumber, undefined); // postcode locations never gain this field
});
