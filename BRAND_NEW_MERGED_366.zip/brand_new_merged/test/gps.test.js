'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { haversineMetres, etaMinutes, parseTraccarForward } = require('../src/gps');

test('haversineMetres: known distance between two real points is roughly right', () => {
  // Nailsea town centre to Portishead town centre, ~8.3km as the crow flies.
  const nailsea = { lat: 51.4308, lng: -2.7626 };
  const portishead = { lat: 51.4863, lng: -2.7644 };
  const d = haversineMetres(nailsea, portishead);
  assert.ok(d > 6000 && d < 9500, `expected ~6-9.5km, got ${d}`);
});

test('haversineMetres: same point is zero, missing coords is null', () => {
  const p = { lat: 51.4, lng: -2.7 };
  assert.equal(haversineMetres(p, p), 0);
  assert.equal(haversineMetres(p, null), null);
  assert.equal(haversineMetres(p, { lat: null, lng: -2.7 }), null);
});

test('etaMinutes: uses reported speed when it is a real speed', () => {
  // 10km at 30kph = 20 minutes
  assert.equal(etaMinutes(10000, 30), 20);
});

test('etaMinutes: falls back to a fixed average when stopped or speed unknown', () => {
  const stopped = etaMinutes(10000, 0);
  const noSpeed = etaMinutes(10000, null);
  assert.equal(stopped, noSpeed);
  assert.ok(stopped > 0 && stopped < 60);
});

test('etaMinutes: null distance gives null, never a fake number', () => {
  assert.equal(etaMinutes(null, 30), null);
});

test('parseTraccarForward: real JSON position-forwarding shape from Traccar', () => {
  const body = {
    position: {
      deviceId: 7, latitude: 51.4308, longitude: -2.7626,
      speed: 12.3, course: 88, accuracy: 5, valid: true,
      fixTime: '2026-09-23T20:00:00.000+00:00',
    },
    device: { id: 7, uniqueId: 'DRIVER-PHONE-1', name: 'Dave phone' },
  };
  const fix = parseTraccarForward(body);
  assert.equal(fix.uniqueId, 'DRIVER-PHONE-1');
  assert.equal(fix.lat, 51.4308);
  assert.equal(fix.lng, -2.7626);
  assert.equal(fix.speedKph, Math.round(12.3 * 1.852 * 10) / 10); // knots -> km/h
  assert.equal(fix.valid, true);
});

test('parseTraccarForward: an invalid fix is still parsed, just marked invalid', () => {
  const body = {
    position: { latitude: 0, longitude: 0, valid: false },
    device: { uniqueId: 'D1' },
  };
  const fix = parseTraccarForward(body);
  assert.equal(fix.valid, false);
});

test('parseTraccarForward: rejects payloads that are not a position at all', () => {
  assert.equal(parseTraccarForward(null), null);
  assert.equal(parseTraccarForward({}), null);
  assert.equal(parseTraccarForward({ position: { latitude: 1 } }), null); // no longitude
  assert.equal(parseTraccarForward({ position: { latitude: 1, longitude: 2 } }), null); // no device id
});
