'use strict';

/*
 * Real HTTP requests against a live server instance, same pattern as
 * test/server.e2e.test.js, covering the /boss/* admin routes: header-only
 * token gating, the review queue, debt payments, and menu editing through
 * the master/sync split. The master lives only in the Boss app's own
 * browser storage - the VPS never persists it, only the minimal projection
 * (data/menu.sync.json) the order engine actually loads - see
 * src/menuSync.js and server/index.js's file header.
 *
 * Uses a throwaway copy of data/ per test run so a menu-edit test can never
 * write to the project's real data files.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../server/index');

function req(base, method, url, body, headers) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const h = Object.assign({}, headers);
    if (data) { h['Content-Type'] = 'application/json'; h['Content-Length'] = Buffer.byteLength(data); }
    const r = http.request(base + url, { method, headers: h }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null, raw: out }); }
        catch (e) { reject(e); }
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

function makeTempDataDir() {
  const realDataDir = path.join(__dirname, '..', 'data');
  const tmpDataDir = path.join(os.tmpdir(), `rocket-boss-data-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  fs.cpSync(realDataDir, tmpDataDir, { recursive: true });
  return tmpDataDir;
}

async function startApp() {
  const dataDir = makeTempDataDir();
  const statePath = path.join(os.tmpdir(), `rocket-boss-state-${Date.now()}-${Math.random().toString(36).slice(2)}.json`);
  const app = createApp({ dataDir, statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;
  // The real config.json ships with the placeholder token, which is truthy
  // and therefore a valid (if insecure) token for these tests to use.
  const token = require(path.join(dataDir, 'config.json')).boss.token;
  const auth = { 'X-Boss-Token': token };
  return { app, base, dataDir, token, auth, statePath };
}

function rawGet(base, url) {
  return new Promise((resolve, reject) => {
    http.get(base + url, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => resolve({ status: res.statusCode, raw: out }));
    }).on('error', reject);
  });
}

test('GET /boss serves the admin page without a token', async () => {
  const { app, base } = await startApp();
  try {
    const r = await rawGet(base, '/boss');
    assert.equal(r.status, 200);
    assert.ok(r.raw.includes('Rocket Dispatch'));
  } finally { app.stop(); app.server.close(); }
});

test('unauthorised Boss access: every /boss/* API route refuses a missing token, a wrong token, and a token in the URL', async () => {
  const { app, base, token } = await startApp();
  const routes = [
    ['GET', '/boss/summary'], ['GET', '/boss/review'], ['GET', '/boss/debts'],
    ['GET', '/boss/referrals'], ['GET', '/boss/orders'], ['GET', '/boss/drivers'], ['GET', '/boss/menu'],
  ];
  try {
    for (const [method, url] of routes) {
      let r = await req(base, method, url); // no token at all
      assert.equal(r.status, 401, `${method} ${url} with no token`);
      r = await req(base, method, url, null, { 'X-Boss-Token': 'definitely-wrong' });
      assert.equal(r.status, 401, `${method} ${url} with a wrong token`);
      // The token used to also be accepted as ?token=... - that's gone.
      // Putting it in the URL (which ends up in logs) must not work anymore.
      r = await req(base, method, `${url}?token=${encodeURIComponent(token)}`);
      assert.equal(r.status, 401, `${method} ${url} with the token only in the URL, not a header, must be refused`);
    }
    // The right token, as a header, works.
    const r = await req(base, 'GET', '/boss/summary', null, { 'X-Boss-Token': token });
    assert.equal(r.status, 200);
    assert.equal(r.body.ok, true);
  } finally { app.stop(); app.server.close(); }
});

test('review queue: an engine-flagged review item shows up and can be resolved', async () => {
  const { app, base, auth } = await startApp();
  try {
    // Force a review entry the same way the engine already does elsewhere:
    // call the engine directly (this is testing the /boss route, not how
    // review entries get created - that's covered in test/engine.test.js).
    app.engine._review(null, 'test-triggered review item');
    let r = await req(base, 'GET', '/boss/review', null, auth);
    assert.equal(r.status, 200);
    assert.equal(r.body.review.length, 1);
    const id = r.body.review[0].id;

    r = await req(base, 'POST', `/boss/review/${id}/resolve`, { note: 'handled manually' }, auth);
    assert.equal(r.status, 200);
    assert.equal(r.body.ok, true);

    r = await req(base, 'GET', '/boss/review', null, auth);
    assert.equal(r.body.review.length, 0, 'resolved item should drop off the open queue');

    r = await req(base, 'POST', `/boss/review/${id}/resolve`, {}, auth);
    assert.equal(r.status, 404, 'resolving an already-resolved id again should not silently succeed');
  } finally { app.stop(); app.server.close(); }
});

test('debts: a payment reduces the balance and an invalid amount is rejected', async () => {
  const { app, base, auth } = await startApp();
  try {
    app.engine.state.debts.push({
      id: 'debt-1', phone: '+447700900100', orderId: 'ORD1',
      amount: 20, createdAt: Date.now(), dueAt: Date.now() + 86400000, remindedAt: null, payments: [],
    });

    let r = await req(base, 'POST', '/boss/debts/debt-1/payment', { amount: -5 }, auth);
    assert.equal(r.status, 400, 'negative amount rejected');

    r = await req(base, 'POST', '/boss/debts/debt-1/payment', { amount: 5 }, auth);
    assert.equal(r.status, 200);
    assert.equal(r.body.ok, true);

    r = await req(base, 'GET', '/boss/debts', null, auth);
    const debt = r.body.debts.find((d) => d.id === 'debt-1');
    assert.equal(debt.amount, 15);

    r = await req(base, 'POST', '/boss/debts/no-such-debt/payment', { amount: 5 }, auth);
    assert.equal(r.status, 404);
  } finally { app.stop(); app.server.close(); }
});

test('menu: PUT validates, derives and persists only the minimal synced projection - the master is never written to VPS disk', async () => {
  const { app, base, dataDir, auth } = await startApp();
  try {
    // Fresh install: no master file on disk (see src/menuSync.js / the
    // server file header) and GET reflects only the minimal projection the
    // VPS already has, with no internal-only fields riding along.
    let r = await req(base, 'GET', '/boss/menu', null, auth);
    assert.equal(r.status, 200);
    assert.equal(r.body.menu.items.length, 3);
    assert.equal(r.body.menu.items[0].costPrice, undefined, 'the VPS never has cost price to serve back - it never stored it');
    assert.equal(r.body.legacyMaster, undefined, 'nothing to migrate on a fresh install');
    assert.ok(!fs.existsSync(path.join(dataDir, 'boss', 'menu.master.json')), 'no master file should exist on a fresh install');

    const updated = {
      items: [{ code: 'A', name: 'Item A', unitPrice: 12, tiers: [], costPrice: 5 }],
      bundles: [],
    };
    r = await req(base, 'PUT', '/boss/menu', updated, auth);
    assert.equal(r.status, 200);
    // The response echoes straight back from the request body (there is no
    // stored copy to read it from) - this is why costPrice does come back
    // in THIS response, even though it's never persisted anywhere.
    assert.equal(r.body.menu.items.length, 1);
    assert.equal(r.body.menu.items[0].unitPrice, 12);
    assert.equal(r.body.menu.items[0].costPrice, 5);

    // Nothing resembling a master file was created on disk by that PUT.
    assert.ok(!fs.existsSync(path.join(dataDir, 'boss', 'menu.master.json')), 'PUT /boss/menu must never write a master file to the VPS');
    assert.ok(!fs.existsSync(path.join(dataDir, 'boss')), 'PUT /boss/menu must not even create a boss/ directory on the VPS');

    const syncOnDisk = JSON.parse(fs.readFileSync(path.join(dataDir, 'menu.sync.json'), 'utf8'));
    assert.equal(syncOnDisk.items.length, 1);
    assert.equal(syncOnDisk.items[0].unitPrice, 12);
    assert.equal(syncOnDisk.items[0].costPrice, undefined, 'the synced projection must never carry master-only fields');

    // Live pricing actually changed in the running engine, not just the disk file.
    r = await req(base, 'GET', '/boss/summary', null, auth);
    assert.equal(r.status, 200);
    assert.equal(app.engine.menu.items[0].unitPrice, 12);
    assert.equal(app.engine.menu.items[0].costPrice, undefined, 'the engine in memory never holds master-only fields either');

    // And a subsequent GET only ever reflects the synced projection - the
    // master fields sent in the PUT above are gone, exactly as intended.
    r = await req(base, 'GET', '/boss/menu', null, auth);
    assert.equal(r.body.menu.items[0].costPrice, undefined);
  } finally { app.stop(); app.server.close(); }
});

test('menu: an invalid PUT is rejected and leaves the synced projection untouched, still with no master file created', async () => {
  const { app, base, dataDir, auth } = await startApp();
  try {
    const syncBefore = fs.readFileSync(path.join(dataDir, 'menu.sync.json'), 'utf8');

    const bad = { items: [{ code: 'A', name: 'Item A', unitPrice: -5, tiers: [] }], bundles: [] };
    const r = await req(base, 'PUT', '/boss/menu', bad, auth);
    assert.equal(r.status, 400);
    assert.ok(r.body.error.includes('unitPrice'));

    const syncAfter = fs.readFileSync(path.join(dataDir, 'menu.sync.json'), 'utf8');
    assert.equal(syncBefore, syncAfter, 'a rejected edit must not touch the synced projection');
    assert.ok(!fs.existsSync(path.join(dataDir, 'boss', 'menu.master.json')), 'a rejected edit must not create a master file either');
  } finally { app.stop(); app.server.close(); }
});

test('menu after restart: a fresh server instance trusts whatever synced projection was last written - there is no master on the VPS to re-derive it from', async () => {
  const { app, base, dataDir, auth, statePath } = await startApp();
  try {
    await req(base, 'PUT', '/boss/menu', { items: [{ code: 'Z', name: 'Zed', unitPrice: 99, tiers: [] }], bundles: [] }, auth);

    app.stop();
    await new Promise((r) => app.server.close(r));

    const app2 = createApp({ dataDir, statePath, burstWindowMs: 50, tickIntervalMs: 20 });
    try {
      assert.equal(app2.engine.menu.items.length, 1);
      assert.equal(app2.engine.menu.items[0].code, 'Z', 'the last-saved synced projection survives a restart on its own');
      assert.ok(!fs.existsSync(path.join(dataDir, 'boss', 'menu.master.json')), 'restart must not create or expect a master file on the VPS');
    } finally {
      app2.stop();
      try { app2.server.close(); } catch (e) { /* never listened */ }
    }
  } finally {
    try { app.stop(); app.server.close(); } catch (e) { /* already closed above */ }
  }
});

test('menu: a legacy master file left over from an older build is handed to the Boss app exactly once, then deleted from the VPS', async () => {
  const { app, base, dataDir, auth } = await startApp();
  const legacyPath = path.join(dataDir, 'boss', 'menu.master.json');
  fs.mkdirSync(path.dirname(legacyPath), { recursive: true });
  const legacyMaster = { items: [{ code: 'OLD', name: 'Old Item', unitPrice: 7, tiers: [], costPrice: 2 }], bundles: [] };
  fs.writeFileSync(legacyPath, JSON.stringify(legacyMaster));

  // Migration is read at startup but only deleted once actually served (see
  // server/index.js) - a fresh app instance still has to pick it up, since
  // the running `app` above already started before the file was written.
  app.stop();
  try { app.server.close(); } catch (e) { /* already closed */ }
  const app2 = createApp({ dataDir, statePath: path.join(dataDir, '..', `legacy-state-${Date.now()}.json`), burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app2.server.listen(0, resolve));
  const port = app2.server.address().port;
  const base2 = `http://127.0.0.1:${port}`;
  try {
    assert.ok(fs.existsSync(legacyPath), 'the legacy file must still be on disk before anyone has asked for it');

    let r = await req(base2, 'GET', '/boss/menu', null, auth);
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.legacyMaster, legacyMaster, 'the legacy master rides along exactly once, unmodified');
    assert.ok(!fs.existsSync(legacyPath), 'the legacy file is deleted the moment it has actually been served');

    r = await req(base2, 'GET', '/boss/menu', null, auth);
    assert.equal(r.body.legacyMaster, undefined, 'a second GET never repeats it - one-time migration, not a standing feature');
  } finally {
    app2.stop();
    try { app2.server.close(); } catch (e) { /* never listened */ }
  }
});

test('referrals and drivers routes return the underlying engine state', async () => {
  const { app, base, auth } = await startApp();
  try {
    app.engine.state.referralCodes['ABC1234'] = { ownerPhone: '+447700900100', issuedForOrder: 'ORD1', usedByOrder: null, redeemed: false };
    app.engine.registerDriver('D9', 'Test Driver', {});

    let r = await req(base, 'GET', '/boss/referrals', null, auth);
    assert.equal(r.status, 200);
    assert.ok(r.body.referralCodes.ABC1234);

    r = await req(base, 'GET', '/boss/drivers', null, auth);
    assert.equal(r.status, 200);
    assert.ok(r.body.drivers.D9);
    assert.equal(r.body.drivers.D9.name, 'Test Driver');
  } finally { app.stop(); app.server.close(); }
});

test('unknown /boss/* path returns 404, not a fall-through to the main router', async () => {
  const { app, base, auth } = await startApp();
  try {
    const r = await req(base, 'GET', '/boss/not-a-real-route', null, auth);
    assert.equal(r.status, 404);
  } finally { app.stop(); app.server.close(); }
});
