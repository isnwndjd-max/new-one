'use strict';

/*
 * Regression tests for the "Remaining Offline Fixes" brief:
 *  1. stock accounting (total/reserved/driver-held/available, reserve at
 *     confirm, deduct once at complete, release on cancel, restock/adjust,
 *     low-stock alerts, idempotency, never negative)
 *  2. loyalty: 3 points per item, the ONE rule
 *  3. debt rules (7-day overdue, £100 block, combined debt+order payment)
 *  4. referral: one free item, not points
 *  5. £250 driver cash limit
 *
 * Item A = £10/unit, Item B = £15/unit, Item C = £8/unit (data/menu.sync.json).
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');

const locationsData = require('../data/locations.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const index = new LocationIndex(locationsData);
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function outboxFor(e, phone) {
  return e.state.outbox.filter((m) => m.to === phone).map((m) => m.text);
}
function fullOrder(e, phone, texts) {
  e.handleCustomerBurst(phone, texts);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}
function completeOrder(e, driverId, order, paidClause = '') {
  e.registerDriver(driverId);
  e.handleDriverMessage(driverId, 'ON');
  e.handleDriverMessage(driverId, `ACCEPT ${order.id}`);
  e.handleDriverMessage(driverId, `COMPLETE ${order.id}${paidClause}`);
}

// ================================================================ STOCK

test('config has the default low-stock threshold the brief specified (3)', () => {
  assert.equal(config.stock.defaultLowStockThreshold, 3);
});

test('an untracked item (never restocked) never blocks an order - unlimited/untracked by design', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920001', ['1 item a BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(e.stockSummary('A').tracked, false);
});

test('restockProduct creates the product record and sets TOTAL; RESERVED/AVAILABLE start correct', () => {
  const e = makeEngine();
  e.restockProduct('A', 10, 'initial stock');
  const s = e.stockSummary('A');
  assert.equal(s.tracked, true);
  assert.equal(s.total, 10);
  assert.equal(s.reserved, 0);
  assert.equal(s.driverHeld, 0);
  assert.equal(s.available, 10);
});

test('confirming an order RESERVES stock (available drops, total unchanged)', () => {
  const e = makeEngine();
  e.restockProduct('A', 10);
  const order = fullOrder(e, '+447700920002', ['3 item a BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED');
  const s = e.stockSummary('A');
  assert.equal(s.total, 10);
  assert.equal(s.reserved, 3);
  assert.equal(s.available, 7);
});

test('an order that would over-promise tracked stock is blocked outright - never partially reserved', () => {
  const e = makeEngine();
  e.restockProduct('A', 2);
  const order = fullOrder(e, '+447700920003', ['5 item a BS48 1AB']);
  assert.notEqual(order.state, 'CONFIRMED');
  const s = e.stockSummary('A');
  assert.equal(s.reserved, 0); // nothing reserved - all or nothing
  assert.ok(outboxFor(e, '+447700920003').some((t) => t.toLowerCase().includes('out of stock')));
});

test('two customers cannot both be promised the same last units - the second is blocked', () => {
  const e = makeEngine();
  e.restockProduct('A', 3);
  const order1 = fullOrder(e, '+447700920004', ['3 item a BS48 1AB']);
  assert.equal(order1.state, 'CONFIRMED');
  const order2 = fullOrder(e, '+447700920005', ['1 item a BS48 1AB']);
  assert.notEqual(order2.state, 'CONFIRMED'); // nothing left - prevented double-promising
});

test('completing an order DEDUCTS stock exactly once (total and reserved both drop)', () => {
  const e = makeEngine();
  e.restockProduct('A', 10);
  const order = fullOrder(e, '+447700920006', ['2 item a BS48 1AB']);
  completeOrder(e, 'D1', order);
  const s = e.stockSummary('A');
  assert.equal(s.total, 8);
  assert.equal(s.reserved, 0);
  assert.equal(s.available, 8);
});

test('a duplicate COMPLETE does not deduct stock twice', () => {
  const e = makeEngine();
  e.restockProduct('A', 10);
  const order = fullOrder(e, '+447700920007', ['2 item a BS48 1AB']);
  completeOrder(e, 'D1', order);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`); // duplicate
  assert.equal(e.stockSummary('A').total, 8);
});

test('cancelling a CONFIRMED order RELEASES its reservation (available restored, total unchanged)', () => {
  const e = makeEngine();
  e.restockProduct('A', 10);
  const order = fullOrder(e, '+447700920008', ['3 item a BS48 1AB']);
  assert.equal(e.stockSummary('A').available, 7);
  e.handleCustomerBurst('+447700920008', ['CANCEL']);
  assert.equal(order.state, 'CANCELLED');
  const s = e.stockSummary('A');
  assert.equal(s.total, 10);
  assert.equal(s.reserved, 0);
  assert.equal(s.available, 10);
});

test('a released reservation is not released twice, and stock is freed for the next order', () => {
  const e = makeEngine();
  e.restockProduct('A', 3);
  const order = fullOrder(e, '+447700920009', ['3 item a BS48 1AB']);
  e.handleCustomerBurst('+447700920009', ['CANCEL']);
  const order2 = fullOrder(e, '+447700920010', ['3 item a BS48 1AB']);
  assert.equal(order2.state, 'CONFIRMED'); // freed stock is usable again
});

test('adjustStock supports a negative correction, but refuses to go below reserved+driver-held', () => {
  const e = makeEngine();
  e.restockProduct('A', 10);
  fullOrder(e, '+447700920011', ['4 item a BS48 1AB']); // reserves 4
  assert.throws(() => e.adjustStock('A', -8), /reserved|driver-held/);
  e.adjustStock('A', -3, 'breakage');
  assert.equal(e.stockSummary('A').total, 7);
});

test('low-stock alert fires at/under the threshold and clears once restocked above it', () => {
  const e = makeEngine();
  e.restockProduct('B', 5); // default threshold 3
  fullOrder(e, '+447700920012', ['2 item b BS48 1AB']); // reserves 2, available=3
  assert.ok(e.state.lowStockAlerts.includes('B'));
  e.restockProduct('B', 10);
  assert.ok(!e.state.lowStockAlerts.includes('B'));
});

test('restockProduct is idempotent when given the same idempotencyKey (a retried Boss request is a safe no-op)', () => {
  const e = makeEngine();
  const key = 'restock-A-batch-1';
  e.restockProduct('A', 10, 'batch 1', key);
  e.restockProduct('A', 10, 'batch 1', key); // retried
  assert.equal(e.stockSummary('A').total, 10); // not 20
});

test('stock movements are durably audited (stockLedger + the general auditLog), restart-safe', () => {
  const { Store } = require('../src/store');
  const os = require('os');
  const path = require('path');
  const fs = require('fs');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-stock-restart-'));
  const file = path.join(dir, 'state.json');
  try {
    const e1 = makeEngine();
    e1.restockProduct('A', 10, 'opening stock');
    const order = fullOrder(e1, '+447700920013', ['2 item a BS48 1AB']);
    completeOrder(e1, 'D1', order);
    new (require('../src/store').Store)(file).save(e1.state);

    const reloaded = new Store(file).load(emptyEngineState);
    assert.equal(reloaded.stock.A.total, 8);
    assert.ok(reloaded.stockLedger.some((x) => x.action === 'RESTOCK'));
    assert.ok(reloaded.stockLedger.some((x) => x.action === 'RESERVE'));
    assert.ok(reloaded.stockLedger.some((x) => x.action === 'DEDUCT'));
    assert.ok(reloaded.auditLog.length > 0);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// ============================================================== LOYALTY

test('config has the ONE loyalty rule: 3 points per item', () => {
  assert.equal(config.rewards.pointsPerItem, 3);
  assert.equal(config.rewards.pointsPerOrder, undefined, 'the old flat per-order rate must be removed, not just unused');
});

test('1/2/3/5-item orders earn 3/6/9/15 points, matching the brief examples exactly', () => {
  const cases = [[1, 3], [2, 6], [3, 9], [5, 15]];
  for (const [qty, pts] of cases) {
    const e = makeEngine();
    const order = fullOrder(e, '+447700920020', [`${qty} item a BS48 1AB`]);
    completeOrder(e, 'D1', order);
    assert.equal(e.state.customers['+447700920020'].points, pts, `${qty} items should earn ${pts} points`);
  }
});

test('no points on cancellation', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920021', ['2 item a BS48 1AB']);
  e.handleCustomerBurst('+447700920021', ['CANCEL']);
  assert.equal(order.state, 'CANCELLED');
  assert.equal(e.state.customers['+447700920021'], undefined);
});

test('no duplicate points on a repeated COMPLETE', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920022', ['2 item a BS48 1AB']);
  completeOrder(e, 'D1', order);
  const after1 = e.state.customers['+447700920022'].points;
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  assert.equal(e.state.customers['+447700920022'].points, after1);
});

test('points persist across restart', () => {
  const { Store } = require('../src/store');
  const os = require('os');
  const path = require('path');
  const fs = require('fs');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-loyalty-restart-'));
  const file = path.join(dir, 'state.json');
  try {
    const e1 = makeEngine();
    const order = fullOrder(e1, '+447700920023', ['3 item a BS48 1AB']);
    completeOrder(e1, 'D1', order);
    new Store(file).save(e1.state);
    const reloaded = new Store(file).load(emptyEngineState);
    assert.equal(reloaded.customers['+447700920023'].points, 9);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('Boss can manually add/remove points, audited, with retry-safe idempotency', () => {
  const e = makeEngine();
  e.adjustLoyaltyPoints('+447700920024', 20, 'goodwill');
  assert.equal(e.state.customers['+447700920024'].points, 20);
  e.adjustLoyaltyPoints('+447700920024', -5, 'correction');
  assert.equal(e.state.customers['+447700920024'].points, 15);
  assert.equal(e.state.pointsAdjustments.length, 2);
  const key = 'points-adj-1';
  e.adjustLoyaltyPoints('+447700920024', 10, 'bonus', key);
  e.adjustLoyaltyPoints('+447700920024', 10, 'bonus', key); // retried
  assert.equal(e.state.customers['+447700920024'].points, 25); // only applied once
});

// ================================================================= DEBT

test('a shortfall on COMPLETE records a new debt due in 7 days', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920030', ['1 item a BS48 1AB']); // £10
  completeOrder(e, 'D1', order, ' PAID 4');
  const debt = e.state.debts.find((d) => d.orderId === order.id);
  assert.ok(debt);
  assert.equal(debt.amount, 6);
  assert.equal(debt.dueAt - e.now(), config.debtReminderDays * 86400000);
});

test('a debt becomes overdue exactly at its 7-day mark, not before', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920031', ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', order, ' PAID 0');
  const sixDays = 6 * 86400000;
  e.advance(sixDays);
  assert.equal(e._overdueDebtTotal('+447700920031'), 0, 'not yet overdue at day 6');
  e.advance(1 * 86400000 + 1000); // past day 7
  assert.equal(e._overdueDebtTotal('+447700920031'), 10, 'overdue once the 7-day due date has passed');
});

test('£100+ overdue debt blocks a new order from confirming; ordering resumes once paid off in full', () => {
  const e = makeEngine();
  const phone = '+447700920032';
  // Build up £100 of overdue debt via one big unpaid order, then age it past 7 days.
  const order = fullOrder(e, phone, ['10 item b BS48 1AB']); // 10 x £15 = £150
  completeOrder(e, 'D1', order, ' PAID 50'); // £100 shortfall -> debt
  e.advance(8 * 86400000);
  const blocked = fullOrder(e, phone, ['1 item a BS48 1AB']);
  assert.notEqual(blocked.state, 'CONFIRMED');
  assert.ok(outboxFor(e, phone).some((t) => t.toLowerCase().includes('overdue')));

  // Paying it down to £40 is still an OVERDUE debt (its due date has
  // already passed) - under the tightened 7-day rule (see the dedicated
  // test below) that alone still blocks, £100 threshold or not.
  const debt = e.state.debts.find((d) => d.orderId === order.id);
  e.recordDebtPayment(debt.id, 60); // £40 remaining, but still overdue
  const stillBlocked = fullOrder(e, phone, ['1 item a BS48 1AB']);
  assert.notEqual(stillBlocked.state, 'CONFIRMED', 'a £40 overdue remainder still blocks - it is still overdue, just no longer over £100');

  // Only paying the overdue debt off IN FULL lifts the block.
  e.recordDebtPayment(debt.id, 40);
  const nowOk = fullOrder(e, phone, ['1 item a BS48 1AB']);
  assert.ok(['CONFIRMED','OFFERED','ASSIGNED'].includes(nowOk.state));
});

test('a debt under £100 STILL blocks once it is overdue (7-day rule is an enforcement rule, not just a £100 threshold)', () => {
  // Tightened after review: the brief says "once it reaches 7 days it
  // must be paid that day" - that is a standalone enforcement rule, not
  // conditional on also reaching £100. A small, genuinely overdue debt
  // (here £10, well under £100) must block a new order exactly the same
  // way a large one does, until it's paid.
  const e = makeEngine();
  const phone = '+447700920033';
  const order = fullOrder(e, phone, ['1 item a BS48 1AB']); // £10
  completeOrder(e, 'D1', order, ' PAID 0'); // £10 debt, not yet overdue
  const debt = e.state.debts.find((d) => d.orderId === order.id);
  assert.equal(debt.amount, 10);

  // Not yet overdue: ordering again is fine.
  const early = fullOrder(e, '+447700920033b', ['1 item a BS48 1AB']);
  assert.ok(['CONFIRMED', 'OFFERED', 'ASSIGNED'].includes(early.state));

  // Advance exactly past the 7-day due date - the debt is now overdue,
  // still only £10 (nowhere near the £100 threshold).
  e.advance(7 * 86400000 + 1000);
  assert.equal(e._overdueDebtTotal(phone), 10);
  const blocked = fullOrder(e, phone, ['1 item a BS48 1AB']);
  assert.notEqual(blocked.state, 'CONFIRMED', 'a £10 overdue debt at day 7+ must still block, not just £100+');
  assert.ok(outboxFor(e, phone).some((t) => t.toLowerCase().includes('overdue')));

  // Paying it off in full unblocks ordering again.
  e.recordDebtPayment(debt.id, 10);
  const nowOk = fullOrder(e, phone, ['1 item a BS48 1AB']);
  assert.ok(['CONFIRMED', 'OFFERED', 'ASSIGNED'].includes(nowOk.state));
});

test('paying debt alongside a new order allocates correctly: existing £20 debt + £10 order, pays £30 -> both cleared', () => {
  const e = makeEngine();
  const phone = '+447700920034';
  const first = fullOrder(e, phone, ['2 item a BS48 1AB']); // £20
  completeOrder(e, 'D1', first, ' PAID 0'); // £20 debt recorded
  const debtBefore = e.state.debts.find((d) => d.orderId === first.id);
  assert.equal(debtBefore.amount, 20);

  const second = fullOrder(e, phone, ['1 item a BS48 1AB']); // £10, but debt isn't overdue yet so this isn't blocked
  e.handleDriverMessage('D1', `ACCEPT ${second.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${second.id} PAID 30`);

  assert.equal(debtBefore.amount, 0, 'the existing £20 debt is cleared by the excess payment');
  const newDebt = e.state.debts.find((d) => d.orderId === second.id);
  assert.equal(newDebt, undefined, 'the £10 order itself needed no new debt - it was paid in full');
});

test('an overpayment beyond order total + all open debts is flagged for review, not silently absorbed', () => {
  const e = makeEngine();
  const phone = '+447700920035';
  const order = fullOrder(e, phone, ['1 item a BS48 1AB']); // £10
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id} PAID 500`);
  assert.ok(e.state.review.some((r) => !r.resolved && /above order total/.test(r.reason)));
});

test('Boss can view a debt summary per phone: open count, total owed, total overdue, returning-debtor flag', () => {
  const e = makeEngine();
  const phone = '+447700920036';
  const o1 = fullOrder(e, phone, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1, ' PAID 0');
  const summaryFirst = e.debtSummaryForPhone(phone);
  assert.equal(summaryFirst.returningDebtor, false);

  const o2 = fullOrder(e, phone, ['1 item b BS48 1AB']);
  e.handleDriverMessage('D1', `ACCEPT ${o2.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o2.id} PAID 0`);
  const summary = e.debtSummaryForPhone(phone);
  assert.equal(summary.openCount, 2);
  assert.equal(summary.totalOwed, 25);
  assert.equal(summary.returningDebtor, true, 'a second separate debt marks them as a returning debtor');
});

test('Boss debt payment is duplicate-protected via idempotencyKey', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920037', ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', order, ' PAID 0');
  const debt = e.state.debts.find((d) => d.orderId === order.id);
  const key = 'boss-payment-1';
  e.recordDebtPayment(debt.id, 4, key);
  e.recordDebtPayment(debt.id, 4, key); // retried
  assert.equal(debt.amount, 6); // only applied once
});

test('Boss can manually adjust (write off) a debt, audited', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920038', ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', order, ' PAID 0');
  const debt = e.state.debts.find((d) => d.orderId === order.id);
  e.adjustDebt(debt.id, -10, 'written off - goodwill');
  assert.equal(debt.amount, 0);
});

// ============================================================= REFERRAL

test('the referral reward is ONE FREE ITEM, not loyalty points', () => {
  const e = makeEngine();
  const referrer = '+447700920040';
  const referee = '+447700920041';
  const o1 = fullOrder(e, referrer, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);
  const code = e._issueReferralCode ? null : null; // issued during _complete via existing mechanism
  const referralCode = Object.keys(e.state.referralCodes).find((c) => e.state.referralCodes[c].ownerPhone === referrer);
  assert.ok(referralCode);

  const o2 = fullOrder(e, referee, [`1 item a ${referralCode} BS48 1AB`]);
  assert.equal(o2.referralCode, referralCode);
  completeOrder(e, 'D1', o2);

  const reward = e.state.freeItemRewards.find((r) => r.phone === referrer);
  assert.ok(reward, 'referrer should have a free-item reward');
  assert.equal(reward.status, 'available');
  assert.equal(reward.sourceReferralCode, referralCode);
  // Referrer's own points come ONLY from their own order's items (1 x £10 item = 3pts), not from the referral.
  assert.equal(e.state.customers[referrer].points, 3);
});

test('the free-item reward is redeemed automatically on the referrer\'s NEXT order, discounting the cheapest item', () => {
  const e = makeEngine();
  const referrer = '+447700920042';
  const referee = '+447700920043';
  const o1 = fullOrder(e, referrer, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);
  const referralCode = Object.keys(e.state.referralCodes).find((c) => e.state.referralCodes[c].ownerPhone === referrer);
  const o2 = fullOrder(e, referee, [`1 item a ${referralCode} BS48 1AB`]);
  completeOrder(e, 'D1', o2);

  const reward = e.state.freeItemRewards.find((r) => r.phone === referrer);
  assert.equal(reward.status, 'available');

  // Referrer orders again: item C (£8, the cheapest available) should come free.
  const nextOrder = fullOrder(e, referrer, ['1 item c BS48 1AB']);
  assert.ok(['CONFIRMED','OFFERED','ASSIGNED'].includes(nextOrder.state));
  assert.equal(nextOrder.total, 0); // £8 item, £8 reward
  assert.equal(reward.status, 'redeemed');
  assert.equal(reward.redeemedOrderId, nextOrder.id);
  assert.equal(nextOrder.freeItemRewardId, reward.id);
});

test('a redeemed reward cannot be used twice', () => {
  const e = makeEngine();
  const referrer = '+447700920044';
  const referee = '+447700920045';
  const o1 = fullOrder(e, referrer, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);
  const referralCode = Object.keys(e.state.referralCodes).find((c) => e.state.referralCodes[c].ownerPhone === referrer);
  const o2 = fullOrder(e, referee, [`1 item a ${referralCode} BS48 1AB`]);
  completeOrder(e, 'D1', o2);

  const first = fullOrder(e, referrer, ['1 item c BS48 1AB']);
  assert.equal(first.total, 0);
  completeOrder(e, 'D1', first); // free the referrer's phone for a genuinely new order
  const second = fullOrder(e, referrer, ['1 item c BS48 1AB']);
  assert.equal(second.total, 8); // no reward left - full price
});

test('self-referral is rejected (unchanged pre-existing behaviour, still covered here)', () => {
  const e = makeEngine();
  const phone = '+447700920046';
  const o1 = fullOrder(e, phone, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);
  const referralCode = Object.keys(e.state.referralCodes).find((c) => e.state.referralCodes[c].ownerPhone === phone);
  const o2 = fullOrder(e, phone, [`1 item a ${referralCode} BS48 1AB`]);
  assert.notEqual(o2.referralCode, referralCode);
});

test('a referral code that happens to look like a UK postcode never breaks item/location parsing in the same message', () => {
  // Root-caused a real, intermittent failure: referral codes are randomly
  // generated (RF + 5 alphanumerics), and purely by chance one can take
  // the exact shape of a valid UK postcode - e.g. "RF216CA" reads as
  // outward "RF21" + inward "6CA". Before this fix, the location parser
  // saw the FULL raw message (item + code + real postcode) and could
  // match the code itself as a candidate postcode, resolve it to
  // OUTSIDE_AREA (RF21 isn't a real serviceable district), and stop right
  // there - silently stranding the order in DRAFT even though the
  // customer's real postcode was right there in the same text. Forced
  // here with a deliberately postcode-shaped code rather than relying on
  // randomness to hit it.
  const e = makeEngine();
  const referrer = '+447700920047';
  const referee = '+447700920048';
  const o1 = fullOrder(e, referrer, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);

  const code = 'RF216CA'; // deliberately postcode-shaped: "RF21 6CA"
  e.state.referralCodes[code] = {
    ownerPhone: referrer, issuedForOrder: o1.id, issuedAt: e.now(), usedByOrder: null, redeemed: false,
  };

  const o2 = fullOrder(e, referee, [`1 item a ${code} BS48 1AB`]);
  assert.equal(o2.referralCode, code, 'the referral code is still attached');
  assert.equal(o2.location.confirmed && o2.location.confirmed.postcode, 'BS48 1AB', 'the REAL postcode resolves, not the code');
  assert.ok(['CONFIRMED', 'OFFERED', 'ASSIGNED'].includes(o2.state), 'the order confirms instead of being silently stranded in DRAFT');
});

test('redeeming the free item correctly affects stock (the item is still reserved/deducted, only price changes)', () => {
  const e = makeEngine();
  e.restockProduct('C', 5);
  const referrer = '+447700920047';
  const referee = '+447700920048';
  const o1 = fullOrder(e, referrer, ['1 item a BS48 1AB']);
  completeOrder(e, 'D1', o1);
  const referralCode = Object.keys(e.state.referralCodes).find((c) => e.state.referralCodes[c].ownerPhone === referrer);
  const o2 = fullOrder(e, referee, [`1 item a ${referralCode} BS48 1AB`]);
  completeOrder(e, 'D1', o2);

  const freeOrder = fullOrder(e, referrer, ['1 item c BS48 1AB']);
  assert.equal(freeOrder.total, 0);
  assert.equal(e.stockSummary('C').reserved, 1, 'the free item is still reserved like any other');
  completeOrder(e, 'D2', freeOrder);
  assert.equal(e.stockSummary('C').total, 4, 'the free item is still deducted from stock on completion');
});

// ============================================================= £250 CASH

test('config has the £250 driver cash limit', () => {
  assert.equal(config.driverCash.limit, 250);
});

test('completed CASH orders add to the driver\'s held cash, separate from Bonus', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700920050', ['1 item a BS48 1AB']); // £10
  completeOrder(e, 'D1', order, ' PAID 10');
  assert.equal(e.state.drivers.D1.cash.held, 10);
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 5); // unaffected, separate figure
});

test('a driver at/over the £250 limit cannot ACCEPT another job until they bank cash', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  // Push the driver to the limit with one big cash order.
  const big = fullOrder(e, '+447700920051', ['25 item a BS48 1AB']); // 25 x £10 = £250
  e.handleDriverMessage('D1', `ACCEPT ${big.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${big.id} PAID 250`);
  assert.equal(e.state.drivers.D1.cash.held, 250);

  const next = fullOrder(e, '+447700920052', ['1 item a BS48 1AB']);
  const r = e.handleDriverMessage('D1', `ACCEPT ${next.id}`);
  assert.equal(r.ok, false);
  assert.equal(next.driverId, null);
});

test('banking cash (Boss adjustDriverCash) frees the driver to accept jobs again', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  const big = fullOrder(e, '+447700920053', ['25 item a BS48 1AB']);
  e.handleDriverMessage('D1', `ACCEPT ${big.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${big.id} PAID 250`);

  e.adjustDriverCash('D1', -250, 'banked at the shop');
  assert.equal(e.state.drivers.D1.cash.held, 0);

  const next = fullOrder(e, '+447700920054', ['1 item a BS48 1AB']);
  const r = e.handleDriverMessage('D1', `ACCEPT ${next.id}`);
  assert.equal(r.ok, true);
});

test('driverCashSummary reports approaching/at-limit correctly for Boss visibility', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  const order = fullOrder(e, '+447700920055', ['21 item a BS48 1AB']); // £210 = 84% of £250
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id} PAID 210`);
  const summary = e.driverCashSummary('D1');
  assert.equal(summary.approachingLimit, true);
  assert.equal(summary.atOrOverLimit, false);
});

test('adjustDriverCash never allows cash to go negative', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  assert.throws(() => e.adjustDriverCash('D1', -10, 'oops'), /below zero/);
});

test('cash adjustments are audited and idempotent under retry', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.registerDriver('D1'); // no-op, already exists
  e.state.drivers.D1.cash.held = 100;
  const key = 'bank-1';
  e.adjustDriverCash('D1', -50, 'banked', key);
  e.adjustDriverCash('D1', -50, 'banked', key); // retried
  assert.equal(e.state.drivers.D1.cash.held, 50); // only applied once
  assert.equal(e.state.drivers.D1.cash.adjustments.length, 1);
});

test('a debt paid alongside a cash order can never push recorded held cash over £250 - it is capped, not silently exceeded', () => {
  // Reproduces the exact reported gap: driver already holding £230
  // (under the limit, so ACCEPT for a further £10 order is correctly
  // allowed), but the customer ALSO settles a £20 old debt in cash at
  // completion - paid=£30 total. Held would become £260 if simply added;
  // Rocket must never let its own recorded `held` figure exceed the
  // £250 limit, and must flag the genuine overflow for Boss instead of
  // burying it in a generic "approaching/at limit" note.
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.state.drivers.D1.cash.held = 230;

  // An existing £20 debt for the customer who's about to order again.
  const debtOwner = '+447700920060';
  const priorOrder = fullOrder(e, debtOwner, ['2 item a BS48 1AB']); // £20
  e.handleDriverMessage('D1', `ACCEPT ${priorOrder.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${priorOrder.id} PAID 0`); // £20 debt recorded
  // That completion itself added £0 cash - D1 still at £230.
  assert.equal(e.state.drivers.D1.cash.held, 230);

  const order = fullOrder(e, debtOwner, ['1 item a BS48 1AB']); // £10
  const acceptResult = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(acceptResult.ok, true, 'ACCEPT is correctly allowed - £230 held is still under the £250 limit');

  e.handleDriverMessage('D1', `COMPLETE ${order.id} PAID 30`); // £10 order + £20 debt, paid together in cash
  assert.equal(e.state.drivers.D1.cash.held, 250, 'recorded held cash is capped at the £250 limit, never allowed to silently read 260');

  const overflowFlag = e.state.review.find(
    (r) => !r.resolved && /OVER the £250 cash limit/.test(r.reason)
  );
  assert.ok(overflowFlag, 'the £10 genuine overflow is raised as its own Boss-visible review flag');
  assert.ok(e.state.auditLog.some((ev) => ev.type === 'DRIVER_CASH_LIMIT_EXCEEDED'), 'the overflow is in the durable audit trail');

  // Capped at the limit means the driver is now correctly blocked from
  // accepting another cash-collecting job until Boss banks it down.
  const next = fullOrder(e, '+447700920061', ['1 item a BS48 1AB']);
  const blockedAccept = e.handleDriverMessage('D1', `ACCEPT ${next.id}`);
  assert.equal(blockedAccept.ok, false);
});

// ================================================================== TAKE

test('TAKE deducts the taken item\'s menu value from the driver\'s Bonus ("driver wage")', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.loadDriverStock('D1', 'A', 5); // £10/unit
  e.handleDriverMessage('D1', 'ON');
  // Give the driver some Bonus to deduct from first.
  const order = fullOrder(e, '+447700920070', ['3 item b BS48 1AB']);
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id} PAID 45`);
  const bonusBefore = e.state.drivers.D1.earnings.totalBonus;
  assert.ok(bonusBefore > 0);

  e.handleDriverMessage('D1', 'TAKE A 2'); // 2 x £10 = £20 taken

  assert.equal(
    e.state.drivers.D1.earnings.totalBonus,
    Math.max(0, Math.round((bonusBefore - 20) * 100) / 100),
    'Bonus is reduced by the taken items\' menu value'
  );
});

test('TAKE bonus deduction floors at £0, never goes negative', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.loadDriverStock('D1', 'B', 3); // £15/unit
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 0);

  e.handleDriverMessage('D1', 'TAKE B 1'); // would be -£15 if not floored

  assert.equal(e.state.drivers.D1.earnings.totalBonus, 0, 'Bonus never goes negative from a TAKE');
});

test('every TAKE raises its own dedicated, Boss-visible review flag - never silently absorbed', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.loadDriverStock('D1', 'A', 5);

  e.handleDriverMessage('D1', 'TAKE A 1');
  e.handleDriverMessage('D1', 'TAKE A 1'); // a second, identical-looking TAKE - must still get its OWN flag

  const flags = e.state.review.filter((r) => !r.resolved && /took 1 x A/.test(r.reason));
  assert.equal(flags.length, 2, 'two separate TAKEs produce two separate Boss review entries, not deduplicated away');
  assert.ok(e.state.auditLog.filter((ev) => ev.type === 'DRIVER_TAKE_BONUS_DEDUCTED').length >= 2);
});
