'use strict';

/*
 * End-to-end proof: real HTTP requests, exactly the shape Tasker (customer
 * SMS) and a future Signal adapter (driver messages) would send, against a
 * live server instance in this sandbox. Not a mock of the transport layer.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../server/index');

// /sms/* and /driver/* now require this (see server/index.js's
// gatewayTokenOk). These tests use the real data/config.json (no dataDir
// override), so this is the same placeholder value that ships there. Sent
// on every request here regardless of route - harmless on routes that
// don't check it, and one less thing to remember per call.
const GATEWAY_TOKEN = require('../data/config.json').gateway.token;

function req(base, method, url, body, extraHeaders) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + url, {
      method,
      headers: Object.assign(
        { 'X-Gateway-Token': GATEWAY_TOKEN },
        data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {},
        extraHeaders
      ),
    }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); }
        catch (e) { reject(e); }
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

test('full order lifecycle over real HTTP: customer SMS in, driver commands, messages out', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-e2e-${Date.now()}.json`);
  // Real wall-clock time here (not a fixed test clock) so the burst window
  // and the server's own tick timer actually elapse during the test.
  const app = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  try {
    // Register a driver and bring them on duty via the driver channel
    let r = await req(base, 'POST', '/driver/register', { id: 'D1', name: 'Dave' });
    assert.equal(r.status, 200);
    r = await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON', messageId: 'd-1' });
    assert.equal(r.status, 200);

    // Customer sends a burst: greeting, then order + real postcode
    await req(base, 'POST', '/sms/inbound', { from: '+447700900100', text: 'hi', messageId: 'c-1' });
    await new Promise((res) => setTimeout(res, 120)); // let the burst window close
    r = await req(base, 'GET', '/sms/outbound/pending');
    assert.equal(r.status, 200);
    assert.ok(r.body.messages.some((m) => m.text.includes('Cash only')), 'greeting should be queued');
    for (const m of r.body.messages) await req(base, 'POST', '/sms/outbound/ack', { id: m.id, ok: true });

    await req(base, 'POST', '/sms/inbound', { from: '+447700900100', text: '2 item b', messageId: 'c-2' });
    await req(base, 'POST', '/sms/inbound', { from: '+447700900100', text: 'BS48 1AB', messageId: 'c-3' });
    await new Promise((res) => setTimeout(res, 120));

    r = await req(base, 'GET', '/sms/outbound/pending');
    const confirmMsg = r.body.messages.find((m) => m.text.includes('Order confirmed'));
    assert.ok(confirmMsg, `expected an order confirmation, got ${JSON.stringify(r.body.messages)}`);
    assert.ok(confirmMsg.text.includes('£30.00'));
    for (const m of r.body.messages) await req(base, 'POST', '/sms/outbound/ack', { id: m.id, ok: true });

    // Find the order id from the driver offer
    r = await req(base, 'GET', '/driver/outbound/pending');
    const offer = r.body.messages.find((m) => m.text.startsWith('JOB'));
    assert.ok(offer, `expected a driver offer, got ${JSON.stringify(r.body.messages)}`);
    const orderId = offer.text.match(/JOB (R\d{4})/)[1];
    for (const m of r.body.messages) await req(base, 'POST', '/driver/outbound/ack', { id: m.id, ok: true });

    // Driver accepts, updates, completes - all over HTTP
    r = await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${orderId} 12`, messageId: 'd-2' });
    assert.equal(r.body.ok, true);
    r = await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: `HERE ${orderId}`, messageId: 'd-3' });
    assert.equal(r.body.ok, true);
    r = await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${orderId}`, messageId: 'd-4' });
    assert.equal(r.body.ok, true);

    r = await req(base, 'GET', '/sms/outbound/pending');
    const texts = r.body.messages.map((m) => m.text);
    assert.ok(texts.some((t) => t.includes('ETA about 12')));
    assert.ok(texts.some((t) => t.includes('arrived')));
    assert.ok(texts.some((t) => t.includes('referral code')));

    // A retried inbound with the same messageId (simulating Tasker retrying
    // after a timeout) must not re-trigger anything.
    const before = app.engine.state.outbox.length;
    r = await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${orderId}`, messageId: 'd-4' });
    assert.equal(r.body.duplicate, true);
    assert.equal(app.engine.state.outbox.length, before);

    // Health endpoint reflects real state honestly
    r = await req(base, 'GET', '/health');
    assert.equal(r.body.ok, true);
    assert.equal(typeof r.body.pendingSms, 'number');

    // Restart: new server instance from the same state file picks up where it left off
    app.stop();
    app.server.close();
    const app2 = createApp({ statePath });
    assert.equal(app2.engine.state.orders[orderId].state, 'COMPLETED');
    app2.stop();
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
    if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
    if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
  }
});

test('Traccar GPS forwarding: token-gated ingestion feeds a live tracking snapshot for the open order', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-e2e-gps-${Date.now()}.json`);
  const app = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;
  const token = app.engine.config.gps.forwardToken;
  const gpsAuth = { 'X-Gps-Token': token };

  try {
    await req(base, 'POST', '/driver/register', { id: 'D1', name: 'Dave', traccarId: 'PHONE-D1' });
    await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON', messageId: 'g-1' });

    await req(base, 'POST', '/sms/inbound', { from: '+447700900200', text: '1 item a BS48 1AB', messageId: 'g-2' });
    await new Promise((res) => setTimeout(res, 120));
    let r = await req(base, 'GET', '/driver/outbound/pending');
    const offer = r.body.messages.find((m) => m.text.startsWith('JOB'));
    assert.ok(offer, `expected a driver offer, got ${JSON.stringify(r.body.messages)}`);
    const orderId = offer.text.match(/JOB (R\d{4})/)[1];
    for (const m of r.body.messages) await req(base, 'POST', '/driver/outbound/ack', { id: m.id, ok: true });

    await req(base, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${orderId}`, messageId: 'g-3' });

    // Wrong/missing token is rejected
    r = await req(base, 'POST', '/gps/traccar', { position: { latitude: 51.437, longitude: -2.755, valid: true }, device: { uniqueId: 'PHONE-D1' } });
    assert.equal(r.status, 401);
    // A token in the URL (rather than the X-Gps-Token header) must not work either.
    r = await req(base, 'POST', `/gps/traccar?token=${token}`, { position: { latitude: 51.437, longitude: -2.755, valid: true }, device: { uniqueId: 'PHONE-D1' } });
    assert.equal(r.status, 401, 'a Traccar token in the query string must be refused - header only');

    // Real Traccar JSON position-forwarding shape, correctly authenticated via header
    r = await req(base, 'POST', '/gps/traccar', {
      position: { latitude: 51.437, longitude: -2.755, speed: 15, course: 90, valid: true, fixTime: new Date().toISOString() },
      device: { uniqueId: 'PHONE-D1', name: 'Dave phone' },
    }, gpsAuth);
    assert.equal(r.status, 200);
    assert.equal(r.body.ok, true);

    // /track/:orderId requires that order's own tracking token - the order
    // id alone (guessable) must not be enough.
    r = await req(base, 'GET', `/track/${orderId}`);
    assert.equal(r.status, 404, 'no tracking token supplied - must not reveal anything, not even that the order exists');
    r = await req(base, 'GET', `/track/${orderId}?token=not-the-real-token`);
    assert.equal(r.status, 404);
    const trackingToken = app.engine.state.orders[orderId].trackingToken;
    assert.ok(trackingToken, 'the engine must issue a tracking token for every order');
    r = await req(base, 'GET', `/track/${orderId}?token=${trackingToken}`);
    assert.equal(r.status, 200);
    assert.equal(r.body.driverId, 'D1');
    assert.ok(r.body.distanceMetres < 1000);
    assert.ok(typeof r.body.etaMinutes === 'number');
    // The header form works too, not just the query param.
    r = await req(base, 'GET', `/track/${orderId}`, null, { 'X-Tracking-Token': trackingToken });
    assert.equal(r.status, 200);

    // A device nobody has linked to a driver is safely ignored, not a 500
    r = await req(base, 'POST', '/gps/traccar', {
      position: { latitude: 1, longitude: 1, valid: true }, device: { uniqueId: 'RANDOM-UNLINKED-PHONE' },
    }, gpsAuth);
    assert.equal(r.status, 202);
    assert.equal(r.body.ok, false);
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
    if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
    if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
  }
});

test('a new message bundled in the same burst as an already-seen id is never permanently lost', async () => {
  // Reproduces an independent-review finding: the old processBurst used
  // ids.some((id) => !engine.firstSeen(id)) to decide whether to skip an
  // already-processed burst. firstSeen() both checks AND marks an id as
  // seen, so Array.some()'s short-circuiting meant a genuinely new id
  // checked BEFORE an already-seen one in the same burst got marked seen
  // as a side effect, even though the burst was then dropped without ever
  // calling handleCustomerBurst - permanently losing that message, since a
  // later retry with the same id would then also be treated as a duplicate.
  const statePath = path.join(os.tmpdir(), `rocket-e2e-burstdedup-${Date.now()}.json`);
  const app = createApp({ statePath, burstWindowMs: 80, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;
  const phone = '+447700900300';

  try {
    // Phase 1: 'r-1' is genuinely processed once, so it's a real duplicate later.
    await req(base, 'POST', '/sms/inbound', { from: phone, text: 'hi', messageId: 'r-1' });
    await new Promise((res) => setTimeout(res, 150));

    // Phase 2: a burst where the NEW message ('r-2') is added BEFORE the
    // already-seen one ('r-1') - the exact ordering that triggered the old
    // premature-marking bug. The whole burst is still expected to be
    // skipped (a duplicate anywhere in a burst means treat it as a repeat
    // delivery) - what matters is whether 'r-2' survives to be retried.
    await req(base, 'POST', '/sms/inbound', { from: phone, text: '2 item b BS48 1AB', messageId: 'r-2' });
    await req(base, 'POST', '/sms/inbound', { from: phone, text: 'hi', messageId: 'r-1' });
    await new Promise((res) => setTimeout(res, 150));

    // 'hi' alone in phase 1 already created a DRAFT order (handleCustomerBurst
    // always creates one on first contact) - so the real check here is that
    // it's still the ONLY order and still just a DRAFT: the mixed burst in
    // phase 2 must not have advanced it, confirming the burst was skipped
    // as a whole rather than the new message sneaking through.
    let orders = Object.values(app.engine.state.orders);
    assert.equal(orders.length, 1);
    assert.equal(orders[0].state, 'DRAFT');

    // Phase 3: a later, genuine retry of just the new message, same id.
    // With the bug, 'r-2' was already (wrongly) marked seen in phase 2 and
    // this would be silently dropped forever. Fixed, it was never marked
    // seen in phase 2 (nothing was processed, nothing was marked), so this
    // retry goes through.
    await req(base, 'POST', '/sms/inbound', { from: phone, text: '2 item b BS48 1AB', messageId: 'r-2' });
    await new Promise((res) => setTimeout(res, 150));

    orders = Object.values(app.engine.state.orders);
    assert.equal(orders.length, 1, 'the new message must eventually get through on retry, not be lost forever');
    assert.equal(orders[0].state, 'CONFIRMED');
    assert.equal(orders[0].total, 30);
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
    if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
    if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
  }
});

test('gateway token: /sms/* and /driver/* refuse a missing or wrong token, /health and /gps/traccar are unaffected', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-e2e-gwtoken-${Date.now()}.json`);
  const app = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  function rawReq(method, url, body, headers) {
    return new Promise((resolve, reject) => {
      const data = body ? JSON.stringify(body) : null;
      const h = Object.assign({}, headers);
      if (data) { h['Content-Type'] = 'application/json'; h['Content-Length'] = Buffer.byteLength(data); }
      const r = http.request(base + url, { method, headers: h }, (res) => {
        let out = '';
        res.on('data', (c) => (out += c));
        res.on('end', () => { try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); } catch (e) { reject(e); } });
      });
      r.on('error', reject);
      if (data) r.write(data);
      r.end();
    });
  }

  try {
    // No token at all -> refused, and nothing is processed as a side effect.
    let r = await rawReq('POST', '/sms/inbound', { from: '+447700900999', text: 'hi', messageId: 'nt-1' });
    assert.equal(r.status, 401);
    await new Promise((res) => setTimeout(res, 100));
    assert.equal(Object.keys(app.engine.state.orders).length, 0, 'an unauthenticated inbound must not create an order');

    // Wrong token -> also refused.
    r = await rawReq('POST', '/sms/inbound', { from: '+447700900999', text: 'hi', messageId: 'nt-2' }, { 'X-Gateway-Token': 'not-the-real-token' });
    assert.equal(r.status, 401);

    // Right token, as a header -> accepted.
    r = await rawReq('POST', '/sms/inbound', { from: '+447700900999', text: 'hi', messageId: 'nt-3' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    assert.equal(r.status, 202);

    // The token in the URL used to also work - it doesn't anymore. A query
    // param ends up in access logs, so header-only is the whole point.
    r = await rawReq('GET', `/sms/outbound/pending?token=${encodeURIComponent(GATEWAY_TOKEN)}`);
    assert.equal(r.status, 401, 'a gateway token in the query string must be refused - header only');
    r = await rawReq('GET', '/sms/outbound/pending', null, { 'X-Gateway-Token': GATEWAY_TOKEN });
    assert.equal(r.status, 200);

    // Routes outside the gateway list are unaffected by this token entirely.
    r = await rawReq('GET', '/health');
    assert.equal(r.status, 200);
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
    if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
    if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
  }
});
