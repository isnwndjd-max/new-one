'use strict';

/*
 * Regression tests for the security startup guard (Remaining Offline Fixes
 * brief, item 8): Rocket must refuse to start in staging/production with
 * placeholder credentials or the dev encryption-key fallback, but must
 * never interfere with development/test (which is what every other test
 * file, and the whole existing suite, relies on - none of them set
 * ROCKET_ENV or call this guard).
 *
 * These tests exercise src/startupGuard.js's checkStartupSafety() function
 * directly - no server is started, since the guard is deliberately a pure,
 * synchronous check with no side effects, wired into server/index.js's
 * `require.main === module` block (i.e. only a real `node server/index.js`
 * run), not into createApp() itself.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { checkStartupSafety, PLACEHOLDER } = require('../src/startupGuard.js');

function safeConfig() {
  return {
    boss: { token: 'a-real-boss-secret-1234567890' },
    gateway: { token: 'a-real-gateway-secret-1234567890' },
    gps: { forwardToken: 'a-real-gps-secret-1234567890' },
  };
}
function placeholderConfig() {
  return {
    boss: { token: PLACEHOLDER },
    gateway: { token: PLACEHOLDER },
    gps: { forwardToken: PLACEHOLDER },
  };
}

test('development (default, no env set) allows placeholder tokens and dev key fallback', () => {
  const r = checkStartupSafety({ config: placeholderConfig(), usingDevFallback: true });
  assert.equal(r.ok, true);
  assert.equal(r.enforced, false);
});

test('explicit "development" and "test" envs are not enforced', () => {
  for (const env of ['development', 'test']) {
    const r = checkStartupSafety({ env, config: placeholderConfig(), usingDevFallback: true });
    assert.equal(r.ok, true);
    assert.equal(r.enforced, false);
  }
});

test('staging refuses to start with placeholder boss token', () => {
  const config = safeConfig();
  config.boss.token = PLACEHOLDER;
  assert.throws(
    () => checkStartupSafety({ env: 'staging', config, usingDevFallback: false }),
    /boss\.token/
  );
});

test('production refuses to start with placeholder gateway token', () => {
  const config = safeConfig();
  config.gateway.token = PLACEHOLDER;
  assert.throws(
    () => checkStartupSafety({ env: 'production', config, usingDevFallback: false }),
    /gateway\.token/
  );
});

test('production refuses to start with placeholder gps.forwardToken', () => {
  const config = safeConfig();
  config.gps.forwardToken = PLACEHOLDER;
  assert.throws(
    () => checkStartupSafety({ env: 'production', config, usingDevFallback: false }),
    /gps\.forwardToken/
  );
});

test('production refuses to start with the dev encryption-key fallback', () => {
  assert.throws(
    () => checkStartupSafety({ env: 'production', config: safeConfig(), usingDevFallback: true }),
    /ROCKET_STATE_KEY/
  );
});

test('staging/production is case-insensitive on the env name', () => {
  assert.throws(
    () => checkStartupSafety({ env: 'PRODUCTION', config: placeholderConfig(), usingDevFallback: true })
  );
});

test('a fully-configured production start is allowed', () => {
  const r = checkStartupSafety({ env: 'production', config: safeConfig(), usingDevFallback: false });
  assert.equal(r.ok, true);
  assert.equal(r.enforced, true);
});

test('a fully-configured staging start is allowed', () => {
  const r = checkStartupSafety({ env: 'staging', config: safeConfig(), usingDevFallback: false });
  assert.equal(r.ok, true);
  assert.equal(r.enforced, true);
});

test('production error lists every problem found, not just the first', () => {
  try {
    checkStartupSafety({ env: 'production', config: placeholderConfig(), usingDevFallback: true });
    assert.fail('expected to throw');
  } catch (err) {
    assert.equal(err.code, 'ROCKET_STARTUP_UNSAFE');
    assert.equal(err.problems.length, 4); // boss, gateway, gps, dev key
  }
});

test('missing config sections are treated as placeholder (unsafe), not a crash', () => {
  assert.throws(
    () => checkStartupSafety({ env: 'production', config: {}, usingDevFallback: false }),
    /boss\.token/
  );
});
