'use strict';

/*
 * Tests signalCliClient.js against a real TCP server speaking the
 * documented signal-cli JSON-RPC daemon protocol (newline-delimited JSON,
 * "send" request/response, unsolicited "receive" notifications) - not a
 * mock of the client's own internals. See signal/signalCliClient.js's own
 * header comment for the source.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const net = require('net');
const { createSignalCliClient } = require('../signal/signalCliClient');

/**
 * A minimal stand-in for `signal-cli daemon --tcp`: accepts one connection,
 * parses newline-delimited JSON-RPC requests, and lets the test script
 * responses to "send" calls and push "receive" notifications at will.
 */
function makeMockSignalCliDaemon() {
  const state = { received: [], connection: null, sendBehavior: () => ({ result: { timestamp: Date.now() } }) };
  const server = net.createServer((sock) => {
    state.connection = sock;
    sock.setEncoding('utf8');
    let buffer = '';
    sock.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 1);
        if (!line.trim()) continue;
        const msg = JSON.parse(line);
        state.received.push(msg);
        if (msg.method === 'send') {
          const outcome = state.sendBehavior(msg);
          if (outcome.noResponse) return; // simulate a hang, for timeout tests
          const response = outcome.error
            ? { jsonrpc: '2.0', id: msg.id, error: outcome.error }
            : { jsonrpc: '2.0', id: msg.id, result: outcome.result };
          sock.write(JSON.stringify(response) + '\n');
        }
      }
    });
  });
  state.pushReceive = (envelope) => {
    state.connection.write(JSON.stringify({ jsonrpc: '2.0', method: 'receive', params: { envelope } }) + '\n');
  };
  return { server, state };
}

async function withDaemon(fn) {
  const { server, state } = makeMockSignalCliDaemon();
  await new Promise((resolve) => server.listen(0, resolve));
  const port = server.address().port;
  try {
    await fn({ state, port });
  } finally {
    server.close();
  }
}

test('connect() resolves once the TCP connection is established, isConnected() reflects it', async () => {
  await withDaemon(async ({ port }) => {
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    assert.equal(client.isConnected(), false);
    await client.connect();
    assert.equal(client.isConnected(), true);
    client.close();
  });
});

test('send() writes a well-formed JSON-RPC request and resolves on the matching response', async () => {
  await withDaemon(async ({ state, port }) => {
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    await client.connect();
    const result = await client.send('+15550001111', 'hello driver');
    assert.equal(state.received.length, 1);
    const req = state.received[0];
    assert.equal(req.jsonrpc, '2.0');
    assert.equal(req.method, 'send');
    assert.deepEqual(req.params.recipient, ['+15550001111']);
    assert.equal(req.params.message, 'hello driver');
    assert.ok(typeof req.id === 'number');
    assert.ok(result.timestamp);
    client.close();
  });
});

test('an error response from signal-cli rejects the send() promise', async () => {
  await withDaemon(async ({ state, port }) => {
    state.sendBehavior = () => ({ error: { code: -1, message: 'Unregistered user' } });
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    await client.connect();
    await assert.rejects(() => client.send('+15550002222', 'hi'), /Unregistered user/);
    client.close();
  });
});

test('a send() call that never gets a response times out rather than hanging forever', async () => {
  await withDaemon(async ({ state, port }) => {
    state.sendBehavior = () => ({ noResponse: true });
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    await client.connect();
    await assert.rejects(() => client.call('send', { recipient: ['+1'], message: 'x' }, { timeoutMs: 50 }), /timed out/);
    client.close();
  });
});

test('unsolicited "receive" notifications are delivered to onReceive as they arrive, with no request involved', async () => {
  await withDaemon(async ({ state, port }) => {
    const received = [];
    const client = createSignalCliClient({ host: '127.0.0.1', port, onReceive: (params) => received.push(params) });
    await client.connect();
    state.pushReceive({ source: '+15550003333', sourceNumber: '+15550003333', timestamp: 111, dataMessage: { message: 'ACCEPT R1234', timestamp: 111 } });
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(received.length, 1);
    assert.equal(received[0].envelope.dataMessage.message, 'ACCEPT R1234');
    client.close();
  });
});

test('multiple concurrent send() calls are correlated to the right response by id, not by arrival order', async () => {
  await withDaemon(async ({ state, port }) => {
    // Respond out of order: second request's response arrives first.
    state.sendBehavior = (msg) => ({ result: { timestamp: msg.id * 1000 } });
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    await client.connect();
    const [r1, r2] = await Promise.all([client.send('+1', 'first'), client.send('+2', 'second')]);
    assert.equal(state.received[0].params.message, 'first');
    assert.equal(state.received[1].params.message, 'second');
    assert.equal(r1.timestamp, state.received[0].id * 1000);
    assert.equal(r2.timestamp, state.received[1].id * 1000);
    client.close();
  });
});

test('a dropped connection rejects any still-pending call instead of hanging', async () => {
  await withDaemon(async ({ state, port }) => {
    state.sendBehavior = () => ({ noResponse: true });
    const client = createSignalCliClient({ host: '127.0.0.1', port });
    await client.connect();
    const pending = client.call('send', { recipient: ['+1'], message: 'x' }, { timeoutMs: 5000 });
    await new Promise((r) => setTimeout(r, 30));
    state.connection.destroy();
    await assert.rejects(() => pending, /closed/);
  });
});

test('account is included in every request when the daemon runs multi-account', async () => {
  await withDaemon(async ({ state, port }) => {
    const client = createSignalCliClient({ host: '127.0.0.1', port, account: '+447700900000' });
    await client.connect();
    await client.send('+1', 'hi');
    assert.equal(state.received[0].params.account, '+447700900000');
    client.close();
  });
});
