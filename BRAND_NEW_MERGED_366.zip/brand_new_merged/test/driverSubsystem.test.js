'use strict';

/*
 * Regression tests for the Driver Subsystem Brief:
 *  1. driver bonus - cancellation gives no bonus (the bonus math itself is
 *     covered by test/driverBonus.test.js; this file only adds the
 *     no-bonus-on-cancel + restart-survival cases the brief calls out
 *     separately)
 *  2. ACCEPT / TAKE command separation
 *  3. driver status ON / OFF / BREAK
 *  4. driver mode FOOT / CAR enforcement (Nailsea-only for FOOT)
 *  5. driver-relay app wiring (SHIFT BREAK reaches the engine as real
 *     BREAK, not OFF; snapshot carries bonus/stock)
 *  6. concurrency: simultaneous ACCEPT stays atomic; TAKE can't go negative
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData); // needed to resolve real road/town names - see test/footModeAccuracy.test.js
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function driverOutbox(e, id) {
  return e.state.outbox.filter((m) => m.to === id).map((m) => m.text);
}
function fullOrder(e, phone, texts) {
  e.handleCustomerBurst(phone, texts);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}

// ---------------------------------------------------------- 1. bonus edges

test('a cancelled order earns the driver no bonus', () => {
  const e = makeEngine();
  // Cancelled while still OFFERED (before a driver accepts) - once a
  // driver is assigned, _cancel() deliberately hands off to dispatch
  // review instead of auto-cancelling (see src/engine.js's WITH_DRIVER
  // guard), so this is the reachable no-bonus-on-cancel case.
  const order = fullOrder(e, '+447700900301', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  assert.equal(order.state, 'OFFERED');
  e.handleCustomerBurst('+447700900301', ['CANCEL']);
  assert.equal(order.state, 'CANCELLED');
  assert.equal(order.driverBonus, undefined);
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 0);
  assert.equal(e.state.drivers.D1.earnings.completedOrders, 0);
});

test('bonus totals survive a save/reload of engine state (durable, not in-memory only)', () => {
  const { Store } = require('../src/store');
  const os = require('os');
  const path = require('path');
  const fs = require('fs');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-bonus-restart-'));
  const file = path.join(dir, 'state.json');
  try {
    const store1 = new Store(file);
    const e1 = new Engine({ index: new LocationIndex(locationsData), menu, messages, config, state: emptyEngineState(), now: () => 0 });
    const order = fullOrder(e1, '+447700900302', ['1 item a BS48 1AB']);
    e1.registerDriver('D1');
    e1.handleDriverMessage('D1', 'ON');
    e1.handleDriverMessage('D1', `ACCEPT ${order.id}`);
    e1.handleDriverMessage('D1', `COMPLETE ${order.id}`);
    store1.save(e1.state);

    const store2 = new Store(file);
    const reloaded = store2.load(emptyEngineState);
    assert.equal(reloaded.drivers.D1.earnings.totalBonus, 5);
    assert.equal(reloaded.drivers.D1.earnings.completedOrders, 1);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------- 2. ACCEPT/TAKE split

test('TAKE no longer aliases ACCEPT: it never acquires a job', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900303', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 5);
  const r = e.handleDriverMessage('D1', `TAKE ${order.id}`);
  // "TAKE R1234" is not a recognised stock item/qty, so it should fail
  // as an unknown stock item, and critically must NOT assign the order.
  assert.equal(r.ok, false);
  assert.equal(order.driverId, null);
  assert.equal(order.state, 'OFFERED');
});

test('ACCEPT acquires the job and does not touch driver stock', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900304', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 5);
  const r = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(r.ok, true);
  assert.equal(order.driverId, 'D1');
  assert.equal(e.state.drivers.D1.stock.A, 5); // untouched by ACCEPT
});

test('TAKE deducts driver stock, records the action, and cannot go negative', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 3);
  let r = e.handleDriverMessage('D1', 'TAKE a 2');
  assert.equal(r.ok, true);
  assert.equal(e.state.drivers.D1.stock.A, 1);
  r = e.handleDriverMessage('D1', 'TAKE a 5'); // more than the 1 remaining
  assert.equal(r.ok, false);
  assert.equal(e.state.drivers.D1.stock.A, 1); // unchanged - refused, not clamped to 0
  const events = e.state.drivers && Object.values(e.state.orders); // no-op, just ensures no crash reading state
  assert.ok(Array.isArray(events));
});

test('TAKE with no quantity defaults to 1', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 2);
  e.handleDriverMessage('D1', 'TAKE a');
  assert.equal(e.state.drivers.D1.stock.A, 1);
});

test('a duplicate TAKE message (same transport messageId) does not double-deduct stock', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 5);
  // Mirrors how server/index.js gates driver messages: engine.firstSeen()
  // is checked before handleDriverMessage() is ever called - see
  // server/index.js's driver-message route.
  const msgId = 'driver-msg-take-1';
  if (e.firstSeen(msgId)) e.handleDriverMessage('D1', 'TAKE a 2');
  assert.equal(e.state.drivers.D1.stock.A, 3);
  if (e.firstSeen(msgId)) e.handleDriverMessage('D1', 'TAKE a 2'); // retried delivery of the same message
  assert.equal(e.state.drivers.D1.stock.A, 3); // unchanged
});

// ------------------------------------------------------- 3. driver status

test('ON / OFF / BREAK set a real 3-state status, keeping onDuty in sync', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  assert.equal(e.state.drivers.D1.status, 'OFF');
  e.handleDriverMessage('D1', 'ON');
  assert.equal(e.state.drivers.D1.status, 'ON');
  assert.equal(e.state.drivers.D1.onDuty, true);
  e.handleDriverMessage('D1', 'BREAK');
  assert.equal(e.state.drivers.D1.status, 'BREAK');
  assert.equal(e.state.drivers.D1.onDuty, false);
  e.handleDriverMessage('D1', 'ON');
  assert.equal(e.state.drivers.D1.status, 'ON');
  e.handleDriverMessage('D1', 'OFF');
  assert.equal(e.state.drivers.D1.status, 'OFF');
  assert.equal(e.state.drivers.D1.onDuty, false);
});

test('a driver on BREAK receives no new job offers', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'BREAK');
  const order = fullOrder(e, '+447700900305', ['1 item a BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED'); // never dispatched - no free driver
  assert.deepEqual(driverOutbox(e, 'D1').filter((t) => t.includes(order.id)), []);
});

test('a driver cannot go on BREAK (or OFF) mid-job; must finish it first', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900306', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  const r = e.handleDriverMessage('D1', 'BREAK');
  assert.equal(r.ok, false);
  assert.equal(e.state.drivers.D1.status, 'ON');
});

// --------------------------------------------------------- 4. driver mode

test('a FOOT driver only receives Nailsea (BS48) jobs, never other enabled areas', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  // BS21 is Clevedon, a different enabled service town - not Nailsea.
  const order = fullOrder(e, '+447700900307', ['1 item a BS21 7RH']);
  assert.equal(order.state, 'CONFIRMED'); // stuck waiting - the only driver is FOOT and this isn't Nailsea
  assert.deepEqual(driverOutbox(e, 'D1').filter((t) => t.includes(order.id)), []);
});

test('a FOOT driver does receive a job whose location is confidently resolved as Nailsea', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', 'FOOT');
  // "colliers walk nailsea" resolves to a real Nailsea road (town: 'Nailsea')
  // via RoadIndex - not a bare BS48 postcode guess. See
  // test/footModeAccuracy.test.js for the fuller BS48-locality matrix.
  const order = fullOrder(e, '+447700900308', ['1 item a']);
  e.handleCustomerBurst('+447700900308', ['colliers walk nailsea']);
  assert.equal(order.state, 'OFFERED');
  assert.ok(driverOutbox(e, 'D1').some((t) => t.includes(order.id)));
});

test('a CAR driver receives jobs from any enabled service area, Nailsea or not', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON'); // defaults to CAR
  const order = fullOrder(e, '+447700900309', ['1 item a BS21 7RH']);
  assert.equal(order.state, 'OFFERED');
});

test('ACCEPT itself refuses a non-Nailsea job for a FOOT driver, even bypassing the offer step', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON'); // CAR - gets offered the job
  const order = fullOrder(e, '+447700900310', ['1 item a BS21 7RH']);
  assert.equal(order.state, 'OFFERED');
  // Now switch the SAME driver to FOOT before accepting (simulates a
  // stale/hand-crafted ACCEPT sent after already having switched mode).
  e.handleDriverMessage('D1', 'FOOT');
  const r = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(r.ok, false);
  assert.equal(order.driverId, null);
});

// ------------------------------------------------- 5. driver-relay wiring

test('driver-relay SHIFT BREAK sets real engine BREAK status, not OFF', () => {
  const { applyCommand, validateCommand } = require('../driver-relay/commands');
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  const cmd = validateCommand({ action: 'SHIFT', mode: 'BREAK' });
  const revTracker = { currentRev: () => null };
  const r = applyCommand(e, 'D1', cmd, revTracker);
  assert.equal(r.ok, true);
  assert.equal(e.state.drivers.D1.status, 'BREAK');
});

test('driver-relay snapshot reports bonus total and stock to the Driver app', () => {
  const { buildSnapshot } = require('../driver-relay/snapshot');
  const e = makeEngine();
  const order = fullOrder(e, '+447700900311', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  e.loadDriverStock('D1', 'a', 4);
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const snap = buildSnapshot(e, 'D1', { now: 1000, revOf: () => 1 });
  assert.equal(snap.driver.totalWagesPence, 500);
  assert.equal(snap.driver.jobsCompleted, 1);
  assert.ok(snap.stock.some((s) => s.held === 4));
});

// -------------------------------------------------- 6. concurrency safety

test('two ACCEPTs for the same offered order stay atomic - only one driver ever wins it', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900312', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.registerDriver('D2');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D2', 'ON');
  const r1 = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  const r2 = e.handleDriverMessage('D2', `ACCEPT ${order.id}`);
  assert.equal(r1.ok, true);
  assert.equal(r2.ok, false);
  assert.equal(order.driverId, 'D1');
});

test('a repeated ACCEPT by the same driver for a job they already hold is a safe no-op (duplicate), not an error', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900313', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  const r = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(r.ok, true);
  assert.equal(r.duplicate, true);
  assert.equal(order.driverId, 'D1');
});
