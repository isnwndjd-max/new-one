'use strict';

/*
 * Runs the 12 multi-message acceptance cases that came with the research pack
 * (data/source/conversation_tests.json) against the real four-district data.
 *
 * How "expected" is interpreted (the pack does not define a format):
 *  - town:        the last town the customer named
 *  - candidate:   the place we resolved or are asking them to confirm;
 *                 if "clarify" is also given, it must be among the options we ask about
 *  - clarify:     we must ask a question rather than commit
 *  - postcode / preserve_location / eta_minutes / arrival: final state
 *  - intent null: nothing location-related is inferred
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { LocationConversation } = require('../src/locationConversation');

const index = new LocationIndex(require('../data/locations.json'));
const cases = require('../data/source/conversation_tests.json');

const QUESTIONS = new Set(['CONFIRM', 'ASK_TOWN', 'ASK_WHICH', 'SPECIAL', 'TOWN_ONLY', 'NOT_IN_TOWN']);

function offered(outcome) {
  if (!outcome) return [];
  if (outcome.type === 'CONFIRM') return [outcome.location.name, ...outcome.alternatives.map((a) => a.name)];
  if (outcome.type === 'ASK_WHICH') return outcome.options.map((o) => o.name);
  if (outcome.type === 'RESOLVED' && outcome.location.name) return [outcome.location.name];
  return [];
}

for (const c of cases) {
  test(`research case: ${c.messages.join(' | ')}`, () => {
    const conv = new LocationConversation(index);
    let last = null;
    let lastLocationOutcome = null;
    for (const m of c.messages) {
      last = conv.handle(m, { allowPartial: true });
      if (!['ETA', 'ARRIVAL', 'NONE'].includes(last.type)) lastLocationOutcome = last;
    }
    const e = c.expected;
    const s = conv.state;
    const outcome = lastLocationOutcome;

    if (e.town) assert.equal(s.town, e.town, 'town');
    if (e.candidate && !e.clarify) {
      const names = offered(outcome);
      assert.equal(names[0], e.candidate, `candidate (got ${JSON.stringify(outcome)})`);
    }
    if (e.clarify) {
      assert.ok(outcome && QUESTIONS.has(outcome.type), `should ask, got ${outcome && outcome.type}`);
      assert.equal(s.confirmed, null, 'must not commit a location while asking');
      if (e.candidate) assert.ok(offered(outcome).includes(e.candidate), `offer should include ${e.candidate}`);
    }
    if (e.match_type) assert.equal(outcome.location.matchKind, 'inferred');
    if (e.postcode) assert.equal(s.confirmed && s.confirmed.postcode, e.postcode);
    if (e.preserve_location) assert.ok(s.confirmed, 'location kept after timing messages');
    if (e.eta_minutes) assert.equal(s.etaMinutes, e.eta_minutes);
    if (e.arrival) assert.equal(s.arrived, true);
    if ('intent' in e && e.intent === null) {
      assert.equal(last.type, 'NONE');
      assert.equal(s.confirmed, null);
      assert.equal(s.etaMinutes, null);
    }
    if (e.do_not_assume_operational_rail_station) assert.equal(outcome.type, 'SPECIAL');
    if (e.supersede_old_candidate) assert.equal(offered(outcome)[0], e.candidate);
  });
}
