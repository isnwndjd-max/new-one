'use strict';

/*
 * Spot-checks for the venue/nickname half of
 * CHANGELOG_BRISTOL_EXTRACT_ENRICHMENT.md: 811 new venues/landmarks
 * (including 44 pubs/bars) found in the Bristol OSM extract, scoped to
 * ONLY the 4 districts Rocket already covers (BS20, BS21, BS48, BS49) -
 * no coverage expansion. Every new venue is status "UNCERTAIN", so the
 * existing VERIFIED_STATUS gate (src/locationIndex.js) already makes
 * these ask/confirm rather than auto-resolve - the same mechanism 484 of
 * the original 561 venues already relied on before this pass.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex, VERIFIED_STATUS } = require('../src/locationIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');

const locationsData = require('../data/locations.json');

function makeIndex() {
  return new LocationIndex(locationsData);
}
const index = makeIndex();

function run(msg) {
  const conv = new LocationConversation(index, emptyState());
  return conv.handle(msg, { allowPartial: true });
}

const newVenues = locationsData.venues.filter((v) => (v.source || '').startsWith('Bristol_osm_full_extract'));

test('every venue added from the Bristol extract is confined to the 4 covered districts', () => {
  const covered = new Set(['BS20', 'BS21', 'BS48', 'BS49']);
  assert.ok(newVenues.length > 0);
  for (const v of newVenues) assert.ok(covered.has(v.id.split('-')[0]), `${v.id} outside covered districts`);
});

test('every venue added from the Bristol extract is UNCERTAIN, never auto-verified', () => {
  for (const v of newVenues) assert.notEqual(v.status, VERIFIED_STATUS);
});

test('a new pub from the extract asks for confirmation rather than auto-resolving ("The Old Inn" - ambiguous, 2 real pubs)', () => {
  const out = run('the old inn');
  assert.equal(out.type, 'ASK_TOWN');
  assert.ok(out.towns.length >= 2);
});

test('a new venue with a distinctive single-word brand name is found and asks to confirm rather than dispatching silently ("Budgens")', () => {
  const out = run('budgens');
  assert.notEqual(out.type, 'RESOLVED');
  assert.ok(['CONFIRM', 'ASK_TOWN', 'ASK_WHICH', 'UNVERIFIED_LOCATION'].includes(out.type));
});

test('a venue whose OSM category is a school/clinic/similar is recognised by name but never offered as a meeting point', () => {
  const nonMeeting = newVenues.filter((v) => v.meetingPoint === false);
  assert.ok(nonMeeting.length > 0);
  for (const v of nonMeeting) assert.ok(v.qualityFlags.includes('not_a_meeting_point'));
});

test('no new venue name collides with an existing road/alley name (the 4 that did were caught and removed)', () => {
  const removedIds = new Set(['BS48-0154', 'BS20-0285', 'BS20-0480', 'BS48-0331']);
  const liveIds = new Set(locationsData.venues.map((v) => v.id));
  for (const id of removedIds) assert.equal(liveIds.has(id), false, `${id} should have been removed as a road/venue name collision`);
});
