'use strict';

/*
 * Tests for the location-resolver hardening pass: safe use of the four-
 * district research data (see data/source/RESEARCH_README.md) without
 * trusting every record as an open, verified, dispatchable meeting point.
 *
 * Covers, against the REAL data/locations.json (not a synthetic fixture,
 * except where noted):
 *  - postcode validation (active/terminated/nonexistent/out-of-area)
 *  - venue status gating (ACTIVE auto-resolves; UNCERTAIN asks first;
 *    DEMOLISHED/FORMER/CLOSED never auto-dispatches)
 *  - exact alias matching beating generic keyword ambiguity
 *  - town context narrowing an otherwise-ambiguous name
 *  - the "&"/"and" and other normalisation variants
 *  - coordinate safety (invalid pin coordinates, postcode centre never
 *    silently promoted to an exact destination)
 *  - order state (items) surviving a clarification cycle, at the engine level
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { LocationConversation } = require('../src/locationConversation');
const { Engine, emptyEngineState } = require('../src/engine');

const index = new LocationIndex(require('../data/locations.json'));
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function outboxFor(e, phone) {
  return e.state.outbox.filter((m) => m.to === phone).map((m) => m.text);
}

// ----------------------------------------------------------- 1. postcode validation

test('an active BS48 postcode resolves with its dataset coordinates', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS48 1AB');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.postcode, 'BS48 1AB');
});

test('an active BS49 postcode resolves', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS49 4AA');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.postcode, 'BS49 4AA');
});

test('an active BS21 postcode resolves', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS21 5AB');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.postcode, 'BS21 5AB');
});

test('an active BS20 postcode resolves', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS20 0AA');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.postcode, 'BS20 0AA');
});

test('a terminated postcode is rejected, not treated as current', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS20 0BS');
  assert.equal(out.type, 'POSTCODE_TERMINATED');
  assert.equal(conv.state.confirmed, null);
});

test('a nonexistent postcode inside a Rocket district (correct format, not in the dataset) is not accepted', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS49 9ZZ');
  assert.equal(out.type, 'NOT_FOUND');
  assert.equal(conv.state.confirmed, null);
});

test('a syntactically valid UK postcode outside the Rocket districts is rejected, not accepted on format alone', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('SW1A 1AA');
  assert.equal(out.type, 'OUTSIDE_AREA');
  assert.equal(conv.state.confirmed, null);
});

// ----------------------------------------------------------- 2. venue status gating

test('a strong, unambiguous name match on an ACTIVE venue auto-resolves', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('the bridge inn yatton', { allowPartial: true });
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.name, 'The Bridge Inn');
  assert.equal(conv.state.confirmed.name, 'The Bridge Inn');
});

test('a strong, unambiguous name match on an UNCERTAIN venue asks for confirmation instead of auto-dispatching', () => {
  const conv = new LocationConversation(index);
  // Ring O' Bells (Nailsea) is status UNCERTAIN in the research data.
  const out = conv.handle('ring o bells nailsea', { allowPartial: true });
  assert.equal(out.type, 'UNVERIFIED_LOCATION');
  assert.equal(out.location.name, "Ring O' Bells");
  assert.equal(conv.state.confirmed, null, 'must not silently commit an unverified venue');
  assert.equal(conv.state.proposed.location.name, "Ring O' Bells", 'still offered, so a plain "yes" can confirm it');
});

test('an explicit "yes" to an UNVERIFIED_LOCATION does commit it - the customer is the verification', () => {
  const conv = new LocationConversation(index);
  conv.handle('ring o bells nailsea', { allowPartial: true });
  const out = conv.handle('yes thats right', {});
  assert.equal(out.type, 'RESOLVED');
  assert.equal(conv.state.confirmed.name, "Ring O' Bells");
});

test('a name that only matches a demolished venue is reported as a former location, not silently dropped or dispatched', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('lord nelson cleeve', { allowPartial: true });
  assert.equal(out.type, 'FORMER_LOCATION');
  assert.equal(conv.state.confirmed, null);
  assert.ok(out.candidates.some((c) => c.name === 'Lord Nelson, former site'));
});

test('a phrase naming a historic site by a name no current venue carries also resolves as FORMER_LOCATION (via the formerLocations dataset hook)', () => {
  // The real data/locations.json ships formerLocations empty (the research
  // pack's 06_former_closed_locations dataset was not included in this
  // import - see CHANGELOG_LOCATION_HARDENING.md), so this exercises the
  // mechanism with a synthetic record rather than claiming real coverage.
  const data = JSON.parse(JSON.stringify(require('../data/locations.json')));
  data.formerLocations = [{
    phrase: 'the old post office',
    formerName: 'The Old Post Office',
    currentVenueId: null,
    note: 'closed - site now residential (test fixture, not real research data)',
  }];
  const syntheticIndex = new LocationIndex(data);
  const conv = new LocationConversation(syntheticIndex);
  const out = conv.handle('meet at the old post office', { allowPartial: true });
  assert.equal(out.type, 'FORMER_LOCATION');
  assert.equal(out.formerName, 'The Old Post Office');
  assert.equal(conv.state.confirmed, null);
});

// ----------------------------------------------------------- 3/4. alias matching + town context

test('an exact alias (Yatton Station) resolves directly, ahead of the generic "station" ambiguity', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('yatton station', { allowPartial: true });
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.name, 'Yatton railway station');
});

test('the bare generic word "station" alone is ambiguous and asks, rather than guessing', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('meet at the station', { allowPartial: true });
  assert.ok(['ASK_TOWN', 'ASK_WHICH'].includes(out.type), `expected a question, got ${out.type}`);
  assert.equal(conv.state.confirmed, null);
});

test('"Royal Oak" alone is ambiguous between towns', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('meet at royal oak', { allowPartial: true });
  assert.equal(out.type, 'ASK_TOWN');
  assert.ok(out.towns.includes('Nailsea'));
  assert.ok(out.towns.includes('Clevedon'));
});

test('"Royal Oak Nailsea" (name + town in one message) strongly prefers the Nailsea venue over asking which town', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('royal oak nailsea', { allowPartial: true });
  assert.notEqual(out.type, 'ASK_TOWN', 'town context in the same message should resolve the ambiguity, not repeat the question');
  assert.equal(out.location.name, 'Royal Oak');
  assert.equal(out.location.town, 'Nailsea');
});

test('a Nailsea town named on an earlier message then "royal oak" prefers the Nailsea venue', () => {
  const conv = new LocationConversation(index);
  conv.handle('nailsea', { allowPartial: true });
  const out = conv.handle('royal oak', { allowPartial: true });
  assert.equal(out.location.name, 'Royal Oak');
  assert.equal(out.location.town, 'Nailsea');
});

test('Co-op Yatton resolves via its alias', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('co op yatton', { allowPartial: true });
  assert.equal(out.location.name, 'Co-op Yatton High Street');
});

test('Grove Sports Centre resolves via its alias, not swallowed by the generic word "grove"', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('grove sports centre and social club nailsea', { allowPartial: true });
  assert.equal(out.location.name, 'Grove Sports Centre & Social Club');
});

// ----------------------------------------------------------- 8. normalisation

test('"&" and "and" normalise the same way for venue matching', () => {
  const conv1 = new LocationConversation(index);
  const conv2 = new LocationConversation(index);
  const outAmp = conv1.handle('grove sports centre & social club nailsea', { allowPartial: true });
  const outAnd = conv2.handle('grove sports centre and social club nailsea', { allowPartial: true });
  assert.equal(outAmp.location.name, outAnd.location.name);
  assert.equal(outAmp.location.venueId, outAnd.location.venueId);
});

// ----------------------------------------------------------- 7. coordinate safety

test('an impossible lat/lng pair is rejected rather than accepted as a pin', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('meet me at 999.999,999.999');
  assert.notEqual(out.type, 'RESOLVED');
  assert.equal(conv.state.confirmed, null);
});

test('a valid customer-shared pin resolves as an exact point', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('51.4308,-2.7626');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.lat, 51.4308);
  assert.equal(out.location.lng, -2.7626);
  assert.equal(out.location.exactPointKnown, true);
});

test('a bare postcode resolves with exactPointKnown false - its coordinate is an area reference, not a promised exact destination', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS48 1AB');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.exactPointKnown, false, 'a postcode centroid must never be presented as an exact meeting point');
});

test('a venue with no recorded coordinates falls back to its postcode centre for navigation, but the driver offer is still labelled area-only, never presented as exact', () => {
  const e = makeEngine();
  // Yatton railway station (BS49-0054) is ACTIVE but has no lat/lng in the
  // research data - a real, current case of an ACTIVE venue with an
  // unverified entrance point.
  e.handleCustomerBurst('+447700900201', ['1 item a yatton station']);
  const orderId = e.state.activeByPhone['+447700900201'];
  const order = e.state.orders[orderId];
  assert.equal(order.location.confirmed.name, 'Yatton railway station');
  assert.equal(order.location.confirmed.exactPointKnown, false);

  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  const offers = e.state.outbox.filter((m) => m.to === 'D1').map((m) => m.text).join('\n');
  assert.match(offers, /postcode\/area only/i, 'the driver must be told this is an area reference, not a confirmed exact entrance');
});

// ----------------------------------------------------------- 11. order state survives clarification

test('items survive a two-step clarification cycle: which town, then confirm the unverified venue', () => {
  const e = makeEngine();
  e.handleCustomerBurst('+447700900202', ['2 item a']);
  e.handleCustomerBurst('+447700900202', ['meet at royal oak']);
  const orderId = e.state.activeByPhone['+447700900202'];
  let order = e.state.orders[orderId];
  assert.equal(order.state, 'DRAFT', 'still waiting on which town');
  assert.equal(order.items[0].qty, 2, 'the item must not be lost while asking which Royal Oak');

  e.handleCustomerBurst('+447700900202', ['nailsea']);
  order = e.state.orders[orderId];
  assert.equal(order.state, 'DRAFT', 'Royal Oak (Nailsea) is UNCERTAIN status, so naming the town alone must still ask for confirmation, not auto-dispatch');
  assert.equal(order.items[0].qty, 2, 'items must still be intact after the town clarification');

  e.handleCustomerBurst('+447700900202', ['yes thats right']);
  order = e.state.orders[orderId];
  assert.equal(order.items[0].qty, 2, 'items must still be intact after the final confirmation');
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.location.confirmed.name, 'Royal Oak');
  assert.equal(order.location.confirmed.town, 'Nailsea');
});

test('an UNVERIFIED_LOCATION confirmation cycle also preserves already-typed items', () => {
  const e = makeEngine();
  e.handleCustomerBurst('+447700900203', ['1 item b ring o bells nailsea']);
  let orderId = e.state.activeByPhone['+447700900203'];
  let order = e.state.orders[orderId];
  assert.equal(order.state, 'DRAFT', 'Ring O\' Bells is UNCERTAIN status, so this must ask before confirming');
  assert.equal(order.items[0].qty, 1);

  e.handleCustomerBurst('+447700900203', ['yes thats right']);
  order = e.state.orders[orderId];
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.items[0].qty, 1, 'the item must have survived the unverified-location confirmation step');
  assert.equal(order.location.confirmed.name, "Ring O' Bells");
});
