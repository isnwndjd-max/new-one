'use strict';

/*
 * End-to-end proof for the offline Driver-relay adapter (driver-relay/
 * adapter.js + commands.js + snapshot.js + protocol.js): a REAL rocket-
 * dispatch Engine on one side, and a protocol-faithful MOCK HTTP server
 * standing in for the existing relay's backend/adapter interface (:8912)
 * on the other - same "real protocol, not a stub" pattern as
 * test/signalAdapter.test.js. Envelopes are built with driver-relay/
 * protocol.js exactly as the real Driver APK would build them
 * (Protocol.java/Crypto.java, ported line-for-line - see that file).
 *
 * NOT a test against the real 100.103.3.32:8912 interface or a real
 * device - see driver-relay/adapter.js's header comment and
 * driver-relay/README.md's gap list for what remains unverified.
 *
 * Covers: snapshot -> offer -> accept -> active order; ETA/HERE; payment
 * full/part/owe + completion; duplicate/idempotency; receipt matching;
 * reconnect/retry.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');
const { createDriverRelayAdapter } = require('../driver-relay/adapter');
const protocol = require('../driver-relay/protocol');
const { toAppOrderId, toRocketOrderId } = require('../driver-relay/orderIds');
const { makeMockAdapterServer } = require('./helpers/mockAdapterServer');

const index = new LocationIndex(require('../data/locations.json'));
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function fullOrder(e, phone, texts) {
  e.handleCustomerBurst(phone, texts);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}

async function startMockServer() {
  const { server, state } = makeMockAdapterServer();
  await new Promise((resolve) => server.listen(0, resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { server, state, base };
}

function makeDriverPairing(driverId) {
  return { driverId, room: protocol.random(16).toString('hex'), root: protocol.b64(protocol.random(32)) };
}

function sealCommand(pairing, action, at) {
  const packet = protocol.seal(protocol.un64(pairing.root), pairing.room, 'command', protocol.id(), at, protocol.COMMAND_TTL, JSON.stringify(action));
  return { packet, envelope: protocol.encode(packet) };
}

function sealGps(pairing, body, at) {
  const packet = protocol.seal(protocol.un64(pairing.root), pairing.room, 'gps', protocol.id(), at, protocol.GPS_TTL, JSON.stringify(body));
  return { packet, envelope: protocol.encode(packet) };
}

function decodeSnapshot(pairing, rawEnvelope) {
  const decoded = protocol.decode(rawEnvelope);
  const plaintext = protocol.open(protocol.un64(pairing.root), pairing.room, 'snapshot', decoded);
  return JSON.parse(plaintext);
}

function decodeReceipt(pairing, rawEnvelope) {
  const decoded = protocol.decode(rawEnvelope);
  const plaintext = protocol.open(protocol.un64(pairing.root), pairing.room, 'receipt', decoded);
  return JSON.parse(plaintext);
}

async function setup(t0 = 1_700_000_000_000) {
  const e = makeEngine(t0);
  const { server, state: mock, base } = await startMockServer();
  const pairing = makeDriverPairing('D1');
  const adapter = createDriverRelayAdapter({
    engine: e,
    adapterApiBase: base,
    drivers: [{ driverId: pairing.driverId, room: pairing.room, root: pairing.root, name: 'Dave' }],
    now: () => e.now(),
    pollIntervalMs: 3600000, // never fires on its own - tests call tick()/pollX() directly
    log: () => {},
  });
  return { e, server, mock, base, pairing, adapter };
}

// --------------------------------------------- 1. snapshot -> offer -> accept

test('driver relay: snapshot -> offer -> accept -> active order, end to end through real envelopes', async () => {
  const { e, server, mock, pairing, adapter } = await setup();
  try {
    // Bring the driver on shift via a real sealed SHIFT command, exactly as
    // the app would send it.
    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);
    let tick = await adapter.tick();
    assert.equal(tick.commands.applied, 1);
    assert.equal(mock.receipts.length, 1);
    let receipt = decodeReceipt(pairing, mock.receipts[0].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(e.state.drivers['D1'].onDuty, true);
    assert.equal(e.state.drivers['D1'].mode, 'CAR');

    // Now a customer order comes in and gets offered to the on-duty driver.
    const order = fullOrder(e, '+447700900801', ['1 item a BS48 1AB']);
    assert.equal(order.state, 'OFFERED');

    await adapter.pushSnapshot('D1');
    let snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    assert.equal(snap.jobs.length, 1);
    const appId = toAppOrderId(order.id);
    assert.equal(snap.jobs[0].id, appId, 'job id must be translated to the app-required A+digits shape');
    assert.equal(snap.jobs[0].status, 'OFFERED');
    const offerRev = snap.jobs[0].rev;

    // Driver accepts, referencing the rev they were just shown.
    ({ envelope } = sealCommand(pairing, { action: 'ACCEPT', orderId: appId, expectedRev: offerRev }, e.now()));
    mock.injectCommand(pairing.room, envelope);
    tick = await adapter.tick();
    assert.equal(tick.commands.applied, 1);
    receipt = decodeReceipt(pairing, mock.receipts[1].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(receipt.message, 'Accepted.');

    assert.equal(e.state.orders[order.id].state, 'ASSIGNED');
    assert.equal(e.state.orders[order.id].driverId, 'D1');
    assert.equal(e.state.drivers['D1'].activeOrderId, order.id);

    snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    assert.equal(snap.jobs[0].status, 'ASSIGNED');
    assert.ok(snap.jobs[0].rev > offerRev, 'rev must advance once the job visibly changed state');
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: an offer no longer available (already taken) is rejected, not silently accepted', async () => {
  const { e, server, mock, pairing, adapter } = await setup();
  try {
    e.registerDriver('D2', 'Other Driver');
    e.handleDriverMessage('D2', 'ON');

    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();

    const order = fullOrder(e, '+447700900802', ['1 item a BS48 1AB']);
    e.handleDriverMessage('D2', `ACCEPT ${order.id}`); // the OTHER driver takes it first
    assert.equal(e.state.orders[order.id].driverId, 'D2');

    await adapter.pushSnapshot('D1');
    const snapBefore = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    assert.equal(snapBefore.jobs.length, 0, 'a job already taken by someone else must not appear in this driver\'s snapshot');

    // D1 tries to accept anyway (e.g. a stale offer notification) with a
    // rev it never actually had.
    ({ envelope } = sealCommand(pairing, { action: 'ACCEPT', orderId: toAppOrderId(order.id), expectedRev: 1 }, e.now()));
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'rejected');
    assert.equal(e.state.orders[order.id].driverId, 'D2', 'must not be reassigned');
  } finally { adapter.stop(); server.close(); }
});

// ---------------------------------------------------------------- 2. ETA/HERE

async function acceptedOrder(ctx, phone) {
  const { e, mock, pairing, adapter } = ctx;
  let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
  mock.injectCommand(pairing.room, envelope);
  await adapter.tick();

  const order = fullOrder(e, phone, ['1 item a BS48 1AB']);
  await adapter.pushSnapshot('D1');
  let snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
  const appId = snap.jobs[0].id;
  const offerRev = snap.jobs[0].rev;

  ({ envelope } = sealCommand(pairing, { action: 'ACCEPT', orderId: appId, expectedRev: offerRev }, e.now()));
  mock.injectCommand(pairing.room, envelope);
  await adapter.tick();
  snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
  return { order, appId, rev: snap.jobs[0].rev };
}

test('driver relay: ETA sends a real dispatch ETA, and HERE (reusing the ETA-unchanged app-visible rev) marks arrival', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await acceptedOrder(ctx, '+447700900803');

    let { envelope } = sealCommand(pairing, { action: 'ETA', orderId: appId, expectedRev: rev, minutes: 10 }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    let receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(e.state.orders[order.id].state, 'EN_ROUTE');
    assert.equal(e.state.orders[order.id].etaMinutes, 10);

    // EN_ROUTE has no app-visible equivalent (see driver-relay/snapshot.js's
    // jobStatus) - the app still shows ASSIGNED, so the rev must NOT have
    // changed; the same rev from before ETA is still correct for HERE.
    let snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    assert.equal(snap.jobs[0].status, 'ASSIGNED');
    assert.equal(snap.jobs[0].rev, rev);

    ({ envelope } = sealCommand(pairing, { action: 'HERE', orderId: appId, expectedRev: rev }, e.now()));
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(e.state.orders[order.id].state, 'ARRIVED');

    snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    assert.equal(snap.jobs[0].status, 'ARRIVED');
    assert.ok(snap.jobs[0].rev > rev, 'a real app-visible change (ASSIGNED -> ARRIVED) must bump the rev');
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: HERE before ASSIGNED (job must be assigned before arrival) is rejected', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();

    const order = fullOrder(e, '+447700900804', ['1 item a BS48 1AB']);
    await adapter.pushSnapshot('D1');
    const snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    const appId = snap.jobs[0].id;
    const rev = snap.jobs[0].rev; // still OFFERED, never accepted

    ({ envelope } = sealCommand(pairing, { action: 'HERE', orderId: appId, expectedRev: rev }, e.now()));
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'rejected');
    assert.notEqual(e.state.orders[order.id].state, 'ARRIVED');
  } finally { adapter.stop(); server.close(); }
});

// --------------------------------------------------- 3. payment / completion

async function arrivedOrder(ctx, phone) {
  const { e, mock, pairing, adapter } = ctx;
  const { order, appId, rev } = await acceptedOrder(ctx, phone);
  const { envelope } = sealCommand(pairing, { action: 'HERE', orderId: appId, expectedRev: rev }, e.now());
  mock.injectCommand(pairing.room, envelope);
  await adapter.tick();
  const snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
  return { order, appId, rev: snap.jobs[0].rev };
}

test('driver relay: COMPLETE with full payment collected leaves no debt', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await arrivedOrder(ctx, '+447700900805');
    const totalPence = Math.round(order.total * 100);

    const { envelope } = sealCommand(pairing, { action: 'COMPLETE', orderId: appId, expectedRev: rev, collectedPence: totalPence, checksConfirmed: false }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(receipt.message, 'Completed.');

    assert.equal(e.state.orders[order.id].state, 'COMPLETED');
    assert.equal(e.state.orders[order.id].paid, order.total);
    assert.ok(!e.state.debts.some((d) => d.orderId === order.id), 'no debt when the full amount was collected');
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: COMPLETE with a partial payment records a debt for the shortfall', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await arrivedOrder(ctx, '+447700900806');
    const totalPence = Math.round(order.total * 100);
    const partialPence = Math.round(totalPence / 2);

    const { envelope } = sealCommand(pairing, { action: 'COMPLETE', orderId: appId, expectedRev: rev, collectedPence: partialPence, checksConfirmed: false }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');

    assert.equal(e.state.orders[order.id].state, 'COMPLETED');
    const debt = e.state.debts.find((d) => d.orderId === order.id);
    assert.ok(debt, 'a debt must be recorded for the shortfall');
    assert.ok(Math.abs(debt.amount - (totalPence - partialPence) / 100) < 0.01);
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: COMPLETE with nothing collected (owe) records the full amount as a debt', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await arrivedOrder(ctx, '+447700900807');

    const { envelope } = sealCommand(pairing, { action: 'COMPLETE', orderId: appId, expectedRev: rev, collectedPence: 0, checksConfirmed: false }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');

    const debt = e.state.debts.find((d) => d.orderId === order.id);
    assert.ok(debt);
    assert.ok(Math.abs(debt.amount - order.total) < 0.01, 'the whole order total is owed when nothing was collected');
  } finally { adapter.stop(); server.close(); }
});

// ----------------------------------------------------- 4. duplicate/idempotency

test('driver relay: the exact same command envelope redelivered (a real app retry) is never applied twice', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await arrivedOrder(ctx, '+447700900808');
    const receiptsBefore = mock.receipts.length; // SHIFT/ACCEPT/HERE already sent their own receipts

    const { envelope } = sealCommand(pairing, { action: 'COMPLETE', orderId: appId, expectedRev: rev, collectedPence: Math.round(order.total * 100), checksConfirmed: false }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    assert.equal(e.state.orders[order.id].state, 'COMPLETED');
    const cust = e.state.customers[order.phone];
    const expectedPoints = order.items.reduce((n, i) => n + i.qty, 0) * e.config.rewards.pointsPerItem; // 3 pts/item - config.rewards.pointsPerItem
    assert.equal(cust.points, expectedPoints);
    assert.equal(cust.completedOrders, 1);

    // The app resends the IDENTICAL saved envelope (same id) because it
    // never got a receipt in time - see DriverClient.java#submit's own
    // comment: "Retry sends the SAME saved action."
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();

    // Completing again must not double-issue rewards, double-record a
    // debt, or otherwise re-run any side effect a second time.
    assert.equal(cust.points, expectedPoints, 'points must not be awarded twice for one redelivered envelope');
    assert.equal(cust.completedOrders, 1);

    assert.equal(mock.receipts.length - receiptsBefore, 2, 'a receipt is still sent for the retry - the app needs confirmation each time it asks');
    const first = decodeReceipt(pairing, mock.receipts[receiptsBefore].envelope);
    const second = decodeReceipt(pairing, mock.receipts[receiptsBefore + 1].envelope);
    assert.equal(first.state, second.state);
    assert.equal(first.message, second.message);
    assert.equal(first.snapshotSeq, second.snapshotSeq, 'a cached (not re-derived) result must carry the same snapshotSeq both times');
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: two DIFFERENT envelopes for the same ACCEPT are still safe (engine-level idempotency, not just envelope dedup)', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();

    const order = fullOrder(e, '+447700900809', ['1 item a BS48 1AB']);
    await adapter.pushSnapshot('D1');
    let snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    const appId = snap.jobs[0].id;
    const rev = snap.jobs[0].rev;

    ({ envelope } = sealCommand(pairing, { action: 'ACCEPT', orderId: appId, expectedRev: rev }, e.now()));
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    assert.equal(e.state.orders[order.id].state, 'ASSIGNED');

    // A second, genuinely different envelope (different id/nonce) for the
    // same ACCEPT - e.g. a double-tap that raced the first one's receipt.
    snap = decodeSnapshot(pairing, mock.snapshots.get(pairing.room));
    const revAfterAccept = snap.jobs[0].rev;
    ({ envelope } = sealCommand(pairing, { action: 'ACCEPT', orderId: appId, expectedRev: revAfterAccept }, e.now() + 1));
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();
    const receipt = decodeReceipt(pairing, mock.receipts[mock.receipts.length - 1].envelope);
    assert.equal(receipt.state, 'applied');
    assert.equal(receipt.message, 'Already accepted.');
    assert.equal(e.state.drivers['D1'].activeOrderId, order.id);
  } finally { adapter.stop(); server.close(); }
});

// --------------------------------------------------------- 5. receipt matching

test('driver relay: a receipt is sealed under the SAME envelope id as its request, with a matching commandHash fingerprint', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);
    await adapter.tick();

    const requestPacket = protocol.decode(envelope);
    const receiptEnvelope = mock.receipts[0].envelope;
    assert.equal(receiptEnvelope.id, requestPacket.id, 'the receipt ENVELOPE id must equal the original command envelope id');

    const receiptBody = decodeReceipt(pairing, receiptEnvelope);
    assert.equal(receiptBody.id, requestPacket.id, 'the receipt BODY id must also equal the original command id');
    assert.equal(receiptBody.commandHash, protocol.fingerprint(requestPacket), 'commandHash must be the fingerprint of the ORIGINAL request packet');
    assert.match(receiptBody.state, /^(applied|rejected)$/);
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: concurrent commands for two different drivers each get their own correctly-matched receipt', async () => {
  const e = makeEngine(1_700_000_000_000);
  const { server, state: mock, base } = await startMockServer();
  const p1 = makeDriverPairing('D1');
  const p2 = makeDriverPairing('D2');
  const adapter = createDriverRelayAdapter({
    engine: e, adapterApiBase: base,
    drivers: [{ driverId: 'D1', room: p1.room, root: p1.root }, { driverId: 'D2', room: p2.room, root: p2.root }],
    now: () => e.now(), pollIntervalMs: 3600000, log: () => {},
  });
  try {
    const c1 = sealCommand(p1, { action: 'SHIFT', mode: 'CAR' }, e.now());
    const c2 = sealCommand(p2, { action: 'SHIFT', mode: 'FOOT' }, e.now());
    mock.injectCommand(p1.room, c1.envelope);
    mock.injectCommand(p2.room, c2.envelope);
    await adapter.tick();

    assert.equal(mock.receipts.length, 2);
    const r1 = mock.receipts.find((r) => r.room === p1.room);
    const r2 = mock.receipts.find((r) => r.room === p2.room);
    assert.equal(r1.envelope.id, c1.packet.id);
    assert.equal(r2.envelope.id, c2.packet.id);
    assert.equal(decodeReceipt(p1, r1.envelope).commandHash, protocol.fingerprint(c1.packet));
    assert.equal(decodeReceipt(p2, r2.envelope).commandHash, protocol.fingerprint(c2.packet));
    assert.equal(e.state.drivers['D1'].mode, 'CAR');
    assert.equal(e.state.drivers['D2'].mode, 'FOOT');
  } finally { adapter.stop(); server.close(); }
});

// -------------------------------------------------------- 6. reconnect/retry

test('driver relay: the relay being unreachable fails a poll soft (no throw) and recovers cleanly once it is reachable again', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    let { envelope } = sealCommand(pairing, { action: 'SHIFT', mode: 'CAR' }, e.now());
    mock.injectCommand(pairing.room, envelope);

    mock.failNextRequests = 1; // the GET /v1/adapter/commands itself fails
    let result = await adapter.pollCommandsOnce();
    assert.equal(result.errors, 1);
    assert.equal(result.applied, 0);
    assert.equal(e.state.drivers['D1'].onDuty, false, 'nothing must have been applied from a failed poll');

    // The command was never actually collected (the failed GET returned
    // before touching the queue), so it's still there for the next try.
    result = await adapter.pollCommandsOnce();
    assert.equal(result.applied, 1);
    assert.equal(e.state.drivers['D1'].onDuty, true);
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: the relay being completely unreachable (connection refused) is handled the same way, not a crash', async () => {
  const e = makeEngine(1_700_000_000_000);
  const pairing = makeDriverPairing('D1');
  const adapter = createDriverRelayAdapter({
    engine: e,
    adapterApiBase: 'http://127.0.0.1:1', // nothing listens here
    drivers: [{ driverId: 'D1', room: pairing.room, root: pairing.root }],
    now: () => e.now(), pollIntervalMs: 3600000, log: () => {},
  });
  const commands = await adapter.pollCommandsOnce();
  assert.equal(commands.errors, 1);
  const gps = await adapter.pollGpsOnce();
  assert.equal(gps.errors, 1);
  const snap = await adapter.pushSnapshot('D1');
  assert.equal(snap.ok, false);
  adapter.stop();
});

test('driver relay: GPS fixes reuse the engine\'s existing GPS pipeline - a fix through the app drives the same tested auto-arrival logic Traccar does', async () => {
  const ctx = await setup();
  const { e, mock, pairing, adapter, server } = ctx;
  try {
    const { order, appId, rev } = await acceptedOrder(ctx, '+447700900810'); // BS48 1AB: 51.435121,-2.754996
    void appId; void rev;

    const { envelope } = sealGps(pairing, { v: 1, driverId: 'D1', at: e.now(), lat: 51.43539, lon: -2.75497, accuracyM: 15, speedMps: 2 }, e.now());
    mock.injectGps(pairing.room, envelope);
    const result = await adapter.tick();
    assert.equal(result.gps.applied, 1);
    assert.equal(result.gps.errors, 0);

    assert.equal(e.state.orders[order.id].state, 'ARRIVED', 'the same distance-based auto-arrival logic used for Traccar fires for a Driver-app GPS fix too');
  } finally { adapter.stop(); server.close(); }
});

test('driver relay: order id translation round-trips (rocket "R####" <-> app "A####")', () => {
  assert.equal(toAppOrderId('R1234'), 'A1234');
  assert.equal(toRocketOrderId('A1234'), 'R1234');
  assert.throws(() => toAppOrderId('X1234'));
  assert.throws(() => toRocketOrderId('R1234'));
});
