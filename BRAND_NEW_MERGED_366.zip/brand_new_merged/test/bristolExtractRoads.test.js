'use strict';

/*
 * Spot-checks for CHANGELOG_BRISTOL_EXTRACT_ENRICHMENT.md: 49 named roads
 * found only in the full-region Bristol OSM extract (not the original
 * targeted footway/highway export) were added to the road database. This
 * covers a genuinely new single-locality road, a same-name-twice case that
 * must still ask rather than guess (two disconnected "Penpole Lane"
 * segments), and confirms the 13 boundary-duplicate clusters caught and
 * removed during review did NOT end up in the live data.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const alleyAliasData = require('../data/alleyAliases.json');

function makeIndex() {
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData, alleyAliasData);
  return index;
}
const index = makeIndex();

function run(msg) {
  const conv = new LocationConversation(index, emptyState());
  return conv.handle(msg, { allowPartial: true });
}

test('a genuinely new road from the Bristol extract resolves ("Yanley Lane")', () => {
  const out = run('yanley lane');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.id, 'ROAD-BS48-0505');
  assert.equal(out.location.town, 'Yanley');
});

test('a new road with two disconnected segments sharing a name asks rather than guessing ("Penpole Lane")', () => {
  const out = run('penpole lane');
  assert.equal(out.type, 'ASK_WHICH');
  assert.equal(out.options.length, 2);
  assert.ok(out.options.every((o) => o.name === 'Penpole Lane'));
});

test('a named landmark road from the extract resolves on its own ("Sylvan Way")', () => {
  const out = run('sylvan way');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.district, 'BS20');
});

test('the road layer alone correctly identifies "Welcome Break Gordano Services" even though a same-named venue batch now also exists', () => {
  // A single-word venue ("Break", a real BS20 shop added in the venue
  // enrichment pass - see CHANGELOG_BRISTOL_EXTRACT_ENRICHMENT.md) is a
  // substring of this road's name, and the venue/road override logic
  // only lets the road win when the venue match is weak - here it isn't
  // (the venue's own real name IS "Break"), so this asks rather than
  // silently guessing. That's the safe outcome, not a bug: it never
  // mis-dispatches. Confirm the road itself is still correctly built and
  // findable by RoadIndex directly, independent of the venue layer.
  const match = index.roadIndex.findMatch('welcome break gordano services');
  assert.equal(match.candidates.length, 1);
  assert.equal(match.candidates[0].road.id, 'ROAD-BS20-0593');
  const out = run('welcome break gordano services');
  assert.notEqual(out.type, 'RESOLVED');
});

test('the pre-existing "Claverham Drove" (Kenn Moor) still resolves without ambiguity', () => {
  // A second "Claverham Drove" cluster was built from the extract but
  // turned out to be a partial re-detection of THIS SAME road (its OSM
  // way ids were a strict subset of this record's) - it was removed
  // rather than merged, since this existing verified record already
  // covers it in full.
  const out = run('claverham drove');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.id, 'ROAD-BS49-0120');
});

test('none of the 13 boundary-duplicate road ids from the review made it into the live road database', () => {
  const dupeIds = new Set([
    'ROAD-BS48-0506', 'ROAD-BS49-0250', 'ROAD-BS48-0508', 'ROAD-BS48-0513',
    'ROAD-BS49-0255', 'ROAD-BS48-0515', 'ROAD-BS21-0359', 'ROAD-BS21-0360',
    'ROAD-BS48-0520', 'ROAD-BS21-0363', 'ROAD-BS21-0365', 'ROAD-BS21-0366',
    'ROAD-BS21-0367',
  ]);
  const liveIds = new Set(roadsData.roads.map((r) => r.id));
  for (const id of dupeIds) assert.equal(liveIds.has(id), false, `${id} should not be in data/roads.json`);
});
