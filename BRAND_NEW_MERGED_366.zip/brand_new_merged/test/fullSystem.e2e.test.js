'use strict';

/*
 * Final full-system end-to-end proof, spanning everything built this
 * project across every session: a real customer order arrives over the
 * SMS gateway contract, is dispatched to a driver over a (mocked) Signal
 * connection, the driver's GPS auto-triggers the same customer updates
 * the manual 5 MIN / HERE commands send, the order completes with a
 * partial cash payment (creating a debt) and a referral code redemption
 * (rewarding the referring customer), and - the point of doing this last -
 * every bit of that state (order, debt, referral, driver) survives a real
 * server restart from disk, and is visible through the Boss app's own API
 * afterwards, not just in the engine's in-memory object.
 *
 * Every HTTP call here goes through the same gateway-token and boss-token
 * checks a real deployment would enforce - nothing is reaching in through
 * a back door the real transports don't have.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const net = require('net');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../server/index');
const { createSignalAdapter } = require('../signal/adapter');

const GATEWAY_TOKEN = require('../data/config.json').gateway.token;
const BOSS_TOKEN = require('../data/config.json').boss.token;

function req(base, method, url, body, extraHeaders) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const headers = Object.assign({ 'X-Gateway-Token': GATEWAY_TOKEN }, extraHeaders);
    if (data) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(data); }
    const r = http.request(base + url, { method, headers }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => { try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); } catch (e) { reject(e); } });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

function bossReq(base, method, url, body) {
  return req(base, method, url, body, { 'X-Boss-Token': BOSS_TOKEN });
}

// A real TCP server speaking signal-cli's own JSON-RPC daemon protocol -
// same mock used in test/signalAdapter.test.js and test/signalCliClient.test.js.
function makeMockSignalCliDaemon() {
  const state = { sent: [], connection: null };
  const server = net.createServer((sock) => {
    state.connection = sock;
    sock.setEncoding('utf8');
    let buffer = '';
    sock.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 1);
        if (!line.trim()) continue;
        const msg = JSON.parse(line);
        if (msg.method === 'send') {
          state.sent.push({ recipient: msg.params.recipient, message: msg.params.message });
          sock.write(JSON.stringify({ jsonrpc: '2.0', id: msg.id, result: { timestamp: Date.now() } }) + '\n');
        }
      }
    });
  });
  state.pushReceive = (envelope) => {
    state.connection.write(JSON.stringify({ jsonrpc: '2.0', method: 'receive', params: { envelope } }) + '\n');
  };
  return { server, state };
}

test('full system: customer SMS -> order -> Signal driver offer -> accept -> GPS auto-updates -> DONE (debt + referral) -> restart -> Boss app', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-full-${Date.now()}.json`);
  const app = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  const { server: daemonServer, state: daemonState } = makeMockSignalCliDaemon();
  await new Promise((resolve) => daemonServer.listen(0, resolve));
  const daemonPort = daemonServer.address().port;

  const driverNumber = '+15550008888';
  const adapter = createSignalAdapter({
    signalCliHost: '127.0.0.1', signalCliPort: daemonPort, rocketApiBase: base, rocketApiToken: GATEWAY_TOKEN,
    log: () => {},
  });
  await adapter.connect();

  const custA = '+447700900301'; // referrer: completes an order first, earns a code
  const custB = '+447700900302'; // referred: a brand-new customer, redeems that code

  try {
    // ---- Driver setup, over Signal ----
    let r = await req(base, 'POST', '/driver/register', { id: driverNumber, name: 'Dave', traccarId: 'PHONE-FULL-D1' });
    assert.equal(r.status, 200, 'driver registration must succeed with a valid gateway token');

    daemonState.pushReceive({ source: driverNumber, timestamp: 1, dataMessage: { timestamp: 1, message: 'ON' } });
    await new Promise((res) => setTimeout(res, 30));
    await adapter.pollInboundOnce();
    assert.equal(app.engine.state.drivers[driverNumber].onDuty, true);

    // ---- Order 1 (customer A): full payment, no referral, mints a code ----
    await req(base, 'POST', '/sms/inbound', { from: custA, text: '1 item a BS48 1AB', messageId: 'a-1' });
    await new Promise((res) => setTimeout(res, 120));

    let offer = app.engine.state.outbox.find((m) => m.channel === 'driver' && m.status === 'pending' && m.text.startsWith('JOB'));
    assert.ok(offer, 'order A should have been offered to the on-duty driver over Signal');
    const orderA = offer.text.match(/JOB (R\d{4})/)[1];

    daemonState.pushReceive({ source: driverNumber, timestamp: 2, dataMessage: { timestamp: 2, message: `ACCEPT ${orderA}` } });
    await new Promise((res) => setTimeout(res, 30));
    await adapter.pollInboundOnce();
    assert.equal(app.engine.state.orders[orderA].state, 'ASSIGNED');

    daemonState.pushReceive({ source: driverNumber, timestamp: 3, dataMessage: { timestamp: 3, message: `DONE ${orderA}` } });
    await new Promise((res) => setTimeout(res, 30));
    await adapter.pollInboundOnce();
    assert.equal(app.engine.state.orders[orderA].state, 'COMPLETED');
    assert.equal(app.engine.state.orders[orderA].paid, 10, 'no PAID clause means the full £10 total is assumed paid');

    r = await req(base, 'GET', '/sms/outbound/pending');
    const completedMsgA = r.body.messages.find((m) => m.to === custA && m.text.includes('referral code'));
    assert.ok(completedMsgA, 'customer A should get a completion message containing a referral code');
    const referralCode = completedMsgA.text.match(/referral code:\s*(RF[A-Z0-9]{5})/)[1];
    for (const m of r.body.messages) await req(base, 'POST', '/sms/outbound/ack', { id: m.id, ok: true });
    await adapter.pollOutboundOnce(); // drain and ack the driver's own "completed" reply over Signal too

    // ---- Order 2 (customer B): new customer, redeems A's referral code ----
    await req(base, 'POST', '/sms/inbound', { from: custB, text: '1 item a BS48 1AB', messageId: 'b-1' });
    await req(base, 'POST', '/sms/inbound', { from: custB, text: referralCode, messageId: 'b-2' });
    await new Promise((res) => setTimeout(res, 120));

    const orderBObj = Object.values(app.engine.state.orders).find((o) => o.phone === custB);
    assert.ok(orderBObj, 'order B should exist');
    assert.equal(orderBObj.referralCode, referralCode, 'referral code sent as its own message in the same burst should still attach');
    const orderB = orderBObj.id;
    // The driver came free right after completing order A, so the tick's own
    // dispatch loop may already have offered order B by the time this burst
    // finished processing - either CONFIRMED (not yet offered) or OFFERED
    // (already dispatched) is a correct outcome here; what matters is the
    // referral attached and the order isn't stuck in DRAFT.
    assert.ok(['CONFIRMED', 'OFFERED'].includes(orderBObj.state), `expected order B to be confirmed/offered, got ${orderBObj.state}`);

    await new Promise((res) => setTimeout(res, 60)); // let the tick's own dispatch pass run
    offer = app.engine.state.outbox.find((m) => m.channel === 'driver' && m.status === 'pending' && m.text.includes(orderB));
    assert.ok(offer, 'order B should have been offered once the driver was free again');

    daemonState.pushReceive({ source: driverNumber, timestamp: 4, dataMessage: { timestamp: 4, message: `ACCEPT ${orderB}` } });
    await new Promise((res) => setTimeout(res, 30));
    await adapter.pollInboundOnce();
    assert.equal(app.engine.state.orders[orderB].state, 'ASSIGNED');

    // ---- GPS: automatic 5-min and arrival messages, no manual driver command ----
    // BS48 1AB resolves to 51.435121,-2.754996 (same fixture used elsewhere
    // in this project's own tests). A few hundred metres away first.
    const gpsAuth = { 'X-Gps-Token': app.engine.config.gps.forwardToken };
    r = await req(base, 'POST', '/gps/traccar', {
      position: { latitude: 51.4370, longitude: -2.7550, speed: 30, valid: true, fixTime: new Date().toISOString() },
      device: { uniqueId: 'PHONE-FULL-D1' },
    }, gpsAuth);
    assert.equal(r.status, 200);
    assert.equal(app.engine.state.orders[orderB].state, 'EN_ROUTE', 'a close-enough GPS fix should auto-advance to EN_ROUTE, same as a manual 5 MIN');

    r = await req(base, 'GET', '/sms/outbound/pending');
    assert.ok(r.body.messages.some((m) => m.to === custB && m.text.includes('5 minutes away')), 'customer B should get the automatic 5-minute message');
    for (const m of r.body.messages) await req(base, 'POST', '/sms/outbound/ack', { id: m.id, ok: true });

    // Now well inside the arrival radius.
    r = await req(base, 'POST', '/gps/traccar', {
      position: { latitude: 51.43539, longitude: -2.75497, speed: 5, accuracy: 15, valid: true, fixTime: new Date().toISOString() },
      device: { uniqueId: 'PHONE-FULL-D1' },
    }, gpsAuth);
    assert.equal(r.status, 200);
    assert.equal(app.engine.state.orders[orderB].state, 'ARRIVED');

    r = await req(base, 'GET', '/sms/outbound/pending');
    assert.ok(r.body.messages.some((m) => m.to === custB && m.text.includes('arrived')), 'customer B should get the automatic arrival message');
    for (const m of r.body.messages) await req(base, 'POST', '/sms/outbound/ack', { id: m.id, ok: true });

    // ---- DONE with a partial cash payment: creates a debt ----
    daemonState.pushReceive({ source: driverNumber, timestamp: 5, dataMessage: { timestamp: 5, message: `DONE ${orderB} PAID 6` } });
    await new Promise((res) => setTimeout(res, 30));
    await adapter.pollInboundOnce();
    assert.equal(app.engine.state.orders[orderB].state, 'COMPLETED');
    assert.equal(app.engine.state.orders[orderB].paid, 6);

    const debtBefore = app.engine.state.debts.find((d) => d.orderId === orderB);
    assert.ok(debtBefore, 'a £6 payment against a £10 order should leave a debt');
    assert.equal(debtBefore.amount, 4);

    // Referral reward landed on customer A, and the code is now spent.
    const rcBefore = app.engine.state.referralCodes[referralCode];
    assert.equal(rcBefore.redeemed, true);
    assert.equal(rcBefore.usedByOrder, orderB);
    // Loyalty is 3 points/item (Rocket's one rule) - customer A's own order
    // was "1 item a" = 3 points. The referral reward itself is a FREE
    // ITEM, not points (see Engine._complete's referral handling) - it
    // shows up as an 'available' reward for customer A to redeem on a
    // future order, not as extra points here.
    const rewardedCustA = app.engine.state.customers[custA];
    assert.equal(rewardedCustA.points, 1 * app.engine.config.rewards.pointsPerItem, "customer A earns points for their own order only - the referral reward is a free item, not points");
    const custAReward = app.engine.state.freeItemRewards.find((r) => r.phone === custA);
    assert.ok(custAReward, 'customer A should have a free-item reward from referring customer B');
    assert.equal(custAReward.status, 'available');
    assert.equal(custAReward.sourceReferralCode, referralCode);

    await adapter.pollOutboundOnce(); // drain the driver's own Signal replies so nothing pending is lost on restart

    // ---- Restart: a fresh server instance reading the same state file ----
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));

    const app2 = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
    await new Promise((resolve) => app2.server.listen(0, resolve));
    const port2 = app2.server.address().port;
    const base2 = `http://127.0.0.1:${port2}`;

    try {
      assert.equal(app2.engine.state.orders[orderB].state, 'COMPLETED', 'order state must survive the restart');
      assert.equal(app2.engine.state.orders[orderA].state, 'COMPLETED');
      const debtAfter = app2.engine.state.debts.find((d) => d.orderId === orderB);
      assert.ok(debtAfter, 'the debt must survive the restart, not just live in memory');
      assert.equal(debtAfter.amount, 4);
      const rcAfter = app2.engine.state.referralCodes[referralCode];
      assert.equal(rcAfter.redeemed, true);

      // ---- Boss app sees exactly this restored state through its own API ----
      r = await bossReq(base2, 'GET', '/boss/summary');
      assert.equal(r.status, 200);
      assert.equal(r.body.ok, true);

      r = await bossReq(base2, 'GET', '/boss/debts');
      assert.equal(r.status, 200);
      const bossDebt = r.body.debts.find((d) => d.orderId === orderB);
      assert.ok(bossDebt, 'the Boss debts endpoint should show the restored debt');
      assert.equal(bossDebt.amount, 4);

      r = await bossReq(base2, 'GET', '/boss/referrals');
      assert.equal(r.status, 200);
      assert.equal(r.body.referralCodes[referralCode].redeemed, true);

      r = await bossReq(base2, 'GET', '/boss/orders');
      assert.equal(r.status, 200);
      assert.equal(r.body.orders.filter((o) => o.state === 'COMPLETED').length, 2, 'both completed orders should be visible after restart');

      r = await bossReq(base2, 'GET', '/boss/menu');
      assert.equal(r.status, 200);
      assert.equal(r.body.menu.items.find((i) => i.code === 'A').unitPrice, 10, 'menu.json (untouched by this test) should load correctly after restart too');

      // Settle the debt through the Boss app itself, and confirm it sticks.
      r = await bossReq(base2, 'POST', `/boss/debts/${bossDebt.id}/payment`, { amount: 4 });
      assert.equal(r.status, 200);
      r = await bossReq(base2, 'GET', '/boss/debts');
      const settled = r.body.debts.find((d) => d.id === bossDebt.id);
      assert.equal(settled.amount, 0, 'the debt should be fully settled after the Boss app payment');
    } finally {
      app2.stop();
      await new Promise((resolve) => app2.server.close(resolve));
    }
  } finally {
    adapter.stop();
    try { app.stop(); app.server.close(); } catch (e) { /* already closed above in the success path */ }
    daemonServer.close();
    if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
    if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
  }
});
