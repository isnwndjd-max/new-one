'use strict';

/*
 * End-to-end proof for customer-relay/adapter.js: a REAL rocket-dispatch
 * server/index.js + engine (over real HTTP, the same gateway/boss surface
 * Tasker and the Boss app use) on one side, and a protocol-faithful MOCK
 * HTTP server standing in for customer-app/server.py's own
 * /api/integration/* endpoints on the other - same "real protocol, not a
 * stub" approach as test/signalAdapter.test.js and
 * test/driverRelay.adapter.test.js.
 *
 * NOT a test against the real customer-app/server.py process (Python) -
 * see customer-relay/README.md for what that would still need to confirm.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const os = require('node:os');
const path = require('node:path');
const { createApp } = require('../server/index');
const { createCustomerRelayAdapter } = require('../customer-relay/adapter');
const { makeMockCustomerAppServer } = require('./helpers/mockCustomerAppServer');

const BOSS_TOKEN = require('../data/config.json').boss.token;
const GATEWAY_TOKEN = require('../data/config.json').gateway.token;

function req(base, method, url, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + url, {
      method,
      headers: Object.assign(
        headers,
        data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}
      ),
    }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => { try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); } catch (e) { reject(e); } });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

async function setup() {
  const statePath = path.join(os.tmpdir(), `rocket-customer-relay-${Date.now()}-${Math.random()}.json`);
  // Real wall-clock time, tiny windows - same pattern as test/server.e2e.test.js.
  const rd = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => rd.server.listen(0, resolve));
  const rdBase = `http://127.0.0.1:${rd.server.address().port}`;

  const mock = makeMockCustomerAppServer({ integrationKey: 'test-key' });
  await new Promise((resolve) => mock.server.listen(0, resolve));
  const appBase = `http://127.0.0.1:${mock.server.address().port}`;

  const adapter = createCustomerRelayAdapter({
    rocketDispatchBase: rdBase,
    gatewayToken: GATEWAY_TOKEN,
    bossToken: BOSS_TOKEN,
    customerAppBase: appBase,
    integrationKey: 'test-key',
    burstSettleMs: 100,
    log: () => {},
  });

  async function stop() {
    rd.stop(); rd.server.close(); mock.server.close();
  }
  return { rd, rdBase, mock, appBase, adapter, stop };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('pushMenu: converts rocket-dispatch\'s own minimal menu into the customer-app shape, no cost/admin fields', async () => {
  const { adapter, mock, stop } = await setup();
  try {
    const out = await adapter.pushMenu();
    assert.ok(out.length >= 3);
    const itemA = out.find((p) => p.code === 'A');
    assert.equal(itemA.name, 'Item A');
    assert.equal(itemA.pricePence, 1000);
    assert.deepEqual(Object.keys(itemA).sort(), ['active', 'aliases', 'category', 'code', 'deal', 'emoji', 'name', 'pricePence', 'size'].sort());
    assert.equal(mock.state.menuPushes.length, 1);
    assert.deepEqual(mock.state.menuPushes[0], out);
  } finally { await stop(); }
});

test('a new pending web order with a correct price is forwarded into rocket-dispatch as a real order and acked FORWARDED', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WAAAA1111', phone: '+447700900100',
      items: [{ code: 'B', qty: 2, name: 'Item B' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB', street: '', venue: '', pinLat: null, pinLng: null },
      note: '', totalPence: 3000, // 2 x Item B @ £15
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();

    assert.equal(mock.state.acks.length, 1);
    assert.equal(mock.state.acks[0].status, 'FORWARDED');
    assert.ok(mock.state.acks[0].rocketOrderId.match(/^R\d{4}$/));
    assert.equal(mock.state.orders.get('WAAAA1111').status, 'FORWARDED');

    const r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    const order = r.body.orders.find((o) => o.id === mock.state.acks[0].rocketOrderId);
    assert.equal(order.phone, '+447700900100');
    assert.equal(order.total, 30);
  } finally { await stop(); }
});

test('a client-submitted total that does not match rocket-dispatch\'s own pricing is flagged for review, never dispatched', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WBBBB2222', phone: '+447700900101',
      items: [{ code: 'B', qty: 2, name: 'Item B' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 100, // wrong - real price is 3000
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();

    assert.equal(mock.state.acks.length, 1);
    assert.equal(mock.state.acks[0].status, 'REVIEW_REQUIRED');
    assert.equal(mock.state.orders.get('WBBBB2222').status, 'REVIEW_REQUIRED');
    const r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    assert.equal(r.body.orders.filter((o) => o.phone === '+447700900101').length, 0, 'no engine order should be created for an unpriceable/mismatched order');
  } finally { await stop(); }
});

test('an item code the app has that rocket-dispatch\'s own menu does not is flagged for review, never guessed', async () => {
  const { adapter, mock, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WCCCC3333', phone: '+447700900102',
      items: [{ code: 'ZZZ', qty: 1, name: 'Mystery Item' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 500,
    });
    await adapter.pollOnce();
    assert.equal(mock.state.acks[0].status, 'REVIEW_REQUIRED');
  } finally { await stop(); }
});

test('a shared GPS pin is preferred over postcode/venue text, and resolves to an exact meeting point', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WPPPP4444', phone: '+447700900103',
      items: [{ code: 'A', qty: 1, name: 'Item A' }],
      location: { text: 'somewhere', postcode: '', street: '', venue: 'Ignore Me', pinLat: 51.4322, pinLng: -2.7523 },
      note: '', totalPence: 1000,
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();
    assert.equal(mock.state.acks[0].status, 'FORWARDED');
    const r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    const order = r.body.orders.find((o) => o.id === mock.state.acks[0].rocketOrderId);
    assert.ok(order.location.confirmed, 'expected a confirmed location from the shared pin');
    assert.equal(order.location.confirmed.type, 'pin');
    assert.equal(Math.round(order.location.confirmed.lat * 10000), Math.round(51.4322 * 10000));
  } finally { await stop(); }
});

test('a full driver lifecycle (accept, 5-min via GPS, here, complete) is reflected back to the customer app as customer-safe statuses, in order', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    await req(rdBase, 'POST', '/driver/register', { id: 'D1', name: 'Dave' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON' }, { 'X-Gateway-Token': GATEWAY_TOKEN });

    mock.seedOrder({
      orderId: 'WLIFE0001', phone: '+447700900104',
      items: [{ code: 'A', qty: 1, name: 'Item A' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 1000,
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();
    const rid = mock.state.acks[0].rocketOrderId;
    assert.ok(rid);
    assert.equal(mock.state.orders.get('WLIFE0001').status, 'FORWARDED');
    // driver offer should already have gone out (order dispatched, one free driver)
    let r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    assert.equal(r.body.orders.find((o) => o.id === rid).state, 'OFFERED');

    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await adapter.pollOnce();
    assert.equal(mock.state.orders.get('WLIFE0001').status, 'ASSIGNED');

    // Simulate the auto GPS "5 minutes away" the same way Traccar would.
    await req(rdBase, 'POST', '/gps/traccar', { deviceId: 'D1', latitude: 51.4322, longitude: -2.7523, speed: 0 }, { 'X-Gps-Token': require('../data/config.json').gps.forwardToken });
    r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    const order = r.body.orders.find((o) => o.id === rid);
    // Order location may not be close enough to trigger five-min/here from a single fixed test pin - drive it explicitly via driver text instead, which is the same customer-facing effect and does not depend on real coordinates matching.
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `5MIN ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await adapter.pollOnce();
    assert.equal(mock.state.orders.get('WLIFE0001').status, 'FIVE_MIN');

    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `HERE ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await adapter.pollOnce();
    assert.equal(mock.state.orders.get('WLIFE0001').status, 'HERE');

    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${rid} PAID 10` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await adapter.pollOnce();
    assert.equal(mock.state.orders.get('WLIFE0001').status, 'COMPLETE');
    assert.equal(mock.state.orders.get('WLIFE0001').paidPence, 1000);
  } finally { await stop(); }
});

test('an already-forwarded order (status no longer PENDING_DISPATCH) is never re-sent as a second engine order, even across repeated polls', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WDUP00001', phone: '+447700900105',
      items: [{ code: 'A', qty: 1, name: 'Item A' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 1000,
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();
    await adapter.pollOnce();
    await adapter.pollOnce();

    const r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    assert.equal(r.body.orders.filter((o) => o.phone === '+447700900105').length, 1, 'exactly one engine order for this phone/request, however many times we poll');
  } finally { await stop(); }
});

test('acking the same customer-safe status twice in a row is not repeated (no redundant network calls once nothing has changed)', async () => {
  const { adapter, mock, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WSAME0001', phone: '+447700900106',
      items: [{ code: 'A', qty: 1, name: 'Item A' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 1000,
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce();
    assert.equal(mock.state.acks.length, 1);
    await adapter.pollOnce();
    await adapter.pollOnce();
    assert.equal(mock.state.acks.length, 1, 'status has not changed (still FORWARDED, no driver) - no repeat ack');
  } finally { await stop(); }
});

// ------------------------------------------------ points unification

test('a real SMS-only order (never touched the app) has its points credited to the app once it completes', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    const phone = '+447700900300';
    await req(rdBase, 'POST', '/driver/register', { id: 'D1', name: 'Dave' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/sms/inbound', { from: phone, text: '1 item a BS48 1AB', messageId: 'sms-pts-1' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await sleep(150);

    let r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    const rid = r.body.orders.find((o) => o.phone === phone).id;
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${rid} PAID 10` }, { 'X-Gateway-Token': GATEWAY_TOKEN });

    // This order never went through mock.seedOrder()/the app's pending
    // queue at all - it's a pure SMS order start to finish, the exact
    // gap CHANGELOG_POINTS_UNIFICATION.md describes.
    await adapter.pollOnce();

    assert.equal(mock.state.pointsCredits.length, 1);
    assert.equal(mock.state.pointsCredits[0].phone, phone);
    assert.equal(mock.state.pointsCredits[0].externalRef, rid);
    assert.equal(mock.state.pointsCredits[0].paidPence, 1000);
    assert.equal(mock.state.customerPoints.get(phone), 100); // 10 paid pounds x pointsPerPound(10)
  } finally { await stop(); }
});

test('polling again after the same SMS order already synced does not re-credit it (idempotent, no repeat network call)', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    const phone = '+447700900301';
    await req(rdBase, 'POST', '/driver/register', { id: 'D1', name: 'Dave' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/sms/inbound', { from: phone, text: '1 item a BS48 1AB', messageId: 'sms-pts-2' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await sleep(150);
    let r = await req(rdBase, 'GET', '/boss/orders', null, { 'X-Boss-Token': BOSS_TOKEN });
    const rid = r.body.orders.find((o) => o.phone === phone).id;
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${rid} PAID 10` }, { 'X-Gateway-Token': GATEWAY_TOKEN });

    await adapter.pollOnce();
    await adapter.pollOnce();
    await adapter.pollOnce();

    assert.equal(mock.state.customerPoints.get(phone), 100, 'still just one credit worth of points, not three');
    assert.ok(adapter._pointsSynced.has(rid));
  } finally { await stop(); }
});

test('an app-originated order is NOT double-credited by the SMS-only points sync once it completes', async () => {
  const { adapter, mock, rdBase, stop } = await setup();
  try {
    mock.seedOrder({
      orderId: 'WPTS0001', phone: '+447700900302',
      items: [{ code: 'A', qty: 1, name: 'Item A' }],
      location: { text: 'BS48 1AB', postcode: 'BS48 1AB' },
      note: '', totalPence: 1000,
    });
    await adapter.pollOnce();
    await sleep(150);
    await adapter.pollOnce(); // forwards + acks FORWARDED, records the mapping

    const rid = mock.state.acks[0].rocketOrderId;
    await req(rdBase, 'POST', '/driver/register', { id: 'D1', name: 'Dave' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: 'ON' }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `ACCEPT ${rid}` }, { 'X-Gateway-Token': GATEWAY_TOKEN });
    await req(rdBase, 'POST', '/driver/inbound', { driverId: 'D1', text: `COMPLETE ${rid} PAID 10` }, { 'X-Gateway-Token': GATEWAY_TOKEN });

    await adapter.pollOnce(); // syncActiveOrders sees COMPLETE -> calls completeOrder() (the existing app-order path)

    assert.equal(mock.state.acks.filter((a) => a.status === 'COMPLETE').length, 1, 'completed via the existing order-complete path');
    assert.equal(mock.state.pointsCredits.length, 0, 'the SMS-only points-credit path must never fire for an app-originated order');
  } finally { await stop(); }
});
