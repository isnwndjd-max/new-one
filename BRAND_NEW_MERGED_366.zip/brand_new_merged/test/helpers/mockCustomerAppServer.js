'use strict';

/*
 * A real HTTP server standing in for customer-app/server.py's own
 * /api/integration/* surface (pending/ack/order-complete/menu/mappings) -
 * same "real protocol, not a stub" approach as
 * test/helpers/mockAdapterServer.js and test/signalAdapter.test.js's mocked
 * signal-cli daemon. Tracks orders exactly the way server.py's own
 * `orders` table does (status starts PENDING_DISPATCH, ack moves it on),
 * so customer-relay/adapter.js's polling logic is exercised the same way
 * it would be against the real Python server.
 */
const http = require('http');

function makeMockCustomerAppServer({ integrationKey = 'test-integration-key' } = {}) {
  const state = { orders: new Map(), menuPushes: [], acks: [], pointsCredits: [], customerPoints: new Map() };

  function seedOrder(order) {
    state.orders.set(order.orderId, { rocketOrderId: '', status: 'PENDING_DISPATCH', ...order });
  }

  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      const send = (status, obj) => {
        const b = JSON.stringify(obj);
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(b);
      };
      const key = req.headers['x-rocket-integration-key'];
      if (key !== integrationKey) return send(403, { error: 'integration key' });
      let parsed = null;
      try { parsed = body ? JSON.parse(body) : {}; } catch { /* ignore */ }

      if (req.method === 'GET' && req.url === '/api/integration/pending') {
        const orders = [...state.orders.values()].filter((o) => o.status === 'PENDING_DISPATCH');
        return send(200, { orders });
      }
      if (req.method === 'GET' && req.url === '/api/integration/mappings') {
        const orders = [...state.orders.values()]
          .filter((o) => o.rocketOrderId && !['COMPLETE', 'CANCELLED', 'REJECTED'].includes(o.status))
          .map((o) => ({ orderId: o.orderId, rocketOrderId: o.rocketOrderId, status: o.status, phone: o.phone }));
        return send(200, { orders });
      }
      if (req.method === 'POST' && req.url === '/api/integration/ack') {
        const o = state.orders.get(parsed.orderId);
        if (!o) return send(404, { error: 'order not found' });
        o.status = parsed.status;
        if (parsed.rocketOrderId) o.rocketOrderId = parsed.rocketOrderId;
        state.acks.push({ ...parsed, at: Date.now() });
        return send(200, { ok: true });
      }
      if (req.method === 'POST' && req.url === '/api/integration/order-complete') {
        const o = state.orders.get(parsed.orderId);
        if (!o) return send(404, { error: 'order not found' });
        o.status = 'COMPLETE';
        o.paidPence = parsed.paidPence;
        state.acks.push({ ...parsed, status: 'COMPLETE', at: Date.now() });
        return send(200, { ok: true });
      }
      if (req.method === 'POST' && req.url === '/api/integration/points-credit') {
        // Mirrors the real server.py's idempotency: a repeat call with the
        // same (phone, externalRef) is a no-op, not a double-credit - see
        // customer-app/server.py's unique index on points_ledger.
        const dupeKey = `${parsed.phone}:${parsed.externalRef}`;
        state.pointsCredits.push({ ...parsed, at: Date.now() });
        if (!state._creditedRefs) state._creditedRefs = new Set();
        let credited = false;
        if (!state._creditedRefs.has(dupeKey) && parsed.paidPence > 0) {
          state._creditedRefs.add(dupeKey);
          const prev = state.customerPoints.get(parsed.phone) || 0;
          const earned = Math.floor(parsed.paidPence / 100) * 10; // pointsPerPound=10, no remainder-carry needed for whole-pound test amounts
          state.customerPoints.set(parsed.phone, prev + earned);
          credited = true;
        }
        return send(200, { ok: true, credited, pointsEarned: credited ? Math.floor(parsed.paidPence / 100) * 10 : 0 });
      }
      if (req.method === 'POST' && req.url === '/api/integration/menu') {
        state.menuPushes.push(parsed.menu);
        return send(200, { ok: true, count: (parsed.menu || []).length });
      }
      send(404, { error: 'not found' });
    });
  });

  return { server, state, seedOrder };
}

module.exports = { makeMockCustomerAppServer };
