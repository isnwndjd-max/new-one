'use strict';

/*
 * A minimal stand-in for the EXISTING Driver relay's backend/adapter
 * interface at :8912 (POST /v1/adapter/snapshot, GET /v1/adapter/gps,
 * GET /v1/adapter/commands, POST /v1/adapter/receipt) - a REAL HTTP server,
 * same "real protocol, not a stub" pattern as
 * test/signalAdapter.test.js's mock signal-cli daemon. This is NOT a claim
 * about what the real relay's JSON shapes are (see driver-relay/adapter.js's
 * header comment - those are undocumented) - it's this integration's own
 * best-faith shape, used consistently by both the adapter and this mock so
 * the tests exercise real HTTP + real envelope crypto end to end.
 */

const http = require('http');

function makeMockAdapterServer() {
  const state = {
    snapshots: new Map(), // room -> raw envelope JSON last posted
    receipts: [], // every {room, envelope} ever posted, in order
    pendingCommands: [], // [{room, envelope}] waiting to be collected by GET
    pendingGps: [], // [{room, envelope}] waiting to be collected by GET
    failNextRequests: 0, // test hook: next N requests get a 500
  };

  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const send = (code, obj) => {
        const b = JSON.stringify(obj);
        res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(b) });
        res.end(b);
      };
      if (state.failNextRequests > 0) {
        state.failNextRequests--;
        return send(500, { ok: false, error: 'simulated relay failure' });
      }
      try {
        if (req.method === 'POST' && req.url === '/v1/adapter/snapshot') {
          const b = JSON.parse(body);
          state.snapshots.set(b.room, b.envelope);
          return send(200, { ok: true });
        }
        if (req.method === 'GET' && req.url === '/v1/adapter/commands') {
          const items = state.pendingCommands.splice(0, state.pendingCommands.length);
          return send(200, { commands: items });
        }
        if (req.method === 'GET' && req.url === '/v1/adapter/gps') {
          const items = state.pendingGps.splice(0, state.pendingGps.length);
          return send(200, { fixes: items });
        }
        if (req.method === 'POST' && req.url === '/v1/adapter/receipt') {
          const b = JSON.parse(body);
          state.receipts.push(b);
          return send(200, { ok: true });
        }
        send(404, { ok: false, error: 'not found' });
      } catch (e) {
        send(500, { ok: false, error: e.message });
      }
    });
  });

  // Test-side helpers, simulating "a command/gps fix arrived at the relay
  // from the real Driver app" - what GET /v1/adapter/commands and
  // GET /v1/adapter/gps would return on their next poll.
  state.injectCommand = (room, envelope) => state.pendingCommands.push({ room, envelope });
  state.injectGps = (room, envelope) => state.pendingGps.push({ room, envelope });

  return { server, state };
}

module.exports = { makeMockAdapterServer };
