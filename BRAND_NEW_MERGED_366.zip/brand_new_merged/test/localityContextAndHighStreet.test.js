'use strict';

/*
 * Tests for the locality-context-alias layer and the Hill Road / "High
 * Street" colloquial-alias fix (see
 * CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md).
 *
 * Background: the road/alley layer's OSM-derived "locality" field is a
 * nearest-point label, not what a customer actually calls a place - e.g.
 * the road serving Nailsea & Backwell railway station is labelled "West
 * Town" (a real hamlet), not "Backwell". This layer adds an evidence-backed
 * accepted_town_context per road_id (data/localityContext.json, built from
 * REAL venue-postcode records already in data/locations.json - never
 * guessed) so a customer can use the town name they actually know, WITHOUT
 * rewriting the road's own real OSM locality field.
 *
 * Separately, "High Street" was confirmed (by the person operating Rocket,
 * with direct local knowledge) to be what locals colloquially call Hill
 * Road, Clevedon - the same real road, not a second one. That is now an
 * additional confirmed alias on ROAD-BS21-0171, sourced as local knowledge,
 * not as an OSM or research-pack fact - see data/roads.json's
 * alias_provenance on that record.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');
const { Engine, emptyEngineState } = require('../src/engine');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeIndex() {
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData);
  return index;
}
const index = makeIndex();

function run(msgs, opts = { allowPartial: true }) {
  const conv = new LocationConversation(index, emptyState());
  const outs = [];
  for (const m of msgs) outs.push(conv.handle(m, opts));
  return { outs, last: outs[outs.length - 1], state: conv.state };
}

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}

// -------------------------------------------------- Station Road / Backwell

test('1. "station rd backwell" resolves the road, preserving the real OSM locality and surfacing the customer town separately', () => {
  const { last } = run(['station rd backwell']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.name, 'Station Road');
  assert.equal(last.location.town, 'West Town'); // real geography, untouched
  assert.equal(last.location.customerContextTown, 'Backwell'); // what the customer said
});

test('2. "station road backwell" (full word) resolves the same way', () => {
  const { last } = run(['station road backwell']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.customerContextTown, 'Backwell');
});

test('3. "station rd" alone is still genuinely ambiguous and asks - context aliases never remove real ambiguity', () => {
  const { last } = run(['station rd']);
  assert.equal(last.type, 'ASK_TOWN');
  assert.ok(last.towns.length > 5);
});

test('4. "station road nailsea" resolves the DIFFERENT, correct Station Road (not the Backwell one)', () => {
  const { last } = run(['station road nailsea']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.town, 'Nailsea');
  assert.notEqual(last.location.customerContextTown, 'Backwell');
});

test('5. Station Road + a full valid postcode: the postcode wins outright, as before this change', () => {
  const pc = Object.keys(locationsData.activePostcodes)[0];
  const { last } = run([`${pc} Station Road`]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'postcode');
  assert.equal(last.location.postcode, pc);
});

// ------------------------------------------------- High Street / Hill Road

for (const [n, msg] of [
  [6, 'high street clevedon'],
  [7, 'high st clevedon'],
  [8, 'highstreet clevedon'],
  [9, 'on high street clevedon'],
]) {
  test(`${n}. "${msg}" resolves to Hill Road, Clevedon (colloquial alias, not a fabricated second road)`, () => {
    const { last } = run([msg]);
    assert.equal(last.type, 'RESOLVED');
    assert.equal(last.location.type, 'road');
    assert.equal(last.location.id, 'ROAD-BS21-0171');
    assert.equal(last.location.name, 'Hill Road'); // the road's real name is never renamed
    assert.equal(last.location.customerContextTown, 'Clevedon');
  });
}

test('10. "high st" with an already-known town=Clevedon context resolves without asking again', () => {
  const conv = new LocationConversation(index, emptyState());
  conv.handle('clevedon', { allowPartial: true });
  const out = conv.handle('high st', { allowPartial: true });
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.id, 'ROAD-BS21-0171');
});

test('11. Hill Road, Clevedon by its real name still resolves to the same record - it was never renamed', () => {
  const { last } = run(['hill road clevedon']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, 'ROAD-BS21-0171');
  assert.equal(last.location.name, 'Hill Road');
});

test('12. High Street was NOT split into a separate fabricated road - only one BS21 record answers to either name', () => {
  const byHighSt = run(['high street clevedon']).last.location.id;
  const byHillRd = run(['hill road clevedon']).last.location.id;
  assert.equal(byHighSt, byHillRd);
  const roadNamed = roadsData.roads.filter((r) => r.district === 'BS21' && r.name.toLowerCase() === 'high street');
  assert.equal(roadNamed.length, 0, 'no separate "High Street" road record should exist in BS21');
});

test('13. a same-named road in a different town is never selected because of the Clevedon context alias', () => {
  // "high street" alone (no town) must still behave exactly as before this
  // fix - Clevedon's alias never leaks into an unrelated bare "high street" ask.
  const { last } = run(['high street']);
  assert.equal(last.type, 'ASK_TOWN');
  assert.ok(!last.towns.includes('Clevedon') || last.towns.length > 1);
});

// --------------------------------------------------------- priority rules

test('14. exact full postcode still beats a weak/absent context alias', () => {
  const pc = Object.keys(locationsData.activePostcodes)[0];
  const { last } = run([`${pc} high street`]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'postcode');
});

test('15. venue matching is unaffected by this change', () => {
  const activeVenue = locationsData.venues.find((v) => v.status === 'ACTIVE' && v.name && v.name.includes(' '));
  const { last } = run([activeVenue.name.toLowerCase()]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'venue');
});

test('16. postcode matching is unaffected by this change', () => {
  const [pc, rec] = Object.entries(locationsData.activePostcodes)[5];
  const { last } = run([pc]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.postcode, pc);
  assert.equal(last.location.lat, rec.lat);
});

test('17. ordinary road matching (no context alias involved) is unaffected', () => {
  const { last } = run(['kenn road']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'road');
});

test('18. alley/path matching is unaffected', () => {
  const namedAlley = alleysData.alleys.find((a) => a.name_source === 'osm_named');
  const sameName = alleysData.alleys.filter((a) => a.name === namedAlley.name);
  if (sameName.length === 1) {
    const { last } = run([namedAlley.name]);
    assert.equal(last.type, 'RESOLVED');
    assert.equal(last.location.type, 'alley');
  }
});

test('19. an ETA message is never mistaken for a road/context match', () => {
  const { last } = run(['10 mins']);
  assert.notEqual(last.type, 'RESOLVED');
  assert.equal(last.type, 'ETA');
});

test('20. HERE / CANCEL / STOP are not mistaken for roads', () => {
  for (const msg of ['here now', 'stop']) {
    const { last } = run([msg]);
    assert.notEqual(last.location && last.location.type, 'road');
    assert.notEqual(last.location && last.location.type, 'alley');
  }
  const e = makeEngine();
  e.handleCustomerBurst('c1', ['high street clevedon', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.location.confirmed.id, 'ROAD-BS21-0171');
  e.handleCustomerBurst('c1', ['cancel']);
  assert.equal(order.state, 'CANCELLED');
});

// ---------------------------------------------- context data sanity checks

test('every accepted context row is scoped to a real road_id and a real Rocket town (never a guess, never a blanket remap)', () => {
  const validIds = new Set([...roadsData.roads.map((r) => r.id), ...alleysData.alleys.map((a) => a.id)]);
  const canonicalTowns = new Set(locationsData.towns);
  for (const c of contextData.contexts) {
    assert.ok(validIds.has(c.road_id), `context row references unknown road_id ${c.road_id}`);
    assert.ok(canonicalTowns.has(c.accepted_town), `context row's accepted_town "${c.accepted_town}" is not a real Rocket town`);
  }
});

test('end-to-end: a Backwell customer ordering via Station Road gets a CONFIRMED order with the recognisable town in their text', () => {
  const e = makeEngine();
  e.handleCustomerBurst('c2', ['station rd backwell', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.state, 'CONFIRMED');
  const sent = e.state.outbox.filter((m) => m.to === 'c2').map((m) => m.text).join(' | ');
  assert.ok(sent.includes('Backwell'), `expected "Backwell" in the customer-facing text: ${sent}`);
});
