'use strict';

/*
 * Direct unit tests for LocationConversation, covering fixes found in an
 * independent review (not already exercised by the fixed research-pack
 * cases in conversationCases.test.js).
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { LocationConversation } = require('../src/locationConversation');

const index = new LocationIndex(require('../data/locations.json'));

test('a "yeah" that goes on to name a different real venue is a correction, not a confirmation', () => {
  const conv = new LocationConversation(index);
  conv.handle('yatton', { allowPartial: true });
  const proposed = conv.handle('bridge', { allowPartial: true });
  assert.equal(proposed.type, 'CONFIRM');
  assert.equal(proposed.location.name, 'The Bridge Inn');

  // Cheungs Chinese Takeaway is status UNCERTAIN in the research data (never
  // individually checked for current trading status - see
  // RESEARCH_README.md), so switching to it is still a correction of the
  // CANDIDATE (not silently re-confirmed to Bridge Inn), but it lands as
  // UNVERIFIED_LOCATION rather than RESOLVED - it still needs its own "yes"
  // before s.confirmed is set. See the dedicated UNVERIFIED_LOCATION tests
  // below for that confirmation step.
  const out = conv.handle('yeah not that one, cheungs chinese takeaway', { allowPartial: true });
  assert.equal(out.type, 'UNVERIFIED_LOCATION', `should switch to the named correction, got ${JSON.stringify(out)}`);
  assert.equal(out.location.name, 'Cheungs Chinese Takeaway');
  assert.equal(conv.state.confirmed, null, 'an unverified venue must not be auto-confirmed just because it was named as a correction');
  assert.equal(conv.state.proposed.location.name, 'Cheungs Chinese Takeaway');
});

test('a plain "yeah" with no other venue named still confirms the proposed place', () => {
  const conv = new LocationConversation(index);
  conv.handle('yatton', { allowPartial: true });
  conv.handle('bridge', { allowPartial: true });
  const out = conv.handle('yeah thats right', { allowPartial: true });
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.name, 'The Bridge Inn');
});

test('a shared location pin is marked as an exact point, unlike a bare postcode', () => {
  const conv = new LocationConversation(index);
  // Use a real pin format the index recognises - a plain lat,lng pair, which
  // findPin treats as a shared-location pin independent of postcode/venue data.
  const out = conv.handle('51.4308,-2.7626', {});
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.exactPointKnown, true, 'a pin is a real point, not an area centroid - drivers should not get the "postcode/area only" note for it');
  assert.equal(out.location.serviceAreaVerified, false, 'a pin has not been proven to be inside the coverage area');
});

// ---------------------------------------------------------- street refinement

test('a full postcode with a street name in the same message attaches the street as a label, without changing the resolved coordinate', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('42 Silver Street BS48 1AB');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.street, '42 Silver Street');
  assert.equal(out.location.postcode, 'BS48 1AB');
  // The coordinate is exactly what the postcode alone resolves to - a street
  // name is never used to invent or move a coordinate (see the STREET_RE
  // comment in src/locationIndex.js: there is no street-level geocoding data
  // in this project).
  assert.equal(out.location.lat, 51.435121);
  assert.equal(out.location.lng, -2.754996);
});

test('a bare postcode with no street name leaves street unset', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('BS48 1AB');
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.street, null);
});

test('a street name given as a follow-up after the postcode was already confirmed refines the existing location in place', () => {
  const conv = new LocationConversation(index);
  conv.handle('BS48 1AB');
  assert.equal(conv.state.confirmed.street, null);

  const out = conv.handle("it's Silver Street");
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.street, 'Silver Street');
  assert.equal(out.location.postcode, 'BS48 1AB', 'the postcode/coordinate already confirmed must not change');
  assert.equal(out.location.lat, 51.435121);
});

test('a timing-only message is never reinterpreted as a street refinement, even if it happens to contain a street-shaped phrase', () => {
  const conv = new LocationConversation(index);
  conv.handle('BS48 1AB');
  const out = conv.handle('5 mins away');
  assert.equal(out.type, 'ETA');
  assert.equal(conv.state.confirmed.street, null, 'no street-shaped text in this message, and ETA takes priority over location changes either way');
});

test('a street name with only a partial/outward postcode cannot be resolved to a coordinate - no street gazetteer exists - so it is surfaced for a human instead of guessed', () => {
  const conv = new LocationConversation(index);
  const out = conv.handle('Silver Street, BS48');
  assert.equal(out.type, 'NOT_FOUND');
  assert.equal(out.reason, 'postcode district only');
  assert.equal(out.street, 'Silver Street');
  assert.equal(conv.state.confirmed, null, 'must not fabricate a confirmed location from a street name alone');
});
