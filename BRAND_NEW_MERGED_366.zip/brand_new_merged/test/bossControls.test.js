'use strict';

/*
 * Regression tests for the new Boss-side controls (Remaining Offline Fixes
 * brief, item 6): stock, Bonus rates, loyalty, referral rewards, debt
 * summary/adjustment, driver cash. Each endpoint is a thin HTTP wrapper
 * around the SAME engine methods already covered by
 * test/remainingOfflineFixes.test.js - these tests exist to prove the wiring
 * (auth, routing, body parsing, persistence) works, not to re-prove the
 * business rules themselves.
 *
 * Uses a real server (like test/fullSystem.e2e.test.js) over a COPY of
 * data/ in a temp dir, via createApp's dataDir option - the driverPay
 * endpoint writes config.json back to disk, and this must never touch the
 * real project's data/config.json.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createApp } = require('../server/index.js');

function copyDataDir() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-boss-data-'));
  const src = path.join(__dirname, '..', 'data');
  fs.cpSync(src, dir, { recursive: true });
  return dir;
}

async function setup() {
  const dataDir = copyDataDir();
  const stateDir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-boss-state-'));
  const statePath = path.join(stateDir, 'state.json');
  const app = createApp({ dataDir, statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const token = app.engine.config.boss.token;
  return { app, dataDir, stateDir, base, token };
}
async function teardown(ctx) {
  await new Promise((resolve) => ctx.app.server.close(resolve));
  fs.rmSync(ctx.dataDir, { recursive: true, force: true });
  fs.rmSync(ctx.stateDir, { recursive: true, force: true });
}
function req(base, token, method, url, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : null;
    const r = http.request(
      base + url,
      { method, headers: { 'Content-Type': 'application/json', 'X-Boss-Token': token } },
      (res) => {
        let b = '';
        res.on('data', (c) => (b += c));
        res.on('end', () => resolve({ status: res.statusCode, body: b ? JSON.parse(b) : null }));
      }
    );
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

test('boss endpoints require the boss token', async () => {
  const ctx = await setup();
  try {
    const r = await req(ctx.base, 'wrong-token', 'GET', '/boss/stock');
    assert.equal(r.status, 401);
  } finally {
    await teardown(ctx);
  }
});

test('GET/POST /boss/stock/:code/restock and /adjust', async () => {
  const ctx = await setup();
  try {
    let r = await req(ctx.base, ctx.token, 'POST', '/boss/stock/A/restock', { qty: 20, note: 'opening stock' });
    assert.equal(r.status, 200);
    assert.equal(r.body.stock.total, 20);

    r = await req(ctx.base, ctx.token, 'GET', '/boss/stock');
    assert.equal(r.status, 200);
    assert.ok(r.body.stock.find((s) => s.code === 'A' && s.total === 20));

    r = await req(ctx.base, ctx.token, 'POST', '/boss/stock/A/adjust', { delta: -5, note: 'breakage' });
    assert.equal(r.status, 200);
    assert.equal(r.body.stock.total, 15);

    r = await req(ctx.base, ctx.token, 'POST', '/boss/stock/A/adjust', { delta: 0 });
    assert.equal(r.status, 400);
  } finally {
    await teardown(ctx);
  }
});

test('PUT /boss/driverPay updates the Bonus rate and persists it to config.json on disk', async () => {
  const ctx = await setup();
  try {
    let r = await req(ctx.base, ctx.token, 'GET', '/boss/driverPay');
    assert.equal(r.body.driverPay.firstItemBonus, 5);

    r = await req(ctx.base, ctx.token, 'PUT', '/boss/driverPay', { firstItemBonus: 6, extraItemBonus: 3 });
    assert.equal(r.status, 200);
    assert.equal(r.body.driverPay.firstItemBonus, 6);
    assert.equal(ctx.app.engine.config.driverPay.firstItemBonus, 6, 'engine.config is the single source of truth - same object updated');

    const onDisk = JSON.parse(fs.readFileSync(path.join(ctx.dataDir, 'config.json'), 'utf8'));
    assert.equal(onDisk.driverPay.firstItemBonus, 6, 'persisted so a restart keeps the new rate');

    r = await req(ctx.base, ctx.token, 'PUT', '/boss/driverPay', { firstItemBonus: -1, extraItemBonus: 3 });
    assert.equal(r.status, 400);
  } finally {
    await teardown(ctx);
  }
});

test('POST /boss/loyalty/:phone/adjust', async () => {
  const ctx = await setup();
  try {
    const phone = '+447700930001';
    let r = await req(ctx.base, ctx.token, 'POST', `/boss/loyalty/${encodeURIComponent(phone)}/adjust`, { delta: 15, note: 'goodwill' });
    assert.equal(r.status, 200);
    assert.equal(r.body.points, 15);
    r = await req(ctx.base, ctx.token, 'GET', `/boss/loyalty/${encodeURIComponent(phone)}`);
    assert.equal(r.body.points, 15);
  } finally {
    await teardown(ctx);
  }
});

test('GET /boss/rewards lists free-item referral rewards', async () => {
  const ctx = await setup();
  try {
    const r = await req(ctx.base, ctx.token, 'GET', '/boss/rewards');
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.freeItemRewards, []);
  } finally {
    await teardown(ctx);
  }
});

test('GET /boss/debts/:phone/summary and POST /boss/debts/:id/adjust', async () => {
  const ctx = await setup();
  try {
    const phone = '+447700930002';
    await req(ctx.base, ctx.token, 'POST', '/sms/inbound', { from: phone, text: '1 item a BS48 1AB', messageId: 'm1' });
    await new Promise((r) => setTimeout(r, 80));

    const summaryBefore = await req(ctx.base, ctx.token, 'GET', `/boss/debts/${encodeURIComponent(phone)}/summary`);
    assert.equal(summaryBefore.body.summary.openCount, 0);
  } finally {
    await teardown(ctx);
  }
});

test('GET /boss/cash and POST /boss/drivers/:id/cash/adjust', async () => {
  const ctx = await setup();
  try {
    ctx.app.engine.registerDriver('D1');
    ctx.app.engine.state.drivers.D1.cash.held = 100;

    let r = await req(ctx.base, ctx.token, 'GET', '/boss/cash');
    assert.equal(r.status, 200);
    assert.equal(r.body.limit, 250);
    assert.ok(r.body.drivers.find((d) => d.driverId === 'D1' && d.held === 100));

    r = await req(ctx.base, ctx.token, 'POST', '/boss/drivers/D1/cash/adjust', { delta: -100, note: 'banked' });
    assert.equal(r.status, 200);
    assert.equal(r.body.cash.held, 0);

    r = await req(ctx.base, ctx.token, 'POST', '/boss/drivers/D1/cash/adjust', { delta: -10, note: 'oops' });
    assert.equal(r.status, 400);
  } finally {
    await teardown(ctx);
  }
});

test('POST /boss/drivers/:id/stock loads driver stock via the existing engine ledger', async () => {
  const ctx = await setup();
  try {
    ctx.app.engine.registerDriver('D1');
    const r = await req(ctx.base, ctx.token, 'POST', '/boss/drivers/D1/stock', { code: 'A', qty: 4 });
    assert.equal(r.status, 200);
    assert.equal(r.body.held, 4);
    assert.equal(ctx.app.engine.state.drivers.D1.stock.A, 4);
  } finally {
    await teardown(ctx);
  }
});
