'use strict';

/*
 * End-to-end proof for the Signal adapter: a mocked signal-cli JSON-RPC
 * daemon (a real TCP server speaking the documented newline-delimited
 * protocol - see test/signalCliClient.test.js and
 * signal/signalCliClient.js's own header comment) on one side, and a REAL
 * server/index.js + engine on the other, with the adapter driving real
 * traffic between them - not a mock of the adapter itself.
 *
 * This is NOT a test against a real signal-cli process (that's still open,
 * see docs/SIGNAL_INTEGRATION.md) - it verifies the adapter does what it
 * claims against the documented signal-cli JSON-RPC contract.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const net = require('net');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../server/index');
const { createSignalAdapter } = require('../signal/adapter');

// The gateway token /driver/* now requires (see server/index.js's
// gatewayTokenOk). These tests use the real data/config.json (no dataDir
// override), so this is the same placeholder value that ships there.
const GATEWAY_TOKEN = require('../data/config.json').gateway.token;

function req(base, method, url, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + url, {
      method,
      headers: Object.assign(
        { 'X-Gateway-Token': GATEWAY_TOKEN },
        data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}
      ),
    }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => { try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); } catch (e) { reject(e); } });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

/**
 * A minimal stand-in for `signal-cli daemon --tcp`: one real TCP
 * connection speaking newline-delimited JSON-RPC 2.0. `pushReceive` writes
 * an unsolicited "receive" notification (what a real incoming Signal
 * message looks like over this protocol); `sent` records every "send"
 * request the adapter makes, in the daemon's own wire shape.
 */
function makeMockSignalCliDaemon() {
  const state = { sent: [], connection: null, failSend: false, nextSendTimestamp: 5000000 };
  const server = net.createServer((sock) => {
    state.connection = sock;
    sock.setEncoding('utf8');
    let buffer = '';
    sock.on('data', (chunk) => {
      buffer += chunk;
      let idx;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 1);
        if (!line.trim()) continue;
        const msg = JSON.parse(line);
        if (msg.method === 'send') {
          // A distinct, deterministic, test-readable timestamp per send -
          // Date.now() risks two sends landing in the same millisecond,
          // which would make the quoted-reply tests ambiguous about which
          // send a recorded timestamp actually belongs to.
          const ts = state.nextSendTimestamp++;
          state.sent.push({ recipient: msg.params.recipient, message: msg.params.message, account: msg.params.account, timestamp: ts });
          const response = state.failSend
            ? { jsonrpc: '2.0', id: msg.id, error: { code: -1, message: 'simulated send failure' } }
            : { jsonrpc: '2.0', id: msg.id, result: { timestamp: ts } };
          sock.write(JSON.stringify(response) + '\n');
        }
      }
    });
  });
  state.pushReceive = (envelope) => {
    state.connection.write(JSON.stringify({ jsonrpc: '2.0', method: 'receive', params: { envelope } }) + '\n');
  };
  return { server, state };
}

async function setup() {
  const statePath = path.join(os.tmpdir(), `rocket-signal-${Date.now()}-${Math.random().toString(36).slice(2)}.json`);
  const app = createApp({ statePath, burstWindowMs: 50, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const rocketPort = app.server.address().port;
  const rocketApiBase = `http://127.0.0.1:${rocketPort}`;

  const { server: daemonServer, state: daemonState } = makeMockSignalCliDaemon();
  await new Promise((resolve) => daemonServer.listen(0, resolve));
  const daemonPort = daemonServer.address().port;

  const logs = [];
  const adapter = createSignalAdapter({
    signalCliHost: '127.0.0.1', signalCliPort: daemonPort, rocketApiBase, rocketApiToken: GATEWAY_TOKEN,
    log: (m) => logs.push(m),
  });
  await adapter.connect(); // real connection established before any test pushes a "receive" notification into it

  return {
    app, rocketApiBase, daemonState, daemonServer, adapter, logs,
    async cleanup() {
      adapter.stop();
      app.stop();
      await new Promise((r) => app.server.close(r));
      await new Promise((r) => daemonServer.close(r));
      if (fs.existsSync(statePath)) fs.unlinkSync(statePath);
      if (fs.existsSync(statePath + '.tmp')) fs.unlinkSync(statePath + '.tmp');
    },
  };
}

test('an inbound Signal message from a driver is forwarded and processed by the real engine', async () => {
  const ctx = await setup();
  try {
    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550001111' });

    ctx.daemonState.pushReceive({
      source: '+15550001111', sourceNumber: '+15550001111', sourceName: 'Dave',
      sourceDevice: 1, timestamp: 1700000000000,
      dataMessage: { timestamp: 1700000000000, message: 'ON', expiresInSeconds: 0 },
    });
    await new Promise((r) => setTimeout(r, 30)); // let the notification arrive over the socket

    const result = await ctx.adapter.pollInboundOnce();
    assert.equal(result.received, 1);
    assert.equal(result.errors, 0);
    assert.equal(ctx.app.engine.state.drivers['+15550001111'].onDuty, true, 'the real engine should have processed ON');
  } finally {
    await ctx.cleanup();
  }
});

test('a non-text envelope (receipt, typing indicator, sync message) is skipped, not treated as an error', async () => {
  const ctx = await setup();
  try {
    ctx.daemonState.pushReceive({ source: '+15550002222', timestamp: 1, receiptMessage: { when: 1 } });
    ctx.daemonState.pushReceive({ source: '+15550002222', timestamp: 2, typingMessage: { action: 'STARTED' } });
    await new Promise((r) => setTimeout(r, 30));
    const result = await ctx.adapter.pollInboundOnce();
    assert.equal(result.received, 0);
    assert.equal(result.errors, 0);
  } finally {
    await ctx.cleanup();
  }
});

test('an outgoing driver message is sent via signal-cli\'s JSON-RPC "send" method with the documented request shape, then acked', async () => {
  const ctx = await setup();
  try {
    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550003333' });
    // ON itself queues a reply too ("You're ON duty") - HELP queues a second.
    await req(ctx.rocketApiBase, 'POST', '/driver/inbound', { driverId: '+15550003333', text: 'ON', messageId: 'm1' });
    await req(ctx.rocketApiBase, 'POST', '/driver/inbound', { driverId: '+15550003333', text: 'HELP', messageId: 'm2' });

    const result = await ctx.adapter.pollOutboundOnce();
    assert.equal(result.sent, 2);
    assert.equal(ctx.daemonState.sent.length, 2);
    const helpMsg = ctx.daemonState.sent.find((s) => s.message === ctx.app.engine.msg.driver_help);
    assert.deepEqual(helpMsg.recipient, ['+15550003333']);
    assert.equal(helpMsg.message, ctx.app.engine.msg.driver_help);

    // Acked, not left pending.
    const pendingAfter = await req(ctx.rocketApiBase, 'GET', '/driver/outbound/pending');
    assert.equal(pendingAfter.body.messages.length, 0);
  } finally {
    await ctx.cleanup();
  }
});

test('a failed Signal send is acked as failed (not resent), and the engine flags it for review', async () => {
  const ctx = await setup();
  try {
    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550004444' });
    await req(ctx.rocketApiBase, 'POST', '/driver/inbound', { driverId: '+15550004444', text: 'HELP', messageId: 'm1' });

    ctx.daemonState.failSend = true;
    const result = await ctx.adapter.pollOutboundOnce();
    assert.equal(result.sent, 0);
    assert.equal(result.errors, 1);

    // Not left pending forever, and not silently dropped either - the
    // engine's own ack handling marks it failed, which the next tick()
    // turns into a review flag (see engine.js ackOutbox).
    const failed = ctx.app.engine.state.outbox.filter((m) => m.status === 'failed');
    assert.equal(failed.length, 1);
  } finally {
    await ctx.cleanup();
  }
});

test('Signal retry/duplicate handling: a redelivered envelope (Signal\'s own retry) with the same timestamp does not re-process', async () => {
  const ctx = await setup();
  try {
    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550006666' });

    const envelope = { source: '+15550006666', sourceNumber: '+15550006666', timestamp: 42, dataMessage: { timestamp: 42, message: 'ON' } };
    ctx.daemonState.pushReceive(envelope);
    await new Promise((r) => setTimeout(r, 30));
    let result = await ctx.adapter.pollInboundOnce();
    assert.equal(result.received, 1);
    assert.equal(ctx.app.engine.state.drivers['+15550006666'].onDuty, true);

    // Signal itself redelivers the exact same envelope (same source +
    // timestamp) - a real, documented behaviour, not a test artifact. The
    // adapter derives the same messageId both times, so the engine's own
    // firstSeen() dedup (already tested in test/engine.test.js) rejects the
    // second delivery as a duplicate rather than reprocessing it.
    await req(ctx.rocketApiBase, 'POST', '/driver/inbound', { driverId: '+15550006666', text: 'OFF', messageId: 'unrelated' }); // sanity: driver can still act
    ctx.daemonState.pushReceive(envelope);
    await new Promise((r) => setTimeout(r, 30));
    result = await ctx.adapter.pollInboundOnce();
    // The forward to /driver/inbound still succeeds (still HTTP 202/200,
    // "received" from the adapter's point of view) - the engine is what
    // recognises the duplicate and no-ops it, which is what actually matters.
    assert.equal(result.received, 1);
    assert.equal(result.errors, 0);
  } finally {
    await ctx.cleanup();
  }
});

test('a full round trip: driver texts ACCEPT over Signal, customer gets the assignment message, driver reply is sent back over Signal', async () => {
  const ctx = await setup();
  try {
    // Real order via the SMS side of the same running server.
    await req(ctx.rocketApiBase, 'POST', '/sms/inbound', { from: '+447700900555', text: '2 item b BS48 1AB', messageId: 'c-1' });
    await new Promise((r) => setTimeout(r, 100));

    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550005555' });
    ctx.daemonState.pushReceive({ source: '+15550005555', timestamp: 1, dataMessage: { timestamp: 1, message: 'ON' } });
    await new Promise((r) => setTimeout(r, 30));
    await ctx.adapter.pollInboundOnce();

    const offer = ctx.app.engine.state.outbox.find((m) => m.channel === 'driver' && m.text.startsWith('JOB'));
    assert.ok(offer, 'driver should have been offered the order after coming ON duty');
    const orderId = offer.text.match(/JOB (R\d{4})/)[1];

    ctx.daemonState.pushReceive({ source: '+15550005555', timestamp: 2, dataMessage: { timestamp: 2, message: `ACCEPT ${orderId}` } });
    await new Promise((r) => setTimeout(r, 30));
    await ctx.adapter.pollInboundOnce();
    assert.equal(ctx.app.engine.state.orders[orderId].state, 'ASSIGNED');

    await ctx.adapter.pollOutboundOnce();
    const acceptedReply = ctx.daemonState.sent.find((s) => s.recipient[0] === '+15550005555' && s.message.includes(orderId));
    assert.ok(acceptedReply, `driver should get an "is yours" reply over Signal, got ${JSON.stringify(ctx.daemonState.sent)}`);
  } finally {
    await ctx.cleanup();
  }
});

test('a driver can swipe-to-quote-reply "ACCEPT" with no order id typed, and it resolves to the quoted job offer', async () => {
  const ctx = await setup();
  try {
    await req(ctx.rocketApiBase, 'POST', '/sms/inbound', { from: '+447700900555', text: '1 item a BS48 1AB', messageId: 'q-1' });
    await new Promise((r) => setTimeout(r, 100));

    await req(ctx.rocketApiBase, 'POST', '/driver/register', { id: '+15550009999' });
    ctx.daemonState.pushReceive({ source: '+15550009999', timestamp: 10, dataMessage: { timestamp: 10, message: 'ON' } });
    await new Promise((r) => setTimeout(r, 30));
    await ctx.adapter.pollInboundOnce();

    // The adapter must actually SEND the JOB offer (not just have it
    // queued) for its Signal timestamp to be recorded - this is what
    // rememberSentTimestamp() in signal/adapter.js hooks into.
    await ctx.adapter.pollOutboundOnce();
    const offerSent = ctx.daemonState.sent.find((s) => s.recipient[0] === '+15550009999' && s.message.startsWith('JOB'));
    assert.ok(offerSent, 'the JOB offer should have actually been sent over Signal');
    const orderId = offerSent.message.match(/JOB (R\d{4})/)[1];

    // The driver replies with a bare "ACCEPT" - no order id anywhere in
    // the text - but quotes the JOB offer message. dataMessage.quote.id is
    // the Signal timestamp of the quoted message (signal-cli's documented
    // envelope shape); the mock daemon assigned and returned that exact
    // timestamp when the offer was sent above, exactly as a real signal-cli
    // "send" response would - offerSent.timestamp is that real value.
    ctx.daemonState.pushReceive({
      source: '+15550009999', timestamp: 11,
      dataMessage: { timestamp: 11, message: 'ACCEPT', quote: { id: offerSent.timestamp } },
    });
    await new Promise((r) => setTimeout(r, 100));
    await ctx.adapter.pollInboundOnce();

    assert.equal(
      ctx.app.engine.state.orders[orderId].state, 'ASSIGNED',
      `bare ACCEPT quoting the job offer should have assigned ${orderId}, order is ${JSON.stringify(ctx.app.engine.state.orders[orderId])}`
    );
    assert.equal(ctx.app.engine.state.drivers['+15550009999'].activeOrderId, orderId);
  } finally {
    await ctx.cleanup();
  }
});
