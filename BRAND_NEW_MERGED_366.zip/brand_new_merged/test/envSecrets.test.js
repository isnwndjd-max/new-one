'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createApp } = require('../server');

function withEnv(values, fn) {
  const old = {};
  for (const [k, v] of Object.entries(values)) {
    old[k] = process.env[k];
    if (v == null) delete process.env[k]; else process.env[k] = v;
  }
  try { return fn(); }
  finally {
    for (const [k, v] of Object.entries(old)) {
      if (v == null) delete process.env[k]; else process.env[k] = v;
    }
  }
}

test('runtime environment overrides boss, gateway and GPS secrets without changing config.json', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-env-secrets-'));
  const statePath = path.join(dir, 'state.json');
  const key = '11'.repeat(32);
  withEnv({
    ROCKET_BOSS_TOKEN: 'boss-runtime-secret',
    ROCKET_GATEWAY_TOKEN: 'gateway-runtime-secret',
    ROCKET_GPS_FORWARD_TOKEN: 'gps-runtime-secret',
    ROCKET_STATE_KEY: key,
  }, () => {
    const app = createApp({ statePath });
    try {
      assert.equal(app.config.boss.token, 'boss-runtime-secret');
      assert.equal(app.config.gateway.token, 'gateway-runtime-secret');
      assert.equal(app.config.gps.forwardToken, 'gps-runtime-secret');
      assert.equal(app.store.usingDevFallback, false);
    } finally {
      app.stop();
    }
  });
});

test('invalid ROCKET_STATE_KEY length is rejected before server use', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-bad-state-key-'));
  withEnv({ ROCKET_STATE_KEY: 'abcd' }, () => {
    assert.throws(
      () => createApp({ statePath: path.join(dir, 'state.json') }),
      /ROCKET_STATE_KEY must be 64 hex characters \(32 bytes\)/
    );
  });
});
