'use strict';

/*
 * Tests for the venue-confirmation-count / promotion-candidate mechanism
 * (src/engine.js's _maybeRecordVenueConfirmation, PROMOTION_CONFIRM_THRESHOLD)
 * - built per the user's own gating rules for the Bristol OSM venue
 * enrichment: "Once a new alias has been confirmed reliably, it can be
 * promoted to the verified database so future customers don't need the
 * extra question." This only TRACKS and FLAGS candidates; it never
 * silently flips a venue to ACTIVE live - see scripts/promoteVenues.js
 * for the offline, human-reviewed promotion step.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');

const locationsData = require('../data/locations.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine() {
  const index = new LocationIndex(locationsData);
  return new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => 0 });
}

// Pick a real UNCERTAIN venue from the live data to drive orders through.
const uncertainVenue = locationsData.venues.find((v) => v.status === 'UNCERTAIN' && v.name && v.meetingPoint !== false);

function confirmOrderForVenue(e, phone) {
  e.handleCustomerBurst(phone, [`1 item a ${uncertainVenue.name}`]);
  const draft = Object.values(e.state.orders).slice(-1)[0];
  if (draft.location.proposed) {
    e.handleCustomerBurst(phone, ['yes']);
  }
}

test('confirming the same not-yet-ACTIVE venue across separate orders increments a shared counter', () => {
  assert.ok(uncertainVenue, 'fixture requires at least one UNCERTAIN, meeting-point-eligible venue in the live data');
  const e = makeEngine();
  confirmOrderForVenue(e, '+447700900801');
  const countAfter1 = e.state.venueConfirmations[uncertainVenue.id] || 0;
  assert.ok(countAfter1 >= 1);
  confirmOrderForVenue(e, '+447700900802');
  const countAfter2 = e.state.venueConfirmations[uncertainVenue.id] || 0;
  assert.ok(countAfter2 > countAfter1);
});

test('reaching the promotion threshold adds the venue to promotionCandidates exactly once', () => {
  const e = makeEngine();
  for (let i = 0; i < 4; i += 1) {
    confirmOrderForVenue(e, `+44770090090${i}`);
  }
  const occurrences = e.state.promotionCandidates.filter((id) => id === uncertainVenue.id).length;
  assert.equal(occurrences, 1);
});

test('an already-ACTIVE venue is never counted (it never needed confirming to begin with)', () => {
  const activeVenue = locationsData.venues.find((v) => v.status === 'ACTIVE');
  assert.ok(activeVenue);
  const e = makeEngine();
  e.handleCustomerBurst('+447700900810', [`1 item a ${activeVenue.name}`]);
  assert.equal(e.state.venueConfirmations[activeVenue.id], undefined);
});

test('promoteVenues.js dry run reports candidates without changing data/locations.json', () => {
  const { execFileSync } = require('child_process');
  const fs = require('fs');
  const os = require('os');
  const path = require('path');
  const e = makeEngine();
  for (let i = 0; i < 4; i += 1) confirmOrderForVenue(e, `+44770090091${i}`);
  const tmp = path.join(os.tmpdir(), `rocket-promo-test-${Date.now()}.json`);
  fs.writeFileSync(tmp, JSON.stringify(e.state));
  const before = fs.readFileSync(path.join(__dirname, '..', 'data', 'locations.json'), 'utf8');
  const out = execFileSync('node', [path.join(__dirname, '..', 'scripts', 'promoteVenues.js'), tmp]).toString();
  const after = fs.readFileSync(path.join(__dirname, '..', 'data', 'locations.json'), 'utf8');
  assert.equal(before, after); // dry run must not touch the live file
  assert.match(out, /promotion candidate/);
  fs.unlinkSync(tmp);
});
