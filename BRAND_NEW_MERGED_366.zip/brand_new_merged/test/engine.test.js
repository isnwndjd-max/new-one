'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');

const index = new LocationIndex(require('../data/locations.json'));
// The real engine only ever loads the synced projection, never the Boss
// app's master menu (see src/menuSync.js) - testing against anything else
// would drift from what actually runs.
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function outboxFor(e, phone) {
  return e.state.outbox.filter((m) => m.to === phone).map((m) => m.text);
}
function driverOutbox(e, id) {
  return e.state.outbox.filter((m) => m.to === id).map((m) => m.text);
}
function fullOrder(e, phone, texts) {
  e.handleCustomerBurst(phone, texts);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}

test('greeting is sent once, not on every message', () => {
  const e = makeEngine();
  e.handleCustomerBurst('+447700900001', ['hi']);
  e.handleCustomerBurst('+447700900001', ['hi again']);
  const menuMsgs = outboxFor(e, '+447700900001').filter((t) => t.includes('Cash only'));
  assert.equal(menuMsgs.length, 1);
});

test('order + real postcode confirms with an exact total', () => {
  const e = makeEngine();
  // 2 x item b only, no bundle or tier applies to this combination
  const order = fullOrder(e, '+447700900002', ['2 item b BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.total, 30); // 2 x £15.00
  assert.ok(outboxFor(e, '+447700900002').some((t) => t.includes('£30.00')));
  assert.equal(order.location.confirmed.postcode, 'BS48 1AB');
});

test('a mixed order that DOES qualify for a bundle picks the cheaper price, not the naive sum', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900026', ['2 item a and 1 item b BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.total, 30); // bundle price beats 2x10 + 15 = 35
});

test('bundle pricing is used instead of naive per-item sum', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900003', ['2 item a and 1 item b, BS48 1AB']);
  assert.equal(order.total, 30); // bundle price, cheaper than 35
});

test('unresolved location asks once and does not repeat the same question', () => {
  const e = makeEngine();
  e.handleCustomerBurst('+447700900004', ['2 item a']);
  const id = e.state.activeByPhone['+447700900004'];
  const before = outboxFor(e, '+447700900004').length;
  e.handleCustomerBurst('+447700900004', ['somewhere vague']);
  e.handleCustomerBurst('+447700900004', ['somewhere else vague']);
  const order = e.state.orders[id];
  assert.equal(order.state, 'DRAFT');
  // still just one location question queued (the ask_location one), not one per message
  const asks = outboxFor(e, '+447700900004').slice(before);
  assert.ok(asks.length <= 1, `expected at most 1 new message, got ${asks.length}: ${JSON.stringify(asks)}`);
});

test('unknown item code is flagged for review, never guessed or priced', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900005', ['1 item a BS48 1AB']);
  order.items = [{ code: 'ZZZ', qty: 1 }];
  order.state = 'DRAFT';
  order.location.confirmed = { type: 'postcode', name: 'BS48 1AB', postcode: 'BS48 1AB' };
  e._confirm(order);
  assert.notEqual(order.state, 'CONFIRMED');
  assert.ok(e.state.review.some((r) => r.orderId === order.id));
});

test('draft expires after the configured timeout, assigned orders never do', () => {
  const e = makeEngine();
  // item only, no location yet: stays in DRAFT so the timeout applies
  const order = fullOrder(e, '+447700900006', ['1 item a']);
  assert.equal(order.state, 'DRAFT');
  e.advance(31 * 60000);
  e.tick();
  assert.equal(e.state.orders[order.id].state, 'EXPIRED');

  const e2 = makeEngine();
  const o2 = fullOrder(e2, '+447700900007', ['1 item a BS48 1AB']);
  e2.registerDriver('D1');
  e2.handleDriverMessage('D1', 'ON');
  e2.handleDriverMessage('D1', `ACCEPT ${o2.id}`);
  assert.equal(e2.state.orders[o2.id].state, 'ASSIGNED');
  e2.advance(999 * 60000);
  e2.tick();
  assert.equal(e2.state.orders[o2.id].state, 'ASSIGNED');
});

test('a later "I will be 10 minutes" does not replace the confirmed meeting point', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900008', ['1 item a BS48 1AB']);
  const before = JSON.stringify(order.location.confirmed);
  e.handleCustomerBurst('+447700900008', ["I'll be 10 minutes"]);
  assert.equal(JSON.stringify(order.location.confirmed), before);
});

test('first driver ACCEPT wins; the second is told the job is taken, not duplicated', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900009', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.registerDriver('D2');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D2', 'ON');
  const r1 = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  const r2 = e.handleDriverMessage('D2', `ACCEPT ${order.id}`);
  assert.equal(r1.ok, true);
  assert.equal(r2.ok, false);
  assert.equal(order.driverId, 'D1');
  assert.ok(driverOutbox(e, 'D2').some((t) => t.includes('taken')));
});

test('a duplicate ACCEPT from the same driver does not double-assign', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900010', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  const r2 = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(r2.duplicate, true);
  assert.equal(order.driverId, 'D1');
});

test('a command with no order id is rejected rather than guessing the active job', () => {
  const e = makeEngine();
  fullOrder(e, '+447700900011', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  const r = e.handleDriverMessage('D1', 'HERE');
  assert.equal(r.ok, false);
});

test('a command for an order that is not the driver\'s own is rejected', () => {
  const e = makeEngine();
  const o1 = fullOrder(e, '+447700900012', ['1 item a BS48 1AB']);
  const o2 = fullOrder(e, '+447700900013', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.registerDriver('D2');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D2', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${o1.id}`);
  e.handleDriverMessage('D2', `ACCEPT ${o2.id}`);
  const r = e.handleDriverMessage('D2', `HERE ${o1.id}`);
  assert.equal(r.ok, false);
});

test('COMPLETE sent twice only completes once, and referral/points are not doubled', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900014', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const pointsAfterFirst = e.state.customers['+447700900014'].points;
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  assert.equal(e.state.customers['+447700900014'].points, pointsAfterFirst);
  const completions = outboxFor(e, '+447700900014').filter((t) => t.includes('referral code')).length;
  assert.equal(completions, 1);
});

test('ETA / arrival / assigned / completed messages each fire exactly once', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900015', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id} 12`);
  e.handleDriverMessage('D1', `ACCEPT ${order.id} 12`); // duplicate, ignored
  e.handleDriverMessage('D1', `EN ROUTE ${order.id}`);
  e.handleDriverMessage('D1', `HERE ${order.id}`);
  e.handleDriverMessage('D1', `HERE ${order.id}`); // duplicate
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const outbound = outboxFor(e, '+447700900015');
  for (const phrase of ['ETA about 12', 'arrived', 'referral code']) {
    assert.equal(outbound.filter((t) => t.includes(phrase)).length, 1, `"${phrase}" should appear once`);
  }
});

test('cancelling a drafted order (no driver yet) sends no driver message', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900016', ['1 item a']);
  e.handleCustomerBurst('+447700900016', ['cancel']);
  assert.equal(order.state, 'CANCELLED');
  assert.equal(e.state.outbox.filter((m) => m.channel === 'driver').length, 0);
});

test('cancelling after a driver is assigned is flagged, not silently applied', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900017', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleCustomerBurst('+447700900017', ['cancel']);
  assert.equal(order.state, 'ASSIGNED');
  assert.ok(e.state.review.some((r) => r.orderId === order.id));
});

test('a debt reminder fires once, after the configured number of days, not before', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900018', ['1 item a BS48 1AB']); // total 10
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id} PAID 4`); // owes 6
  e.advance(6 * 86400000);
  e.tick();
  assert.equal(outboxFor(e, '+447700900018').filter((t) => t.includes('still owed')).length, 0);
  e.advance(2 * 86400000);
  e.tick();
  e.tick();
  assert.equal(outboxFor(e, '+447700900018').filter((t) => t.includes('still owed')).length, 1);
});

test('self-referral is rejected', () => {
  const e = makeEngine();
  const o1 = fullOrder(e, '+447700900019', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${o1.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o1.id}`);
  const code = Object.keys(e.state.referralCodes)[0];

  const o2 = fullOrder(e, '+447700900019', [`use code ${code} 1 item a BS48 1AB`]);
  assert.equal(o2.referralCode, null);
});

test('a referral code cannot be redeemed twice', () => {
  const e = makeEngine();
  const o1 = fullOrder(e, '+447700900020', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${o1.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o1.id}`);
  const code = Object.keys(e.state.referralCodes)[0];

  const o2 = fullOrder(e, '+447700900021', [`${code} 1 item a BS48 1AB`]);
  e.registerDriver('D2');
  e.handleDriverMessage('D2', 'ON');
  e.handleDriverMessage('D2', `ACCEPT ${o2.id}`);
  e.handleDriverMessage('D2', `COMPLETE ${o2.id}`);
  const referrerPoints = e.state.customers['+447700900020'].points;

  const o3 = fullOrder(e, '+447700900022', [`${code} 1 item a BS48 1AB`]);
  assert.equal(o3.referralCode, null); // already redeemed
  e.registerDriver('D3');
  e.handleDriverMessage('D3', 'ON');
  e.handleDriverMessage('D3', `ACCEPT ${o3.id}`);
  e.handleDriverMessage('D3', `COMPLETE ${o3.id}`);
  assert.equal(e.state.customers['+447700900020'].points, referrerPoints); // not rewarded again
});

test('a postcode outside the four covered districts is flagged for a person, not silently accepted', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900023', ['1 item a BS1 1AA']);
  assert.equal(order.state, 'DRAFT');
  assert.ok(e.state.review.some((r) => r.orderId === order.id && r.reason.includes('outside')));
});

test('a real terminated postcode is not accepted as a delivery point', () => {
  const e = makeEngine();
  const data = require('../data/locations.json');
  const terminated = Object.keys(data.terminatedPostcodes)[0];
  const order = fullOrder(e, '+447700900024', [`1 item a ${terminated}`]);
  assert.equal(order.location.confirmed, null);
});

test('duplicate inbound message id does not process the burst twice', () => {
  const e = makeEngine();
  assert.equal(e.firstSeen('msg-1'), true);
  assert.equal(e.firstSeen('msg-1'), false);
  assert.equal(e.firstSeen('msg-2'), true);
});

test('state survives a save/reload round trip with in-flight orders intact', () => {
  const os = require('node:os');
  const path = require('node:path');
  const fs = require('node:fs');
  const { Store } = require('../src/store');

  const e = makeEngine();
  const order = fullOrder(e, '+447700900025', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  const file = path.join(os.tmpdir(), `rocket-test-${Date.now()}.json`);
  const store = new Store(file);
  store.save(e.state);
  const reloaded = store.load(emptyEngineState);
  assert.equal(reloaded.orders[order.id].state, 'ASSIGNED');
  assert.equal(reloaded.orders[order.id].driverId, 'D1');
  fs.unlinkSync(file);
});

test('a corrupt state file is refused, not silently loaded as empty', () => {
  const os = require('node:os');
  const path = require('node:path');
  const fs = require('node:fs');
  const { Store } = require('../src/store');
  const file = path.join(os.tmpdir(), `rocket-corrupt-${Date.now()}.json`);
  fs.writeFileSync(file, '{not valid json');
  const store = new Store(file);
  assert.throws(() => store.load(emptyEngineState), /corrupt/);
  fs.unlinkSync(file);
  const backups = fs.readdirSync(os.tmpdir()).filter((f) => f.startsWith(path.basename(file) + '.corrupt-'));
  for (const b of backups) fs.unlinkSync(path.join(os.tmpdir(), b));
});

// ------------------------------------------------------------- gps / traccar

test('driver location updates via a linked Traccar device, and unknown devices are ignored', () => {
  const e = makeEngine();
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });

  const ignored = e.updateDriverLocation({ uniqueId: 'SOME-OTHER-PHONE', lat: 51.4, lng: -2.7, valid: true });
  assert.equal(ignored.ok, false);
  assert.equal(e.state.drivers.D1.location, null);

  const applied = e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.4308, lng: -2.7626, speedKph: 22, course: 90, valid: true });
  assert.equal(applied.ok, true);
  assert.equal(applied.driverId, 'D1');
  assert.equal(e.state.drivers.D1.location.lat, 51.4308);
  assert.equal(e.state.drivers.D1.locationAt, 0);
});

test('an invalid GPS fix is recorded as a non-event, not applied as a position', () => {
  const e = makeEngine();
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  const r = e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 0, lng: 0, valid: false });
  assert.equal(r.ok, true);
  assert.equal(r.applied, false);
  assert.equal(e.state.drivers.D1.location, null);
});

test('liveTracking gives a distance and ETA once the assigned driver has a real fix near the destination', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900050', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  assert.equal(e.liveTracking(order.id), null); // accepted, but no GPS fix yet

  // A few hundred metres from BS48 1AB (51.435121, -2.754996), driving.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.4370, lng: -2.7550, speedKph: 30, valid: true });
  const snap = e.liveTracking(order.id);
  assert.equal(snap.driverId, 'D1');
  assert.ok(snap.distanceMetres > 0 && snap.distanceMetres < 1000, `expected a short distance, got ${snap.distanceMetres}`);
  assert.ok(snap.etaMinutes >= 0 && snap.etaMinutes < 10);
  assert.equal(snap.staleSeconds, 0);
});

test('a driver GPS going stale mid-delivery is flagged for review exactly once', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900051', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.437, lng: -2.755, speedKph: 20, valid: true });

  e.tick(); // fresh fix: nothing GPS-related flagged yet (order was briefly driverless before ON, that's a separate flag)
  assert.equal(e.state.review.filter((r) => !r.resolved && /GPS/.test(r.reason)).length, 0);

  e.advance(9 * 60000); // past the 8-minute staleAfterMinutes default with no new fix
  e.tick();
  e.tick(); // a second tick must not double-flag the same staleness
  const flags = e.state.review.filter((r) => !r.resolved && /GPS/.test(r.reason));
  assert.equal(flags.length, 1);
});

test('a driver never linked to a GPS device is not flagged as having stale GPS', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900052', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave'); // no traccarId
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  e.advance(20 * 60000);
  e.tick();
  const flags = e.state.review.filter((r) => !r.resolved && /GPS/.test(r.reason));
  assert.equal(flags.length, 0);
});

test('re-linking a Traccar device to a different driver removes the old mapping', () => {
  const e = makeEngine();
  e.registerDriver('D1', 'Dave');
  e.registerDriver('D2', 'Sam');
  e.linkTraccarDevice('D1', 'SHARED-PHONE');
  e.linkTraccarDevice('D2', 'SHARED-PHONE');
  assert.equal(e.state.driversByTraccarId['SHARED-PHONE'], 'D2');
  const r = e.updateDriverLocation({ uniqueId: 'SHARED-PHONE', lat: 51.43, lng: -2.75, valid: true });
  assert.equal(r.driverId, 'D2');
  assert.equal(e.state.drivers.D1.location, null);
});

// ----------------------------------------------------- independent-review fixes

test('attaching a second referral code releases the first one instead of orphaning it', () => {
  const e = makeEngine();
  const o1 = fullOrder(e, '+447700900060', ['1 item a BS48 1AB']);
  e.registerDriver('D1'); e.handleDriverMessage('D1', 'ON'); e.handleDriverMessage('D1', `ACCEPT ${o1.id}`); e.handleDriverMessage('D1', `COMPLETE ${o1.id}`);
  const codeA = Object.keys(e.state.referralCodes)[0];

  const o2 = fullOrder(e, '+447700900061', ['1 item a BS48 1AB']);
  e.registerDriver('D2'); e.handleDriverMessage('D2', 'ON'); e.handleDriverMessage('D2', `ACCEPT ${o2.id}`); e.handleDriverMessage('D2', `COMPLETE ${o2.id}`);
  const codeB = Object.keys(e.state.referralCodes).find((c) => c !== codeA);

  // Attach codeA first (order still DRAFT - no items/location yet), then swap
  // to codeB in the same message that completes the order.
  e.handleCustomerBurst('+447700900062', [codeA]);
  const orderId = e.state.activeByPhone['+447700900062'];
  assert.equal(e.state.orders[orderId].referralCode, codeA);
  assert.equal(e.state.referralCodes[codeA].usedByOrder, orderId);

  e.handleCustomerBurst('+447700900062', [`${codeB} 1 item a BS48 1AB`]);
  const order = e.state.orders[orderId];
  assert.equal(order.referralCode, codeB);
  assert.equal(e.state.referralCodes[codeB].usedByOrder, orderId);
  assert.equal(e.state.referralCodes[codeA].usedByOrder, null, 'the first code must be released, not orphaned');
});

test('mentioning the confirmed venue again after confirmation does not spuriously flag for review', () => {
  const e = makeEngine();
  // "The Bridge Inn" (Yatton) is status ACTIVE in the research data, so a
  // strong multi-word name match auto-resolves - see
  // locationConversation.test.js for the UNCERTAIN-venue path this test is
  // deliberately not exercising.
  const order = fullOrder(e, '+447700900063', ['1 item a the bridge inn yatton']);
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.location.confirmed.name, 'The Bridge Inn');
  const before = e.state.review.filter((r) => !r.resolved).length;

  e.handleCustomerBurst('+447700900063', ['still at the bridge inn, is he close']);
  const after = e.state.review.filter((r) => !r.resolved).length;
  assert.equal(after, before, 'mentioning the same confirmed venue again must not be treated as a location change');
});

test('a genuinely different location sent after confirmation is still flagged for review', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900064', ['1 item a the bridge inn yatton']);
  assert.equal(order.state, 'CONFIRMED');
  const before = e.state.review.filter((r) => !r.resolved).length;

  e.handleCustomerBurst('+447700900064', ['actually meet me at BS48 1AB instead']);
  const after = e.state.review.filter((r) => !r.resolved).length;
  assert.equal(after, before + 1);
});

test('a shared-pin meeting point is flagged for a human to glance at, but the order still proceeds', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900065', ['1 item a 51.4308,-2.7626']);
  assert.equal(order.state, 'CONFIRMED', 'a pin does not block the order - there is no proof it is outside the area either');
  const flags = e.state.review.filter((r) => !r.resolved && /pin/.test(r.reason));
  assert.equal(flags.length, 1);
});

test('GPS staleness is measured from acceptance, not from when the order was first offered', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900066', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');

  e.advance(7 * 60000); // order sits OFFERED for 7 minutes before anyone accepts
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.tick(); // must NOT immediately flag - the driver just accepted, offeredAt is stale but assignedAt is now
  const flagsRightAfterAccept = e.state.review.filter((r) => !r.resolved && /GPS/.test(r.reason));
  assert.equal(flagsRightAfterAccept.length, 0, 'a driver who just accepted must not be penalised for how long the offer itself sat unaccepted');

  e.advance(9 * 60000); // now genuinely 9 minutes since acceptance with no GPS fix
  e.tick();
  const flagsAfterRealStaleness = e.state.review.filter((r) => !r.resolved && /GPS/.test(r.reason));
  assert.equal(flagsAfterRealStaleness.length, 1);
});

// ------------------------------------------------- automatic GPS 5-min / HERE

test('a GPS fix close enough to imply a ~5 minute ETA auto-sends the same message as a driver texting 5 MIN', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900070', ['1 item a BS48 1AB']); // BS48 1AB: 51.435121,-2.754996
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(e.state.orders[order.id].state, 'ASSIGNED');

  // A few hundred metres away at a plausible driving speed - well under the
  // default 5-minute-ETA threshold.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.4370, lng: -2.7550, speedKph: 30, valid: true });

  assert.equal(e.state.orders[order.id].state, 'EN_ROUTE');
  assert.ok(outboxFor(e, '+447700900070').some((t) => t.includes('5 minutes away')));
});

test('the automatic 5-minute message and a manual 5 MIN command never both send', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900071', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.4370, lng: -2.7550, speedKph: 30, valid: true });
  e.handleDriverMessage('D1', `5 MIN ${order.id}`); // driver also texts it manually moments later

  // Exact match, not .includes(): "A driver has accepted..." also contains
  // the substring "5 minutes away" as part of a different, earlier message.
  const count = outboxFor(e, '+447700900071').filter((t) => t === messages.five_minutes).length;
  assert.equal(count, 1, 'must not double-send just because both the GPS trigger and the manual command fired');
});

test('a GPS fix inside the arrival radius auto-marks the order ARRIVED and messages the customer', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900072', ['1 item a BS48 1AB']); // 51.435121,-2.754996
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  // ~30m away - well inside the default 120m arrival radius, good accuracy.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.43539, lng: -2.75497, speedKph: 5, accuracy: 15, valid: true });

  assert.equal(e.state.orders[order.id].state, 'ARRIVED');
  assert.ok(outboxFor(e, '+447700900072').some((t) => t.includes('arrived')));
});

test('a low-accuracy GPS fix that happens to compute close by does not auto-trigger arrival', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900073', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  // Close by distance, but a 200m accuracy radius means this fix cannot be
  // trusted to mean "arrived" - a false "your driver is here" is worse than
  // noticing a real arrival a few seconds late.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.43539, lng: -2.75497, speedKph: 5, accuracy: 200, valid: true });

  assert.notEqual(e.state.orders[order.id].state, 'ARRIVED');
  assert.ok(!outboxFor(e, '+447700900073').some((t) => t.includes('arrived')));
});

test('GPS auto-events never fire once the order has already moved past EN_ROUTE (e.g. driver already marked HERE)', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900074', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `HERE ${order.id}`); // driver manually marks arrived first

  const before = outboxFor(e, '+447700900074').length;
  // A GPS fix arriving after HERE was already sent must be a no-op for state/messages.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.43539, lng: -2.75497, speedKph: 5, accuracy: 15, valid: true });
  assert.equal(e.state.orders[order.id].state, 'ARRIVED');
  assert.equal(outboxFor(e, '+447700900074').length, before);
});

test('automatic 5-min/HERE GPS events measure against the final resolved meeting-point coordinates, never re-derived from the postcode at trigger time', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900075', ['1 item a BS48 1AB']); // postcode centroid: 51.435121,-2.754996
  e.registerDriver('D1', 'Dave', { traccarId: 'PHONE-D1' });
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);

  // Move the confirmed meeting point far away from the postcode centroid the
  // order was actually created against - simulating a venue/pin resolution
  // whose exact point differs from its postcode's centroid. If the GPS
  // trigger silently re-looked-up the postcode instead of using
  // order.location.confirmed, a fix next to the ORIGINAL postcode centroid
  // would still fire "arrived"; it must not, because that is no longer
  // where the resolved meeting point is.
  e.state.orders[order.id].location.confirmed = { type: 'venue', name: 'Moved Point', lat: 51.5, lng: -2.9, exactPointKnown: true };

  // A fix right at the OLD postcode centroid, nowhere near the new confirmed point.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.435121, lng: -2.754996, speedKph: 5, accuracy: 15, valid: true });
  assert.notEqual(e.state.orders[order.id].state, 'ARRIVED', 'must not arrive against a stale postcode centroid once the confirmed point has moved');

  // A fix at the NEW confirmed point does trigger it.
  e.updateDriverLocation({ uniqueId: 'PHONE-D1', lat: 51.5, lng: -2.9, speedKph: 5, accuracy: 15, valid: true });
  assert.equal(e.state.orders[order.id].state, 'ARRIVED', 'must arrive against the actual resolved meeting point, wherever it is');
});

// --------------------------------------------------------------- boss app

test('resolveReview marks an open flag resolved exactly once and is idempotent against a wrong id', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900080', ['1 item a 51.4308,-2.7626']); // pin -> auto review flag
  const flag = e.state.review.find((r) => !r.resolved);
  assert.ok(flag);

  assert.equal(e.resolveReview(flag.id, 'checked, fine'), true);
  const after = e.state.review.find((r) => r.id === flag.id);
  assert.equal(after.resolved, true);
  assert.equal(after.resolvedNote, 'checked, fine');

  assert.equal(e.resolveReview(flag.id), false, 'already resolved - cannot resolve twice');
  assert.equal(e.resolveReview('not-a-real-id'), false);
});

test('setMenu updates live pricing immediately and rejects invalid input without changing anything', () => {
  const e = makeEngine();
  const before = fullOrder(e, '+447700900081', ['1 item a BS48 1AB']);
  assert.equal(before.total, 10);

  e.setMenu({
    items: [{ code: 'A', name: 'Item A', aliases: ['item a'], unitPrice: 12.5, tiers: [] }],
    bundles: [],
  });
  const after = fullOrder(e, '+447700900082', ['1 item a BS48 1AB']);
  assert.equal(after.total, 12.5);

  const snapshot = JSON.stringify(e.menu);
  assert.throws(() => e.setMenu({ items: [{ code: 'A', name: 'Item A', unitPrice: -5 }] }), /non-negative/);
  assert.throws(() => e.setMenu({ items: [{ code: 'A' }] }), /name/);
  assert.throws(() => e.setMenu({ bundles: [{ code: 'X', label: 'x', price: 1, contains: { ZZZ: 1 } }], items: e.menu.items }), /unknown item code/);
  assert.equal(JSON.stringify(e.menu), snapshot, 'a rejected update must not partially apply');
});

// ------------------------------------------------ driver isolation / PII

test('a driver can never access, accept, or learn anything about an order already accepted by a different driver', () => {
  const e = makeEngine();
  e.registerDriver('D1', 'Dave');
  e.registerDriver('D2', 'Priya');
  // Both on duty *before* the order exists, so the initial broadcast offer
  // legitimately goes to both of them (that part - being offered an open
  // job - is not what's under test here).
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D2', 'ON');
  const order = fullOrder(e, '+447700900090', ['1 item a BS48 1AB']);
  assert.ok(order.offeredTo.includes('D1'));
  assert.ok(order.offeredTo.includes('D2'));

  // D2 accepts first. From this instant the order belongs to D2 alone, and
  // every command D1 could send about it must be refused - even though D1
  // was legitimately offered the job (and legitimately saw its summary)
  // before D2 accepted it. What's under test is what happens AFTER that:
  // none of D1's post-acceptance refusal replies may leak the order's
  // contents (items, price, meeting point, customer phone) - they only
  // ever echo back the order id the driver themselves typed in.
  const repliesToD1BeforeAccept = driverOutbox(e, 'D1').length;
  let r = e.handleDriverMessage('D2', `ACCEPT ${order.id}`);
  assert.equal(r.ok, true);
  assert.equal(order.driverId, 'D2');

  r = e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(r.ok, false);
  assert.equal(order.driverId, 'D2', 'D1 accepting must never reassign the order to D1');

  for (const cmd of ['EN ROUTE', 'HERE', `COMPLETE`, 'PROBLEM test']) {
    r = e.handleDriverMessage('D1', `${cmd} ${order.id}`.trim());
    assert.equal(r.ok, false, `D1 sending ${cmd} for an order that isn't theirs must be refused`);
  }
  assert.equal(order.state, 'ASSIGNED', 'none of D1\'s attempts should have changed the order at all');

  const repliesToD1AfterAccept = driverOutbox(e, 'D1').slice(repliesToD1BeforeAccept).join(' | ');
  assert.ok(!repliesToD1AfterAccept.includes('BS48'), 'D1 must never see the meeting point of an order that is no longer theirs');
  assert.ok(!repliesToD1AfterAccept.includes('10.00') && !repliesToD1AfterAccept.includes('£10'), 'D1 must never see the price of an order that is no longer theirs');
  assert.ok(!repliesToD1AfterAccept.includes('+447700900090'), 'D1 must never see the customer\'s phone number');
});

test('a driver guessing a real but unrelated order id gets a generic "not yours" reply, never the order\'s details', () => {
  const e = makeEngine();
  const orderA = fullOrder(e, '+447700900091', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave');
  e.registerDriver('D2', 'Priya');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${orderA.id}`);
  assert.equal(orderA.driverId, 'D1');

  e.handleDriverMessage('D2', 'ON');
  const r = e.handleDriverMessage('D2', `HERE ${orderA.id}`); // D2 guesses/knows the id (they're 4 sequential digits) but was never offered it
  assert.equal(r.ok, false);
  assert.notEqual(orderA.state, 'ARRIVED', 'a stranger driver must not be able to move someone else\'s order forward');
  const repliesToD2 = driverOutbox(e, 'D2').join(' | ');
  assert.ok(!repliesToD2.includes('+447700900091'));
  assert.ok(!repliesToD2.includes('BS48'));
});

test('no driver-facing message ever contains a customer phone number, across a full order lifecycle', () => {
  const e = makeEngine();
  const phone = '+447700900092';
  const order = fullOrder(e, phone, ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `5 MIN ${order.id}`);
  e.handleDriverMessage('D1', `HERE ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);

  const allDriverText = e.state.outbox.filter((m) => m.channel === 'driver').map((m) => m.text).join(' | ');
  assert.ok(!allDriverText.includes(phone), 'the customer\'s phone number must never appear in any message sent to a driver');
});

// ---------------------------------------------- post-confirmation silence

test('a post-confirmation item-change request that does not parse as a literal item line still gets a reply, not silence', () => {
  // Found via a live role-play: "add another one of them mucker" after an
  // order was already ASSIGNED went completely silent (no reply, nothing
  // flagged) because parseItems() can't resolve "them"/"mucker" to a real
  // item code. The customer has no way to tell that from a message that
  // never sent at all. ORDER_CHANGE_RE catches the explicit change/addition
  // language even when parseItems finds nothing.
  const e = makeEngine();
  const phone = '+447700900093';
  const order = fullOrder(e, phone, ['3 item a BS48 1AB']);
  assert.equal(order.state, 'CONFIRMED');
  const before = outboxFor(e, phone).length;

  e.handleCustomerBurst(phone, ['add another one of them mucker']);

  const after = outboxFor(e, phone);
  assert.equal(after.length, before + 1, 'the customer must get exactly one reply, not silence');
  assert.ok(after[after.length - 1].includes("can't be changed here"));
  assert.equal(order.items.length, 1, 'the order itself must never change through this path');
  assert.equal(order.items[0].qty, 3);
});

test('a clean item-code post-confirmation change request still gets the same reply (unchanged behaviour)', () => {
  const e = makeEngine();
  const phone = '+447700900094';
  const order = fullOrder(e, phone, ['3 item a BS48 1AB']);
  e.handleCustomerBurst(phone, ['item a 6 of them please']);
  const last = outboxFor(e, phone).slice(-1)[0];
  assert.ok(last.includes("can't be changed here"));
  assert.equal(order.items[0].qty, 3);
});

test('ordinary post-confirmation chit-chat ("thanks", "cheers") still gets no reply - ORDER_CHANGE_RE stays narrow', () => {
  const e = makeEngine();
  const phone = '+447700900095';
  const order = fullOrder(e, phone, ['1 item a BS48 1AB']);
  const before = outboxFor(e, phone).length;
  e.handleCustomerBurst(phone, ['thanks a lot']);
  e.handleCustomerBurst(phone, ['cheers mate']);
  assert.equal(outboxFor(e, phone).length, before, 'idle chat after confirmation must not trigger a reply');
});

test('the same fix applies once a driver is already ASSIGNED, not just CONFIRMED', () => {
  const e = makeEngine();
  const phone = '+447700900096';
  const order = fullOrder(e, phone, ['2 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  assert.equal(order.state, 'ASSIGNED');
  const before = outboxFor(e, phone).length;

  e.handleCustomerBurst(phone, ['can i swap for extra item b instead']);

  const after = outboxFor(e, phone);
  assert.equal(after.length, before + 1);
  assert.ok(after[after.length - 1].includes("can't be changed here"));
  assert.equal(order.items[0].code, 'A');
  assert.equal(order.items[0].qty, 2);
});
