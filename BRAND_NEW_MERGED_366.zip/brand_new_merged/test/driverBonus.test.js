'use strict';

/*
 * Tests for the per-order driver bonus: firstItemBonus (£5) for the
 * order's first item, plus extraItemBonus (£2.50) for every item after
 * that - counted by TOTAL quantity across the whole order (every line
 * summed), not by distinct menu lines or by order count. Config lives in
 * data/config.json's new "driverPay" section. Computed once, at
 * COMPLETE, in Engine._complete - see src/engine.js.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { Engine, emptyEngineState } = require('../src/engine');
const { LocationIndex } = require('../src/locationIndex');

const locationsData = require('../data/locations.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeEngine(t0 = 0) {
  let clock = t0;
  const index = new LocationIndex(locationsData);
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function outboxFor(e, phone) {
  return e.state.outbox.filter((m) => m.to === phone).map((m) => m.text);
}
function driverOutbox(e, id) {
  return e.state.outbox.filter((m) => m.to === id).map((m) => m.text);
}
function fullOrder(e, phone, texts) {
  e.handleCustomerBurst(phone, texts);
  const id = e.state.activeByPhone[phone];
  return e.state.orders[id];
}

test('config has the driver bonus rates the user specified: £5 first item, £2.50 each extra', () => {
  assert.equal(config.driverPay.firstItemBonus, 5);
  assert.equal(config.driverPay.extraItemBonus, 2.5);
});

test('a single-item order earns exactly the first-item bonus, nothing more', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900201', ['1 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  assert.equal(order.driverBonus, 5);
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 5);
  assert.equal(e.state.drivers.D1.earnings.completedOrders, 1);
});

test('a multi-item order (3 of the same item) is £5 + 2 x £2.50 = £10, not £5 x 3', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900202', ['3 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  assert.equal(order.driverBonus, 10);
});

test('quantity is summed ACROSS DIFFERENT items, not per distinct menu line (2 item a + 1 item b = 3 total items = £10)', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900203', ['2 item a, 1 item b BS48 1AB']);
  const totalQty = order.items.reduce((s, i) => s + i.qty, 0);
  assert.equal(totalQty, 3);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  assert.equal(order.driverBonus, 10); // 5 + 2*2.5
});

test('the running total accumulates correctly across separate completed orders for the same driver', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');

  const o1 = fullOrder(e, '+447700900204', ['1 item a BS48 1AB']); // £5
  e.handleDriverMessage('D1', `ACCEPT ${o1.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o1.id}`);
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 5);

  const o2 = fullOrder(e, '+447700900205', ['2 item a BS48 1AB']); // 5 + 2.5 = 7.5
  e.handleDriverMessage('D1', `ACCEPT ${o2.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o2.id}`);
  assert.equal(e.state.drivers.D1.earnings.totalBonus, 12.5);
  assert.equal(e.state.drivers.D1.earnings.completedOrders, 2);
});

test('sending COMPLETE twice for the same order does not double-count the bonus', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900206', ['2 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const afterFirst = e.state.drivers.D1.earnings.totalBonus;
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`); // duplicate
  assert.equal(e.state.drivers.D1.earnings.totalBonus, afterFirst);
  assert.equal(e.state.drivers.D1.earnings.completedOrders, 1);
});

test('two different drivers completing separate orders keep fully independent totals', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  e.registerDriver('D2');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D2', 'ON');

  const o1 = fullOrder(e, '+447700900207', ['1 item a BS48 1AB']);
  e.handleDriverMessage('D1', `ACCEPT ${o1.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${o1.id}`);

  const o2 = fullOrder(e, '+447700900208', ['4 item a BS48 1AB']); // 5 + 3*2.5 = 12.5
  e.handleDriverMessage('D2', `ACCEPT ${o2.id}`);
  e.handleDriverMessage('D2', `COMPLETE ${o2.id}`);

  assert.equal(e.state.drivers.D1.earnings.totalBonus, 5);
  assert.equal(e.state.drivers.D2.earnings.totalBonus, 12.5);
});

test('the driver sees the bonus and their running total in the COMPLETE reply', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900209', ['2 item a BS48 1AB']);
  e.registerDriver('D1');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const msgs = driverOutbox(e, 'D1');
  assert.ok(msgs.some((t) => t.includes('£7.50') && t.includes('completed')));
});

test('Engine.summary() reports a per-driver bonus breakdown for the Boss app', () => {
  const e = makeEngine();
  const order = fullOrder(e, '+447700900210', ['1 item a BS48 1AB']);
  e.registerDriver('D1', 'Dave');
  e.handleDriverMessage('D1', 'ON');
  e.handleDriverMessage('D1', `ACCEPT ${order.id}`);
  e.handleDriverMessage('D1', `COMPLETE ${order.id}`);
  const row = e.summary().driverEarnings.find((r) => r.id === 'D1');
  assert.ok(row);
  assert.equal(row.name, 'Dave');
  assert.equal(row.totalBonus, 5);
  assert.equal(row.completedOrders, 1);
});

test('a driver with no completed orders yet shows a zero bonus, not undefined/NaN', () => {
  const e = makeEngine();
  e.registerDriver('D1');
  const row = e.summary().driverEarnings.find((r) => r.id === 'D1');
  assert.equal(row.totalBonus, 0);
  assert.equal(row.completedOrders, 0);
});
