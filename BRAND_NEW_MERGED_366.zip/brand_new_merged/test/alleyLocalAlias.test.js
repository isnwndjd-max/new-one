'use strict';

/*
 * Tests for the local alley alias / landmark matching layer (see
 * CHANGELOG_ALLEY_LOCAL_ALIAS.md). This layer lets a customer describe an
 * unnamed alley by a nearby VERIFIED venue or VERIFIED road ("Zig Zag
 * alley", "alley off Strode Road", "alley by Strode Leisure Centre"),
 * derived from real OSM/venue geometry (never text-guessed adjacency), and
 * gated so a generated alias only auto-resolves when the geometric
 * relationship is strong AND unique - otherwise it's CONFIRM_REQUIRED
 * (mapped onto the existing CONFIRM/ASK_WHICH outcome types, so engine.js
 * needs no new cases).
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');
const { Engine, emptyEngineState } = require('../src/engine');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const contextData = require('../data/localityContext.json');
const alleyAliasData = require('../data/alleyAliases.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeIndex() {
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData, contextData, alleyAliasData);
  return index;
}
const index = makeIndex();

function run(msgs, opts = { allowPartial: true }) {
  const conv = new LocationConversation(index, emptyState());
  const outs = [];
  for (const m of msgs) outs.push(conv.handle(m, opts));
  return { outs, last: outs[outs.length - 1], state: conv.state };
}

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}

// -------------------------------------------------------- basic data sanity

test('the alley alias layer loaded a non-trivial number of aliases', () => {
  assert.ok(index.roadIndex.alleyAliasMeta.size > 1000);
});

// ---------------------------------------------------- 1. venue + one alley

test('1. one venue + exactly one adjacent alley -> auto-resolves (road_and_venue, unique)', () => {
  const { last } = run(['alley by strode leisure centre']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'alley');
  assert.equal(last.location.id, 'PATH-BS21-0155');
  assert.equal(last.location.localAlias.anchorType, 'venue');
  assert.equal(last.location.localAlias.anchorName, 'Strode Leisure Centre');
});

test('"strode leisure centre alleyway" / "alley next to strode leisure centre" resolve the same alley', () => {
  for (const msg of ['strode leisure centre alleyway', 'alley next to strode leisure centre']) {
    const { last } = run([msg]);
    assert.equal(last.type, 'RESOLVED');
    assert.equal(last.location.id, 'PATH-BS21-0155');
  }
});

// ----------------------------------------------------- 2. road + one alley

test('2. one road + exactly one directly connected alley -> auto-resolves (road_direct, connects_to)', () => {
  const { last } = run(['rock road alleyway']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'alley');
  assert.equal(last.location.id, 'PATH-BS49-0008');
  assert.equal(last.location.localAlias.anchorType, 'road');
  assert.equal(last.location.localAlias.anchorName, 'Rock Road');
});

test('"alley off rock road" (the "off" phrasing) resolves the same way', () => {
  const { last } = run(['alley off rock road']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, 'PATH-BS49-0008');
});

test('"rock rd alley" (abbreviated road suffix) resolves the same way', () => {
  const { last } = run(['rock rd alley']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, 'PATH-BS49-0008');
});

test('a road name that collides with another, unrelated road of the same name elsewhere is correctly asked, not guessed (real "Zig Zag" case)', () => {
  const { last } = run(['zig zag alley']);
  assert.notEqual(last.type, 'RESOLVED');
  assert.ok(['ASK_WHICH', 'ASK_TOWN', 'CONFIRM'].includes(last.type));
});

// ------------------------------------------------- road+venue both present

test('road_and_venue: "strode road alley" (the road side of the same combined anchor) also resolves', () => {
  const { last } = run(['strode road alleyway']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, 'PATH-BS21-0155');
  assert.equal(last.location.localAlias.anchorType, 'road');
});

test('"strode rd alley" (abbreviated) still resolves', () => {
  const { last } = run(['strode rd alley']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, 'PATH-BS21-0155');
});

// ----------------------------------------- 3/4. multiple alleys, same anchor

test('3/4. multiple alleys sharing one road anchor -> CONFIRM_REQUIRED (ASK_WHICH), never auto-picked', () => {
  const { last } = run(['church lane alley']);
  assert.notEqual(last.type, 'RESOLVED');
  assert.ok(['ASK_WHICH', 'ASK_TOWN', 'CONFIRM'].includes(last.type));
});

test('the underlying alias rows for a shared anchor are all marked auto_resolve_allowed=false', () => {
  const rows = alleyAliasData.aliases.filter((r) => r.anchor_name === 'Church Lane' && r.anchor_type === 'road');
  assert.ok(rows.length > 0);
  assert.ok(rows.every((r) => r.auto_resolve_allowed === false));
});

// ------------------------------------------------- 5/6. weak generated labels

test('5/6. a weak/locality-anchored generated alley never auto-resolves even via a "near" alias', () => {
  const { last } = run(['alley near stock way north']);
  assert.notEqual(last.type, 'RESOLVED');
  assert.equal(last.type, 'CONFIRM');
  assert.equal(last.location.id, 'PATH-BS48-0012');
});

// --------------------------------------------------------- 7. wrong town

test('7. wrong town context prevents auto-resolve / picks the correct one, never guesses cross-town', () => {
  // Zig Zag alley is in a specific town; asking with an unrelated town first
  // must not silently resolve to the same alley if the town doesn't match.
  const alley = alleysData.alleys.find((a) => a.id === 'PATH-BS21-0002');
  const wrongTown = locationsData.towns.find((t) => t !== alley.town);
  const { last } = run([`zig zag alley ${wrongTown}`]);
  assert.notEqual(last.type, 'RESOLVED');
});

// ------------------------------------------------ 8. postcode beats alias

test('8. a full active postcode always wins outright over a local alley alias', () => {
  const pc = Object.keys(locationsData.activePostcodes)[0];
  const { last } = run([`${pc} zig zag alley`]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'postcode');
  assert.equal(last.location.postcode, pc);
});

// -------------------------------------- 9. venue nearby but not associated

test('9. a venue that is merely in the same neighbourhood (not geometrically adjacent) creates no alias', () => {
  // No alias row should exist naming a venue whose relationship is beyond
  // the adjacency thresholds - the build only emits rows for real
  // connects_to/adjacent_to/entrance_beside/near_only relationships.
  const relSet = new Set(alleyAliasData.aliases.map((r) => r.relationship));
  for (const r of relSet) {
    assert.notEqual(r, 'unknown', 'no alias row should ever carry an "unknown" (unassociated) relationship');
  }
});

// --------------------------------------- 10. genuine OSM-named alley intact

test('10. a genuine OSM-named alley keeps resolving by its real name, untouched by this layer', () => {
  const namedAlley = alleysData.alleys.find((a) => a.name_source === 'osm_named');
  const sameName = alleysData.alleys.filter((a) => a.name === namedAlley.name);
  if (sameName.length === 1) {
    const { last } = run([namedAlley.name]);
    assert.equal(last.type, 'RESOLVED');
    assert.equal(last.location.type, 'alley');
    assert.equal(last.location.id, namedAlley.id);
    assert.equal(last.location.name, namedAlley.name);
    assert.equal(last.location.localAlias, null); // matched by its own real name, not a local alias
  }
});

// --------------------------------------- 11. generated alias never rewrites

test('11. a generated customer alias never overwrites the underlying alley record', () => {
  const alley = alleysData.alleys.find((a) => a.id === 'PATH-BS49-0008');
  assert.equal(alley.name, 'Rock Road'); // the real OSM/generated name is unchanged
  const { last } = run(['rock road alleyway']);
  assert.equal(last.location.name, 'Rock Road'); // never renamed to "Rock Road Alleyway" or similar
});

// ------------------------------------------------------------ two_roads

test('a two-roads-connected alley auto-resolves via either endpoint road name', () => {
  const twoRoadRow = alleyAliasData.aliases.find((r) => r.anchor_strength === 'two_roads' && r.auto_resolve_allowed);
  assert.ok(twoRoadRow);
  const { last } = run([twoRoadRow.alias]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.id, twoRoadRow.alley_id);
});

// --------------------------------------------------- priority / regressions

test('road/alley NAME matching still outranks a local alias (roads.json/alleys.json unchanged)', () => {
  const { last } = run(['kenn road']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'road');
});

test('venue matching is unaffected by this layer', () => {
  const activeVenue = locationsData.venues.find((v) => v.status === 'ACTIVE' && v.name && v.name.includes(' '));
  const { last } = run([activeVenue.name.toLowerCase()]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'venue');
});

test('ETA/HERE/CANCEL are never mistaken for an alley alias', () => {
  const { last } = run(['10 mins']);
  assert.equal(last.type, 'ETA');
  const { last: last2 } = run(['here now']);
  assert.equal(last2.type, 'ARRIVAL');
});

test('backward compatible: RoadIndex still works with no alleyAliasData argument at all', () => {
  const idx2 = new LocationIndex(locationsData);
  idx2.roadIndex = new RoadIndex(roadsData, alleysData, contextData); // 4th arg omitted
  const conv = new LocationConversation(idx2, emptyState());
  const out = conv.handle('rock road alleyway', { allowPartial: true });
  // Without the alias layer, "rock road alleyway" isn't a registered alley
  // phrase at all - the embedded real ROAD name "rock road" still matches
  // (unchanged legacy behaviour), but never the alley, since there is no
  // local-alias entry to produce that outcome without alleyAliasData.
  assert.notEqual(out.location && out.location.type, 'alley');
});

// -------------------------------------------------------------- end-to-end

test('end-to-end: a customer ordering via a local alley alias reaches CONFIRMED with the alley in their order', () => {
  const e = makeEngine();
  e.handleCustomerBurst('c1', ['rock road alleyway', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.state, 'CONFIRMED');
  assert.equal(order.location.confirmed.id, 'PATH-BS49-0008');
});

test('end-to-end: CANCEL still works after a local-alias order is confirmed', () => {
  const e = makeEngine();
  e.handleCustomerBurst('c1', ['rock road alleyway', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.state, 'CONFIRMED');
  e.handleCustomerBurst('c1', ['cancel']);
  assert.equal(order.state, 'CANCELLED');
});

// ----------------------------------------------- audit file sanity checks

test('every alias row references a real alley_id present in data/alleys.json', () => {
  const validIds = new Set(alleysData.alleys.map((a) => a.id));
  for (const r of alleyAliasData.aliases) {
    assert.ok(validIds.has(r.alley_id), `alias row references unknown alley_id ${r.alley_id}`);
  }
});
