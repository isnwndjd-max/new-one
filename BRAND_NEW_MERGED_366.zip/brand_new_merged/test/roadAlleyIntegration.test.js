'use strict';

/*
 * Tests for the offline road/alley layer integration (see
 * CHANGELOG_ROAD_ALLEY_INTEGRATION.md). This wires the OSM-derived road and
 * alley/footway datasets (data/roads.json, data/alleys.json - see
 * src/roadIndex.js) into the EXISTING location resolver as a separate
 * layer, consulted only after postcode and venue matching have both
 * already failed for a message.
 *
 * Run against the REAL data/locations.json + data/roads.json +
 * data/alleys.json, not synthetic fixtures, so these tests exercise the
 * actual data this build would ship.
 *
 * Covers:
 *  - every named test road/alias from the integration brief
 *  - match priority (postcode > venue > road name > road alias > alley >
 *    ambiguous) including the "station" vs "station road" generic-term case
 *  - road-name collisions kept separate by town (Station Road, High Street...)
 *  - conversation context (town carried across messages, no repeat asking)
 *  - existing behaviour NOT broken (ETA/HERE/CANCEL/yes/no never treated as
 *    roads; full regression of the existing venue/postcode test suites,
 *    which run unmodified in their own files and are not duplicated here)
 *  - backward compatibility: a LocationIndex with NO roadIndex attached
 *    (every pre-existing test in this repo) behaves exactly as before
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const { LocationIndex } = require('../src/locationIndex');
const { RoadIndex } = require('../src/roadIndex');
const { LocationConversation, emptyState } = require('../src/locationConversation');
const { Engine, emptyEngineState } = require('../src/engine');

const locationsData = require('../data/locations.json');
const roadsData = require('../data/roads.json');
const alleysData = require('../data/alleys.json');
const menu = require('../data/menu.sync.json');
const messages = require('../data/messages.json');
const config = require('../data/config.json');

function makeIndexWithRoads() {
  const index = new LocationIndex(locationsData);
  index.roadIndex = new RoadIndex(roadsData, alleysData);
  return index;
}
const index = makeIndexWithRoads();

function run(msgs, opts = { allowPartial: true }) {
  const conv = new LocationConversation(index, emptyState());
  const outs = [];
  for (const m of msgs) outs.push(conv.handle(m, opts));
  return { outs, last: outs[outs.length - 1], state: conv.state };
}

function makeEngine(t0 = 0) {
  let clock = t0;
  const e = new Engine({ index, menu, messages, config, state: emptyEngineState(), now: () => clock });
  e.advance = (ms) => { clock += ms; };
  return e;
}
function outboxFor(e, phone) {
  return e.state.outbox.filter((m) => m.to === phone).map((m) => m.text);
}

// ------------------------------------------------------------- named roads

test('all twelve named test roads from the integration brief resolve or ask sensibly', () => {
  // Single-locality roads: resolve straight away, no ambiguity possible.
  for (const [msg, expectTown] of [
    ['kenn road', 'Clevedon'],
    ['nailsea wall', null],
    ['backwell bow', null],
    ['claverham drove', null],
    ['newfoundland way', null],
    ['harbour road', null],
  ]) {
    const { last } = run([msg]);
    assert.equal(last.type, 'RESOLVED', `"${msg}" should resolve (got ${last.type})`);
    assert.equal(last.location.type, 'road');
    if (expectTown) assert.equal(last.location.town, expectTown);
  }

  // Multi-locality roads: bare name is genuinely ambiguous (several real
  // physical roads share the name) - must ask, never guess.
  for (const msg of ['weston road', 'old church road', 'station road', 'high street', 'moor lane', 'the avenue']) {
    const { last } = run([msg]);
    assert.equal(last.type, 'ASK_TOWN', `"${msg}" should ask which town (got ${last.type})`);
    assert.ok(last.towns.length > 1);
  }
});

test('road-suffix abbreviations match the same road as the full word', () => {
  const full = run(['kenn road']).last;
  const abbr = run(['kenn rd']).last;
  assert.equal(full.type, 'RESOLVED');
  assert.equal(abbr.type, 'RESOLVED');
  assert.equal(full.location.id, abbr.location.id);
});

test('a filler word in front of a road name does not block the match ("on weston road")', () => {
  const bare = run(['weston road']).last;
  const withOn = run(['on weston road']).last;
  assert.equal(bare.type, 'ASK_TOWN');
  assert.equal(withOn.type, 'ASK_TOWN');
  assert.deepEqual(bare.towns, withOn.towns);
});

// ------------------------------------------------------- collisions/towns

test('Station Road, Yatton and Station Road, Backwell are separate records - a bare name never guesses', () => {
  const { last } = run(['station road']);
  assert.equal(last.type, 'ASK_TOWN');
  assert.ok(last.towns.includes('Yatton'));
});

test('"station road yatton" resolves the ROAD in Yatton directly, not a generic ambiguity guess', () => {
  const { last } = run(['station road yatton']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'road');
  assert.equal(last.location.name, 'Station Road');
  assert.equal(last.location.town, 'Yatton');
});

test('"station rd yatton" (abbreviated) resolves the same way', () => {
  const { last } = run(['station rd yatton']);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.town, 'Yatton');
});

test('a bare, real single-word venue-ambiguity term ("station" alone, no road/street word) still asks about VENUES as before - this integration does not change that', () => {
  const { last } = run(['station']);
  // Still the existing venue ambiguity behaviour (kind: ambiguity, no
  // "road"/"street" suffix in the phrase at all, so no road phrase can ever
  // be longer than it) - proves the road layer only overrides a weak venue
  // match when it has strictly more specific evidence, never on a level playing field.
  assert.ok(['ASK_TOWN', 'ASK_WHICH', 'CONFIRM'].includes(last.type));
  assert.notEqual(last.location && last.location.type, 'road');
});

test('road name + full postcode in the same message: the postcode wins outright (priority 1 beats 3) and the road rides along as a label, unchanged legacy behaviour', () => {
  const pc = Object.keys(locationsData.activePostcodes)[0];
  const { last } = run([`${pc} Weston Road`]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'postcode');
  assert.equal(last.location.postcode, pc);
  assert.equal(last.location.street, 'Weston Road');
});

test('road name + a bare outward postcode district (no full postcode) narrows an ambiguous road by district', () => {
  // Weston Road exists in BS48 (Long Ashton) and BS49 (Congresbury) - find
  // which BS48/BS49 split actually applies from the real data, then prove
  // the district text narrows to just that district's candidate(s).
  const weston = roadsData.roads.filter((r) => r.name === 'Weston Road');
  const districtsPresent = [...new Set(weston.map((r) => r.district))];
  assert.ok(districtsPresent.length > 1, 'fixture assumption: Weston Road spans >1 district');
  const district = districtsPresent[0];
  const { last } = run([`weston road ${district}`]);
  // Either resolves directly (if only one candidate in that district) or
  // narrows the ASK_TOWN list to just that district's towns - either way it
  // must never suggest a town from a DIFFERENT district.
  const inDistrictTowns = new Set(weston.filter((r) => r.district === district).map((r) => r.town));
  if (last.type === 'RESOLVED') {
    assert.ok(inDistrictTowns.has(last.location.town));
  } else {
    assert.equal(last.type, 'ASK_TOWN');
    for (const t of last.towns) assert.ok(inDistrictTowns.has(t), `${t} should be in district ${district}`);
  }
});

// ------------------------------------------------------------- conversation

test('road + town across two messages resolves, and once resolved a later road-only message does not need the town repeated', () => {
  const conv = new LocationConversation(index, emptyState());
  const o1 = conv.handle('weston road', { allowPartial: true });
  assert.equal(o1.type, 'ASK_TOWN');
  const o2 = conv.handle('congresbury', { allowPartial: true });
  assert.equal(o2.type, 'RESOLVED');
  assert.equal(o2.location.town, 'Congresbury');
  assert.equal(conv.state.town, 'Congresbury');
});

test('once a town is already known from context, a later bare road name in that town resolves without asking again', () => {
  const conv = new LocationConversation(index, emptyState());
  // Establish town context via an ordinary town mention (not a pending road).
  const withTown = conv.handle('congresbury weston road', { allowPartial: true });
  assert.equal(withTown.type, 'RESOLVED');
  assert.equal(withTown.location.town, 'Congresbury');
});

test('alias + town resolves the same way as full name + town', () => {
  const conv = new LocationConversation(index, emptyState());
  conv.handle('weston rd', { allowPartial: true }); // ASK_TOWN
  const o2 = conv.handle('failand', { allowPartial: true });
  assert.equal(o2.type, 'RESOLVED');
  assert.equal(o2.location.town, 'Failand');
});

test('wrong town for a road that does not exist there: asked, then told plainly rather than guessing', () => {
  const conv = new LocationConversation(index, emptyState());
  const o1 = conv.handle('weston road', { allowPartial: true });
  assert.equal(o1.type, 'ASK_TOWN');
  assert.ok(!o1.towns.includes('Portishead'), 'fixture assumption: Weston Road does not exist in Portishead');
  const o2 = conv.handle('portishead', { allowPartial: true });
  assert.equal(o2.type, 'NOT_IN_TOWN');
  assert.equal(conv.state.confirmed, null);
});

test('unknown road (not in the dataset at all) never fabricates a match', () => {
  const { last } = run(['Sesame Street']);
  assert.notEqual(last.type, 'RESOLVED');
  assert.equal(last.type, 'NONE');
});

test('a misspelled road name is not fuzzily matched - this project does not guess, for venues or roads', () => {
  for (const msg of ['westun rd', 'klaverham drove', 'stachun road yatton']) {
    const { last } = run([msg]);
    assert.notEqual(last.type, 'RESOLVED', `"${msg}" should not have resolved`);
  }
});

// -------------------------------------------- existing behaviour preserved

test('a road resolved in one message is not disturbed by an ETA message that follows', () => {
  const { state, outs } = run(['kenn road', '10 mins']);
  assert.equal(outs[0].type, 'RESOLVED');
  assert.equal(outs[1].type, 'ETA');
  assert.equal(state.confirmed.type, 'road');
  assert.equal(state.confirmed.name, 'Kenn Road');
  assert.equal(state.etaMinutes, 10);
});

test('"here now" after a road match does not touch the confirmed location', () => {
  const { state, outs } = run(['kenn road', 'here now']);
  assert.equal(outs[1].type, 'ARRIVAL');
  assert.equal(state.confirmed.name, 'Kenn Road');
  assert.equal(state.arrived, true);
});

test('bare status words (yes/yeah/yh/here/stop-adjacent "no") never get treated as a road/alley on their own', () => {
  for (const msg of ['yes', 'yeah', 'yh', 'ok', 'no', 'nope']) {
    const { last } = run([msg]);
    assert.notEqual(last.type, 'RESOLVED', `"${msg}" must not resolve a location`);
    assert.notEqual(last.location && last.location.type, 'road');
    assert.notEqual(last.location && last.location.type, 'alley');
  }
});

test('CANCEL after a road match is handled by the engine before the location layer ever sees it (unchanged, pre-existing behaviour)', () => {
  const e = makeEngine();
  e.handleCustomerBurst('p1', ['weston road']); // ambiguous -> asks
  e.handleCustomerBurst('p1', ['congresbury']); // resolves the road
  e.handleCustomerBurst('p1', ['2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.location.confirmed.type, 'road');
  e.handleCustomerBurst('p1', ['cancel']);
  assert.equal(order.state, 'CANCELLED');
});

test('a genuine strong venue-name match is never second-guessed by an overlapping road/alias word', () => {
  // Pick a real ACTIVE venue whose canonical name is at least two words, so
  // it is a STRONG (canonical) match - must always win outright, exactly as
  // before this integration, regardless of what the road layer contains.
  const activeVenue = locationsData.venues.find((v) => v.status === 'ACTIVE' && v.name && v.name.includes(' '));
  assert.ok(activeVenue, 'fixture assumption: at least one multi-word ACTIVE venue exists');
  const { last } = run([activeVenue.name.toLowerCase()]);
  assert.equal(last.type, 'RESOLVED');
  assert.equal(last.location.type, 'venue');
  assert.equal(last.location.venueId, activeVenue.id);
});

// ------------------------------------------------------------- alley layer

test('alley/footway layer: a real OSM-named path resolves like a road when unique', () => {
  const namedAlley = alleysData.alleys.find((a) => a.name_source === 'osm_named');
  assert.ok(namedAlley, 'fixture assumption: at least one OSM-named alley exists');
  const sameName = alleysData.alleys.filter((a) => a.name === namedAlley.name);
  const { last } = run([namedAlley.name]);
  if (sameName.length === 1) {
    assert.equal(last.type, 'RESOLVED');
    assert.equal(last.location.type, 'alley');
    assert.equal(last.location.id, namedAlley.id);
  } else {
    assert.equal(last.type, 'ASK_TOWN');
  }
});

test('a weakly-anchored generated alley label (locality/district fallback only) asks for confirmation rather than auto-resolving', () => {
  const weak = alleysData.alleys.find(
    (a) => a.name_source === 'generated' && ['locality_only', 'district_only'].includes(a.anchor_strength)
  );
  assert.ok(weak, 'fixture assumption: at least one weakly-anchored generated alley exists');
  const { last } = run([weak.name]);
  // Either genuinely ambiguous (several alleys share that generated label -
  // common, since many are "Footpath near <locality>") or a single weak
  // match asking for confirmation - never a silent RESOLVED.
  assert.notEqual(last.type, 'RESOLVED');
});

test('a strongly-anchored generated alley (named road at both ends) resolves directly when unique - tested at the _resolveRoad mechanism level', () => {
  // NOTE ON METHOD: a "road_pair" generated label is built FROM two real
  // road names ("Footpath: West Town Road to Lotts Avenue"), so texting
  // that label back in as an SMS almost always also contains a real road
  // name as a substring - and roads correctly outrank alleys (see the very
  // next test), so the ROAD layer would answer first, not the alley. A
  // customer would never actually text a generated label anyway (see
  // README.txt / data/alleys.json _provenance - these aren't real place
  // names). So this test proves the CONFIRM-vs-RESOLVED anchor_strength
  // gate itself directly, the same way _resolveRoad is actually invoked
  // from handle() once a phrase has already matched, rather than relying
  // on a coincidence-free text search to reach it.
  const strong = alleysData.alleys.filter((a) => a.name_source === 'generated' && a.anchor_strength === 'road_pair');
  const uniqueOne = strong.find((a) => alleysData.alleys.filter((x) => x.name === a.name).length === 1);
  assert.ok(uniqueOne, 'fixture assumption: at least one uniquely-named road_pair alley exists');
  const conv = new LocationConversation(index, emptyState());
  const out = conv._resolveRoad({ phrase: 'x', layer: 'ALLEY', candidates: [{ road: uniqueOne, kind: 'name' }] }, null);
  assert.equal(out.type, 'RESOLVED');
  assert.equal(out.location.type, 'alley');
  assert.equal(out.location.id, uniqueOne.id);
});

test('a road name embedded inside a generated alley label correctly resolves as the ROAD, not the alley (roads always outrank alleys - see module header)', () => {
  const strong = alleysData.alleys.filter((a) => a.name_source === 'generated' && a.anchor_strength === 'road_pair');
  const uniqueOne = strong.find((a) => alleysData.alleys.filter((x) => x.name === a.name).length === 1);
  assert.ok(uniqueOne);
  const { last } = run([uniqueOne.name]);
  // Not asserting a specific outcome type here (it depends on whether the
  // embedded road name happens to be ambiguous) - only that whatever
  // resolves, it is never the alley, since a real road name was found in
  // the text and roads always win.
  assert.notEqual(last.location && last.location.type, 'alley');
});

test('roads always outrank alleys when a phrase could plausibly match either', () => {
  // Construct a message that is exactly a real road's name - the alley
  // layer must never be consulted at all once the road layer matched.
  const road = roadsData.roads[0];
  const { last } = run([road.name]);
  assert.notEqual(last.location && last.location.type, 'alley');
});

// --------------------------------------------------- backward compatibility

test('backward compatibility: a LocationIndex with no roadIndex attached behaves exactly as before (no road/alley branch ever fires)', () => {
  // Uses a nonsense phrase rather than a real road name: the venue
  // enrichment pass (CHANGELOG_BRISTOL_EXTRACT_ENRICHMENT.md) added
  // enough real single/short-word venue names that a genuine road-shaped
  // phrase like "weston road" can now also partial-match an unrelated
  // venue on its own, independent of any road layer - that's expected
  // venue-layer behaviour, not something this test is checking. The
  // point here is narrower: with no roadIndex attached at all, the
  // road/alley branch in locationConversation.js must never fire.
  const legacyIndex = new LocationIndex(locationsData); // no .roadIndex attached
  const conv = new LocationConversation(legacyIndex, emptyState());
  const out = conv.handle('zzqvx blorp nonexistent road', { allowPartial: true });
  assert.notEqual(out.type, 'RESOLVED');
  assert.notEqual(out.type, 'ASK_TOWN');
  assert.equal(conv.state.pendingRoad, null);
});

// --------------------------------------------------- end-to-end via Engine

test('end-to-end: order text + a road name confirms and dispatches, with the road in the driver-facing place label', () => {
  const e = makeEngine();
  e.handleCustomerBurst('p2', ['kenn road', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.location.confirmed.type, 'road');
  assert.equal(order.state, 'CONFIRMED');
  const sent = outboxFor(e, 'p2').join(' | ');
  assert.ok(sent.includes('Kenn Road'), `expected the road name in the customer confirmation: ${sent}`);
});

test('end-to-end: a road-resolved order still gets the "postcode/area only" driver note (exactPointKnown: false)', () => {
  const e = makeEngine();
  e.handleCustomerBurst('p3', ['kenn road', '2 item a']);
  const order = Object.values(e.state.orders)[0];
  assert.equal(order.location.confirmed.exactPointKnown, false);
});
