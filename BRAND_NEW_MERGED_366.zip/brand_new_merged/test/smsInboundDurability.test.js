'use strict';

/*
 * Tests for CHANGELOG_SMS_INBOUND_DURABILITY.md: previously POST
 * /sms/inbound put the message straight into an in-memory-only burst
 * buffer and returned 202 immediately - the message only became durable
 * (written to state.json) once the burst window elapsed and it was
 * processed. A crash in that gap lost the message even though the
 * customer's phone shows it sent and the gateway got a 202.
 *
 * Fix: durably save the raw inbound message (synchronous, fsync'd,
 * atomic write via Store.save) BEFORE responding 202, and only clear
 * that durable record once it has actually been folded into a processed
 * burst. On startup, any leftover record (meaning the process died
 * before that) is replayed through the normal burst pipeline.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');
const { createApp } = require('../server/index');
const { Store } = require('../src/store');

const GATEWAY_TOKEN = require('../data/config.json').gateway.token;

function req(base, method, url, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + url, {
      method,
      headers: Object.assign(
        { 'X-Gateway-Token': GATEWAY_TOKEN },
        data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}
      ),
    }, (res) => {
      let out = '';
      res.on('data', (c) => (out += c));
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: out ? JSON.parse(out) : null }); }
        catch (e) { reject(e); }
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

test('an inbound SMS is durably on disk (readable back out via a fresh Store) before the 202 response is even sent', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-durability-${Date.now()}.json`);
  const app = createApp({ statePath, burstWindowMs: 5000, tickIntervalMs: 50 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  try {
    const r = await req(base, 'POST', '/sms/inbound', { from: '+447700900700', text: 'hi', messageId: 'dur-1' });
    assert.equal(r.status, 202);

    // Read the state file back with a completely separate Store instance -
    // proves it's really on disk, not just true in the running process's
    // memory - and confirm it happened WITHOUT waiting for the (5s) burst
    // window to elapse at all.
    const freshStore = new Store(statePath);
    const onDisk = freshStore.load(() => null);
    assert.ok(onDisk, 'state.json should already exist');
    assert.ok(
      onDisk.pendingInboundSms.some((p) => p.from === '+447700900700' && p.text === 'hi' && p.messageId === 'dur-1'),
      'the raw inbound message should be durably saved before the burst window ever elapses'
    );
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
  }
});

test('once a burst is actually processed, its pending-inbound records are cleared from disk', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-durability-${Date.now()}-2.json`);
  const app = createApp({ statePath, burstWindowMs: 30, tickIntervalMs: 20 });
  await new Promise((resolve) => app.server.listen(0, resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  try {
    await req(base, 'POST', '/sms/inbound', { from: '+447700900701', text: 'hi', messageId: 'dur-2' });
    assert.ok(app.engine.state.pendingInboundSms.length >= 1);
    await new Promise((resolve) => setTimeout(resolve, 150)); // let the burst window + tick process it
    assert.equal(
      app.engine.state.pendingInboundSms.some((p) => p.messageId === 'dur-2'),
      false,
      'a processed message should no longer be in the pending-inbound list'
    );
    const freshStore = new Store(statePath);
    const onDisk = freshStore.load(() => null);
    assert.equal(onDisk.pendingInboundSms.some((p) => p.messageId === 'dur-2'), false);
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
  }
});

test('a message saved but never processed before a "crash" (server never ticked) is recovered and processed on the next startup', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-durability-${Date.now()}-3.json`);
  // A burst window long enough that it will NOT elapse before we kill this
  // instance - simulates a crash between the durable save and processing.
  const app1 = createApp({ statePath, burstWindowMs: 60000, tickIntervalMs: 20 });
  await new Promise((resolve) => app1.server.listen(0, resolve));
  const port1 = app1.server.address().port;
  const base1 = `http://127.0.0.1:${port1}`;

  const r = await req(base1, 'POST', '/sms/inbound', { from: '+447700900702', text: 'hi', messageId: 'dur-3' });
  assert.equal(r.status, 202);
  assert.equal(app1.engine.state.pendingInboundSms.length, 1, 'should be durably pending, not yet processed');
  app1.stop(); // simulate the process ending - no clean burst flush happened
  await new Promise((resolve) => app1.server.close(resolve));

  // Fresh app instance against the SAME state file - like a restart after a crash.
  const app2 = createApp({ statePath, burstWindowMs: 20, tickIntervalMs: 15 });
  try {
    await new Promise((resolve) => app2.server.listen(0, resolve));
    const base2 = `http://127.0.0.1:${app2.server.address().port}`;
    await new Promise((resolve) => setTimeout(resolve, 150)); // let recovery + the burst window process it
    const outbox = await req(base2, 'GET', '/sms/outbound/pending');
    assert.ok(
      outbox.body.messages.some((m) => m.text.toLowerCase().includes('cash only') || m.text.length > 0),
      'the recovered message should have been processed into a real reply, not lost'
    );
    assert.equal(app2.engine.state.pendingInboundSms.length, 0, 'recovered message should be cleared once processed');
  } finally {
    app2.stop();
    await new Promise((resolve) => app2.server.close(resolve));
  }
});

test('an old state.json saved before these fields existed loads without throwing (migration default)', async () => {
  const statePath = path.join(os.tmpdir(), `rocket-durability-${Date.now()}-4.json`);
  const legacyStore = new Store(statePath);
  legacyStore.save({ version: 1, orders: {}, activeByPhone: {}, drivers: {}, driversByTraccarId: {}, outbox: [], review: [], debts: [], customers: {}, referralCodes: {}, seenInbound: {} });
  const app = createApp({ statePath, burstWindowMs: 5000, tickIntervalMs: 50 });
  try {
    await new Promise((resolve) => app.server.listen(0, resolve));
    assert.deepEqual(app.engine.state.pendingInboundSms, []);
    assert.deepEqual(app.engine.state.venueConfirmations, {});
    assert.deepEqual(app.engine.state.promotionCandidates, []);
  } finally {
    app.stop();
    await new Promise((resolve) => app.server.close(resolve));
  }
});
