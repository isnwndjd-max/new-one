# Rocket Dispatch — Remaining Offline Fixes

**Status: OFFLINE ONLY. Not deployed. Nothing live, Tasker, or production
was touched. Customer app and Driver app were explicitly out of scope and
were not modified.**

This session closed out the nine outstanding items from the "ROCKET
DISPATCH — CLAUDE: FINISH REMAINING OFFLINE BACKEND + BOSS WORK" brief,
plus a documentation cleanup (item 10). Work was done on a copy of the
project; the uploaded original was left untouched throughout.

Starting test count: **292 passing**. Final: **364 passing, 0 failing**
(`node --test test/*.test.js`). No existing test was weakened or deleted
to obtain a pass; a small number of pre-existing tests that hardcoded now
-intentionally-changed values (the old flat `pointsPerOrder`/
`referrerRewardPoints` figures) were updated to compute their expected
values from the new config instead, since the brief itself mandated the
behaviour change those old assertions were pinned against.

## 1. Stock accounting

**New:** `src/engine.js` — `restockProduct`, `adjustStock`, `stockSummary`,
`allStockSummary`, `_reserveStock`, `_releaseStockReservation`,
`_deductStock`, `_maybeLowStockAlert`, `_driverHeldTotal`, `_stockAudit`.
New state: `state.stock`, `state.stockLedger`, `state.lowStockAlerts`.

Every tracked product (anything ever passed to `restockProduct`) has one
record: `total`, `reserved`, `available` (`total - reserved`), and a
computed `driverHeld` (read live from each driver's own `d.stock[code]`
carried-stock ledger — never duplicated into the new system). An untracked
product code is treated as unlimited (`available: Infinity`) so existing
behaviour for anything not yet migrated onto real stock tracking is
unchanged.

- Reserved **exactly once**, all-or-nothing, when an order is confirmed
  (`Engine._confirm`) — an order that can't be fully covered by available
  stock is blocked from confirming at all, never partially reserved.
- Deducted **exactly once**, when an order completes (`Engine._complete`)
  — protected by the pre-existing `order.state === 'COMPLETED'` early-out,
  so a retried/duplicate `COMPLETE` never deducts twice.
- Released back to `available` when a confirmed/offered order is
  cancelled (`Engine._cancel`).
- `restockProduct`/`adjustStock` both take an optional idempotency key
  (backed by the new generic `Engine.idempotent()` helper and
  `state.idempotency`) so a retried Boss HTTP request can't double-apply.
- `adjustStock` floors at zero — stock is never silently allowed negative.
- A low-stock alert (`state.lowStockAlerts`) fires once `available` drops
  to/under the product's threshold (`data/config.json`'s
  `stock.defaultLowStockThreshold`, default 3) and clears once restocked
  back above it.
- Every reservation, deduction, release, restock and adjustment is written
  to `state.stockLedger` — a durable, restart-safe audit trail (part of
  the same encrypted, atomically-written `state.json` as everything else),
  not just an in-memory `audit()` callback.

## 2. Loyalty — ONE rule only

**Changed:** `data/config.json`'s `rewards` block — `pointsPerOrder: 10`
and `referrerRewardPoints: 50` **removed entirely** (not left unused),
replaced with `pointsPerItem: 3`. `Engine._complete`'s loyalty section
rewritten to `earned = totalItemsForLoyalty * config.rewards.pointsPerItem`.
**New:** `Engine.adjustLoyaltyPoints` (idempotency-key aware, audited).

3 points per purchased item, summed across the order — 1 item = 3, 2 = 6,
3 = 9, 5 = 15 (the brief's own worked examples; each is its own test).
Awarded once, on valid completion only; never on cancellation; a repeat
`COMPLETE` never re-awards (same completion-idempotency guard as stock);
persists across a restart as part of `state.customers`. Boss can add or
remove points manually via the new endpoint, and every manual adjustment
is audited via `Engine.auditNote`.

## 3. Debt rules

**New:** `Engine._debtRemaining`, `_openDebtsForPhone`,
`_overdueDebtTotal`, `debtSummaryForPhone`, `adjustDebt`. **Changed:**
`recordDebtPayment` (now idempotency-key aware), `Engine._confirm` (new
debt-block check), `Engine._complete` (rewritten combined debt+order
payment allocation). **New config:** `debt.blockOverdueAmount: 100`.
`debtReminderDays: 7` (pre-existing) now explicitly documented as doing
double duty as the 7-day debt-age rule.

- A debt can remain outstanding for up to 7 days from when it's recorded;
  on day 7 it's "due" and expected to be paid that day
  (`_overdueDebtTotal` treats it as overdue from that point).
- A customer whose *overdue* debt (summed across every open debt on their
  phone) reaches £100+ is blocked from confirming a **new** order
  (`Engine._confirm`, checked before stock reservation) until it's paid
  down — tested at both £99 (not blocked) and £100 (blocked), and that the
  block lifts again once paid below the threshold.
- Paying while placing a new order allocates correctly: the new order's
  own total is covered first, any excess pays down open debts
  oldest-first. The brief's own worked example — existing debt £20, new
  order £10, customer pays £30 → debt clears to £0, order is paid in full,
  £0 remaining — is a direct test. An overpayment beyond both order and
  every open debt is flagged for Boss review rather than silently
  vanishing or producing a negative debt.
- `debtSummaryForPhone` reports `returningDebtor: true` once a customer has
  had more than one debt on file, for Boss visibility.
- `recordDebtPayment`/`adjustDebt` both accept an idempotency key; every
  payment and manual adjustment is audited.

## 4. Referrals — ONE FREE ITEM reward

**Changed:** `Engine._complete`'s referral section — no longer awards
`referrerRewardPoints`; instead creates a `state.freeItemRewards` entry.
**New:** `Engine._availableFreeItemReward`, `_applyFreeItemReward`
(called from `Engine._confirm`).

One-time referral codes are unchanged (still reject self-referral, still
single-use). What changed is the reward: completing a qualifying order
placed under someone's referral code creates a free-item reward for the
referrer (`status: 'earned'`), auto-applied on their *next* order to
discount the cheapest item in it (`status` moves to `'redeemed'` once
applied) — it can never be redeemed twice, and a redeemed free item
correctly reduces stock the same as any paid item (it's still a real item
leaving the shelf, just at zero price). Boss can view every reward and its
current state via `GET /boss/rewards`.

## 5. £250 driver cash limit

**New:** `d.cash = { held: 0, adjustments: [] }` on every driver record
(`Engine.registerDriver`). **New:** `Engine.adjustDriverCash`,
`driverCashSummary`. **Changed:** `Engine._accept` (new cash-limit check),
`Engine._complete` (cash orders add to `d.cash.held`). **New config:**
`driverCash.limit: 250`.

Cash/takings tracking is completely separate from the driver Bonus
(`driverPay`) — a driver's Bonus total and their held cash never mix.
Completed cash orders add to `d.cash.held`; `ACCEPT` is refused once a
driver's held cash is at or over the £250 limit (the driver must bank it
down first via a Boss cash adjustment) — Rocket never silently keeps
accumulating past the configured limit. `driverCashSummary` reports both
`atOrOverLimit` and `approachingLimit` (≥80% of the limit) so Boss sees it
coming. `adjustDriverCash` never allows the held total to go negative, and
every adjustment is idempotency-key aware and audited.

## 6. Boss controls

**New routes in `server/index.js`** (all header-token-gated the same way
as the existing Boss endpoints): `GET /boss/stock`, `POST
/boss/stock/:code/restock`, `POST /boss/stock/:code/adjust`, `POST
/boss/drivers/:id/stock`, `GET /boss/driverPay`, `PUT /boss/driverPay`,
`GET /boss/loyalty/:phone`, `POST /boss/loyalty/:phone/adjust`, `GET
/boss/rewards`, `GET /boss/debts/:phone/summary`, `POST
/boss/debts/:id/adjust`, `GET /boss/cash`, `POST
/boss/drivers/:id/cash/adjust`. **New UI in `boss/index.html`**: stock
table + restock form, Bonus rate editor, loyalty adjustment form, referral
rewards table, driver cash table + bank/adjust action, enhanced driver
status/mode columns.

Every one of these routes is a thin wrapper around the same `Engine`
methods described in items 1–5 above — **no separate Boss-only business
state was created**; the engine's `state` remains the single source of
truth throughout, exactly as the brief required. `PUT /boss/driverPay` is
the one route that also writes back to `data/config.json` on disk (so a
rate change survives a restart), guarded by validation (`>= 0`) before
anything is written.

## 7. FOOT mode accuracy

**Changed:** `Engine._isNailseaLocation` — now trusts only a resolved
`location.town === 'Nailsea'` (case-insensitive, from a real venue/road
match), never a bare postcode's district. The prior "BS48 = Nailsea"
shortcut is gone — BS48 also covers Backwell, Wraxall, Flax Bourton and
other genuinely different localities, confirmed directly against
`data/locations.json`/`data/roads.json`, never assumed.

A bare or ambiguous BS48 postcode that doesn't resolve to a specific,
confirmed town is treated as "cannot confidently establish this is
Nailsea" — it is not offered to a FOOT driver (a CAR driver remains fully
eligible for it either way). New regression tests
(`test/footModeAccuracy.test.js`) cover a real Nailsea road, Backwell
(same BS48 district, must be excluded), a bare/ambiguous BS48 postcode
(must be excluded), and CAR behaviour (unrestricted).

## 8. Security startup guard

**New file:** `src/startupGuard.js` — `checkStartupSafety({ env, config,
usingDevFallback })`, a small pure function with no side effects. **Wired
into:** `server/index.js`'s `if (require.main === module)` block only —
never into `createApp()` itself, so it cannot affect any existing test
(none of which sets `ROCKET_ENV` or run through that block).

When `ROCKET_ENV` is `staging` or `production`, Rocket now refuses to
start (throws before `.listen()` is ever called) if `config.boss.token`,
`config.gateway.token` or `config.gps.forwardToken` is still the literal
placeholder `CHANGE_ME_BEFORE_GOING_LIVE` (or unset), or if no
`ROCKET_STATE_KEY` was set (`src/store.js`'s existing `usingDevFallback`
flag). The thrown error lists every problem found, not just the first.
`development`/`test` (the default when `ROCKET_ENV` is unset) remain fully
permissive, by design — they may use explicit placeholder/test credentials
freely.

## 9. 30-active-order concurrency test

**New file:** `test/concurrency30Orders.test.js`. An offline stress test:
30 simultaneous customers, 6 drivers (mixed CAR/FOOT, one on BREAK, one
never clocked on), driven through order creation, stock reservation,
offer/FOOT-Nailsea/BREAK filtering, a same-tick multi-driver `ACCEPT` race
per still-offered order, cancellation + reservation release, completion,
driver Bonus, loyalty points, and a full state serialize/reload cycle.

Proves: no order ever ends up with two drivers; no customer's order,
points or data ever leaks into another customer's; stock is never reserved
or deducted twice for the same order; a driver's Bonus and a customer's
loyalty points are never double-awarded by a repeated `COMPLETE`, even
after the state has been serialized and reloaded into a brand-new `Engine`
instance (proving restart-safety, not just in-memory correctness within a
single run).

## 10. README/handover cleanup

`README.md` gained a new "Remaining Offline Fixes (this session)" section
(items 1–9 above, each with its source/test files) at the top, an
"Environment variables (deployment)" reference table, and a corrected,
current test count (364, replacing the stale 96/37 figures left over from
earlier sessions — those older sections are left as-written for
provenance, with a note pointing at the current total). This file
(`CHANGELOG_REMAINING_OFFLINE_FIXES.md`) and `ROLLBACK_REMAINING_OFFLINE_
FIXES.md` are new. No historical changelog content was rewritten or
invented — where an earlier changelog referenced something not present in
this copy, it was left as-is rather than "fixed" without evidence.

## Post-review tightening (four gaps found on independent review)

An independent pass against the finished backend found four real gaps
between the stated rules and what the code actually enforced (the fourth
was found while investigating what first looked like unrelated test
flakiness). All four are fixed, with new regression tests reproducing each
exact scenario found:

1. **7-day debt rule wasn't actually enforced below £100.** `Engine._confirm`
   only blocked a new order once a customer's *overdue* debt total reached
   the £100 threshold — a small debt (e.g. £10) that had genuinely passed
   its 7-day due date did not block anything. The brief's "once it reaches
   7 days it must be paid that day" is its own enforcement rule, not
   conditional on also reaching £100. Fixed: any overdue debt (`> £0`, past
   its `dueAt`) now blocks a new order, with the £100 threshold kept only
   as a distinct, separately-worded reason inside the same check (a large
   overdue debt still gets its own message). One pre-existing test that
   had asserted the *old*, incorrect behaviour (£99 overdue not blocking)
   was rewritten to assert the corrected rule instead — this is a
   deliberate correction of a wrong assertion, not weakening a test to
   dodge a bug.
2. **£250 cash limit could still be exceeded via a same-visit debt
   payment.** `Engine._accept`'s limit check (driver's *currently held*
   cash vs. the limit) is correct on its own, but `Engine._complete` was
   adding the *full* amount reported `PAID` — order total plus any old
   debt settled in the same cash payment — straight onto `d.cash.held`
   with no ceiling, only a post-hoc warning once it was already over.
   Reproduced exactly as reported: driver at £230 held, accepts a £10
   order (correctly allowed, £230 < £250), then the customer also pays a
   £20 old debt in cash at completion → old code recorded £260 held.
   Fixed: `d.cash.held` is now capped at the configured limit; any genuine
   overflow amount raises its own named, Boss-visible review flag
   (`DRIVER_CASH_LIMIT_EXCEEDED`) demanding immediate banking, and the cap
   naturally blocks the driver from accepting further cash jobs (their
   recorded held cash is already at the limit) until Boss banks it down.
3. **`TAKE` didn't touch Driver Bonus or raise its own Boss warning.**
   `Engine._take` reduced `d.stock` and wrote a generic `DRIVER_TAKE`
   audit event, but never affected the driver's Bonus (the brief's
   clarified meaning of "driver wage") and produced no dedicated
   Boss-facing notification — a driver taking stock for themselves looked
   identical, from Boss's side, to ordinary stock bookkeeping. Fixed:
   every `TAKE` now deducts the taken item(s)' menu value from that
   driver's running Bonus total (`d.earnings.totalBonus`, floored at £0,
   never negative), and raises its own review-queue entry every time
   (deliberately not routed through the general `_review()` helper's
   de-duplication, since two separate real-world TAKEs of the same
   item/qty are two separate events, not one repeated condition).

4. **A referral code could occasionally break its own order's parsing** -
   found while chasing what first looked like ordinary test-suite
   flakiness (a different, unrelated test would fail on maybe 2 of every 5
   full-suite runs, always passing on immediate re-run). It was not a
   timing issue at all. Referral codes are randomly generated
   (`RF` + 5 alphanumerics), and purely by chance one can take the exact
   shape of a valid UK postcode (e.g. `RF216CA` reads as outward `RF21` +
   inward `6CA`). `Engine.handleCustomerBurst` was handing the location
   parser the customer's *entire* raw message - item, referral code, and
   real postcode all together - so on that rare code shape, the parser
   matched the code itself as a candidate postcode, resolved it to
   `OUTSIDE_AREA` (`RF21` isn't a real serviceable district), and stopped
   right there ("a person decides; no automatic reply") - silently
   stranding the order in DRAFT even though the real postcode was right
   there in the same text. Reproduced directly and forced deterministically
   offline: about 1 in ~1,000 random codes triggered it, which is exactly
   why it read as suite flakiness - referral tests are the only ones
   combining a random code with a real postcode in one message. **Fixed**
   in `Engine.handleCustomerBurst`: the matched referral code is now
   stripped out of the message text before it ever reaches item or
   location parsing, so it can never be mistaken for anything else.

New tests: `test/remainingOfflineFixes.test.js` — "a debt under £100
STILL blocks once it is overdue", "a debt paid alongside a cash order can
never push recorded held cash over £250", "TAKE deducts the taken item's
menu value from the driver's Bonus", "TAKE bonus deduction floors at £0",
"every TAKE raises its own dedicated, Boss-visible review flag", "a
referral code that happens to look like a UK postcode never breaks
item/location parsing in the same message" (this last one forces the
exact postcode-shaped code rather than relying on randomness to hit it).
Full suite after all four fixes: **364 passing, 0 failing**, confirmed
clean across 5 consecutive full-suite runs (previously ~2 in 5 runs would
show the referral-parsing failure, always on a different test, since which
test hit the random bad code varied run to run).

## Known, deliberately unfinished/out of scope

- Everything already flagged as not-yet-verified-against-a-real-device in
  the README's pre-existing "What is explicitly NOT done" section is
  unchanged by this session — this pass was backend/Boss/offline-test work
  only, per the brief.
- Menu prices remain the placeholder Item A/B/C figures from earlier
  sessions — out of scope for this brief.

## Files touched

- `src/engine.js` — stock, loyalty, debt, referral, cash sections; audit
  trail always durable regardless of a null order; `_confirm`/`_cancel`/
  `_complete` updated to call into all of the above.
- `src/startupGuard.js` — new.
- `server/index.js` — new `/boss/*` routes (item 6); startup-guard wiring
  in the `require.main === module` block; `store`/`config` exposed from
  `createApp`'s return value.
- `boss/index.html` — new Stock/Bonus/Loyalty/Rewards/Cash sections.
- `data/config.json` — `debt`, `stock`, `driverCash` blocks added;
  `rewards` rewritten to `pointsPerItem`.
- `data/messages.json` — `debt_blocked`, `stock_unavailable`,
  `driver_cash_limit` templates added.
- `test/remainingOfflineFixes.test.js`, `test/footModeAccuracy.test.js`,
  `test/bossControls.test.js`, `test/startupGuard.test.js`,
  `test/concurrency30Orders.test.js` — new.
- `test/driverSubsystem.test.js`, `test/driverRelay.adapter.test.js`,
  `test/fullSystem.e2e.test.js` — updated for the FOOT/Nailsea rewrite and
  the loyalty/referral rule changes (see `ROLLBACK_REMAINING_OFFLINE_
  FIXES.md` for exactly which assertions and why).
- `README.md` — this session's section, environment-variable table,
  corrected test count.
