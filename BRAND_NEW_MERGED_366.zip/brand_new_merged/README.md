# Rocket Dispatch — core engine

## What this actually is

A tested order engine and a real HTTP transport server, built and run in
this sandbox against your verified four-district location research
(`Rocket_Coverage_Research_2026-09-23`). **364 tests, all passing as of
this session** (`node --test test/*.test.js`) — not written and assumed,
actually executed. See "Remaining Offline Fixes (this session)" below for
the most recent pass; the sections after it are earlier sessions' work,
left as-written for provenance, with their own test counts as they stood
at the time (now superseded by the 364 total above).

**It is not connected to your phone, Tasker, Signal, or any real customer.**
Nothing here has touched anything live. That was a deliberate line, not an
oversight — see "Given 5 hours" below.

## Remaining Offline Fixes (this session)

This session worked entirely offline against a copy of the project (the
uploaded original was left untouched) to finish nine items an earlier
handover brief flagged as outstanding, plus a documentation cleanup. No
live system, Tasker, phone, or production database was touched; the
Customer app and Driver app were explicitly out of scope and were not
modified. Starting test count at the top of this session: 292. Final:
**364 passing, 0 failing** (`node --test test/*.test.js`).

- **Stock accounting** (`src/engine.js`'s new stock section;
  `test/remainingOfflineFixes.test.js`, `test/concurrency30Orders.test.js`).
  Every product tracked via `restockProduct` gets one record:
  `total` / `reserved` / `available` (`total - reserved`, `Infinity` for an
  untracked code) / `driverHeld` (computed on the fly from every driver's
  own carried-stock ledger, never stored redundantly - see below). Stock is
  reserved when an order is *confirmed* (`Engine._confirm`, all-or-nothing -
  an order that can't be fully reserved is blocked, never partially
  promised), deducted exactly once when the order *completes*
  (`Engine._complete`, idempotent - a repeat `COMPLETE` never deducts
  twice), and released back to available when a confirmed/offered order is
  *cancelled*. Every reservation, deduction, release, restock and manual
  adjustment is written to `state.stockLedger` (a durable audit trail, not
  just an in-memory callback) and `restockProduct`/`adjustStock` both
  accept an idempotency key so a retried Boss request can't double-apply.
  Stock can never go negative - `adjustStock` floors at zero. A low-stock
  alert fires once a product's `available` drops to/under its threshold
  (`data/config.json`'s `stock.defaultLowStockThreshold`, default **3**,
  overridable per product) and clears once restocked above it.
  **Driver-held stock is a separate, pre-existing system** (`d.stock[code]`,
  loaded via `loadDriverStock`, decremented by the driver's own `TAKE`
  command) that this session deliberately left untouched rather than
  redesigned - the new central stock system only *reads* it (via
  `_driverHeldTotal`) to report `driverHeld` in a summary; it never writes
  to it.
- **Loyalty — ONE rule** (`data/config.json`'s `rewards.pointsPerItem`,
  default **3**): 3 points per purchased item, summed across the whole
  order (1 item = 3pts, 2 = 6, 3 = 9, 5 = 15 - the brief's own worked
  examples, tested verbatim). The old `pointsPerOrder`/flat-per-order and
  points-per-pound logic are **removed from config, not just unused**.
  Points are awarded once, on valid completion only (never on
  cancellation), a repeat `COMPLETE` never re-awards, and the balance
  persists across a restart (it's part of `state.customers`, covered by the
  same encrypted, crash-safe store as everything else). Boss can add or
  remove points manually (`adjustLoyaltyPoints`, idempotency-key aware),
  and every manual adjustment is audited.
- **Debt rules** (`Engine._overdueDebtTotal`, `_openDebtsForPhone`,
  `recordDebtPayment`, `adjustDebt`, `debtSummaryForPhone`;
  `data/config.json`'s `debt.blockOverdueAmount` = **£100** and
  `debtReminderDays` = **7**, which doubles as the 7-day debt-age rule).
  A debt can sit outstanding for up to 7 days; on day 7 it's due that day;
  a customer whose *overdue* debt (summed across all their open debts) hits
  £100+ is blocked from confirming a **new** order until it's paid down
  (`Engine._confirm`). Paying while a new order is in flight allocates the
  payment correctly - the order's own total is covered first, and any
  excess pays down open debts oldest-first (the brief's own worked example
  - existing debt £20, new order £10, customer pays £30 → debt clears to
  £0, order is paid, nothing left over - is a test). An
  accidental *overpayment* beyond both is flagged for Boss review rather
  than silently vanishing or creating negative debt. `debtSummaryForPhone`
  reports a `returningDebtor` flag (more than one debt on file, ever) for
  Boss visibility. Every payment and manual adjustment is idempotency-key
  aware and audited.
- **Referrals — ONE FREE ITEM, not points** (`Engine._applyFreeItemReward`,
  `_availableFreeItemReward`; `state.freeItemRewards`). One-time referral
  codes are unchanged; what changed is the reward itself - completing a
  qualifying order under someone's code creates a `freeItemRewards` entry
  for the referrer (`status: 'earned'`/`'available'`), auto-redeemed to
  discount the cheapest item on their *next* order, then marked
  `'redeemed'` - it can never be used twice, and self-referral is rejected.
  A redeemed free item correctly reduces stock the same as a paid one (it's
  still a real item leaving the shelf). Boss can view every reward and its
  state (`GET /boss/rewards`).
- **£250 driver cash limit** (`data/config.json`'s `driverCash.limit`,
  default **£250**; `d.cash = { held, adjustments }` on every driver
  record). Completed cash orders add to a driver's held cash; the Bonus
  (`driverPay`) is a completely separate figure, never mixed with it.
  `ACCEPT` is refused once a driver's held cash is at/over the limit - "do
  not silently continue accumulating beyond the configured limit" - until
  Boss banks it down (`adjustDriverCash`, never allows the total to go
  negative). `driverCashSummary` reports `atOrOverLimit` and
  `approachingLimit` (80%+) so Boss can see it coming, not just after the
  fact. Every adjustment is idempotency-key aware and audited.
- **Boss controls finished** (`server/index.js`'s `/boss/*` routes;
  `boss/index.html`; `test/bossControls.test.js`). New endpoints for all of
  the above: stock (view, restock, adjust, load a driver's carried stock),
  Bonus rate (view/edit `driverPay.firstItemBonus`/`extraItemBonus`,
  persisted to `data/config.json`), loyalty (view/adjust a customer's
  points), referral rewards (view), debt (per-customer summary, manual
  adjustment - payment recording already existed), driver cash (view every
  driver's held cash against the limit, bank/adjust it). Every mutating
  route is gated by the same `X-Boss-Token` header check as the existing
  Boss endpoints. **The engine (`state`) remains the single source of
  truth throughout - no separate Boss-only business state was created; the
  Boss app only ever reads and writes through the same `Engine` methods the
  SMS/driver flows use.**
- **FOOT mode accuracy** (`Engine._isNailseaLocation`;
  `test/footModeAccuracy.test.js`). FOOT drivers now only ever receive a
  job whose location resolves to a *real, road/venue-matched* Nailsea town
  (`location.town === 'Nailsea'`, case-insensitive) - the previous
  "BS48 = Nailsea" postcode-district shortcut is gone, because BS48 also
  covers Backwell, Wraxall, Flax Bourton and other genuinely different
  localities (confirmed against `data/locations.json`/`data/roads.json`,
  never guessed). A bare or ambiguous BS48 postcode with no resolved town
  is treated as "cannot confidently establish this is Nailsea" and is
  **not** offered to a FOOT driver, even though a CAR driver remains fully
  eligible for it. Regression tests cover a real Nailsea road, Backwell
  (same BS48 district, must be excluded), a bare/ambiguous BS48 postcode
  (must be excluded), and CAR behaviour (unrestricted).
- **Security startup guard** (`src/startupGuard.js`;
  `test/startupGuard.test.js`). Rocket now refuses to start when
  `ROCKET_ENV=staging` or `ROCKET_ENV=production` if `config.boss.token`,
  `config.gateway.token` or `config.gps.forwardToken` is still the literal
  placeholder `CHANGE_ME_BEFORE_GOING_LIVE` (or unset), or if no
  `ROCKET_STATE_KEY` was set (i.e. `src/store.js` would fall back to its
  fixed, publicly-known development encryption key) - the error lists
  *every* problem found, not just the first. `development`/`test`
  (the default when `ROCKET_ENV` is unset, which is every existing test and
  every plain `node server/index.js` run today) are **not** enforced, so
  this can't and doesn't break anything already working - see it run live:
  `ROCKET_ENV=production node server/index.js` refuses to start with the
  placeholder config shipped in this repo; a plain `node server/index.js`
  starts exactly as before.
- **30-active-order concurrency test**
  (`test/concurrency30Orders.test.js`). An offline stress test driving 30
  simultaneous customers, 6 drivers (mixed CAR/FOOT/BREAK/OFF), through
  order creation, stock reservation, offer/FOOT-Nailsea/BREAK filtering, a
  same-tick multi-driver ACCEPT race per order, cancellation and
  reservation release, completion, Bonus, loyalty, and a full state
  save/reload cycle. Proves: no order ever ends up with two drivers, no
  customer's order/points/data leaks into another customer's, no stock
  reservation or deduction ever happens twice for the same order, no
  driver's Bonus or a customer's loyalty points are ever double-awarded by
  a repeated `COMPLETE`, and every one of those invariants still holds
  after the state is serialized and reloaded into a fresh `Engine` instance
  (restart-safety, not just in-memory correctness).

Everything above lives in the same `Engine` (`src/engine.js`) as the rest
of the system - no parallel state, no shadow database. See each numbered
item's source file/test file above for the exact behaviour; nothing in
this section is aspirational or described-but-not-built - every rule has a
passing test exercising it, listed next to it.

### Post-review tightening (four real gaps found after the above, all fixed)

An independent review against the finished backend found four genuine
gaps and reproduced each one directly before it was fixed - not test
tweaks, actual behaviour changes, each with its own regression test in
`test/remainingOfflineFixes.test.js`:

1. **7-day debt block wasn't enforced below £100** - a debt that had
   genuinely passed its 7-day due date didn't block a new order unless it
   also reached £100 overdue. Fixed: any overdue debt now blocks, £100+
   kept as its own separately-worded reason inside the same check.
2. **£250 cash limit could still be exceeded** - a customer settling an
   old debt in cash at the same time as paying for a new order could push
   a driver's recorded held cash over the limit (reproduced: £230 held →
   accept a £10 job → complete with a £30 cash payment → old code recorded
   £260). Fixed: held cash is now capped at the limit and the genuine
   overflow raises its own named, Boss-visible review flag demanding
   immediate banking.
3. **`TAKE` didn't touch Driver Bonus or raise a dedicated warning** - a
   driver taking stock for themselves had no effect on their Bonus ("driver
   wage") and produced no Boss-facing notification distinct from ordinary
   stock bookkeeping. Fixed: every `TAKE` now deducts the taken item(s)'
   menu value from that driver's Bonus (floored at £0) and raises its own
   review-queue entry every time.
4. **A referral code could occasionally break its own order's parsing** -
   found while chasing what looked like test-suite flakiness. A randomly
   generated referral code (`RF` + 5 alphanumerics) can, purely by chance,
   take the exact shape of a valid UK postcode (`RF216CA` reads as
   `RF21 6CA`); the location parser was seeing the customer's whole raw
   message and could match the code itself as a bogus postcode, resolve it
   to `OUTSIDE_AREA`, and stop - silently stranding the order in DRAFT even
   though the real postcode was right there in the same text (about 1 in
   ~1,000 random codes). Fixed: the matched referral code is now stripped
   from the message before item/location parsing ever sees it.

See `CHANGELOG_REMAINING_OFFLINE_FIXES.md`'s "Post-review tightening"
section for the full detail on each.

## What's real and tested

- **Location resolver** (`src/locationIndex.js`, `src/locationConversation.js`)
  wired to all 2,672 active + 1,222 terminated postcodes and 561 venues
  across BS48/BS49/BS21/BS20. Passes all 12 multi-message acceptance cases
  that came with your research pack (`data/source/conversation_tests.json`),
  e.g. "grove" → "nailsea" resolves to Grove Sports Centre & Social Club;
  "station" → "portishead" correctly refuses to route to the not-yet-open
  station instead of guessing.
- Three data-quality bugs found and fixed on import, documented in
  `data/corrections.json` rather than silently edited into the source files:
  Scoop and Spice (Yatton) was mistagged with Co-op aliases (looks like a
  substring match on "sCOOP"); the airside Burger King at Bristol Airport is
  excluded as a meeting point per your research README's own warning.
- **Order engine** (`src/engine.js`): draft → confirmed → offered → assigned
  → en route → arrived → completed, with the 30-minute draft timeout (never
  applied once a driver is assigned), first-valid-ACCEPT-wins with duplicate
  rejection, each customer message sent exactly once, bundle/tier pricing
  computed exactly, referral codes that reject self-referral and double
  redemption, debt reminders after the configured number of days.
- **Crash-safe persistence** (`src/store.js`): state is written atomically
  (temp file + rename) so a restart doesn't lose in-flight orders. Tested
  with a real save/reload and with a deliberately corrupted state file,
  which is refused rather than silently loaded as empty.
- **HTTP transport server** (`server/index.js`): what Tasker would call for
  SMS, and what a future Signal adapter would call for driver messages.
  Proven end-to-end in `test/server.e2e.test.js` with real HTTP requests
  against a live server instance in this sandbox: greeting → order → real
  postcode → driver accept → arrived → complete → referral code, then a
  simulated Tasker retry (same message ID) that correctly does nothing
  twice, then a full server restart that picks the order back up from disk.

Run it yourself: `node --test test/*.test.js` (96 tests as of this session,
including one full-system end-to-end test that runs the entire path in one
go: a customer SMS order, a Signal-driven driver offer/accept, GPS-only
automatic customer updates, a partial-payment completion that creates a
debt and redeems a referral code, a real server restart from disk, and the
Boss app's own API confirming all of it survived).

## Independent review pass (this session)

The original build's own README flagged "no independent verify pass" as a
gap. A fresh review (an agent that hadn't seen the code being written, per
the project's own "checked by someone who didn't write it" standard) went
through `src/engine.js` and `src/locationConversation.js` end to end. It
found no working double-assignment or double-payment path through the
driver state machine, and confirmed the ACCEPT race protection, COMPLETE
idempotency, and crash-safe persistence hold up. It did find and I fixed:

- A "yes" reply that went on to name a different real venue
  ("yeah not that one, the crown please") was read as confirming the
  *rejected* place, because the yes/no check ran before checking whether
  the rest of the message named a correction.
- A shared location pin was treated as *less* precise than a postcode for
  driver messaging (missing `exactPointKnown`), backwards from reality -
  a pin is an exact point, a postcode is an area centroid.
- A pin's "not verified inside the service area" flag was set but never
  read anywhere - pins outside BS48/BS49/BS21/BS20 could confirm with no
  human ever glancing at them. Now flagged for review at confirmation
  (without blocking the order - there's no proof it's outside either).
- The post-confirmation "did the customer send a different location?"
  check compared a bare venue name against a fully formatted driver label,
  so it false-positived on almost every re-mention of the same venue.
- Attaching a second referral code to an order silently orphaned the
  first one - locked forever, never redeemable, never released.
- `server/index.js`'s burst de-duplication used `Array.some()` with a
  side-effecting check, which could mark a genuinely new message as
  "seen" while still discarding it unprocessed if an already-seen message
  happened to sit earlier in the same burst - a real, permanent
  message-loss path, not just a duplicate-handling nuance.
- The GPS staleness check (added with the Traccar integration) measured
  from when an order was first offered rather than from when the
  responding driver actually accepted it, so a driver accepting a job
  that had sat unaccepted for a while could be flagged immediately.

Not fixed, flagged for later: `/sms/inbound` acknowledges Tasker (HTTP 202)
before the message is persisted to disk - a crash within the ~6-second
burst window could lose an already-acknowledged message with no trace.
Narrow window, real gap. Also: the `Math.round(x*100)/100` money-rounding
pattern used for totals/change/debt is a known-fragile idiom at cent
boundaries - latent today only because the placeholder menu has whole-pound
prices; worth a proper fixed-point pass before real (non-round) prices go
in.

## New this session: automatic GPS-triggered driver-status messages

`Engine._maybeAutoGpsEvents` (called from `updateDriverLocation`) now sends
the same customer messages a driver's own `5 MIN` and `HERE` texts send,
triggered by distance instead of requiring the driver to remember to text
them: once the GPS-derived ETA drops to `config.gps.autoFiveMinEtaMinutes`
(default 5), and once the driver is within
`config.gps.autoArrivalRadiusMetres` (default 120m) of the meeting point on
a fix accurate enough to trust (`autoArrivalMaxAccuracyMetres`, default
60m). Shares the same de-duplication keys as the manual commands, so
whichever fires first - GPS or the driver's own text - the customer only
ever gets each message once. Only applies to a driver who has actually
linked a Traccar device; unlinked drivers still rely on manual commands.

## New this session: Tasker gateway reliability, confirmation, and security fixes

`tasker/RocketDispatchSMSGateway.prj.xml` and `tasker/TASKER_SETUP.md` were
both revised:

- **Reliable incoming SMS variables.** `%SMSRF`/`%SMSRB` are Tasker's own
  *global* "last received text" variables, not values scoped to one event
  firing, so a second text arriving mid-run could overwrite them before
  they're read. Task 1 now captures them into local variables as its very
  first action, before any network call, and skips forwarding when the
  body is empty (a real, documented case: `%SMSRB` is only set for SMS, not
  MMS).
- **Confirm the SMS actually sent before acknowledging it.** `sendSMS()`
  returns a boolean; the previous version of the file called it but never
  read that return value, only catching a thrown exception - so a call
  that returned `false` without throwing would have been acknowledged as
  sent anyway. Fixed. Tasker's own docs are explicit that even this return
  value only means "executed without error," not "delivered" - real
  send/fail confirmation exists (the native Send SMS action's "SMS
  Success"/"SMS Failure" events) but this session couldn't verify its exact
  field layout against a real device, so it's a documented manual upgrade
  step (`TASKER_SETUP.md` section 4a) rather than guessed XML.
- **Secured the phone↔server connection.** `/sms/inbound`, `/sms/outbound/*`
  and every `/driver/*` endpoint had **no authentication at all** -
  anyone who could reach the server's port could inject a fake customer
  order or fake driver reply. Both Tasker tasks and the Signal adapter now
  send an `X-Gateway-Token` header, checked server-side against
  `config.gateway.token` (`server/index.js`'s `gatewayTokenOk()`, tested in
  `test/server.e2e.test.js`). `TASKER_SETUP.md` also covers securing the
  connection itself (Tailscale or a real `https://` reverse proxy) since a
  shared token doesn't encrypt plain `http://` traffic.

## New this session: security/privacy hardening before real customer testing

A pass specifically aimed at what shouldn't be true right before this
touches a real customer or driver's data. Nothing here rebuilt working
parts — the engine's order/driver logic, GPS auto-messaging, Signal
retry/dedup, and the customer SMS/debt/referral/Boss flows are unchanged
in behaviour, only in how they're protected.

- **State encrypted at rest** (`src/store.js`). `state.json` — customer
  phone numbers, debts, full order history — is now written and read as an
  AES-256-GCM envelope, not plain JSON. Key comes from `ROCKET_STATE_KEY`
  (env var, 64 hex chars); without it the server falls back to a fixed
  development key and warns loudly on startup, so it's obvious in the logs
  if this was never set for real. See `data/config.json`'s new note.
- **Master menu genuinely off the VPS, not just access-restricted**
  (`src/menuSync.js`, `boss/index.html`'s `localStorage`-backed editor vs.
  `data/menu.sync.json`). The order-processing engine only ever reads the
  minimal synced projection, and the VPS never stores the Boss-owned master
  (which can carry internal-only fields like `costPrice`) at all - not on
  disk, not in memory beyond the single request that derives the
  projection, with validation happening *before* anything touches disk. The
  master lives only in the Boss app's own browser storage, with
  export/import backup built into the page. See `boss/BOSS_APP.md`.
- **Driver isolation and no-PII-to-drivers, verified with new tests, not
  just assumed.** The engine's existing ownership checks (a driver can't
  accept, act on, or learn anything about another driver's order; reply
  templates never interpolate phone numbers) were already correct — this
  session added `test/engine.test.js` coverage that actually proves it,
  including across an accept race between two drivers legitimately offered
  the same open job.
- **`/track/:orderId` requires a real per-order secret.** Each order now
  gets a random `trackingToken` at creation; the order id alone (a
  guessable 4-digit code) is no longer enough to see a stranger's live
  driver location. See `docs/TRACCAR_INTEGRATION.md`.
- **Every server-to-server secret moved out of URLs and into headers.**
  The Traccar forward token (`X-Gps-Token`), the Boss token
  (`X-Boss-Token`), and the gateway token (`X-Gateway-Token`, already
  header-only from the prior session) are no longer accepted as
  `?token=...` — a URL-based secret ends up in access logs, proxy logs,
  and browser history. `boss/index.html`'s own client code was updated to
  match. The customer-facing tracking link is the deliberate exception:
  `/track/:orderId`'s per-order token is still accepted via `?token=...`
  since it's meant to be shared as a link.
- **Signal transport rebuilt on the existing signal-cli setup, not a new
  system.** The prior session's adapter talked to `signal-cli-rest-api`, a
  third-party Docker wrapper; the actual production setup runs `signal-cli`
  itself. Rather than add a second Signal system, `signal/adapter.js` was
  rewired onto a new low-level JSON-RPC client (`signal/signalCliClient.js`)
  that speaks signal-cli's own daemon protocol directly. The envelope shape
  signal-cli's JSON-RPC daemon emits is identical to what the REST wrapper
  always mirrored, so the adapter's dedup/parsing/retry/ack logic needed no
  changes — only the transport underneath it. See
  `docs/SIGNAL_INTEGRATION.md`.

New tests added for all of the above:
`test/boss.test.js` (unauthorised Boss access, menu resync after restart),
`test/server.e2e.test.js` (unauthorised tracking, bad Traccar
authentication), `test/engine.test.js` (driver-to-driver isolation, phone
number never leaking to a driver), `test/signalCliClient.test.js` +
`test/signalAdapter.test.js` (Signal retry/duplicate handling), and the
existing `test/fullSystem.e2e.test.js` restart-recovery test now runs
against the encrypted store and the master/sync menu split as well.
`node --test test/*.test.js` — 96 tests, all passing.

## New this session: the real driver app vendored in (`driver-app/`)

A separate, already-built native Android driver app ("Rocket Driver
Private", v1.1.5) was brought into this repo as documented source — not
written in this session, and deliberately not rebuilt or merged into
`server/index.js`/`src/engine.js`. It talks to its own dispatch relay at a
private Tailscale address, independently of the engine in this repo, with
its own pairing flow, encrypted local vault, HKDF-derived channel
encryption, and gated GPS reporting. Signal (above) and this app are now
two independent driver channels: Signal talks directly to this repo's
engine and is fully tested here; this app talks to its own relay and
nothing here has been changed to depend on it. See `docs/DRIVER_APP.md`
for the full picture, including exactly what was and wasn't verified in
this session (the relay's real server-side behaviour was not — only the
Android client's expectations of it were read) and why connecting this
repo's engine to that relay directly is scoped as separate future work
rather than guessed at here.

## New this session: offline Driver-relay adapter (`driver-relay/`)

A tested, offline integration layer that would let the existing Driver APK
above work against this repo's own engine as the business-logic processor
**behind the existing relay** — the app, its pairing, and its `:8911` relay
are all left completely untouched; this only adds a new adapter that would
sit at the relay's backend interface (`:8912`). Built and tested entirely
offline: real RD1 envelope crypto (`driver-relay/protocol.js`, ported from
the app's own `Protocol.java`/`Crypto.java`), a real command-validation
mirror of the app's own client-side rules (`driver-relay/commands.js`), and
15 tests (`test/driverRelay.adapter.test.js`) against a protocol-faithful
mock of the `:8912` interface — covering snapshot/offer/accept, ETA/HERE,
payment full/part/owe, idempotency, receipt matching, and reconnect/retry.
Nothing here has been deployed or pointed at the real relay. See
`driver-relay/README.md` for the full command mapping, exactly what would
still need connecting for real, and an honest gap list of what the app/
relay can do that this doesn't support yet.

## New this session: the real customer app connected (`customer-app/`, `customer-relay/`)

The real "Rocket V35 Test" customer app's backend (recovered from a second,
more complete handover pack - not the placeholder-only first pack; see
`docs/CUSTOMER_APP.md` for the full provenance story) is now vendored in at
`customer-app/`, adapted to run against rocket-dispatch instead of V35, and
connected via a new adapter, `customer-relay/`, on the same "don't touch
the engine, bridge over its existing HTTP surface" pattern as `driver-relay/`
and `signal/`. Kept: the real dark/green UI, Menu/Basket/Frenzy/Rewards/More
navigation, invite+PIN auth, cash-only checkout, idempotent order
submission - none of it rebuilt. Added: structured postcode/street/venue/
GPS-pin location, a customer-safe order-status view, and rocket-dispatch as
the authoritative price/dispatch backend instead of V35.

This was verified **live**, not just in unit tests: a real
`server/index.js`, a real `customer-app/server.py`, and a real
`customer-relay/run.js` running as three real processes drove the
developer prompt's full 15-step flow (including two independent real
process restarts, with state recovered from disk both times, and a
retried order proven not to duplicate), a two-customer/two-driver
multi-order isolation test, and all six requested privacy checks. See
`customer-relay/README.md`'s "What was verified live" and the delivered
final report for the transcript. The one deliberate staging substitution
(no `sqlcipher3` vendor build in this sandbox, so `customer.db` runs
unencrypted here) is documented and must be reversed before any real
customer data is involved. No Android SDK or signing key was available
here either, so no new APK was built or signed - see `docs/CUSTOMER_APP.md`
"APK" for what a real rebuild still needs.

## What is explicitly NOT done — given 5 hours was not enough for all of it

- **A Signal adapter now exists** (`signal/adapter.js`, run via
  `signal/index.js`), talking to `signal-cli`'s own JSON-RPC daemon
  directly (the existing production setup, not a third-party wrapper - see
  "New this session: security/privacy hardening" above), proven end-to-end
  in `test/signalCliClient.test.js`, `test/signalAdapter.test.js` and
  `test/fullSystem.e2e.test.js` against a mocked signal-cli daemon - not
  yet against a real Signal account. See `docs/SIGNAL_INTEGRATION.md`.
  Unlike Tasker's undocumented XML format, signal-cli's JSON-RPC protocol
  is publicly documented and stable, which is why this could be real,
  runnable, tested code rather than only a design.
- **A Tasker project file now exists** (`tasker/RocketDispatchSMSGateway.prj.xml`),
  built from Tasker's own developer documentation rather than from memory
  (sources in `tasker/TASKER_SETUP.md`), but still **not run against a real
  Android device** - that limitation hasn't changed, only how much of the
  design is grounded rather than guessed. Two pieces (the repeating polling
  schedule, and the stronger native-action send confirmation added this
  session) were deliberately left as manual steps rather than guessed XML
  blocks, because I couldn't find a verified source for their internal
  shape. Read `tasker/TASKER_SETUP.md` before enabling either profile for
  real - it has an action-by-action checklist for exactly this reason.
  `server/index.js` still documents the underlying HTTP contract
  (`POST /sms/inbound`, `GET /sms/outbound/pending`, `POST /sms/outbound/ack`)
  if you'd rather build the Tasker side from scratch.
- **Traccar/GPS integration is now wired and tested**, not yet run against a
  real Traccar server or phone. See `docs/TRACCAR_INTEGRATION.md` for the
  full picture, but in short: the engine can now take a driver's live
  position (via Traccar's JSON "position forwarding" webhook,
  `POST /gps/traccar`, header-authenticated), compute a distance-based ETA,
  and flag an order for review if the assigned driver's GPS goes stale or
  never shows up. `GET /track/:orderId` now requires a real per-order
  secret token (`?token=...` or `X-Tracking-Token`), not just the order id.
  What's still missing: a real customer-facing tracking page (there's only
  a JSON endpoint today) and any verification against an actual Traccar
  deployment and a real phone.
- **A Boss app now exists** (`boss/index.html`, admin API in
  `server/index.js` under `/boss/*`, documented in `boss/BOSS_APP.md`,
  tested in `test/boss.test.js`): review queue, debt payments, a read-only
  view of referral codes/drivers/orders, and a JSON-based menu editor
  (`Engine.setMenu()`, validated before anything is written to disk, and
  split into a Boss-owned master kept only in the browser's own
  `localStorage` - never on the VPS - plus a minimal synced projection the
  order engine does read - see "New this session" above).
  Header-token-gated the same way the gateway endpoints are. Not tested against a real
  browser - the server-side routes are covered by real HTTP tests, but the
  page's own JavaScript has not been exercised outside this write-up.
- **Menu and prices are placeholders.** `data/menu.sync.json` ships with
  sample items (Item A/B/C) — replace before any real use, by opening the
  Boss app and saving a real menu (which becomes the browser's local
  master going forward). The numbers are still fictional until real ones
  go in — explicitly held back this session at your own request.
- **Message wording in `data/messages.json` is proposed, not approved** —
  only the three lines marked `FIXED` are exact wording from your brief.
- **No independent verify pass on this session's own new code** (the Boss
  app, the gateway-token fix, the Tasker changes). The engine and location
  conversation code got a fresh-eyes review in an earlier session (see
  above) - this session's additions have real tests but haven't had that
  same independent pass. Worth doing before anything here touches a real
  customer, same as the caveat that already applied to the original build.

## Environment variables (deployment)

| Variable | Required when | Purpose |
|---|---|---|
| `ROCKET_STATE_KEY` | Always for real data; enforced in staging/production | 64 hex chars / 32 bytes (`openssl rand -hex 32`). Encrypts `state.json`. Keep this key stable for the installation. |
| `ROCKET_BOSS_TOKEN` | Staging/production | Overrides `config.boss.token`; gates `/boss/*`. |
| `ROCKET_GATEWAY_TOKEN` | Staging/production | Overrides `config.gateway.token`; gates `/sms/*` and `/driver/*`. Must match the token provisioned into Tasker / Signal adapter. |
| `ROCKET_GPS_FORWARD_TOKEN` | Staging/production | Overrides `config.gps.forwardToken`; gates `/gps/traccar`. |
| `ROCKET_ENV` | Deploying to staging/production | Set to `staging` or `production` to enable the startup guard. |
| `ROCKET_PORT` | Optional | HTTP port for `server/index.js` (default `8787`). |
| `ROCKET_STATE` | Optional | Path to `state.json` (default `data/state.json`). |

`data/config.json` deliberately keeps harmless placeholder values for the three API tokens.
Real staging/production secrets should be injected through the environment variables above.
The startup guard refuses staging/production if a placeholder remains after environment overrides,
or if `ROCKET_STATE_KEY` is missing.

## Data provenance

`data/locations.json` is generated from `data/source/` (your verified
research pack, SHA-256 checked on read) by `scripts/import_locations.py`.
Nothing is invented: blank stays blank, inferred aliases stay labelled
inferred, terminated postcodes stay terminated. To bring in a newer research
pack, replace the files in `data/source/` and re-run the script — no code
change needed. The importer refuses to finish if the resulting counts don't
match the pack's own `coverage.json` totals.

## Honest bottom line on timing

Five hours got a tested engine and a proven transport contract — not a
system safe to point at real orders. The path from here to that is the
same shape as before: a real Signal bridge, Tasker wiring against the
contract above, Traccar, the Boss app, and testing with real test
contacts before real customers. Nothing here shortens that further; it
gives you a solid, verified foundation to build the rest on rather than
starting from zero again.
