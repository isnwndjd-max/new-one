# customer-native-app/ — the real Android/iOS wrapper, vendored as-is

`source/` is an unmodified copy of `Exact_V35_Native_Source/` from the
developer handover: the real Capacitor wrapper that produces the
`co.rocket.customer.v35test` APK. `APK/Rocket_V35_Test_CORRECTED.apk` is
the real, signed, verified APK from that same handover (SHA-256 confirmed
to match the handover's own audit log - see `docs/CUSTOMER_APP.md`).

Nothing in `source/` was edited in this session — same reasoning as
`driver-app/`'s own vendored source: it's documented, not rebuilt.

## What a real staging rebuild still needs to change

`source/capacitor.config.json`'s `server.url` currently points at a
Cloudflare *quick tunnel*
(`https://opinions-heads-criticism-safe.trycloudflare.com`) — these are
ephemeral by design and very likely already dead. `source/www/runtime-config.js`
points `window.ROCKET_CONFIG.apiBase` at a second, separate quick-tunnel
URL. Neither is a secret (no credential, just a public hostname), so
they're left as-is here rather than silently edited — but a real staging
build must point both at wherever `customer-app/` is actually being
served for that build (a stable staging hostname/Tailscale address, not
another ephemeral quick tunnel), and switch `cleartext` on only if that
hostname is genuinely plain HTTP during testing, never in a real release.

## Why no new APK was built or signed in this session

This sandbox has no Android SDK (`ANDROID_HOME` unset, no
`sdkmanager`/`apksigner`) and, correctly, was never given the private
signing key needed to produce a real installable update — same position
this project has always taken with the Driver app's own `build_driver.py`.
Building a real staging APK from the (now-adapted) `customer-app/` means:

1. Point `source/capacitor.config.json`'s `server.url` at the adapted
   `customer-app/` staging deployment (see above), or switch to bundling
   `www/` locally and drop the `server.url` override entirely so the app
   ships the adapted UI inside the APK instead of loading it live.
2. `npx cap sync android` to refresh `source/android/app/src/main/assets/`.
3. Build + sign with whatever environment already holds the real
   `co.rocket.customer.v35test` signing key — never this sandbox.
4. Bump `versionCode` in `source/android/app/build.gradle` (currently `1`)
   so the device accepts the update without an uninstall (Android blocks
   downgrades — the Driver app's own `RELEASE_NOTES.txt` makes the same
   point).
