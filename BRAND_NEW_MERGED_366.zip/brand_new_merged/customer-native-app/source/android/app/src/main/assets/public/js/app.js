import {accountLabels} from './v35_account_view.js';
import {mountPointsSpin} from './v35_spin_ui.js';
const API_BASE=(window.ROCKET_CONFIG&&window.ROCKET_CONFIG.apiBase||'').replace(/\/$/,'');
const $=id=>document.getElementById(id);
const state={token:localStorage.getItem('rocket.customer.token')||'',menu:[],prizes:[],vault:[],profile:null,reward:{spins:0,spendRemainderPence:0,points:0,pointsRemainderPence:0,pointsPerPound:10,pointsSpinCost:100},debt:{available:false,owedPence:null},sync:{status:'AWAITING_V35'},canCheckout:false,accountRefreshBusy:false,loyaltyRedemptions:[],basket:JSON.parse(localStorage.getItem('rocket.customer.basket')||'{}'),category:'All',page:'menu',spinning:false,scratchResult:null,scratchStarted:false,scratchPreApp:false};
const pointSpins=mountPointsSpin({session:()=>state.token,refreshAccount,freeSpinBusy:()=>state.spinning});
const fmt=p=>'£'+(Number(p||0)/100).toFixed(2);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,options={}){
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  if(state.token)headers.Authorization='Bearer '+state.token;
  const res=await fetch(API_BASE+path,{...options,headers});
  let body={};try{body=await res.json()}catch{}
  if(res.status===401){signOut(false);throw new Error(body.error||'Invite session expired')}
  if(!res.ok)throw new Error(body.error||'Request failed');
  return body;
}
function toast(msg){const e=$('toast');e.textContent=msg;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1500)}
function saveBasket(){localStorage.setItem('rocket.customer.basket',JSON.stringify(state.basket))}
function showGate(){$('invite-screen').hidden=false;$('pin-setup-screen').hidden=true;$('customer-app').hidden=true;const saved=localStorage.getItem('rocket.customer.phone')||'';if(saved)$('login-phone').value=saved}
function showPinSetup(){$('invite-screen').hidden=true;$('pin-setup-screen').hidden=false;$('customer-app').hidden=true}
function showApp(){$('invite-screen').hidden=true;$('pin-setup-screen').hidden=true;$('customer-app').hidden=false}

async function redeemInvite(){
  const code=$('invite-code').value.trim();$('invite-error').textContent='';$('invite-submit').disabled=true;
  try{const r=await api('/api/invite/redeem',{method:'POST',body:JSON.stringify({code})});state.token=r.token;localStorage.setItem('rocket.customer.token',r.token);if(r.phone)localStorage.setItem('rocket.customer.phone',r.phone);if(r.needsPin){showPinSetup();toast('Invite accepted');return}await enterApp()}
  catch(e){$('invite-error').textContent=e.message}
  finally{$('invite-submit').disabled=false}
}
async function enterApp(){
  await bootstrap();
  void pointSpins.inspect();
  $('invite-screen').hidden=true;
  $('pin-setup-screen').hidden=true;
  $('customer-app').hidden=true;
  state.scratchPreApp=true;
  setTimeout(()=>showScratchModal(true),120);
}
async function setupPin(){
  const pin=$('new-pin').value.trim(),confirm=$('confirm-pin').value.trim();$('pin-setup-error').textContent='';
  if(!/^\d{4,6}$/.test(pin)){$('pin-setup-error').textContent='Choose a 4 to 6 digit PIN.';return}
  if(pin!==confirm){$('pin-setup-error').textContent='The PINs do not match.';return}
  $('pin-setup-submit').disabled=true;try{await api('/api/pin/set',{method:'POST',body:JSON.stringify({pin})});$('new-pin').value='';$('confirm-pin').value='';await enterApp()}catch(e){$('pin-setup-error').textContent=e.message}finally{$('pin-setup-submit').disabled=false}
}
async function pinLogin(){
  const phone=$('login-phone').value.trim(),pin=$('login-pin').value.trim();$('pin-login-error').textContent='';$('pin-login-submit').disabled=true;
  try{const r=await api('/api/pin/login',{method:'POST',body:JSON.stringify({phone,pin})});state.token=r.token;localStorage.setItem('rocket.customer.token',r.token);if(r.phone)localStorage.setItem('rocket.customer.phone',r.phone);$('login-pin').value='';await enterApp()}catch(e){$('pin-login-error').textContent=e.message}finally{$('pin-login-submit').disabled=false}
}
function reconcileMenuBasket(){
  let changed=false;
  for(const [code,qty] of Object.entries(state.basket)){
    if(!state.menu.some(p=>p.code===code&&p.active)||!Number.isInteger(qty)||qty<1||qty>30){delete state.basket[code];changed=true;}
  }
  if(changed){saveBasket();toast('Menu updated. Unavailable items were removed.');}
}
async function bootstrap(){
  const r=await api('/api/bootstrap');state.menu=r.menu||[];state.prizes=r.weeklyPrizes||[];state.vault=r.vault||[];state.profile=r.profile||{};state.reward=r.reward||state.reward;acceptV35Account(r);state.loyaltyRedemptions=r.loyaltyRedemptions||[];
  $('delivery-area').textContent=state.profile.areaLabel||'Nailsea, BS48';
  reconcileMenuBasket();renderCategories();renderProducts();renderBasket();renderRewards();renderWeeklyPrizes();seedReels();
}
function nav(name){
  state.page=name;document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
  document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.nav===name));
  if(name==='basket')renderBasket();if(name==='rewards')renderRewards();if(name==='frenzy'){renderSpinCounts();renderWeeklyPrizes();void pointSpins.inspect()}if(name==='more')refreshAccount();
  window.scrollTo({top:0,behavior:'smooth'});
}
function acceptV35Account(r){
  state.debt=r.debt||{available:false,owedPence:null,status:'AWAITING_V35'};
  state.sync=r.sync||{status:'AWAITING_V35',lastCheckedAtMs:null};
  state.reward=r.reward||{points:null,pointsSource:null};
  state.canCheckout=false;
}
async function refreshAccount(){
  if(!state.token||state.accountRefreshBusy)return;
  state.accountRefreshBusy=true;const token=state.token;
  try{
    const r=await api('/api/account');if(token!==state.token)return;
    if((r.sync?.lastCheckedAtMs||0)<(state.sync?.lastCheckedAtMs||0))return;
    acceptV35Account(r);state.menu=r.menu||[];
    if(!state.menu.some(p=>(p.category||'Other')===state.category))state.category='All';
    reconcileMenuBasket();renderCategories();renderProducts();renderBasket();renderRewards();
  }catch(e){
    if(token!==state.token)return;
    state.sync={...state.sync,status:'OFFLINE',stale:true};
    state.canCheckout=false;renderRewards();renderBasket();
  }finally{state.accountRefreshBusy=false}
}

function renderCategories(){
  const cats=['All',...new Set(state.menu.filter(x=>x.active).map(x=>x.category||'Other'))];
  $('category-tabs').innerHTML=cats.map(c=>'<button class="'+(c===state.category?'active':'')+'" data-cat="'+esc(c)+'">'+esc(c)+'</button>').join('');
  $('category-tabs').querySelectorAll('button').forEach(b=>b.onclick=()=>{state.category=b.dataset.cat;renderCategories();renderProducts()});
}
function renderProducts(){
  const q=$('product-search').value.trim().toLowerCase();
  const rows=state.menu.filter(x=>x.active&&(state.category==='All'||(x.category||'Other')===state.category)&&(!q||[x.name,x.code,x.category,...(x.aliases||[])].join(' ').toLowerCase().includes(q)));
  $('product-grid').innerHTML=rows.map(p=>'<article class="product-card"><div class="product-image">'+esc(p.emoji||'🥤')+'</div><h3>'+esc(p.name)+'</h3><div class="product-size">'+esc(p.size||'')+'</div><div class="product-price">'+fmt(p.pricePence)+'</div>'+(p.deal?'<div class="deal-label">'+esc(p.deal.label)+'</div>':'')+'<button class="add-button" data-add="'+esc(p.code)+'">+</button></article>').join('')||'<p class="muted">No products found.</p>';
  $('product-grid').querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>add(b.dataset.add));
}
function add(code){state.basket[code]=(state.basket[code]||0)+1;saveBasket();updateBasketBadge();toast('Added to basket')}
function product(code){return state.menu.find(x=>x.code===code)}
function linePricing(p,qty){
  const regular=p.pricePence*qty;if(!p.deal||!p.deal.qty||!p.deal.totalPence)return{regular,total:regular,saving:0};
  const bundles=Math.floor(qty/p.deal.qty),rest=qty%p.deal.qty,total=bundles*p.deal.totalPence+rest*p.pricePence;return{regular,total,saving:Math.max(0,regular-total)};
}
function basketTotals(){let regular=0,total=0;Object.entries(state.basket).forEach(([code,qty])=>{const p=product(code);if(!p||!p.active)return;const x=linePricing(p,qty);regular+=x.regular;total+=x.total});return{regular,total,saving:regular-total}}
function updateBasketBadge(){const count=Object.values(state.basket).reduce((a,b)=>a+Number(b||0),0);$('basket-badge').textContent=count;$('basket-badge').hidden=!count}
function changeQty(code,delta){state.basket[code]=Math.max(0,(state.basket[code]||0)+delta);if(!state.basket[code])delete state.basket[code];saveBasket();renderBasket()}
function renderBasket(){
  const rows=Object.entries(state.basket).map(([code,qty])=>({p:product(code),qty})).filter(x=>x.p&&x.p.active);
  $('basket-list').innerHTML=rows.map(({p,qty})=>{const x=linePricing(p,qty);return '<div class="basket-item"><div class="basket-thumb">'+esc(p.emoji||'🥤')+'</div><div><h3>'+esc(p.name)+'</h3>'+(p.deal?'<small>'+esc(p.deal.label)+'</small>':'')+'<div><strong>'+fmt(x.total)+'</strong>'+(x.saving?'<span class="old">'+fmt(x.regular)+'</span>':'')+'</div></div><div class="qty-control"><button data-minus="'+esc(p.code)+'">−</button><b>'+qty+'</b><button data-plus="'+esc(p.code)+'">+</button></div></div>'}).join('')||'<p class="muted centre">Your basket is empty.</p>';
  $('basket-list').querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>changeQty(b.dataset.minus,-1));$('basket-list').querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>changeQty(b.dataset.plus,1));
  const t=basketTotals();$('basket-subtotal').textContent=fmt(t.regular);$('basket-savings').textContent='-'+fmt(t.saving);$('basket-total').textContent=fmt(t.total);$('savings-banner').hidden=!t.saving;$('savings-copy').textContent="You're saving "+fmt(t.saving);$('checkout-button').disabled=!rows.length||!state.canCheckout;updateBasketBadge();
}
async function checkout(){
  if(!state.canCheckout){$('checkout-message').textContent='App ordering is awaiting the verified V35 connection.';return}
  const location=$('meeting-point').value.trim(),note=$('order-note').value.trim();if(!location){$('checkout-message').textContent='Add your meeting location first.';return}
  const items=Object.entries(state.basket).map(([code,qty])=>({code,qty})).filter(x=>x.qty>0);if(!items.length)return;
  const core={items,location,note,paymentMethod:'CASH'},fingerprint=JSON.stringify(core);
  let pending=null;try{pending=JSON.parse(localStorage.getItem('rocket.customer.pendingOrder')||'null')}catch{}
  if(!pending||pending.fingerprint!==fingerprint){const requestId=(crypto.randomUUID?crypto.randomUUID():('req_'+Date.now()+'_'+Math.random().toString(36).slice(2)));pending={fingerprint,requestId};localStorage.setItem('rocket.customer.pendingOrder',JSON.stringify(pending))}
  const payload={...core,requestId:pending.requestId};
  $('checkout-button').disabled=true;$('checkout-message').textContent='Sending your cash order securely…';
  try{const r=await api('/api/orders',{method:'POST',body:JSON.stringify(payload)});localStorage.removeItem('rocket.customer.pendingOrder');state.basket={};saveBasket();renderBasket();$('order-note').value='';$('meeting-point').value='';$('checkout-message').textContent='Order '+r.orderId+' received. Total '+fmt(r.totalPence)+' — cash on delivery.';state.reward=r.reward||state.reward;renderRewards();renderSpinCounts();toast(r.duplicate?'Order already received':'Cash order received')}
  catch(e){$('checkout-message').textContent=e.message}
  finally{$('checkout-button').disabled=false}
}
function renderSpinCounts(){
  const spins=Number(state.reward.spins||0),x=accountLabels(state.debt,state.reward,state.sync);
  $('spin-count').textContent=spins;$('reward-spin-count').textContent=spins;
  $('frenzy-points').textContent=x.points;$('points-spin-button').disabled=true;
  pointSpins.render();
}

function renderRewards(){
  renderSpinCounts();const rem=state.reward.spendRemainderPence||0,need=Math.max(0,500-rem);$('progress-copy').textContent=need?'Spend '+fmt(need)+' more for your next 2 spins':'Next 2 spins ready';$('spend-progress').style.width=Math.min(100,(rem/500)*100)+'%';
  $('prize-vault').innerHTML=(state.vault||[]).map(v=>'<div class="prize-row"><div class="prize-icon">'+esc(v.icon||'🎁')+'</div><div class="grow"><strong>'+esc(v.label)+'</strong><small>'+esc(v.wonLabel||'Won recently')+'</small></div><div class="prize-state">'+esc(v.status||'ACTIVE')+'</div></div>').join('')||'<p class="muted">No prizes yet. Use your free spins.</p>';
  renderLoyalty();renderDebt();
}
function renderLoyalty(){
  const x=accountLabels(state.debt,state.reward,state.sync);
  $('points-balance').textContent=x.points;
  $('points-rate').textContent=x.stale?'Last verified V35 points':(x.pointsKnown?'Your existing V35 loyalty points':'Waiting for your V35 loyalty balance');
  $('points-redemptions').innerHTML='<p class="muted">Use the Reel Frenzy points button to check the cost and play for a chance to win an item.</p>';
}

function renderDebt(){
  const x=accountLabels(state.debt,state.reward,state.sync),card=$('debt-card');
  card.hidden=false;card.classList.toggle('blocked',Boolean(state.debt?.blocked)&&!x.stale);
  $('debt-status').textContent=x.status;$('debt-owed').textContent=x.money;
  $('debt-points').textContent=x.points;$('debt-due').textContent=x.due;
  $('debt-updated').textContent=x.updated;
}

async function redeemPoints(code){
  if(code==='REEL1')await pointSpins.play();
}
function renderWeeklyPrizes(){$('weekly-prizes').innerHTML=(state.prizes||[]).map(p=>'<div class="prize-row"><div class="prize-icon">'+esc(p.icon||'🎁')+'</div><div class="grow"><strong>'+esc(p.label)+'</strong><small>'+Number(p.remaining||0)+' remaining this week</small></div></div>').join('')}

function drawScratchCover(){
  const canvas=$('scratch-canvas'),ctx=canvas.getContext('2d');ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,canvas.width,canvas.height);
  const img=new Image();img.onload=()=>ctx.drawImage(img,0,0,canvas.width,canvas.height);img.onerror=()=>{ctx.fillStyle='#38f06e';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#05200e';ctx.font='900 48px sans-serif';ctx.textAlign='center';ctx.fillText('SCRATCH TO REVEAL',canvas.width/2,canvas.height/2)};img.src='/assets/scratch-cover.svg?v=2';
}
function showScratchModal(preApp=false){
  state.scratchResult=null;state.scratchStarted=false;state.scratchPreApp=!!preApp;window.__scratchCells=new Set();
  $('scratch-result-title').textContent='Your Rocket Reward';$('scratch-result-subtitle').textContent='Start scratching to reveal it';
  $('scratch-progress-bar').style.width='0%';$('scratch-help').textContent='Scratch at least half the card';$('scratch-claim').hidden=true;$('scratch-close').hidden=!!preApp;
  $('scratch-canvas').style.opacity='1';$('scratch-canvas').style.pointerEvents='auto';drawScratchCover();
  $('scratch-modal').hidden=false;document.body.classList.add('scratch-open');
}
function closeScratchModal(){
  if(state.scratchPreApp)return;
  $('scratch-modal').hidden=true;document.body.classList.remove('scratch-open');
}
function finishScratchEntry(){
  $('scratch-modal').hidden=true;document.body.classList.remove('scratch-open');
  if(state.scratchPreApp){
    state.scratchPreApp=false;
    showApp();
    nav('menu');
    toast('Welcome to Rocket');
  }
}
async function loadScratchResult(){
  if(state.scratchResult)return state.scratchResult;
  state.scratchResult=await api('/api/scratch/reveal',{method:'POST',body:'{}'});
  const r=state.scratchResult;
  $('scratch-result-title').textContent=r.winner?(r.icon+' '+r.label):'🚀 '+r.label;
  $('scratch-result-subtitle').textContent=r.winner?'Added to your Rocket rewards':'Come back tomorrow for another free scratch';
  state.reward=r.reward||state.reward;state.vault=r.vault||state.vault;renderRewards();renderSpinCounts();
  return r;
}
function scratchPoint(ev){
  const canvas=$('scratch-canvas'),rect=canvas.getBoundingClientRect(),x=(ev.clientX-rect.left)*canvas.width/rect.width,y=(ev.clientY-rect.top)*canvas.height/rect.height,ctx=canvas.getContext('2d');
  ctx.globalCompositeOperation='destination-out';ctx.beginPath();ctx.arc(x,y,48,0,Math.PI*2);ctx.fill();
  const gx=Math.max(0,Math.min(19,Math.floor(x/canvas.width*20))),gy=Math.max(0,Math.min(11,Math.floor(y/canvas.height*12)));
  for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){const xx=gx+dx,yy=gy+dy;if(xx>=0&&xx<20&&yy>=0&&yy<12)window.__scratchCells.add(xx+':'+yy)}
  const pct=Math.min(100,Math.round(window.__scratchCells.size/240*100));$('scratch-progress-bar').style.width=pct+'%';$('scratch-help').textContent=pct<50?'Keep scratching… '+pct+'%':'Reward revealed!';
  if(pct>=50){canvas.style.transition='opacity .35s';canvas.style.opacity='0';canvas.style.pointerEvents='none';$('scratch-claim').hidden=false}
}
function wireScratch(){
  const c=$('scratch-canvas');let down=false;
  c.addEventListener('pointerdown',async e=>{down=true;c.setPointerCapture?.(e.pointerId);try{await loadScratchResult();scratchPoint(e)}catch(err){toast(err.message)}});
  c.addEventListener('pointermove',e=>{if(down)scratchPoint(e)});
  ['pointerup','pointercancel','pointerleave'].forEach(n=>c.addEventListener(n,()=>down=false));
  $('scratch-close').onclick=closeScratchModal;$('scratch-claim').onclick=()=>{const won=state.scratchResult&&state.scratchResult.winner;finishScratchEntry();toast(won?'Reward saved':'Come back tomorrow')};
}

const symbols=['🚀','🪙','💎','🐟','🐚','🎁','⭐','🦀','⚓'];
function seedReels(){document.querySelectorAll('.reel').forEach((r,ri)=>{r.innerHTML='';for(let n=0;n<3;n++){const d=document.createElement('div');d.className='symbol';d.textContent=symbols[(ri*3+n)%symbols.length];r.appendChild(d)}})}
function randomizeReel(r){[...r.children].forEach(x=>x.textContent=symbols[Math.floor(Math.random()*symbols.length)])}
async function spin(){
  if(state.spinning||pointSpins.isBusy())return;if((state.reward.spins||0)<1){toast('No free spins ready');return}state.spinning=true;$('spin-button').disabled=true;
  const reels=[...document.querySelectorAll('.reel')];document.querySelectorAll('.symbol').forEach(x=>x.classList.remove('win'));reels.forEach(r=>r.classList.add('spinning'));const flick=setInterval(()=>reels.forEach(randomizeReel),80);let result;
  try{result=await api('/api/spins',{method:'POST',body:'{}'})}catch(e){clearInterval(flick);reels.forEach(r=>r.classList.remove('spinning'));state.spinning=false;$('spin-button').disabled=false;toast(e.message);return}
  const pattern=result.pattern||['⭐','⭐','⭐','🎁','⭐'];reels.forEach((r,i)=>setTimeout(()=>{r.classList.remove('spinning');randomizeReel(r);r.children[1].textContent=pattern[i]||'⭐';if(result.winner)r.children[1].classList.add('win');if(i===reels.length-1){clearInterval(flick);state.reward=result.reward||state.reward;state.vault=result.vault||state.vault;state.prizes=result.weeklyPrizes||state.prizes;renderSpinCounts();renderWeeklyPrizes();renderRewards();state.spinning=false;$('spin-button').disabled=false;toast(result.winner?'You won: '+result.label:'Spin complete — try again')}},650+i*210));
}
function signOut(showToast=true){pointSpins.reset();const tok=state.token;if(tok)fetch(API_BASE+'/api/session/logout',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tok},body:'{}'}).catch(()=>{});state.token='';localStorage.removeItem('rocket.customer.token');state.profile=null;state.debt={available:false,owedPence:null};state.reward={points:null,pointsSource:null};state.sync={status:'AWAITING_V35'};state.canCheckout=false;showGate();if(showToast)toast('Signed out')}
function wire(){
  wireScratch();
  $('invite-submit').onclick=redeemInvite;$('invite-code').addEventListener('keydown',e=>{if(e.key==='Enter')redeemInvite()});
  $('returning-toggle').onclick=()=>{$('returning-login').hidden=!$('returning-login').hidden;if(!$('returning-login').hidden)$('login-phone').focus()};
  $('pin-login-submit').onclick=pinLogin;$('login-pin').addEventListener('keydown',e=>{if(e.key==='Enter')pinLogin()});
  $('pin-setup-submit').onclick=setupPin;$('confirm-pin').addEventListener('keydown',e=>{if(e.key==='Enter')setupPin()});
  $('product-search').oninput=renderProducts;$('clear-basket').onclick=()=>{state.basket={};saveBasket();renderBasket()};$('checkout-button').onclick=checkout;$('spin-button').onclick=spin;$('points-spin-button').onclick=()=>redeemPoints('REEL1');$('sign-out').onclick=()=>signOut();document.addEventListener('click',e=>{const b=e.target.closest('[data-nav]');if(b)nav(b.dataset.nav)});
}
async function init(){wire();updateBasketBadge();if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js?v=customer-20260923T000530Z').then(r=>r.update()).catch(()=>{});if(!state.token){showGate();return}try{await enterApp()}catch{showGate()}}
setInterval(()=>{if(!document.hidden)refreshAccount()},15000);
window.addEventListener('online',()=>refreshAccount());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshAccount()});
init();
