import {SpinClient,resultPresentation} from './v35_spin_client.js';
const API_BASE=(window.ROCKET_CONFIG&&window.ROCKET_CONFIG.apiBase||'').replace(/\/$/,'');
/* No API key or customer phone is stored by this presentation module. */
export function mountPointsSpin({session,refreshAccount,freeSpinBusy}) {
  const $=id=>document.getElementById(id);
  let lastResult=null, animation=null, identity=0;
  const request=async(path,options,token)=>{
    const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),8000);
    try {
      const r=await fetch(API_BASE+path,{...options,cache:'no-store',signal:abort.signal,
        headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}});
      const body=await r.json();
      if (!r.ok) { const e=new Error('Spin request not confirmed'); e.status=r.status; throw e; }
      return body;
    } finally {clearTimeout(timer);}
  };
  const locked=fn=>{
    if (!globalThis.isSecureContext || !navigator.locks?.request || !crypto.randomUUID)
      return Promise.reject(new Error('Secure browser features required'));
    return navigator.locks.request('rocket-points-spin-v1',{mode:'exclusive',ifAvailable:true},lock=>{
      if (!lock) throw new Error('Another tab is checking a spin'); return fn();
    });
  };
  const client=new SpinClient({request,storage:localStorage,uuid:()=>crypto.randomUUID(),
    withLock:locked,session,onState:render});
  const waiting=()=>['CHECKING','CONFIRM_COST','WAITING_V35','RECOVERY_REQUIRED'].includes(client.view.phase);
  function clearAnimation() {
    clearTimeout(animation); animation=null;
    document.querySelectorAll('.reel').forEach(r=>r.classList.remove('spinning'));
  }
  function render(v=client.view) {
    const button=$('points-spin-button'),text=$('points-spin-cost-copy');
    const result=$('points-spin-result'),done=$('points-spin-done');
    done.hidden=v.phase!=='RESULT'; button.disabled=true;
    if(v.phase!=='RESULT')result.textContent='';
    button.textContent='Use points to spin';
    const messages={UNAVAILABLE:'Point-funded spins are not available yet.',
      SIGNED_OUT:'Log in to view point-funded spins.',CHECKING:'Checking with V35…',
      CONFIRM_COST:'Confirm the points cost before playing.',
      WAITING_V35:'Waiting for your saved spin. Do not start another spin.',
      RECOVERY_REQUIRED:'Connection interrupted. Check the same spin again.',
      INSUFFICIENT:'Not enough points for this spin.'};
    text.textContent=messages[v.phase]||'';
    if (v.phase==='READY') {
      button.disabled=freeSpinBusy();
      text.textContent=v.quote ? v.quote.costPoints+' points per spin — spent whether you win or lose.' : 'Check the points cost before playing.';
    }
    if (['WAITING_V35','RECOVERY_REQUIRED'].includes(v.phase)) {
      button.disabled=freeSpinBusy(); button.textContent='Check saved spin';
    }
    $('spin-button').disabled=waiting()||Boolean(animation)||freeSpinBusy();
    if (v.phase==='RESULT') {
      const present=resultPresentation(v.result); result.textContent=present.message;
      text.textContent='This is the result saved by V35.';
      if (lastResult!==v.result.requestId) {
        lastResult=v.result.requestId; clearAnimation();
        if (present.pattern) animateSaved(present.pattern,v.result.outcome==='WIN');
        // Only an authoritative account refresh may update the visible balance.
        void refreshAccount();
      }
    }
  }
  function animateSaved(pattern,win) {
    const generation=identity,reels=[...document.querySelectorAll('.reel')];
    document.querySelectorAll('.symbol').forEach(x=>x.classList.remove('win'));
    reels.forEach(r=>r.classList.add('spinning'));
    animation=setTimeout(()=>{
      clearAnimation(); if (generation!==identity || !session()) return;
      reels.forEach((r,i)=>{
        if (r.children[1]) {r.children[1].textContent=pattern[i];r.children[1].classList.toggle('win',win);}
      }); render();
    },400);
  }
  const api={
    render:()=>render(),isBusy:()=>waiting()||Boolean(animation),
    inspect:()=>session()&&!freeSpinBusy()?client.inspect():Promise.resolve(),
    play:()=>!session()||freeSpinBusy()?Promise.resolve():client.play(q=>window.confirm(
      'Use '+q.costPoints+' points for one spin?\nPoints are spent whether you win or lose. An item is not guaranteed.')),
    reset:()=>{
      identity++; lastResult=null; clearAnimation(); client.reset();
      $('points-spin-result').textContent='';
      document.querySelectorAll('.symbol').forEach(x=>{x.textContent='—';x.classList.remove('win');});
    }
  };
  $('points-spin-done').onclick=()=>client.acknowledge();
  // Reconnection is GET-only recovery. A new spend always needs a button press.
  window.addEventListener('online',()=>{void api.inspect();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void api.inspect();});
  setInterval(()=>{if(!document.hidden&&waiting())void api.inspect();},5000);
  return api;
}
