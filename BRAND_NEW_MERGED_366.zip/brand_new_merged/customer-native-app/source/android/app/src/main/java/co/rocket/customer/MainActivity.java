package co.rocket.customer;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
