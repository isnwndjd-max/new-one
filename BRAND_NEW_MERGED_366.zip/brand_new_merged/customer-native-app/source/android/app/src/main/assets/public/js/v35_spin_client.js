/* Isolated review: presentation/retry controller, never a points or prize engine. */
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const SCOPE = /^[A-Za-z0-9_-]{24,80}$/;
const integer = x => Number.isSafeInteger(x) && x >= 0;
const copy = x => JSON.parse(JSON.stringify(x));
function assert(ok) { if (!ok) throw new Error('Spin protocol needs review'); }
export class SpinClient {
  constructor({request, storage, uuid, withLock, session, onState, now=Date.now}) {
    Object.assign(this, {request, storage, uuid, withLock, session, onState, now});
    this.busy = null; this.generation = 0; this.scope = null; this.result = null;
    this.view = {phase:'UNAVAILABLE'};
  }
  emit(value) { this.view=copy(value); this.onState(copy(value)); return this.view; }
  reset() {
    this.generation++; this.scope=null; this.result=null;
    // Never erase an unresolved request on logout; it is not another chance.
    this.emit({phase:'SIGNED_OUT'});
  }
  key(scope) { assert(SCOPE.test(scope)); return 'rocket.points-spin.v1.'+scope; }
  load(scope) {
    const raw=this.storage.getItem(this.key(scope)); if (raw===null) return null;
    const x=JSON.parse(raw);
    assert(x && Object.keys(x).sort().join(',')==='phase,quoteId,requestId');
    assert(UUID.test(x.requestId) && UUID.test(x.quoteId));
    assert(['PENDING','RESULT','VIEWED'].includes(x.phase)); return x;
  }
  save(scope, x) {
    const raw=JSON.stringify(x); this.storage.setItem(this.key(scope),raw);
    assert(this.storage.getItem(this.key(scope))===raw);
  }
  quoteDetails(q) {
    assert(UUID.test(q.quoteId) && integer(q.costPoints) && q.costPoints>0);
    assert(integer(q.pointsBalance) && integer(q.expiresAtMs));
    assert(q.expiresAtMs>this.now() && q.expiresAtMs<=this.now()+120000);
    return {quoteId:q.quoteId,costPoints:q.costPoints,pointsBalance:q.pointsBalance,
            expiresAtMs:q.expiresAtMs};
  }
  inspect() { return this.work('inspect'); }
  play(confirmCost) { return this.work('play',confirmCost); }
  acknowledge() { return this.work('acknowledge'); }
  work(action, confirmCost) {
    if (this.busy) return this.busy;
    const token=this.session(), generation=this.generation;
    const current=()=>token && token===this.session() && generation===this.generation;
    const check=()=>assert(current());
    const perform=async()=>{
      assert(typeof this.withLock==='function');
      return this.withLock(async()=>{
        check(); this.emit({phase:'CHECKING'});
        const q=await this.request('/api/points-spin/quote',{},token); check();
        assert(q && typeof q.enabled==='boolean' && SCOPE.test(q.accountScope));
        this.scope=q.accountScope; let record=this.load(this.scope);
        if (q.outstanding) {
          const saved=q.outstanding;
          assert(Object.keys(saved).sort().join(',')==='phase,quoteId,requestId');
          assert(UUID.test(saved.requestId)&&UUID.test(saved.quoteId)&&['PENDING','RESULT'].includes(saved.phase));
          if (record && record.requestId===saved.requestId) assert(record.quoteId===saved.quoteId);
          record={requestId:saved.requestId,quoteId:saved.quoteId,phase:saved.phase};
          this.save(this.scope,record);
        }
        if (action==='acknowledge') {
          assert(record && this.result && record.requestId===this.result.requestId);
          assert(record.phase==='RESULT');
          const ack=await this.request('/api/points-spin/ack',{method:'POST',body:JSON.stringify({requestId:record.requestId})},token);
          check(); assert(ack.ok===true&&ack.requestId===record.requestId);
          this.save(this.scope,{...record,phase:'VIEWED'}); this.result=null;
          return this.emit({phase:q.enabled?'READY':'UNAVAILABLE'});
        }
        if (record && record.phase!=='VIEWED') {
          let response;
          try {
            response=await this.request('/api/points-spin/result?requestId='+record.requestId,{},token);
          } catch (e) {
            check();
            if (e.status!==404 || action!=='play' || record.phase!=='PENDING') throw e;
            // A lost POST response is retried with the SAME quote and request IDs.
            response=await this.submit(record,token);
          }
          check(); return this.accept(response,record);
        }
        if (!q.enabled) return this.emit({phase:'UNAVAILABLE'});
        const quote=this.quoteDetails(q);
        if (quote.pointsBalance<quote.costPoints) return this.emit({phase:'INSUFFICIENT',quote});
        if (action==='inspect') return this.emit({phase:'READY',quote});
        assert(typeof confirmCost==='function'); this.emit({phase:'CONFIRM_COST',quote});
        const confirmed=await confirmCost(copy(quote)); check();
        if (!confirmed) return this.emit({phase:'READY',quote});
        assert(quote.expiresAtMs>this.now());
        const id=this.uuid(); assert(UUID.test(id));
        const pending={requestId:id,quoteId:quote.quoteId,phase:'PENDING'};
        this.save(this.scope,pending); // Must succeed BEFORE any spending request.
        this.result=null; this.emit({phase:'WAITING_V35'});
        const response=await this.submit(pending,token); check();
        return this.accept(response,pending);
      });
    };
    this.busy=perform().catch(()=>{
      if (!current()) return this.view;
      let pending=true;
      try { pending=Boolean(this.scope && this.load(this.scope)?.phase!=='VIEWED' && this.load(this.scope)); }
      catch { /* Corrupt durable state must not silently permit another spend. */ }
      return this.emit({phase:pending?'RECOVERY_REQUIRED':'UNAVAILABLE'});
    }).finally(()=>{this.busy=null;});
    return this.busy;
  }
  submit(record,token) {
    return this.request('/api/loyalty/redeem',{method:'POST',body:JSON.stringify({
      requestId:record.requestId,quoteId:record.quoteId,code:'REEL1'})},token);
  }
  accept(response,record) {
    assert(response && response.requestId===record.requestId);
    if (response.state==='WAITING_V35') return this.emit({phase:'WAITING_V35'});
    assert(['COMPLETE','DECLINED'].includes(response.state));
    let result;
    if (response.state==='DECLINED') {
      assert(response.costPoints===0 && typeof response.reason==='string');
      result={requestId:record.requestId,state:'DECLINED',costPoints:0};
    } else {
      assert(integer(response.costPoints) && response.costPoints>0);
      assert(integer(response.pointsAfterAtSpin));
      assert(['WIN','NO_WIN'].includes(response.outcome));
      const item=response.item;
      if (response.outcome==='WIN') assert(item && /^[A-Z0-9_-]{1,16}$/.test(item.code) &&
        typeof item.label==='string' && item.label.length>0 && item.label.length<=80);
      else assert(item===null);
      result={requestId:record.requestId,state:'COMPLETE',costPoints:response.costPoints,
              outcome:response.outcome,item:item?{code:item.code,label:item.label}:null,
              pointsAfterAtSpin:response.pointsAfterAtSpin};
    }
    this.save(this.scope,{...record,phase:'RESULT'}); this.result=result;
    // Historical points are not written into the current account snapshot.
    return this.emit({phase:'RESULT',result});
  }
}

export function resultPresentation(result) {
  if (result.state==='DECLINED') return {pattern:null,message:'Spin declined. No points spent.'};
  assert(result.state==='COMPLETE');
  if (result.outcome==='WIN') return {pattern:['🚀','🚀','🎁','🚀','🚀'],
    message:'You won: '+result.item.label+'. '+result.costPoints+' points spent.'};
  return {pattern:['⭐','🐟','🪙','🐚','⚓'],
    message:'No win this spin. '+result.costPoints+' points spent.'};
}
