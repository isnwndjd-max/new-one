/* Pure debt/points presentation; never infer money from null or an account suffix. */
export function accountLabels(debt, reward, sync, nowMs=Date.now()) {
  debt=debt||{}; reward=reward||{}; sync=sync||{};
  const at=sync.lastCheckedAtMs;
  const tooOld=Number.isFinite(at) && (nowMs-at>(sync.maxAgeMs||60000) || at>nowMs+30000);
  const stale=Boolean(sync.stale || debt.stale || sync.status==='STALE' || sync.status==='OFFLINE' || tooOld);
  const validDebt=debt.available===true && Number.isSafeInteger(debt.owedPence) && debt.owedPence>=0;
  const validPoints=reward.pointsSource==='V35' && Number.isSafeInteger(reward.points) && reward.points>=0;
  const money=validDebt?'£'+(debt.owedPence/100).toFixed(2):'Awaiting update';
  const points=validPoints?reward.points.toLocaleString('en-GB'):'Awaiting update';
  const status=stale?'Last verified balance':(!validDebt?'Awaiting V35':(debt.blocked?'Account on hold':(debt.overdue?'Payment overdue':'Account up to date')));
  const updated=Number.isFinite(at)?new Date(at).toLocaleString('en-GB'):'Not yet verified';
  return {money,points,status,stale,known:validDebt,pointsKnown:validPoints,
          due:validDebt&&debt.dueAt?'Payment due '+new Date(debt.dueAt*1000).toLocaleDateString('en-GB'):'',
          updated:(stale?'Last checked: ':'Updated: ')+updated,
          canRedeem:false,canCheckout:false};
}
