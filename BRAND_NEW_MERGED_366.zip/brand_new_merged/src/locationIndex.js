'use strict';

const { normalise, withoutLeadingThe, phraseSpans, containsPhrase } = require('./text');

// Strength of a name match. Only canonical names and evidence-backed
// (CONFIRMED) aliases can resolve a location on their own. Inferred variants,
// generic ambiguity words and partial-word matches can only ever produce a
// question back to the customer.
const KIND_RANK = { canonical: 4, confirmed: 3, inferred: 2, ambiguity: 1, partial: 0 };
const STRONG = new Set(['canonical', 'confirmed']);

// Venue statuses that mean "recognise the name, but never dispatch a driver
// there" - a demolished building, a business that has closed, or a site
// the research pack has flagged as former/superseded. Distinct from
// UNCERTAIN (see VERIFIED_STATUS below), which means "still might be
// trading, just not individually checked" - a former/closed site is a
// stronger, structural fact, not just missing verification.
const FORMER_STATUSES = new Set(['DEMOLISHED', 'FORMER', 'CLOSED']);

// The only status that lets a name match auto-resolve a driver's meeting
// point with no confirmation step. Everything else (UNCERTAIN,
// MANUAL_REVIEW, or any status the research data doesn't mark ACTIVE) must
// go back to the customer as an unverified-location confirmation rather
// than being silently trusted - see LocationConversation._resolve().
const VERIFIED_STATUS = 'ACTIVE';

// Words that must never trigger a partial-word match on their own.
const PARTIAL_STOP = new Set(`the and of at in on by for to near outside behind opposite
road street lane st ave avenue drive way close place court crescent hill green park
ltd limited co company group uk bristol somerset north south east west upper lower new old
cafe coffee shop shops store stores club bar inn pub house hall centre center church school
station services service hotel restaurant takeaway pizza fish chips kebab farm community
sports social village town memorial primary junior academy surgery health pharmacy garage
kitchen bakery bakers food foods catering meet meeting come coming mate cheers thanks please
where there here today tonight later outside front back side main high`.split(/\s+/));

const POSTCODE_RE = /\b([A-Z]{1,2}[0-9][A-Z0-9]?)\s*([0-9][A-Z]{2})\b/i;
const OUTWARD_ONLY_RE = /\b(BS(?:48|49|21|20))\b/i;

// A street name, optionally with a house/flat number in front ("42 Silver
// Street", "Flat 2 Silver Street", "Silver St"). This is text recognition
// only - there is no street-level geocoding data in this project (no street
// gazetteer, no per-address coordinates), so a match here never produces a
// lat/lng on its own. What it does do: let a street name ride along with a
// postcode as a human-readable refinement of the meeting point (see
// locationConversation.js), so a driver reads "42 Silver Street, BS49 4AU"
// instead of just the bare postcode - useful because one postcode can cover
// more than one street, and the street name is exactly the detail a
// postcode-centroid coordinate cannot carry. It does NOT move the pin: the
// coordinate GPS automation measures against stays whatever the postcode/
// venue/pin resolution already produced (see engine.js's _maybeAutoGpsEvents,
// which reads order.location.confirmed.lat/lng - this module never touches
// those fields).
const STREET_SUFFIX_RE = '(road|rd|street|st|lane|ln|avenue|ave|drive|dr|close|way|crescent|cres|hill|green|court|ct|place|pl|terrace|grove|gardens|gdns|row|square|sq|rise|view|walk|mews|park)';
const STREET_RE = new RegExp(
  '\\b((?:(?:flat|unit|apt|apartment)\\s*\\d+[a-z]?\\s*,?\\s*)?(?:\\d{1,4}[a-z]?\\s+)?' +
  "[a-z][a-z'-]{1,20}(?:\\s+[a-z][a-z'-]{1,20}){0,3}\\s+" + STREET_SUFFIX_RE + ')\\b',
  'i'
);
// Common filler words that can end up swept into the front of a STREET_RE
// match ("it's Silver Street", "on Silver Street") - stripped in
// findStreet() below rather than tightened out of the pattern itself.
const STREET_LEAD_STOP = new Set(["it's", 'its', 'it', 'on', 'at', 'near', 'by', 'in', 'the', 'just', 'off', 'of']);

// Map pins: Google/Apple/OSM links, geo: URIs, or bare "lat, lng" pairs.
const LATLNG_RE = /(-?\d{1,2}\.\d{3,})\s*,\s*(-?\d{1,3}\.\d{3,})/;
const MAP_LINK_RE = /(https?:\/\/(?:maps\.app\.goo\.gl|goo\.gl\/maps|(?:www\.)?google\.[a-z.]+\/maps|maps\.google\.[a-z.]+|maps\.apple\.com|(?:www\.)?openstreetmap\.org|osm\.org|what3words\.com|w3w\.co)\S*|geo:\S+)/i;

class LocationIndex {
  constructor(data) {
    this.data = data;
    this.covered = new Set(data.coveredDistricts);
    this.venuesById = new Map(data.venues.map((v) => [v.id, v]));
    this.venueTowns = new Set(
      data.venues.map((v) => v.town).filter((t) => t && t !== 'UNRESOLVED')
    );

    this.townKeys = new Map();
    for (const t of data.towns) this.townKeys.set(normalise(t), t);

    this.phrases = new Map(); // phrase -> Map(venueId -> kind)
    this.ambiguityTerms = new Map(); // term -> venueIds
    // Historic/former venues known ONLY by a name that isn't any current
    // venue's own name or alias (e.g. a pub that closed and was replaced by
    // something with a different name). data.formerLocations is an array of
    // { phrase, formerName, currentVenueId (nullable), note } records; this
    // project's data/locations.json ships it empty (see
    // data/source/RESEARCH_README.md's 06_former_closed_locations dataset,
    // which was not included in this import - see the CHANGELOG for what
    // that means in practice). A venue whose OWN status is
    // DEMOLISHED/FORMER/CLOSED (like "Lord Nelson, former site") does not
    // need an entry here - that is handled by FORMER_STATUSES in
    // LocationConversation._resolve() via the normal name-matching path.
    this.formerLocations = new Map();
    for (const f of data.formerLocations || []) {
      this.formerLocations.set(normalise(f.phrase), f);
    }
    this._build();
  }

  /** A phrase known to refer to a former/historic site by a name no current venue carries. */
  findFormerLocation(key) {
    for (const [phrase, rec] of this.formerLocations) {
      if (containsPhrase(key, phrase)) return rec;
    }
    return null;
  }

  _add(phrase, venueId, kind) {
    if (!phrase || phrase.length < 3) return;
    if (this.townKeys.has(phrase)) return; // a bare town name is context, not a venue
    if (PARTIAL_STOP.has(phrase)) return;
    let m = this.phrases.get(phrase);
    if (!m) {
      m = new Map();
      this.phrases.set(phrase, m);
    }
    const prev = m.get(venueId);
    if (!prev || KIND_RANK[kind] > KIND_RANK[prev]) m.set(venueId, kind);
  }

  // "the grove" -> "grove": a derived key. If it is a single ordinary word
  // ("grove", "rock") it is too weak to resolve on its own, so it becomes inferred.
  _addDerived(phrase, venueId, kind) {
    if (!phrase) return;
    this._add(phrase, venueId, phrase.includes(' ') ? kind : 'inferred');
  }

  _build() {
    const tokenVenues = new Map();
    this.tokenVenuesAll = new Map();
    for (const v of this.data.venues) {
      for (const name of [v.name, v.commonName]) {
        if (!name) continue;
        const key = normalise(name);
        this._add(key, v.id, 'canonical');
        this._addDerived(withoutLeadingThe(key), v.id, 'canonical');
        for (const tok of key.split(' ')) {
          if (!this.tokenVenuesAll.has(tok)) this.tokenVenuesAll.set(tok, new Set());
          this.tokenVenuesAll.get(tok).add(v.id);
          if (tok.length < 4 || PARTIAL_STOP.has(tok) || this.townKeys.has(tok)) continue;
          if (!tokenVenues.has(tok)) tokenVenues.set(tok, new Set());
          tokenVenues.get(tok).add(v.id);
        }
      }
    }
    for (const a of this.data.aliases) {
      let kind = a.evidence === 'CONFIRMED' ? 'confirmed' : 'inferred';
      const key = normalise(a.alias);
      const v = this.venuesById.get(a.venueId);
      if (kind === 'inferred' && v && v.town) {
        // "Royal Oak Nailsea" is just the canonical name plus the venue's own town
        const nameKey = normalise(v.name);
        const townKey = normalise(v.town);
        const bare = withoutLeadingThe(nameKey) || nameKey;
        for (const n of [nameKey, bare]) {
          if (key === `${n} ${townKey}` || key === `${townKey} ${n}`) kind = 'canonical';
        }
      }
      this._add(key, a.venueId, kind);
      this._addDerived(withoutLeadingThe(key), a.venueId, kind);
    }
    for (const amb of this.data.ambiguities) {
      const key = normalise(amb.term);
      this.ambiguityTerms.set(key, amb.venueIds);
      // bypass the stop-list for curated ambiguity terms such as "pub" or "station"
      let m = this.phrases.get(key);
      if (!m) {
        m = new Map();
        this.phrases.set(key, m);
      }
      for (const id of amb.venueIds) if (!m.has(id)) m.set(id, 'ambiguity');
    }
    // Partial tokens: only rare, distinctive words (appear in at most 3 venues)
    this.partialTokens = new Map();
    for (const [tok, ids] of tokenVenues) {
      if (ids.size <= 3) this.partialTokens.set(tok, [...ids]);
    }
  }

  venue(id) {
    return this.venuesById.get(id);
  }

  findPin(raw) {
    const link = raw.match(MAP_LINK_RE);
    const ll = raw.match(LATLNG_RE);
    if (!link && !ll) return null;
    let lat = null;
    let lng = null;
    if (ll) {
      lat = parseFloat(ll[1]);
      lng = parseFloat(ll[2]);
      if (Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        lat = null;
        lng = null;
      }
    }
    // A recognised map-link HOST (what3words, a goo.gl/maps or
    // maps.app.goo.gl short link, etc.) with no actual "lat,lng" text
    // anywhere in the message is NOT a resolvable location - those links
    // only reveal coordinates after a server-side fetch/redirect this
    // project doesn't do (no What3Words API call, no following short-link
    // redirects). Previously this fell through to `return {..., lat: null,
    // lng: null}` below, which the caller (LocationConversation) treated as
    // a fully CONFIRMED, exactPointKnown pin - silently locking in an order
    // with no real coordinates: broken driver nav, and GPS auto-messages
    // (5-min/departure-ETA/arrived) would just never fire, with nothing
    // telling anyone why. Treating it as unresolved instead means the
    // customer gets the normal "can't find that location" ask-again
    // response, same as any other location we can't understand.
    if (lat === null) return null;
    return { type: 'pin', raw: link ? link[0] : ll[0], lat, lng };
  }

  findPostcode(raw) {
    const m = String(raw).toUpperCase().match(POSTCODE_RE);
    if (!m) {
      const outward = String(raw).match(OUTWARD_ONLY_RE);
      return outward ? { status: 'PARTIAL', outward: outward[1].toUpperCase() } : null;
    }
    const pc = `${m[1]} ${m[2]}`;
    const outward = m[1];
    if (this.data.activePostcodes[pc]) {
      const r = this.data.activePostcodes[pc];
      return { status: 'ACTIVE', postcode: pc, lat: r.lat, lng: r.lng };
    }
    if (this.data.terminatedPostcodes[pc]) return { status: 'TERMINATED', postcode: pc };
    if (this.covered.has(outward)) return { status: 'UNKNOWN_IN_AREA', postcode: pc };
    return { status: 'OUTSIDE_AREA', postcode: pc };
  }

  /**
   * Recognise a street name (with an optional house/flat number) in the raw
   * message text. Label-only - see the STREET_RE comment above for why this
   * never returns a coordinate. Returns null if nothing street-shaped is
   * found, otherwise { phrase, houseNumber }: `phrase` is the whole street
   * mention (number included, e.g. "33 Greenfield Crescent"); `houseNumber`
   * is just the leading house/flat number portion ("33", "Flat 2, 33"), or
   * null if none was given - split out so a road/alley match (whose own
   * `name` already carries the street name) can show "33 Greenfield
   * Crescent" instead of duplicating the street name twice.
   */
  findStreet(raw) {
    const m = String(raw).match(STREET_RE);
    if (!m) return null;
    // Collapse internal whitespace but keep the customer's own capitalisation.
    const words = m[1].replace(/\s+/g, ' ').trim().split(' ');
    // The word-class before the suffix is deliberately permissive (any
    // ordinary word), which lets a leading filler word ("it's Silver
    // Street", "on Silver Street") get swept in as part of the match. Strip
    // known filler words off the front rather than tightening the whole
    // pattern, which would also start missing real one-word street names.
    while (words.length > 1 && STREET_LEAD_STOP.has(words[0].toLowerCase())) words.shift();
    const phrase = words.join(' ');
    const numMatch = phrase.match(/^((?:(?:flat|unit|apt|apartment)\s*\d+[a-z]?,?\s*)?\d{1,4}[a-z]?)\s+/i);
    return { phrase, houseNumber: numMatch ? numMatch[1] : null };
  }

  /**
   * Longest phrase match in the message. Returns { phrase, span, candidates }
   * where candidates = [{ venue, kind }], or null.
   */
  findVenue(key) {
    let best = null;
    for (const [phrase, ids] of this.phrases) {
      if (!(' ' + key + ' ').includes(' ' + phrase + ' ')) continue;
      const words = phrase.split(' ').length;
      if (!best || words > best.words || (words === best.words && phrase.length > best.phrase.length)) {
        best = { phrase, words, ids, span: phraseSpans(key, phrase)[0] };
      }
    }
    if (!best) return null;
    const candidates = [];
    for (const [id, kind] of best.ids) {
      const venue = this.venuesById.get(id);
      if (venue) candidates.push({ venue, kind });
    }
    // A single word ("hangstones", "grove") may name several places.
    // Add every venue whose name contains that word, as weak candidates,
    // so the customer is asked rather than sent to the first match.
    if (best.words === 1) {
      for (const id of this.tokenVenuesAll.get(best.phrase) || []) {
        if (!best.ids.has(id)) candidates.push({ venue: this.venuesById.get(id), kind: 'partial' });
      }
    }
    return {
      phrase: best.phrase,
      span: best.span,
      generic: this.ambiguityTerms.has(best.phrase),
      candidates,
    };
  }

  /** Rare distinctive words only, e.g. "pier" or "harp". Never resolves on its own. */
  findPartial(key) {
    const ids = new Set();
    let phrase = null;
    for (const tok of key.split(' ')) {
      const hit = this.partialTokens.get(tok);
      if (hit) {
        hit.forEach((id) => ids.add(id));
        phrase = tok;
      }
    }
    if (!ids.size) return null;
    return {
      phrase,
      span: null,
      generic: false,
      candidates: [...ids].map((id) => ({ venue: this.venuesById.get(id), kind: 'partial' })),
    };
  }

  /** Towns mentioned in the message, ignoring words already used by the venue phrase. */
  findTowns(key, excludeSpan) {
    const words = key.split(' ');
    const masked = words
      .map((w, i) => (excludeSpan && i >= excludeSpan[0] && i < excludeSpan[1] ? '_' : w))
      .join(' ');
    const found = [];
    for (const [tk, display] of this.townKeys) {
      for (const span of phraseSpans(masked, tk)) found.push({ display, span, len: tk.split(' ').length });
    }
    // longest wins where town names overlap ("lower claverham" beats "claverham")
    found.sort((a, b) => b.len - a.len);
    const used = new Set();
    const result = [];
    for (const f of found) {
      let clash = false;
      for (let i = f.span[0]; i < f.span[1]; i++) if (used.has(i)) clash = true;
      if (clash) continue;
      for (let i = f.span[0]; i < f.span[1]; i++) used.add(i);
      result.push(f);
    }
    result.sort((a, b) => a.span[0] - b.span[0]);
    return result.map((f) => f.display);
  }

  isVenueTown(town) {
    return this.venueTowns.has(town);
  }

  notOperationalRule(phrase, town) {
    return (this.data.notOperational || []).find(
      (r) => normalise(r.term) === phrase && r.towns.includes(town)
    );
  }
}

module.exports = { LocationIndex, KIND_RANK, STRONG, FORMER_STATUSES, VERIFIED_STATUS };
