'use strict';

const { normalise } = require('./text');
const { KIND_RANK, STRONG, FORMER_STATUSES, VERIFIED_STATUS } = require('./locationIndex');

/*
 * Tracks location across one customer's messages for one order.
 * State is plain JSON so it can be saved and restored after a restart.
 *
 * Outcome types returned by handle():
 *   RESOLVED           confirmed location (postcode, venue, road, alley or
 *                       pin) - only ever set for a venue whose own status is
 *                       ACTIVE, a postcode the dataset marks ACTIVE, a road/
 *                       alias match with validated/unambiguous context, or
 *                       a customer pin
 *   UNVERIFIED_LOCATION a name match strong enough to auto-resolve on name
 *                       alone, but the venue's trading status isn't ACTIVE
 *                       (UNCERTAIN/MANUAL_REVIEW/etc.) - asks the customer
 *                       to confirm rather than silently dispatching there
 *   FORMER_LOCATION     the phrase names a former/closed/demolished site;
 *                       recognised, but never auto-dispatched
 *   CONFIRM            one likely place; ask "Do you mean X?" (also used for
 *                       a generated alley/footway label whose two ends
 *                       weren't both anchored to a named road - see
 *                       roadIndex.js's anchor_strength)
 *   ASK_TOWN           same name in several towns; ask which town (also used
 *                       when a road/alley name exists in more than one
 *                       locality)
 *   ASK_WHICH          several places in the town; ask which one (also used
 *                       for several distinct roads/alleys in one town)
 *   TOWN_ONLY          town given but no place yet
 *   NOT_IN_TOWN        name known, but not in the town given (venue or road)
 *   SPECIAL            known trap (e.g. Portishead station not open)
 *   POSTCODE_TERMINATED, NOT_FOUND, OUTSIDE_AREA
 *   ETA / ARRIVAL      customer timing; never changes the location
 *   NONE               nothing location-related in the message
 *
 * A postcode's own coordinates (its ONS reference point, not a venue) are
 * never treated as more than an approximate area centre: RESOLVED postcode
 * locations always carry exactPointKnown: false, which is what
 * engine.js._navLink uses to add the "postcode/area only" note to a
 * driver's job offer rather than presenting it as a precise destination. A
 * resolved road/alley carries exactPointKnown: false for the same reason -
 * it is a merged-way centroid, not a verified entrance.
 *
 * ROAD / ALLEY LAYER (offline addition - see
 * CHANGELOG_ROAD_ALLEY_INTEGRATION.md): this.index.roadIndex is an OPTIONAL
 * RoadIndex (src/roadIndex.js) built from data/roads.json + data/alleys.json
 * - a separate layer from data/locations.json's venues/postcodes, never
 * merged into it. Every existing test/install constructs a LocationIndex
 * with no roadIndex attached, so every branch below that touches it is
 * guarded on `this.index.roadIndex` and is a complete no-op (identical
 * behaviour to before this change) when it is absent. Road/alias matching
 * is only ever attempted after postcode and venue matching have both
 * already found nothing for the current message, matching the integration
 * brief's priority order: 1 exact postcode, 2 exact venue, 3 exact road
 * name (+context), 4 exact road alias (+context), 5 exact alley/path name
 * (+context), 6 normalised-but-exact match (case/punctuation/spacing only -
 * this project does not do fuzzy/misspelling matching for venues or roads,
 * so an unrecognised or misspelled road safely falls through to
 * NOT_FOUND/NONE rather than guessing), 7 ambiguous -> ask.
 */

const ETA_RE = /\b(\d{1,2})\s*(?:min|mins|minute|minutes|m)\b/;
const ARRIVAL_RE = /\b(here now|im here|i am here|im outside|i am outside|outside now|ive arrived|i have arrived|arrived)\b/;
const YES_RE = /^(yes|yeah|yep|yea|yh|ye|y|correct|thats it|thats the one|that one|sound|ok|okay)\b/;
const NO_RE = /^(no|nope|nah|wrong|not that)\b/;

function emptyState() {
  return {
    town: null, // last town the customer named
    pending: null, // { phrase, candidateIds } waiting for a town (venues)
    pendingRoad: null, // { phrase, layer, candidateIds } waiting for a town (roads/alleys)
    proposed: null, // { location, alternatives } waiting for a yes
    confirmed: null, // the location we will send a driver to
    etaMinutes: null,
    arrived: false,
  };
}

function venueLocation(venue, kind) {
  return {
    type: 'venue',
    venueId: venue.id,
    name: venue.name,
    town: venue.town,
    postcode: venue.postcode || null,
    lat: venue.lat,
    lng: venue.lng,
    matchKind: kind,
    exactPointKnown: venue.lat != null,
  };
}

// A road/alley centroid is a real, spatially-derived coordinate (see
// roadIndex.js's module header) but never a verified entrance - always
// exactPointKnown: false, the same treatment a bare postcode gets, so
// engine.js._navLink's "postcode/area only" driver note applies here too.
// `customerContextTown`, when given, is the town the CUSTOMER actually
// named (or that was already known from conversation context) - kept
// separate from `town`/`locality` (the road/alley's own, real OSM-derived
// locality, always preserved as-is - see CHANGELOG_LOCALITY_CONTEXT_AND_
// HIGHSTREET_FIX.md's "do not falsify source geography" rule). Driver-
// facing text prefers customerContextTown when present (engine.js's
// _placeLabel) since it is what the customer will recognise, without ever
// overwriting the underlying geography field.
function roadLocation(rec, kind, layer, customerContextTown, aliasMeta, houseNumber) {
  return {
    type: layer === 'ALLEY' ? 'alley' : 'road',
    id: rec.id,
    name: rec.name,
    officialName: rec.official_name || null,
    town: rec.town,
    locality: rec.town,
    customerContextTown: customerContextTown || null,
    // A house/flat number given alongside the road name ("33 Greenfield
    // Crescent") - label only, same treatment as the postcode layer's
    // `street` field (locationIndex.js's findStreet): it is never used to
    // compute or move a coordinate, only shown to the driver. Kept as just
    // the number (not the whole "33 Greenfield Crescent" phrase) since
    // `name` above already carries the street name - see
    // CHANGELOG_HOUSE_NUMBER_FIX.md.
    houseNumber: houseNumber || null,
    district: rec.district,
    postcode: rec.postcode,
    postcodeDistrict: rec.postcode_district,
    lat: rec.lat,
    lng: rec.lng,
    matchKind: kind,
    // `localAlias`, when present, is who/what the customer actually named
    // ("the Bridge Inn", "Kenn Road") for a local-landmark-anchored alley
    // match - see roadIndex.js's alleyAliasMeta and
    // CHANGELOG_ALLEY_LOCAL_ALIAS.md. It never replaces the alley's own
    // real name/id above; it's additional context for driver text.
    localAlias: aliasMeta
      ? { anchorType: aliasMeta.anchorType, anchorName: aliasMeta.anchorName, relationship: aliasMeta.relationship }
      : null,
    matchMethod:
      kind === 'local_alias'
        ? 'ALLEY_LOCAL_ALIAS_MATCH'
        : layer === 'ALLEY'
        ? 'ALLEY_NAME_MATCH'
        : kind === 'name'
        ? 'ROAD_NAME_MATCH'
        : 'ROAD_ALIAS_MATCH',
    confidence:
      kind === 'local_alias'
        ? aliasMeta && aliasMeta.autoResolveAllowed
          ? 'MEDIUM'
          : 'LOW'
        : layer === 'ALLEY'
        ? rec.anchor_strength === 'named' || rec.anchor_strength === 'road_pair'
          ? 'MEDIUM'
          : 'LOW'
        : kind === 'name'
        ? 'HIGH'
        : 'MEDIUM',
    source: rec.source,
    exactPointKnown: false,
  };
}

class LocationConversation {
  constructor(index, state) {
    this.index = index;
    this.state = state || emptyState();
  }

  /**
   * @param {string} raw  one customer message
   * @param {object} opts { allowPartial: boolean }
   */
  handle(raw, opts = {}) {
    const s = this.state;
    const key = normalise(raw);

    // Timing messages are recorded but never touch the location
    // ("im 10 mins" must not replace a confirmed meeting point).
    const eta = key.match(ETA_RE);
    const arrival = ARRIVAL_RE.test(key);
    if (eta) s.etaMinutes = parseInt(eta[1], 10);
    if (arrival) s.arrived = true;

    // 1. Map pin: independent location evidence. Service area is NOT proven by
    // it (a pin can land anywhere), but the pin's own coordinates ARE exact -
    // unlike a bare postcode, there's a real entrance point here, not just an
    // area centroid, so this does not get the "postcode/area only" driver note.
    const pin = this.index.findPin(raw);
    if (pin) {
      s.confirmed = { ...pin, name: 'Shared location pin', serviceAreaVerified: false, exactPointKnown: true };
      s.pending = null;
      s.proposed = null;
      return { type: 'RESOLVED', location: s.confirmed };
    }

    // 2. Full postcode - and, riding along in the same message, an optional
    // street name that refines the human-readable meeting point (see
    // locationIndex.js's STREET_RE comment: this is a label only, it never
    // moves the coordinate GPS automation measures against).
    const pc = this.index.findPostcode(raw);
    const streetHere = this.index.findStreet(raw);
    if (pc && pc.status !== 'PARTIAL') {
      s.pending = null;
      s.proposed = null;
      if (pc.status === 'ACTIVE') {
        s.confirmed = {
          type: 'postcode',
          name: pc.postcode,
          postcode: pc.postcode,
          lat: pc.lat,
          lng: pc.lng,
          exactPointKnown: false, // postcode point, not an entrance
          street: streetHere ? streetHere.phrase : null,
        };
        return { type: 'RESOLVED', location: s.confirmed };
      }
      if (pc.status === 'TERMINATED') return { type: 'POSTCODE_TERMINATED', postcode: pc.postcode };
      if (pc.status === 'OUTSIDE_AREA') return { type: 'OUTSIDE_AREA', postcode: pc.postcode };
      return { type: 'NOT_FOUND', reason: 'postcode not in the August 2026 ONS list' };
    }
    // A street name given alongside only a PARTIAL/outward postcode (e.g.
    // "Silver Street, BS49" with no full unit postcode) cannot be resolved
    // to a coordinate here - there is no street gazetteer to geocode it
    // against, and guessing would risk sending a driver to the wrong place.
    // Surface the street in the reason so a human (Boss/driver conversation)
    // has it, rather than silently dropping it.
    // EXCEPT: once a real road layer is attached (this.index.roadIndex),
    // that street-shaped phrase may in fact BE a road we can geocode - let
    // it fall through to the road/alias matching below instead of bailing
    // out early. Legacy behaviour (no road layer) is unchanged.
    if (pc && pc.status === 'PARTIAL' && streetHere && !this.index.roadIndex) {
      return { type: 'NOT_FOUND', reason: 'postcode district only', street: streetHere.phrase };
    }
    const postcodeDistrictHint = pc && pc.status === 'PARTIAL' ? pc.outward : null;

    // 3. "yes" / "no" to a "Do you mean X?" question. A reply that STARTS with
    // an affirmative word but goes on to name a different real place ("yeah
    // not the anchor, the crown please") is a correction, not a confirmation -
    // check for an embedded venue name before trusting the leading "yeah".
    if (s.proposed) {
      const correction = this.index.findVenue(key);
      if (YES_RE.test(key) && !correction) {
        s.confirmed = s.proposed.location;
        s.proposed = null;
        s.pending = null;
        return { type: 'RESOLVED', location: s.confirmed };
      }
      if (NO_RE.test(key)) {
        s.proposed = null;
        return { type: 'NOT_FOUND', reason: 'customer rejected suggestion' };
      }
    }

    // 4. Venue names, then towns in the remaining words
    let match = this.index.findVenue(key);
    // Road/alley matching (offline addition - see the ROAD / ALLEY LAYER
    // note above). A fuzzy road/alias result can never override a REAL
    // venue match - but a "venue match" that is only a generic ambiguity
    // term (e.g. "station", which every railway-adjacent venue is indexed
    // under) is not that: "station road yatton" should resolve the ROAD,
    // not ask which station-flavoured venue the customer meant, because
    // "station road" is a longer, more specific phrase than the bare
    // ambiguity term "station" alone. Only a strictly LONGER road/alias
    // phrase is allowed to win over a weak venue match, and a genuine
    // canonical/confirmed venue name match is never weak, so it is never
    // second-guessed here.
    // A local alley alias ("alley by the Bridge Inn", "alley off Kenn
    // Road" - see roadIndex.js's alleyAliasMeta / CHANGELOG_ALLEY_LOCAL_
    // ALIAS.md) is a DIFFERENT case from the generic weak-match override
    // above: the customer explicitly said "alley"/"alleyway"/"off"/"by",
    // so even when the embedded venue/road name is itself a real, strong
    // venue match, the longer, more specific local-alias phrase is what
    // they actually meant. Still only overrides when strictly longer than
    // the venue's own matched phrase, same "more specific wins" principle
    // used everywhere else in this module.
    let roadMatch = null;
    if (this.index.roadIndex) {
      const matchIsWeak = !match || match.generic || match.candidates.every((c) => c.kind === 'partial');
      const rm = this.index.roadIndex.findMatch(key);
      const rmIsLocalAlias = rm && rm.layer === 'ALLEY' && rm.candidates.some((c) => c.kind === 'local_alias');
      const rmLonger = rm && (!match || rm.phrase.split(' ').length > match.phrase.split(' ').length);
      if (rm && rmLonger && (matchIsWeak || rmIsLocalAlias)) {
        roadMatch = rm;
        match = null;
      }
    }
    // A phrase that names a historic/former site by a name no CURRENT venue
    // carries (distinct from a current venue whose own status has gone
    // DEMOLISHED/FORMER/CLOSED - that's handled inside _resolve() below via
    // FORMER_STATUSES, since it still matches by name normally). Checked
    // only once an ordinary venue match has already failed, so a former
    // name never shadows a real current venue that happens to share words.
    if (!match && !roadMatch) {
      const former = this.index.findFormerLocation(key);
      if (former) {
        s.pending = null;
        s.proposed = null;
        return {
          type: 'FORMER_LOCATION',
          reason: former.note || 'historic name - not a current dispatchable location',
          formerName: former.formerName || former.phrase,
          currentVenueId: former.currentVenueId || null,
        };
      }
    }
    const timingOnly = (eta || arrival) && !match && !roadMatch;
    if (!match && !roadMatch && opts.allowPartial && !timingOnly && key.split(' ').length <= 5) {
      match = this.index.findPartial(key);
    }
    const towns = this.index.findTowns(key, (match && match.span) || (roadMatch && roadMatch.span));
    const namedTown = towns.length ? towns[towns.length - 1] : null;
    if (namedTown) s.town = namedTown; // the latest explicit town wins

    if (match) {
      // A new place name supersedes any earlier suggestion.
      s.proposed = null;
      return this._resolve(match.phrase, match.candidates, match.generic);
    }

    if (roadMatch) {
      s.proposed = null;
      return this._resolveRoad(roadMatch, postcodeDistrictHint, streetHere && streetHere.houseNumber);
    }

    if (namedTown) {
      if (s.pending) {
        const { phrase, candidates, generic } = s.pending;
        return this._resolve(phrase, candidates.map((c) => ({
          venue: this.index.venue(c.id), kind: c.kind,
        })), generic);
      }
      if (s.pendingRoad && this.index.roadIndex) {
        const { phrase, layer, candidateIds, aliasMetaById, houseNumber } = s.pendingRoad;
        const candidates = candidateIds
          .map((id) => this.index.roadIndex.get(id))
          .filter(Boolean)
          .map((road) => ({ road, kind: 'context', aliasMeta: (aliasMetaById && aliasMetaById[road.id]) || null }));
        return this._resolveRoad({ phrase, layer, candidates }, postcodeDistrictHint, houseNumber);
      }
      if (s.proposed) {
        // keep the suggestion if it is in that town, otherwise drop it
        if (s.proposed.location.town === namedTown) {
          return { type: 'CONFIRM', location: s.proposed.location, alternatives: s.proposed.alternatives };
        }
        s.proposed = null;
      }
      if (s.confirmed) return { type: 'NONE' };
      return { type: 'TOWN_ONLY', town: namedTown };
    }

    // 5. A street name arriving on its own, after a location is already
    // confirmed (postcode, venue, road or alley) - a follow-up like "it's
    // Silver Street" (postcode/venue) or "it's number 33" (road/alley,
    // whose own name already carries the street name) after the location
    // was already given. Refines the label only (see the STREET_RE comment
    // in locationIndex.js); the confirmed coordinate is untouched, so this
    // can never move where GPS automation measures against - it only
    // changes what a driver reads. Timing-only messages keep their
    // existing priority (see the "never touch the location" comment at the
    // top of this method) so this only fires when the message isn't purely
    // an ETA/arrival update.
    if (!eta && !arrival && s.confirmed && streetHere) {
      const isRoadOrAlley = s.confirmed.type === 'road' || s.confirmed.type === 'alley';
      if (isRoadOrAlley) {
        if (streetHere.houseNumber && s.confirmed.houseNumber !== streetHere.houseNumber) {
          s.confirmed = { ...s.confirmed, houseNumber: streetHere.houseNumber };
          return { type: 'RESOLVED', location: s.confirmed };
        }
      } else if (s.confirmed.street !== streetHere.phrase) {
        s.confirmed = { ...s.confirmed, street: streetHere.phrase };
        return { type: 'RESOLVED', location: s.confirmed };
      }
    }

    if (arrival) return { type: 'ARRIVAL' };
    if (eta) return { type: 'ETA', minutes: s.etaMinutes };
    if (pc && pc.status === 'PARTIAL') return { type: 'NOT_FOUND', reason: 'postcode district only' };
    return { type: 'NONE' };
  }

  _resolve(phrase, rawCandidates, generic) {
    const s = this.state;
    // Best kind per venue; never offer a demolished/former/closed site as a
    // meeting point - but keep them (in `former`) so a match against ONLY
    // such sites can be reported as FORMER_LOCATION rather than a bare,
    // unexplained NOT_FOUND.
    const byId = new Map();
    for (const c of rawCandidates) {
      if (!c.venue) continue;
      const prev = byId.get(c.venue.id);
      if (!prev || KIND_RANK[c.kind] > KIND_RANK[prev.kind]) byId.set(c.venue.id, c);
    }
    const allCands = [...byId.values()];
    const former = allCands.filter((c) => FORMER_STATUSES.has(c.venue.status));
    let cands = allCands.filter(
      (c) => !FORMER_STATUSES.has(c.venue.status) && c.venue.meetingPoint !== false
    );
    if (!cands.length) {
      s.pending = null;
      s.proposed = null;
      if (former.length) {
        return {
          type: 'FORMER_LOCATION',
          reason: 'former/closed/demolished site - not currently dispatchable',
          candidates: former.map((c) => ({ venueId: c.venue.id, name: c.venue.name, status: c.venue.status })),
        };
      }
      return { type: 'NOT_FOUND', reason: 'only a closed or demolished place matched' };
    }

    const town = s.town;
    if (town) {
      const rule = this.index.notOperationalRule(phrase, town);
      if (rule) {
        s.pending = null;
        return { type: 'SPECIAL', town, reply: rule.reply };
      }
    }
    if (town && this.index.isVenueTown(town)) {
      const inTown = cands.filter((c) => c.venue.town === town);
      if (!inTown.length) {
        s.pending = null;
        return { type: 'NOT_IN_TOWN', town, phrase };
      }
      cands = inTown;
    } else {
      const candTowns = [...new Set(cands.map((c) => c.venue.town || 'UNRESOLVED'))];
      if (candTowns.length > 1) {
        s.pending = {
          phrase,
          generic,
          candidates: cands.map((c) => ({ id: c.venue.id, kind: c.kind })),
        };
        return { type: 'ASK_TOWN', towns: candTowns.filter((t) => t !== 'UNRESOLVED') };
      }
    }
    s.pending = null;

    if (cands.length === 1) {
      const c = cands[0];
      const loc = venueLocation(c.venue, c.kind);
      // Commit only on a strong name for a venue with a known town, and only if
      // the customer named that town or used a multi-word name. Otherwise ask.
      const townKnown = c.venue.town && c.venue.town !== 'UNRESOLVED';
      const townGiven = town && town === c.venue.town;
      const multiWord = phrase.includes(' ');
      if (STRONG.has(c.kind) && townKnown && (townGiven || multiWord)) {
        // A strong, unambiguous name match is still not enough on its own -
        // most of the research pack's venues (see RESEARCH_README.md) have
        // never been individually checked for current trading status. Only
        // a venue the dataset marks ACTIVE gets auto-confirmed; anything
        // else (UNCERTAIN, MANUAL_REVIEW, or an unrecognised status) is
        // asked back as UNVERIFIED_LOCATION - same "yes"/correction flow as
        // CONFIRM (s.proposed), just a different reason for the customer.
        if (c.venue.status === VERIFIED_STATUS) {
          s.confirmed = loc;
          return { type: 'RESOLVED', location: loc };
        }
        s.proposed = { location: loc, alternatives: [] };
        return { type: 'UNVERIFIED_LOCATION', location: loc, alternatives: [], reason: 'trading status not individually verified' };
      }
      s.proposed = { location: loc, alternatives: [] };
      return { type: 'CONFIRM', location: loc, alternatives: [] };
    }

    // Several in one town. If exactly one is a strong name match, suggest it
    // but keep the others (e.g. "grove" in Nailsea).
    const strong = cands.filter((c) => STRONG.has(c.kind));
    if (strong.length === 1) {
      const loc = venueLocation(strong[0].venue, strong[0].kind);
      const alternatives = cands
        .filter((c) => c !== strong[0])
        .map((c) => ({ venueId: c.venue.id, name: c.venue.name }));
      s.proposed = { location: loc, alternatives };
      return { type: 'CONFIRM', location: loc, alternatives };
    }
    // Best-named first, so the question leads with the likeliest place.
    cands.sort((a, b) => KIND_RANK[b.kind] - KIND_RANK[a.kind]);
    s.pending = {
      phrase,
      generic,
      candidates: cands.map((c) => ({ id: c.venue.id, kind: c.kind })),
    };
    return {
      type: 'ASK_WHICH',
      town: cands[0].venue.town,
      options: cands.map((c) => ({ venueId: c.venue.id, name: c.venue.name })),
    };
  }

  /**
   * Resolve a road/alley phrase match from this.index.roadIndex against
   * whatever town/district context is already known - mirrors _resolve()'s
   * shape (RESOLVED / CONFIRM / ASK_TOWN / ASK_WHICH / NOT_IN_TOWN) so
   * engine.js needs no new switch cases. `match` is
   * { phrase, layer: 'ROAD'|'ALLEY', candidates: [{ road, kind }] }.
   * `districtHint` is a bare outward postcode (e.g. "BS48") given alongside
   * the road name with no full postcode - used only when no town is known,
   * never allowed to override an explicit, named town. `houseNumber`, when
   * given, is a house/flat number from the SAME original message (or
   * carried over from s.pendingRoad if this call is a town-clarification
   * follow-up) - label only, see roadLocation()'s comment.
   */
  _resolveRoad(match, districtHint, houseNumber) {
    const s = this.state;
    const byId = new Map();
    for (const c of match.candidates) {
      if (!c.road) continue;
      byId.set(c.road.id, c);
    }
    let cands = [...byId.values()];
    if (!cands.length) {
      s.pendingRoad = null;
      return { type: 'NOT_FOUND', reason: 'road/alley candidate no longer available' };
    }

    const town = s.town;
    if (town) {
      const normTown = normalise(town);
      // A candidate counts as "in that town" if either (a) its own OSM
      // locality is an exact match - the strongest evidence - or (b) an
      // evidence-backed accepted_town_context says so (see
      // CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md /
      // src/roadIndex.js's acceptedTownContexts) - e.g. "station rd
      // backwell" matching a road whose OSM locality is "West Town", where
      // real venue-postcode evidence on that exact road independently
      // confirms "Backwell". This never rewrites the road's own locality
      // field, and it is scoped per road_id, never a blanket remap.
      const inTown = cands.filter(
        (c) =>
          (c.road.town && normalise(c.road.town) === normTown) ||
          (this.index.roadIndex && this.index.roadIndex.acceptsTown(c.road.id, normTown))
      );
      if (!inTown.length) {
        s.pendingRoad = null;
        return { type: 'NOT_IN_TOWN', town, phrase: match.phrase };
      }
      cands = inTown;
    } else if (districtHint && cands.length > 1) {
      // No town named, but the customer gave a bare postcode district
      // alongside the road name ("weston road bs48") - use it only to
      // narrow, never to force a single candidate the district doesn't
      // actually contain.
      const inDistrict = cands.filter((c) => c.road.postcode_district === districtHint);
      if (inDistrict.length) cands = inDistrict;
    }

    if (cands.length === 1) {
      const c = cands[0];
      s.pendingRoad = null;
      const loc = roadLocation(c.road, c.kind, match.layer, town || null, c.aliasMeta, houseNumber);
      // A generated alley/footway label anchored to only a locality or a
      // district (see roadIndex.js's anchor_strength) is weaker evidence
      // than a real name or a two-road-anchored label - ask rather than
      // silently sending a driver down it. A local landmark/anchor alias
      // (c.aliasMeta - see roadIndex.js/CHANGELOG_ALLEY_LOCAL_ALIAS.md)
      // carries its own, geometry-derived auto-resolve decision that
      // overrides the alley's own default anchor_strength when present,
      // since the SAME alley can have both a strong alias ("kenn road
      // alley") and a weak one ("alley near church road").
      const weak = c.aliasMeta
        ? !c.aliasMeta.autoResolveAllowed
        : match.layer === 'ALLEY' && ['locality_only', 'district_only'].includes(c.road.anchor_strength);
      if (weak) {
        s.proposed = { location: loc, alternatives: [] };
        return { type: 'CONFIRM', location: loc, alternatives: [] };
      }
      s.confirmed = loc;
      return { type: 'RESOLVED', location: loc };
    }

    // More than one candidate left. Several different localities -> ask
    // which town; same locality (e.g. two unmerged stretches of the same
    // name - see source_conflicts.csv from the offline build) -> ask which.
    const townsHere = [...new Set(cands.map((c) => c.road.town || 'that area'))];
    const aliasMetaById = {};
    for (const c of cands) if (c.aliasMeta) aliasMetaById[c.road.id] = c.aliasMeta;
    s.pendingRoad = {
      phrase: match.phrase,
      layer: match.layer,
      candidateIds: cands.map((c) => c.road.id),
      aliasMetaById,
      houseNumber: houseNumber || null,
    };
    if (townsHere.length > 1) {
      return { type: 'ASK_TOWN', towns: townsHere };
    }
    return {
      type: 'ASK_WHICH',
      town: townsHere[0],
      options: cands.map((c) => ({ id: c.road.id, name: c.road.name })),
    };
  }
}

module.exports = { LocationConversation, emptyState };
