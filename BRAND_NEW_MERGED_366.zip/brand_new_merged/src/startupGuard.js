'use strict';

/*
 * Security startup guard (Remaining Offline Fixes brief, item 8).
 *
 * Rocket must refuse to start in staging/production if obvious placeholder
 * credentials remain, including the literal string
 * "CHANGE_ME_BEFORE_GOING_LIVE", and must also refuse the known development
 * encryption key fallback (see src/store.js's DEV_FALLBACK_KEY / the
 * usingDevFallback flag it returns).
 *
 * This is deliberately a small, pure, synchronous check with no side
 * effects of its own - it does not read env vars or touch config on its
 * own; the caller (server/index.js's require.main === module block) passes
 * in everything it needs. That keeps it trivially testable (no server has
 * to actually be started to exercise it) and keeps it from ever running
 * during the 292+ existing tests, none of which call it - createApp() never
 * calls this guard itself, only a real "node server/index.js" run does.
 *
 * "development" and "test" environments are intentionally permissive: they
 * may use explicit placeholder/test credentials and the dev encryption key
 * fallback freely. Only "staging" and "production" are enforced.
 */

const PLACEHOLDER = 'CHANGE_ME_BEFORE_GOING_LIVE';
const ENFORCED_ENVS = new Set(['staging', 'production']);

/**
 * @param {object} opts
 * @param {string} [opts.env] - e.g. process.env.ROCKET_ENV; defaults to 'development'
 * @param {object} opts.config - the loaded config.json object
 * @param {boolean} opts.usingDevFallback - Store's usingDevFallback flag (no ROCKET_STATE_KEY set)
 * @returns {{ ok: true }} if safe to start
 * @throws {Error} listing every problem found, if not safe to start
 */
function checkStartupSafety({ env, config, usingDevFallback } = {}) {
  const environment = (env || 'development').toLowerCase();
  if (!ENFORCED_ENVS.has(environment)) {
    return { ok: true, environment, enforced: false };
  }

  const problems = [];

  const tokenChecks = [
    ['boss.token', config && config.boss && config.boss.token],
    ['gateway.token', config && config.gateway && config.gateway.token],
    ['gps.forwardToken', config && config.gps && config.gps.forwardToken],
  ];
  for (const [name, value] of tokenChecks) {
    if (!value || value === PLACEHOLDER) {
      problems.push(
        `config.${name} is still the placeholder "${PLACEHOLDER}" (or unset). ` +
        `Set a real secret before starting in ${environment}.`
      );
    }
  }

  if (usingDevFallback) {
    problems.push(
      'ROCKET_STATE_KEY is not set - state.json would be encrypted with the fixed, ' +
      `publicly-known development key. Set ROCKET_STATE_KEY before starting in ${environment}.`
    );
  }

  if (problems.length) {
    const err = new Error(
      `Refusing to start Rocket Dispatch in ${environment}: ${problems.length} unsafe ` +
      `default(s) found:\n - ${problems.join('\n - ')}`
    );
    err.problems = problems;
    err.code = 'ROCKET_STARTUP_UNSAFE';
    throw err;
  }

  return { ok: true, environment, enforced: true };
}

module.exports = { checkStartupSafety, PLACEHOLDER, ENFORCED_ENVS };
