'use strict';

/**
 * Groups quick successive messages from the same phone number so
 * "Yo" then "where you to?" produces one reply, not two.
 * Pure/testable: caller supplies `now`.
 */
class BurstBuffer {
  constructor({ windowMs = 6000 } = {}) {
    this.windowMs = windowMs;
    this.buffers = new Map(); // phone -> { texts, ids, lastAt }
  }

  // pendingId: the id returned by Engine.recordPendingInboundSms for this
  // exact message, if the caller already durably saved it (see
  // server/index.js's /sms/inbound handler and CHANGELOG_SMS_INBOUND_
  // DURABILITY.md). Carried through flushReady() so the caller can clear
  // the durable record once the burst it ended up in has actually been
  // processed - optional so BurstBuffer stays usable on its own in tests.
  add(phone, text, messageId, now, pendingId) {
    const b = this.buffers.get(phone);
    if (b) {
      b.texts.push(text);
      if (messageId) b.ids.push(messageId);
      if (pendingId) b.pendingIds.push(pendingId);
      b.lastAt = now;
    } else {
      this.buffers.set(phone, {
        texts: [text],
        ids: messageId ? [messageId] : [],
        pendingIds: pendingId ? [pendingId] : [],
        lastAt: now,
      });
    }
  }

  /** Buffers whose window has elapsed. Removes them from the pending set. */
  flushReady(now) {
    const ready = [];
    for (const [phone, b] of this.buffers) {
      if (now - b.lastAt >= this.windowMs) {
        ready.push({ phone, texts: b.texts, ids: b.ids, pendingIds: b.pendingIds });
        this.buffers.delete(phone);
      }
    }
    return ready;
  }
}

module.exports = { BurstBuffer };
