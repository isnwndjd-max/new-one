'use strict';

/*
 * Rocket Dispatch engine: one place that owns every order's official status.
 *
 * Transport-agnostic. It takes customer SMS text and driver command text in,
 * and puts outgoing messages into an outbox. The SMS gateway (Tasker) and the
 * driver channel (Signal adapter, not built yet) only move text in and out.
 *
 * All state is plain JSON (this.state) so it can be saved after every change
 * and restored after a restart.
 */

const crypto = require('crypto');
const { normalise } = require('./text');
const { LocationConversation, emptyState } = require('./locationConversation');
const { VERIFIED_STATUS } = require('./locationIndex');
const { parseItems, mergeItems, priceOrder, describeItems, menuText } = require('./menu');
const { haversineMetres, etaMinutes } = require('./gps');

const ORDER_STATES = [
  'DRAFT', // collecting order + location; the only state the 30-minute timeout applies to
  'CONFIRMED', // order + location confirmed, total sent; waiting for a driver to be free
  'OFFERED', // dispatch started: offer sent to on-duty drivers
  'ASSIGNED', // a driver accepted (first valid ACCEPT wins)
  'EN_ROUTE',
  'ARRIVED',
  'COMPLETED',
  'CANCELLED',
  'EXPIRED',
];
const OPEN = new Set(['DRAFT', 'CONFIRMED', 'OFFERED', 'ASSIGNED', 'EN_ROUTE', 'ARRIVED']);
const WITH_DRIVER = new Set(['ASSIGNED', 'EN_ROUTE', 'ARRIVED']);

const GREETING_RE = /^(hi|hiya|hey|hello|yo|oi|alright|menu|whats on|what you got|what have you got|you about|u about|where you to|where u to|where you at|where are you)\b/;
const CANCEL_RE = /^(cancel|cancel it|cancel order|cancel my order|dont want it|no longer need)\b/;
const REFERRAL_RE = /\b(RF[A-Z0-9]{5})\b/i;
const ORDER_ID_RE = /\b(R\d{4})\b/i;
// The customer ASKING about the driver's ETA ("how long you going to be",
// "how far are you", "eta?") - distinct from the customer STATING their own
// ETA to relay to the driver ("I'll be 10 minutes"), which locationConversation's
// ETA_RE already handles. This one needs no number in the text at all.
const ETA_QUESTION_RE = /\b(how long|how far|what'?s? the eta|whats the eta|eta\??$|are you close|are you near|you close|you near|you coming|when (will|are) you|when('| i)?s (he|she|it|my driver|the driver))\b/;

// A customer trying to change a CONFIRMED order's items, phrased in a way
// parseItems() can't parse as an actual item line ("add another one of them",
// "can I get extra", "change my order") - see _afterConfirmation's comment:
// this used to go completely silent whenever the wording didn't happen to
// parse as a real item mention, which looks to the customer exactly like
// their message never sent. Deliberately narrow (explicit change/addition
// language), so it still never replies to "thanks"/"cheers"/idle chat.
const ORDER_CHANGE_RE = /\b(add|another one|more of|extra|change (my|the|this) order|amend|swap)\b/;

// A venue with status !== VERIFIED_STATUS ('ACTIVE') always makes a
// customer explicitly confirm it before an order can reach CONFIRMED (see
// locationIndex.js's VERIFIED_STATUS gate). Every time that happens, it's
// one more real customer standing behind the name -> coordinates match.
// After PROMOTION_CONFIRM_THRESHOLD independent orders have confirmed the
// SAME venue, it's added to state.promotionCandidates for a human to
// review and promote to ACTIVE in data/locations.json (see
// scripts/promoteVenues.js) - never auto-promoted live. That keeps the
// same "a person decides before verified data changes" discipline this
// whole project has used for every other new-data-becomes-verified step
// (roads, alleys, ambiguities), while still giving repeat-confirmed
// venues a path to stop asking, per the user's own request.
const PROMOTION_CONFIRM_THRESHOLD = 3;

function money(n) {
  return `£${n.toFixed(2)}`;
}

function fill(template, vars) {
  return template.replace(/\{(\w+)\}/g, (_, k) => (vars[k] === undefined || vars[k] === null ? '' : String(vars[k])));
}

function maskPhone(phone) {
  const s = String(phone || '');
  return s.length > 3 ? `***${s.slice(-3)}` : '***';
}

function emptyEngineState() {
  return {
    version: 1,
    orders: {},
    activeByPhone: {},
    drivers: {},
    driversByTraccarId: {}, // traccar device uniqueId -> internal driver id
    outbox: [],
    review: [],
    debts: [],
    customers: {}, // phone -> { points, completedOrders }
    referralCodes: {}, // code -> { ownerPhone, issuedForOrder, usedByOrder, redeemed }
    seenInbound: {},
    venueConfirmations: {}, // venueId -> count of orders that explicitly confirmed a not-yet-ACTIVE venue
    promotionCandidates: [], // venueIds that reached PROMOTION_CONFIRM_THRESHOLD - see scripts/promoteVenues.js
    pendingInboundSms: [], // raw inbound SMS durably saved before processing - see recordPendingInboundSms
    // ---- Remaining Offline Fixes brief ----
    stock: {}, // menu item code -> { total, reserved, lowStockThreshold } - see _reserveStock/_deductStock/restockProduct
    stockLedger: [], // durable stock movement audit trail - see _stockAudit
    lowStockAlerts: [], // codes currently at/under their threshold
    freeItemRewards: [], // { id, phone, sourceReferralCode, status: 'available'|'redeemed', earnedAt, redeemedAt, redeemedOrderId, itemCode }
    pointsAdjustments: [], // Boss manual loyalty adjustments - audit trail, see adjustLoyaltyPoints
    idempotency: {}, // key -> result, for Boss-triggered ops that must be safe to retry (restock/adjust/points/cash)
    auditLog: [], // durable, bounded mirror of every _event() call (order-scoped or not) - see _event
  };
}

class Engine {
  constructor({ index, menu, messages, config, state, audit, now }) {
    this.index = index;
    this.menu = menu;
    this.msg = messages;
    this.config = config;
    this.state = state || emptyEngineState();
    this.audit = audit || (() => {});
    this.now = now || (() => Date.now());
  }

  // ---------------------------------------------------------------- helpers

  _event(order, type, detail) {
    const at = this.now();
    if (order) {
      order.events.push({ at, type, detail: detail || null });
      if (order.events.length > 200) order.events.shift();
    }
    // Durable mirror: previously only order.events was durable (state.json)
    // and this.audit() was an in-memory-only callback (server/index.js's
    // auditLog, capped at 5000, lost on restart) - a general-purpose event
    // with no order (stock/loyalty/cash/driver adjustments) had NO durable
    // trail at all. Every _event() call now also lands here, so "complete
    // audit trail" / "restart-safe" hold for those too, not just orders.
    if (!this.state.auditLog) this.state.auditLog = [];
    this.state.auditLog.push({ at, orderId: order ? order.id : null, type, detail: detail || null });
    if (this.state.auditLog.length > 5000) this.state.auditLog.shift();
    this.audit({ at, orderId: order ? order.id : null, type, detail: detail || null });
  }

  _newOrderId() {
    for (let i = 0; i < 1000; i++) {
      const id = `R${crypto.randomInt(1000, 10000)}`;
      if (!this.state.orders[id]) return id;
    }
    throw new Error('could not allocate order id');
  }

  _review(order, reason) {
    const existing = this.state.review.find(
      (r) => !r.resolved && r.orderId === (order ? order.id : null) && r.reason === reason
    );
    if (existing) return;
    this.state.review.push({
      id: crypto.randomUUID(),
      orderId: order ? order.id : null,
      reason,
      at: this.now(),
      resolved: false,
    });
    this._event(order, 'REVIEW_FLAGGED', reason);
  }

  _queue(channel, to, text, orderId, key) {
    if (key && orderId) {
      const dup = this.state.outbox.find((m) => m.orderId === orderId && m.key === key && m.to === to);
      if (dup) return null;
    }
    const m = {
      id: crypto.randomUUID(),
      channel, // 'sms' (customer, via Tasker) or 'driver' (via Signal adapter)
      to,
      text,
      orderId: orderId || null,
      key: key || null,
      status: 'pending',
      createdAt: this.now(),
      claimedAt: null,
      error: null,
    };
    this.state.outbox.push(m);
    return m;
  }

  // Customer event messages go out once per order, keyed by event name.
  _sendOnce(order, key, text) {
    if (order.sent[key]) return false;
    order.sent[key] = this.now();
    this._queue('sms', order.phone, text, order.id, key);
    this._event(order, 'CUSTOMER_MSG_QUEUED', key);
    return true;
  }

  // Questions: never send the same question twice in a row.
  _ask(order, text, key) {
    if (order.lastQuestion === text) return false;
    order.lastQuestion = text;
    this._queue('sms', order.phone, text, order.id, null);
    this._event(order, 'CUSTOMER_QUESTION_QUEUED', key);
    return true;
  }

  _driverMsg(driverId, text, orderId, key) {
    this._queue('driver', driverId, text, orderId, key);
  }

  _placeLabel(loc) {
    if (!loc) return '';
    // A street name, when the customer gave one, is a human-readable
    // refinement only (see locationIndex.js's STREET_RE comment) - it goes
    // in front of whatever the resolution already produced, it never
    // replaces it, and it never changes loc.lat/loc.lng.
    if (loc.type === 'venue') {
      return [loc.street, loc.name, loc.town, loc.postcode ? `(${loc.postcode})` : null].filter(Boolean).join(', ');
    }
    if (loc.type === 'road' || loc.type === 'alley') {
      // Prefer the town the customer actually named/context confirmed
      // (see roadLocation()'s customerContextTown comment) over the road's
      // raw OSM locality, which can be a hamlet/neighbourhood name the
      // customer never used (e.g. "West Town" for a Backwell road) - the
      // underlying geography is untouched, only the driver-facing text
      // prefers the recognisable name. A house/flat number, when given
      // alongside the road name (loc.houseNumber - see roadLocation()'s
      // comment and CHANGELOG_HOUSE_NUMBER_FIX.md), goes in front of the
      // street name, same as a postcode's `street` label does below -
      // never affects the coordinate, only what the driver reads.
      const streetLine = loc.houseNumber ? `${loc.houseNumber} ${loc.name}` : loc.name;
      return [streetLine, loc.customerContextTown || loc.town, loc.postcode ? `(${loc.postcode})` : null]
        .filter(Boolean)
        .join(', ');
    }
    if (loc.type === 'postcode') return [loc.street, loc.postcode].filter(Boolean).join(', ');
    return 'shared location pin';
  }

  _navLink(loc, mode) {
    if (!loc) return '';
    let lat = loc.lat;
    let lng = loc.lng;
    if ((lat == null || lng == null) && loc.type === 'venue' && loc.postcode) {
      const pc = this.index.data.activePostcodes[loc.postcode];
      if (pc) {
        lat = pc.lat;
        lng = pc.lng;
      }
    }
    if (lat == null || lng == null) return loc.raw || '(no map point - ask dispatch for a pin)';
    const tpl = this.config.navigation[mode === 'FOOT' ? 'FOOT' : 'CAR'];
    return fill(tpl, { lat, lng });
  }

  // Text appended to ask_location with a link the customer can tap to have
  // their phone's browser report its real GPS position straight back into
  // this order (see GET/POST /loc/:orderId in server/index.js). Reuses the
  // order's existing trackingToken - the same one already used to gate the
  // read-only /track/:orderId endpoint - rather than minting a second
  // secret; it's already scoped to "this customer's own order", which is
  // exactly the trust boundary a location-submit endpoint needs too.
  // Empty string (no link at all) if locationShare.publicBaseUrl isn't
  // configured, so ask_location silently falls back to its plain
  // text-only wording rather than sending a broken/local link.
  _locationShareSuffix(order) {
    const base = this.config.locationShare && this.config.locationShare.publicBaseUrl;
    if (!base) return '';
    const url = `${base.replace(/\/$/, '')}/loc/${order.id}?token=${order.trackingToken}`;
    return fill(this.msg.ask_location_link_suffix, { url });
  }

  /**
   * Applied when a customer taps the "share your exact location" link and
   * their phone's browser reports back real GPS coordinates. The caller
   * (server/index.js's POST /loc/:orderId) has already checked the
   * trackingToken before this runs - same split as updateDriverLocation,
   * which trusts its caller to have checked X-Gps-Token first.
   *
   * Only applies while the order is still being drafted (before
   * confirmation) - the same point a pasted map pin or typed postcode
   * would apply. A stale link tapped after the order already confirmed (or
   * a driver is already navigating to it) does not silently move the
   * meeting point out from under them; the customer is told to text
   * dispatch instead if they need to change it (same as any other
   * post-confirmation location change - see _afterConfirmation).
   */
  submitLocationPin(orderId, lat, lng, accuracy) {
    const order = this.state.orders[orderId];
    if (!order) return { ok: false, reason: 'NOT_FOUND' };
    if (order.state !== 'DRAFT') return { ok: false, reason: 'ALREADY_CONFIRMED' };
    if (typeof lat !== 'number' || typeof lng !== 'number' || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
      return { ok: false, reason: 'BAD_COORDS' };
    }
    order.location.confirmed = {
      type: 'pin',
      raw: 'web-share',
      lat,
      lng,
      accuracy: typeof accuracy === 'number' ? accuracy : null,
      name: 'Shared location pin',
      serviceAreaVerified: false,
      exactPointKnown: true,
    };
    order.location.pending = null;
    order.location.proposed = null;
    order.lastCustomerAt = this.now();
    this._event(order, 'LOCATION_OUTCOME', 'WEB_SHARED_PIN');

    const hasItems = !!(order.items && order.items.length);
    if (hasItems) this._confirm(order);
    else this._ask(order, this.msg.ask_order, 'ASK_ORDER');
    return { ok: true, orderId: order.id };
  }

  // ------------------------------------------------------- customer side

  _activeOrderFor(phone) {
    const id = this.state.activeByPhone[phone];
    const o = id && this.state.orders[id];
    return o && OPEN.has(o.state) ? o : null;
  }

  _createDraft(phone) {
    const id = this._newOrderId();
    const now = this.now();
    const order = {
      id,
      phone,
      state: 'DRAFT',
      createdAt: now,
      lastCustomerAt: now,
      items: null,
      total: null,
      pricing: null,
      location: emptyState(),
      sent: {},
      lastQuestion: null,
      driverId: null,
      offeredTo: [],
      offeredAt: null,
      assignedAt: null,
      etaMinutes: null,
      referralCode: null,
      paid: null,
      events: [],
      // A per-order secret for GET /track/:orderId - an order id alone
      // (R1234, 4 digits, trivially guessable/enumerable) must not be
      // enough to see a stranger's live driver location.
      trackingToken: crypto.randomBytes(16).toString('hex'),
    };
    this.state.orders[id] = order;
    this.state.activeByPhone[phone] = id;
    this._event(order, 'DRAFT_CREATED', maskPhone(phone));
    return order;
  }

  /**
   * One burst of customer texts (already grouped by the gateway/server).
   * Produces at most one reply for the burst.
   * @param {string} phone
   * @param {string[]} texts
   */
  handleCustomerBurst(phone, texts) {
    let order = this._activeOrderFor(phone);
    if (!order) order = this._createDraft(phone);
    order.lastCustomerAt = this.now();

    if (order.state !== 'DRAFT') return this._afterConfirmation(order, texts);

    const conv = new LocationConversation(this.index, order.location);
    let greeted = false;
    let anyItems = false;
    let lastLocation = null;

    for (const text of texts) {
      const key = normalise(text);
      if (CANCEL_RE.test(key)) {
        this._cancel(order, 'customer');
        return;
      }
      if (GREETING_RE.test(key)) greeted = true;

      const ref = text.match(REFERRAL_RE);
      if (ref) this._attachReferral(order, ref[1].toUpperCase());
      // Strip the matched referral code out of the text BEFORE it reaches
      // item/location parsing - a random code (RF + 5 alphanumerics) can,
      // purely by chance, take the exact shape of a valid UK postcode
      // (e.g. "RF216CA" reads as outward "RF21" + inward "6CA"), which the
      // location parser would otherwise happily match as a candidate
      // postcode - wrongly, and often ahead of the customer's real
      // postcode later in the same message. Left unfixed, that
      // false-positive resolves to OUTSIDE_AREA and the engine stops
      // right there ("a person decides; no automatic reply"), silently
      // stranding the order in DRAFT even though the real address was
      // right there in the same text. Reproduced directly: about 1 in
      // ~1000 random referral codes trigger this. Item parsing is given
      // the same stripped text for the same reason - a referral code
      // should never be mistaken for anything but a referral code.
      const textForParsing = ref ? text.replace(ref[0], ' ') : text;

      const items = parseItems(textForParsing, this.menu);
      if (items) {
        order.items = mergeItems(order.items, items);
        anyItems = true;
      }
      const outcome = conv.handle(textForParsing, { allowPartial: !items });
      if (!['NONE', 'ETA', 'ARRIVAL'].includes(outcome.type)) lastLocation = outcome;
    }
    order.location = conv.state;
    if (lastLocation) this._event(order, 'LOCATION_OUTCOME', lastLocation.type);

    const hasLocation = !!order.location.confirmed;
    const hasItems = !!(order.items && order.items.length);

    if (lastLocation && lastLocation.type === 'OUTSIDE_AREA') {
      this._review(order, `postcode outside BS48/BS49/BS21/BS20: ${lastLocation.postcode}`);
      return; // a person decides; no automatic reply
    }

    // First contact with nothing usable yet: send the menu once.
    if (!order.sent.MENU && !hasItems && !hasLocation && (greeted || !lastLocation)) {
      const text = [this.msg.menu_intro, menuText(this.menu), this.msg.menu_cash_line].join('\n');
      this._sendOnce(order, 'MENU', text);
      return;
    }

    if (hasItems && hasLocation) return this._confirm(order);

    // A location question takes priority over asking for the order.
    if (lastLocation && lastLocation.type !== 'RESOLVED') {
      const q = this._locationQuestion(lastLocation);
      if (q) return void this._ask(order, q, lastLocation.type);
    }
    if (!hasItems && hasLocation) return void this._ask(order, this.msg.ask_order, 'ASK_ORDER');
    if (hasItems && !hasLocation) {
      return void this._ask(order, fill(this.msg.ask_location, { link: this._locationShareSuffix(order) }), 'ASK_LOCATION');
    }
    if (!hasItems && !hasLocation && order.sent.MENU && !anyItems && !lastLocation) {
      // Unclear message after the menu was already sent: flag, don't spam.
      this._review(order, 'unclear message from customer');
    }
  }

  _locationQuestion(o) {
    const m = this.msg;
    switch (o.type) {
      case 'ASK_TOWN': {
        const towns = o.towns.length && o.towns.length <= 4 ? ` (${o.towns.join(', ')})` : '';
        return fill(m.ask_town, { towns });
      }
      case 'ASK_WHICH':
        if (o.options.length <= 4) {
          return fill(m.ask_which, { town: o.town, options: o.options.map((x) => x.name).join(', ') });
        }
        return fill(m.ask_which_many, { town: o.town });
      case 'CONFIRM':
        return fill(m.confirm_place, { place: this._placeLabel(o.location) });
      case 'UNVERIFIED_LOCATION':
        return fill(m.unverified_location, { place: this._placeLabel(o.location) });
      case 'FORMER_LOCATION':
        return m.former_location;
      case 'TOWN_ONLY':
        return fill(m.town_only, { town: o.town });
      case 'NOT_IN_TOWN':
        return fill(m.not_in_town, { town: o.town });
      case 'SPECIAL':
        return o.reply;
      case 'POSTCODE_TERMINATED':
        return m.postcode_terminated;
      case 'NOT_FOUND':
        return m.location_not_found;
      default:
        return null;
    }
  }

  // ----------------------------------------------------------------- stock
  //
  // TOTAL / RESERVED / AVAILABLE for a product code, only for codes that
  // have ever been stocked (restockProduct()) - an untracked code (never
  // restocked) is treated as unlimited/untracked, so every existing test
  // and order flow that never touches stock keeps working unchanged.
  // "driver-held" is a fourth, separate figure, computed from each
  // driver's own d.stock ledger (loaded/decremented by loadDriverStock/
  // TAKE - unchanged from the driver subsystem pass) rather than folded
  // into `available` here, so that already-tested mechanism didn't need
  // touching to add this.

  _defaultLowStockThreshold() {
    return (this.config.stock && this.config.stock.defaultLowStockThreshold) ?? 3;
  }

  _driverHeldTotal(code) {
    let n = 0;
    for (const d of Object.values(this.state.drivers)) n += (d.stock && d.stock[code]) || 0;
    return n;
  }

  _availableStock(code) {
    const s = this.state.stock[code];
    if (!s) return Infinity; // untracked - never restocked, so never blocks an order
    return s.total - s.reserved - this._driverHeldTotal(code);
  }

  _stockAudit(order, code, action, qty, note) {
    const entry = { at: this.now(), code, action, qty, orderId: order ? order.id : null, note: note || null };
    this.state.stockLedger.push(entry);
    if (this.state.stockLedger.length > 5000) this.state.stockLedger.shift();
    this._event(order, `STOCK_${action}`, `${code} x${qty}${note ? ' - ' + note : ''}`);
  }

  _maybeLowStockAlert(code) {
    const s = this.state.stock[code];
    if (!s) return;
    const threshold = s.lowStockThreshold ?? this._defaultLowStockThreshold();
    const available = this._availableStock(code);
    const idx = this.state.lowStockAlerts.indexOf(code);
    if (available <= threshold) {
      if (idx === -1) {
        this.state.lowStockAlerts.push(code);
        this._event(null, 'LOW_STOCK', `${code} available=${available} (threshold ${threshold})`);
      }
    } else if (idx !== -1) {
      this.state.lowStockAlerts.splice(idx, 1);
    }
  }

  /**
   * Restock (Boss-only). Additive to total. Creates the product's stock
   * record on first use - a code is "tracked" from here on. `idempotencyKey`
   * (optional) makes a retried Boss request a safe no-op instead of a
   * double-restock - see `idempotent()`.
   */
  restockProduct(code, qty, note, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      const item = (this.menu.items || []).find((i) => i.code.toUpperCase() === String(code).toUpperCase());
      if (!item) throw new Error('unknown item');
      if (!Number.isFinite(qty) || qty <= 0) throw new Error('qty must be a positive number');
      const s = (this.state.stock[item.code] = this.state.stock[item.code] || {
        total: 0, reserved: 0, lowStockThreshold: this._defaultLowStockThreshold(),
      });
      s.total = Math.round((s.total + qty) * 1000) / 1000;
      this._stockAudit(null, item.code, 'RESTOCK', qty, note);
      this._maybeLowStockAlert(item.code);
      return this.stockSummary(item.code);
    });
  }

  /**
   * Manual Boss adjustment (can be negative - breakage, correction, stock
   * take). Never allowed to take total below what's currently promised
   * (reserved) or out with a driver (driver-held) - that would silently
   * create a negative/impossible available figure.
   */
  adjustStock(code, delta, note, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      const item = (this.menu.items || []).find((i) => i.code.toUpperCase() === String(code).toUpperCase());
      if (!item) throw new Error('unknown item');
      const s = this.state.stock[item.code];
      if (!s) throw new Error('product not tracked yet - restock it first');
      if (!Number.isFinite(delta) || delta === 0) throw new Error('delta must be a non-zero number');
      const newTotal = Math.round((s.total + delta) * 1000) / 1000;
      const floor = s.reserved + this._driverHeldTotal(item.code);
      if (newTotal < floor - 0.001) {
        throw new Error(`adjustment would take total below what's already reserved/driver-held (${floor})`);
      }
      s.total = Math.max(0, newTotal);
      this._stockAudit(null, item.code, delta >= 0 ? 'ADJUST_UP' : 'ADJUST_DOWN', Math.abs(delta), note);
      this._maybeLowStockAlert(item.code);
      return this.stockSummary(item.code);
    });
  }

  stockSummary(code) {
    const item = (this.menu.items || []).find((i) => i.code.toUpperCase() === String(code).toUpperCase());
    const c = item ? item.code : String(code).toUpperCase();
    const s = this.state.stock[c];
    const driverHeld = this._driverHeldTotal(c);
    if (!s) return { code: c, tracked: false, total: null, reserved: null, driverHeld, available: null, lowStockThreshold: null, low: false };
    const available = s.total - s.reserved - driverHeld;
    const threshold = s.lowStockThreshold ?? this._defaultLowStockThreshold();
    return { code: c, tracked: true, total: s.total, reserved: s.reserved, driverHeld, available, lowStockThreshold: threshold, low: available <= threshold };
  }

  allStockSummary() {
    return (this.menu.items || []).map((i) => this.stockSummary(i.code));
  }

  /** Sum each order item's qty by code. */
  _itemQtyByCode(order) {
    const byCode = {};
    for (const i of order.items) byCode[i.code] = (byCode[i.code] || 0) + i.qty;
    return byCode;
  }

  /**
   * Reserve stock for a CONFIRMED order - the point this brief specifies
   * ("reserve stock at the correct order stage"). Only tracked codes are
   * checked/reserved; an untracked code never blocks an order (see
   * _availableStock). All-or-nothing: if any tracked item is short,
   * NOTHING is reserved and {ok:false} is returned - never half-promise an
   * order. Idempotent by construction: only ever called once, from
   * _confirm(), which itself only ever runs once per order (see its own
   * comment) - and order.stockReserved guards a second call regardless.
   */
  _reserveStock(order) {
    if (order.stockReserved) return { ok: true }; // already reserved - never double-reserve
    const byCode = this._itemQtyByCode(order);
    for (const [code, qty] of Object.entries(byCode)) {
      if (this._availableStock(code) < qty) return { ok: false, code, available: this._availableStock(code), needed: qty };
    }
    for (const [code, qty] of Object.entries(byCode)) {
      const s = this.state.stock[code];
      if (!s) continue; // untracked
      s.reserved += qty;
      this._stockAudit(order, code, 'RESERVE', qty);
      this._maybeLowStockAlert(code);
    }
    order.stockReserved = true;
    return { ok: true };
  }

  /** Release a reservation on cancellation/expiry - idempotent (won't release twice). */
  _releaseStockReservation(order, reason) {
    if (!order.stockReserved || order.stockReleased) return;
    const byCode = this._itemQtyByCode(order);
    for (const [code, qty] of Object.entries(byCode)) {
      const s = this.state.stock[code];
      if (!s) continue;
      s.reserved = Math.max(0, Math.round((s.reserved - qty) * 1000) / 1000);
      this._stockAudit(order, code, 'RELEASE', qty, reason);
      this._maybeLowStockAlert(code);
    }
    order.stockReleased = true;
  }

  /** Deduct stock exactly once, at COMPLETE - idempotent (won't deduct twice). */
  _deductStock(order) {
    if (!order.stockReserved || order.stockDeducted) return;
    const byCode = this._itemQtyByCode(order);
    for (const [code, qty] of Object.entries(byCode)) {
      const s = this.state.stock[code];
      if (!s) continue;
      s.reserved = Math.max(0, Math.round((s.reserved - qty) * 1000) / 1000);
      s.total = Math.max(0, Math.round((s.total - qty) * 1000) / 1000);
      this._stockAudit(order, code, 'DEDUCT', qty);
      this._maybeLowStockAlert(code);
    }
    order.stockDeducted = true;
  }

  // --------------------------------------------------------- idempotency

  /**
   * Runs `fn()` at most once for a given `key` (Boss-triggered ops that
   * must be safe to retry: restock, stock adjust, loyalty adjust, cash
   * adjust). A repeated key returns the SAME recorded result again without
   * re-running `fn` - a genuine no-op on retry, not just "doesn't throw".
   * No key given (the normal, non-retried call) always runs fn().
   */
  idempotent(key, fn) {
    if (!key) return fn();
    if (Object.prototype.hasOwnProperty.call(this.state.idempotency, key)) {
      return this.state.idempotency[key];
    }
    const result = fn();
    this.state.idempotency[key] = result;
    return result;
  }

  // --------------------------------------------------------------- debt

  _debtRemaining(debt) {
    return Math.max(0, Math.round(debt.amount * 100) / 100);
  }

  _openDebtsForPhone(phone) {
    return this.state.debts
      .filter((d) => d.phone === phone && this._debtRemaining(d) > 0.001)
      .sort((a, b) => a.createdAt - b.createdAt);
  }

  /** Debt that has reached its 7-day due date and is still unpaid. */
  _overdueDebtTotal(phone) {
    const now = this.now();
    return this._openDebtsForPhone(phone)
      .filter((d) => now >= d.dueAt)
      .reduce((sum, d) => Math.round((sum + this._debtRemaining(d)) * 100) / 100, 0);
  }

  // ------------------------------------------------------------ referral

  _availableFreeItemReward(phone) {
    return this.state.freeItemRewards.find((r) => r.phone === phone && r.status === 'available') || null;
  }

  /**
   * Apply an available free-item reward to this order's cheapest line, if
   * any: reduces `total` by that item's unit price (never below 0) and
   * marks the reward redeemed. The item itself stays in order.items, so
   * stock reservation/deduction happens exactly as normal - the reward
   * only ever changes price, never stock accounting.
   */
  _applyFreeItemReward(order, total) {
    const reward = this._availableFreeItemReward(order.phone);
    if (!reward || !order.items || !order.items.length) return total;
    const byCode = new Map((this.menu.items || []).map((i) => [i.code, i]));
    let cheapest = null;
    for (const i of order.items) {
      const item = byCode.get(i.code);
      if (!item) continue;
      if (!cheapest || item.unitPrice < cheapest.unitPrice) cheapest = item;
    }
    if (!cheapest) return total;
    reward.status = 'redeemed';
    reward.redeemedAt = this.now();
    reward.redeemedOrderId = order.id;
    order.freeItemRewardId = reward.id;
    const discount = Math.min(total, cheapest.unitPrice);
    this._event(order, 'FREE_ITEM_REDEEMED', `${reward.id} (${cheapest.code}) -${money(discount)}`);
    return Math.round((total - discount) * 100) / 100;
  }

  _confirm(order) {
    const priced = priceOrder(this.menu, order.items);
    if (!priced.ok) {
      this._review(order, `cannot price order: ${priced.reason}`);
      this._ask(order, this.msg.unknown_items, 'UNKNOWN_ITEMS');
      return;
    }

    // Debt blocks a NEW order outright in either of two ways - checked
    // before anything else changes state, so a blocked order stays a
    // clean DRAFT the customer can still pay off their debt against
    // separately:
    //  (a) ANY debt that has reached its 7-day due date - "once it
    //      reaches 7 days it must be paid that day" is an enforcement
    //      rule, not just a reminder, so Rocket must not let a new order
    //      through while an overdue debt (of any size) sits unpaid past
    //      its due date.
    //  (b) overdue debt reaching the configured £ threshold (default
    //      £100) - already implied by (a) whenever any debt is overdue,
    //      kept as its own named check (and its own message wording via
    //      blockAt) since the brief calls it out separately.
    const overdue = this._overdueDebtTotal(order.phone);
    const blockAt = (this.config.debt && this.config.debt.blockOverdueAmount) ?? 100;
    if (overdue > 0.001) {
      const reason = overdue >= blockAt - 0.001
        ? `blocked: £${overdue.toFixed(2)} overdue debt (>= £${blockAt} block threshold)`
        : `blocked: £${overdue.toFixed(2)} overdue debt has reached its ${this.config.debtReminderDays}-day due date and must be paid today`;
      this._review(order, reason);
      this._sendOnce(order, 'DEBT_BLOCKED', fill(this.msg.debt_blocked, { amount: money(overdue) }));
      return;
    }

    // Stock: all-or-nothing reservation before anything is promised to the
    // customer - "prevent the same stock being promised twice".
    const reservation = this._reserveStock(order);
    if (!reservation.ok) {
      this._review(order, `blocked: insufficient stock for ${reservation.code} (need ${reservation.needed}, have ${reservation.available})`);
      this._sendOnce(order, 'STOCK_UNAVAILABLE', this.msg.stock_unavailable);
      return;
    }

    const total = this._applyFreeItemReward(order, priced.total);
    order.total = total;
    order.pricing = priced.breakdown;
    order.state = 'CONFIRMED';
    order.lastQuestion = null;
    this._event(order, 'ORDER_CONFIRMED', `${money(total)}`);
    this._maybeRecordVenueConfirmation(order);
    if (order.location.confirmed && order.location.confirmed.serviceAreaVerified === false) {
      // A shared pin's coordinates are exact, but nothing has proven it's
      // actually inside BS48/BS49/BS21/BS20 - let the order proceed (we have
      // no evidence it's OUTSIDE the area either), but have a human glance.
      this._review(order, 'meeting point is a shared pin - not verified inside the service area');
    }
    this._sendOnce(
      order,
      'ORDER_CONFIRMED',
      fill(this.msg.order_confirmed, {
        items: describeItems(this.menu, order.items),
        total: money(total),
        place: this._placeLabel(order.location.confirmed),
      })
    );
    this._dispatch(order);
  }

  // See PROMOTION_CONFIRM_THRESHOLD above. Only counts venue locations
  // (roads/alleys/postcodes have their own, separate confidence tiers and
  // aren't part of this) that are NOT already ACTIVE - an already-verified
  // venue never needed a confirmation to get here in the first place, so
  // it has nothing to count.
  _maybeRecordVenueConfirmation(order) {
    const loc = order.location && order.location.confirmed;
    if (!loc || loc.type !== 'venue' || !loc.venueId) return;
    const venue = this.index.venue ? this.index.venue(loc.venueId) : null;
    if (!venue || venue.status === VERIFIED_STATUS) return;
    const count = (this.state.venueConfirmations[loc.venueId] || 0) + 1;
    this.state.venueConfirmations[loc.venueId] = count;
    if (count === PROMOTION_CONFIRM_THRESHOLD && !this.state.promotionCandidates.includes(loc.venueId)) {
      this.state.promotionCandidates.push(loc.venueId);
      this._event(order, 'VENUE_PROMOTION_CANDIDATE', `${loc.venueId} confirmed ${count} times - see scripts/promoteVenues.js`);
    }
  }

  _cancel(order, by) {
    if (WITH_DRIVER.has(order.state)) {
      this._review(order, `${by} asked to cancel after a driver was assigned`);
      this._sendOnce(order, 'CANCEL_PASSED', this.msg.cancel_passed_to_dispatch);
      return;
    }
    const wasOffered = order.state === 'OFFERED';
    order.state = 'CANCELLED';
    this._event(order, 'CANCELLED', by);
    this._releaseReferral(order);
    this._releaseStockReservation(order, `cancelled by ${by}`);
    if (order.sent.MENU || order.sent.ORDER_CONFIRMED || order.lastQuestion) {
      this._sendOnce(order, 'CANCELLED', this.msg.cancelled);
    }
    if (wasOffered) {
      for (const d of order.offeredTo) this._driverMsg(d, fill(this.msg.driver_cancelled, { id: order.id }), order.id, `CANCELLED:${d}`);
    }
  }

  // What to tell a customer who asks "how long you going to be" after the
  // order's confirmed, best info first: a live GPS-derived ETA, then the
  // ETA the driver reported at ACCEPT time, then just "still finding you a
  // driver" / "they're on the way" / "already here" depending on state.
  // Never guesses a number it doesn't have.
  _etaAnswerText(order) {
    if (order.state === 'ARRIVED') return this.msg.eta_answer_arrived;
    if (!order.driverId) return this.msg.eta_answer_no_driver;
    const snap = this.liveTracking(order.id);
    if (snap && snap.etaMinutes != null) return fill(this.msg.eta_answer_live, { minutes: snap.etaMinutes });
    if (order.etaMinutes != null) return fill(this.msg.eta_answer_reported, { minutes: order.etaMinutes });
    return this.msg.eta_answer_on_the_way;
  }

  // Messages after the order is confirmed. The meeting location is fixed now:
  // "I'll be 10 minutes" must never replace it.
  _afterConfirmation(order, texts) {
    for (const text of texts) {
      const key = normalise(text);
      if (CANCEL_RE.test(key)) return this._cancel(order, 'customer');

      if (ETA_QUESTION_RE.test(key)) {
        this._queue('sms', order.phone, this._etaAnswerText(order), order.id, null);
        this._event(order, 'ETA_QUESTION_ANSWERED', null);
        continue;
      }

      const probe = new LocationConversation(this.index, JSON.parse(JSON.stringify(order.location)));
      const o = probe.handle(text, { allowPartial: false });
      if ((o.type === 'ETA' || o.type === 'ARRIVAL') && order.driverId) {
        const update = o.type === 'ETA' ? `${o.minutes} mins` : 'here now';
        this._driverMsg(order.driverId, fill(this.msg.driver_customer_update, { id: order.id, update }), order.id, null);
        this._event(order, 'CUSTOMER_UPDATE_RELAYED', o.type);
        continue;
      }
      if (
        o.type === 'RESOLVED' && o.location &&
        o.location.name !== (order.location.confirmed && order.location.confirmed.name)
      ) {
        // Compare bare names, not the formatted "name, town, (postcode)"
        // driver label - comparing against the formatted label here made
        // this fire on almost every post-confirmation mention of the same
        // venue, since o.location.name is always the bare venue/postcode name.
        this._review(order, 'customer sent a different location after the order was confirmed');
        continue;
      }

      // Nothing above understood this message. Previously this was
      // silence with no trace anywhere - a customer trying to add items
      // ("add two more of item a") after confirming had no way of knowing
      // it never happened. Items can't change through this path (see
      // _confirm/priceOrder - the total's already locked in and offered to
      // drivers on it), so say so explicitly whenever the message actually
      // looks like an item request OR explicit change/addition language
      // that doesn't happen to parse as a literal item line (e.g. "add
      // another one of them" - parseItems can't resolve "them" to an item
      // code, but the customer is unmistakably trying to change the
      // order); anything else post-confirmation is left alone rather than
      // replying to every "thanks"/"cheers".
      if (parseItems(text, this.menu) || ORDER_CHANGE_RE.test(key)) {
        this._queue('sms', order.phone, this.msg.cannot_change_order_items, order.id, null);
        this._event(order, 'POST_CONFIRM_ITEM_CHANGE_REJECTED', null);
      }
    }
  }

  // ------------------------------------------------------ referral codes

  _attachReferral(order, code) {
    const rc = this.state.referralCodes[code];
    const cust = this.state.customers[order.phone];
    if (!rc) return this._event(order, 'REFERRAL_REJECTED', 'unknown code');
    if (rc.redeemed || (rc.usedByOrder && rc.usedByOrder !== order.id)) return this._event(order, 'REFERRAL_REJECTED', 'already used');
    if (rc.ownerPhone === order.phone) return this._event(order, 'REFERRAL_REJECTED', 'self-referral');
    if (cust && cust.completedOrders > 0) return this._event(order, 'REFERRAL_REJECTED', 'not a new customer');
    // Swapping to a different code must release the old one's lock first,
    // or it's orphaned: locked as "used by this order" forever, never
    // redeemed, never released (only order.referralCode, now overwritten,
    // is what _releaseReferral looks at on cancel/expiry).
    if (order.referralCode && order.referralCode !== code) this._releaseReferral(order);
    rc.usedByOrder = order.id;
    order.referralCode = code;
    this._event(order, 'REFERRAL_ATTACHED', code);
  }

  _releaseReferral(order) {
    if (!order.referralCode) return;
    const rc = this.state.referralCodes[order.referralCode];
    if (rc && !rc.redeemed && rc.usedByOrder === order.id) rc.usedByOrder = null;
  }

  _issueReferralCode(order) {
    for (let i = 0; i < 1000; i++) {
      const code = 'RF' + crypto.randomBytes(4).toString('hex').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5);
      if (code.length === 7 && !this.state.referralCodes[code]) {
        this.state.referralCodes[code] = {
          ownerPhone: order.phone,
          issuedForOrder: order.id,
          issuedAt: this.now(),
          usedByOrder: null,
          redeemed: false,
        };
        return code;
      }
    }
    throw new Error('could not allocate referral code');
  }

  // ------------------------------------------------------------ dispatch

  /**
   * A driver whose status is 'ON' (onDuty) and not already on a job. When
   * `order` is given, a FOOT driver is excluded unless the order's location
   * is in Nailsea (see _isNailseaLocation) - the engine-level enforcement
   * of driver mode, so a FOOT driver can never be offered a non-Nailsea job
   * even if some future UI forgot to filter it out itself.
   */
  _freeDrivers(order) {
    return Object.values(this.state.drivers).filter((d) => {
      if (!d.onDuty || d.activeOrderId) return false;
      if (order && d.mode === 'FOOT' && !this._isNailseaLocation(order.location && order.location.confirmed)) return false;
      return true;
    });
  }

  /**
   * FOOT mode = Nailsea jobs only (per the driver subsystem brief).
   *
   * IMPORTANT: BS48 is Nailsea's own postcode district, but it also covers
   * several other, genuinely different localities (Backwell, Wraxall, Long
   * Ashton, Flax Bourton and more - see data/locations.json's "towns"
   * list) - it must NEVER be used as a stand-in for "is this Nailsea". A
   * venue- or road-resolved location carries a real `town` field, sourced
   * from actual OSM/venue data (see data/roads.json, data/locations.json's
   * venues); only that is trusted. A bare-postcode location (postcode
   * known, no venue/road name given) has no `town` field at all - that is
   * "cannot confidently establish it's Nailsea", not "assume BS48 means
   * Nailsea", so it correctly returns false here, same as any other
   * genuinely different town. A FOOT driver simply won't be offered that
   * job; a CAR driver still can be (CAR isn't restricted by this check at
   * all - see _freeDrivers()).
   */
  _isNailseaLocation(loc) {
    if (!loc || !loc.town) return false;
    return String(loc.town).trim().toLowerCase() === 'nailsea';
  }

  _dispatch(order) {
    const drivers = this._freeDrivers(order);
    if (!drivers.length) {
      this._event(order, 'NO_FREE_DRIVER');
      this._review(order, 'no free driver on duty');
      return;
    }
    order.state = 'OFFERED';
    order.offeredAt = this.now();
    this._sendOnce(order, 'FINDING_DRIVER', this.msg.finding_driver);
    for (const d of drivers) this._offerTo(order, d);
  }

  _offerTo(order, driver) {
    if (order.offeredTo.includes(driver.id)) return;
    order.offeredTo.push(driver.id);
    const loc = order.location.confirmed;
    const text = fill(this.msg.driver_offer, {
      id: order.id,
      place: this._placeLabel(loc),
      items: describeItems(this.menu, order.items),
      total: money(order.total),
      nav: this._navLink(loc, driver.mode),
      note: loc && loc.exactPointKnown ? '' : this.msg.driver_offer_note_area,
    });
    this._driverMsg(driver.id, text, order.id, `OFFER:${driver.id}`);
    this._event(order, 'OFFER_SENT', driver.id);
  }

  // ------------------------------------------------------- driver side

  registerDriver(id, name, opts = {}) {
    // Allows an optional leading "+" so a driver's own transport address -
    // an E.164 Signal number, e.g. "+447700900123" - can be used directly
    // as the driver id, with no separate id<->phone-number mapping to keep
    // in sync (see signal/adapter.js).
    if (!/^\+?[A-Za-z0-9_-]{2,32}$/.test(id)) throw new Error('driver id must be 2-32 letters/numbers (optionally with a leading + for a phone number)');
    if (!this.state.drivers[id]) {
      this.state.drivers[id] = {
        id, name: name || id, onDuty: false,
        // status is the authoritative 3-state ('OFF'|'ON'|'BREAK'); onDuty
        // stays a derived boolean (true only when status==='ON') so every
        // existing test/UI that reads onDuty keeps working unchanged.
        status: 'OFF',
        mode: 'CAR', activeOrderId: null,
        traccarId: null, location: null, locationAt: null,
        earnings: { totalBonus: 0, completedOrders: 0 }, // see _complete's driver bonus calc
        stock: {}, // driver-carried stock, by menu item code - see TAKE command
        // Cash/takings held by the driver from completed CASH orders -
        // separate from earnings.totalBonus (Bonus is Rocket's own reward
        // to the driver; cash is the customer's money the driver is
        // physically holding until it's banked/handed over). See
        // config.driverCash.limitPence and _complete()'s cash tracking.
        cash: { held: 0, adjustments: [] },
      };
      this._event(null, 'DRIVER_REGISTERED', id);
    }
    if (opts.traccarId) this.linkTraccarDevice(id, opts.traccarId);
    return this.state.drivers[id];
  }

  /** Link (or re-link) a Traccar device's uniqueId to a registered driver. */
  linkTraccarDevice(driverId, traccarUniqueId) {
    const d = this.state.drivers[driverId];
    if (!d) throw new Error('unknown driver');
    // A device can only ever point at one driver; unlink it from a previous one.
    for (const [tid, did] of Object.entries(this.state.driversByTraccarId)) {
      if (did === driverId && tid !== traccarUniqueId) delete this.state.driversByTraccarId[tid];
    }
    d.traccarId = traccarUniqueId;
    this.state.driversByTraccarId[traccarUniqueId] = driverId;
    this._event(null, 'GPS_DEVICE_LINKED', `${driverId} <- ${traccarUniqueId}`);
    return d;
  }

  // ------------------------------------------------------------------ gps

  /**
   * Apply one parsed Traccar position fix (see src/gps.js parseTraccarForward).
   * Unknown device ids are ignored, not errors: a driver who hasn't linked
   * their phone yet, or a stray device on the same Traccar account, must
   * never crash the ingestion endpoint or land in someone else's order.
   */
  updateDriverLocation(fix) {
    if (!fix || !fix.uniqueId) return { ok: false, reason: 'no device id' };
    const driverId = this.state.driversByTraccarId[fix.uniqueId];
    if (!driverId) return { ok: false, reason: 'unlinked device' };
    const d = this.state.drivers[driverId];
    if (!d) return { ok: false, reason: 'unlinked device' };
    if (fix.valid === false) {
      this._event(null, 'GPS_FIX_INVALID', driverId);
      return { ok: true, applied: false };
    }
    const at = this.now();
    d.location = { lat: fix.lat, lng: fix.lng, speedKph: fix.speedKph, course: fix.course, accuracy: fix.accuracy };
    d.locationAt = at;
    if (d.activeOrderId) {
      const order = this.state.orders[d.activeOrderId];
      if (order) {
        this._event(order, 'DRIVER_GPS_UPDATE', `${fix.lat.toFixed(5)},${fix.lng.toFixed(5)}`);
        this._maybeAutoGpsEvents(order, d);
      }
    }
    return { ok: true, applied: true, driverId };
  }

  /**
   * Auto-fire the same customer-facing "5 minutes away" and "arrived"
   * events a driver would normally trigger by texting 5 MIN / HERE, based
   * on GPS distance to the meeting point instead. Uses the same _sendOnce
   * keys ('FIVE_MIN', 'ARRIVED') as the manual commands in
   * handleDriverMessage, so whichever fires first - a GPS fix or the
   * driver's own text - the customer only ever gets the message once.
   */
  _maybeAutoGpsEvents(order, d) {
    if (order.state !== 'ASSIGNED' && order.state !== 'EN_ROUTE') return; // already arrived, or not dispatched yet
    const dest = order.location.confirmed;
    if (!dest || dest.lat == null || dest.lng == null || !d.location) return;
    const distanceMetres = haversineMetres(d.location, { lat: dest.lat, lng: dest.lng });
    if (distanceMetres == null) return;
    const gpsCfg = this.config.gps || {};

    const fiveMinAtEta = gpsCfg.autoFiveMinEtaMinutes ?? 5;
    const etaMins = etaMinutes(distanceMetres, d.location.speedKph, gpsCfg);

    // First GPS-derived ETA once the driver is actually moving toward the
    // customer (not just accepted and stationary), for orders far enough
    // out that the "5 minutes away" message below hasn't fired yet. Same
    // GPS pipeline as the other two auto events (distance + speed off the
    // same fix), same one-shot _sendOnce dedup, and it only ever adds a
    // message on top of - never instead of - "5 minutes away"/"arrived".
    const enRouteMinKph = gpsCfg.minKph ?? 8;
    const isMoving = d.location.speedKph != null && d.location.speedKph > enRouteMinKph;
    if (order.state === 'ASSIGNED' && isMoving && etaMins != null && etaMins > fiveMinAtEta) {
      if (this._sendOnce(order, 'EN_ROUTE_ETA', fill(this.msg.driver_en_route_eta, { minutes: etaMins }))) {
        this._event(order, 'DRIVER_EN_ROUTE_ETA_AUTO', `${Math.round(distanceMetres)}m, eta ${etaMins}m`);
      }
    }

    // Same "actually moving" requirement as the ETA message above - a
    // driver who happens to be stationary within 5 minutes' distance
    // (parked nearby, not yet set off) shouldn't trigger "5 minutes away";
    // that message means "moving and closing in", not just "nearby".
    if (isMoving && etaMins != null && etaMins <= fiveMinAtEta) {
      if (order.state === 'ASSIGNED') order.state = 'EN_ROUTE';
      if (this._sendOnce(order, 'FIVE_MIN', this.msg.five_minutes)) {
        this._event(order, 'DRIVER_FIVE_MIN_AUTO', `${Math.round(distanceMetres)}m, eta ${etaMins}m`);
      }
    }

    // Only trust a fix accurate enough to actually mean "arrived" - a wide
    // GPS error radius that happens to compute close by chance would send
    // a false "your driver has arrived" to the customer, which damages
    // trust more than noticing a real arrival a few seconds late does.
    const arriveRadius = gpsCfg.autoArrivalRadiusMetres ?? 120;
    const maxAccuracy = gpsCfg.autoArrivalMaxAccuracyMetres ?? 60;
    const accuracyOk = d.location.accuracy == null || d.location.accuracy <= maxAccuracy;
    if (distanceMetres <= arriveRadius && accuracyOk) {
      order.state = 'ARRIVED';
      if (this._sendOnce(order, 'ARRIVED', this.msg.arrived)) {
        this._event(order, 'DRIVER_HERE_AUTO', `${Math.round(distanceMetres)}m`);
      }
    }
  }

  /**
   * Live tracking snapshot for one order: the driver's last known fix and a
   * distance-based ETA, for a future customer-facing tracking link/server
   * endpoint. Returns null when there's nothing to show (no driver yet, or
   * the driver's phone hasn't reported a position).
   */
  liveTracking(orderId) {
    const order = this.state.orders[orderId];
    if (!order || !order.driverId) return null;
    const d = this.state.drivers[order.driverId];
    if (!d || !d.location) return null;
    const dest = order.location.confirmed;
    const dLat = dest && dest.lat != null ? dest.lat : null;
    const dLng = dest && dest.lng != null ? dest.lng : null;
    const distanceMetres = dLat != null && dLng != null
      ? haversineMetres(d.location, { lat: dLat, lng: dLng })
      : null;
    return {
      orderId,
      orderState: order.state,
      driverId: d.id,
      location: d.location,
      locationAt: d.locationAt,
      staleSeconds: d.locationAt != null ? Math.round((this.now() - d.locationAt) / 1000) : null,
      distanceMetres,
      etaMinutes: etaMinutes(distanceMetres, d.location.speedKph, this.config.gps || {}),
    };
  }

  /**
   * @param {string} driverId  registered driver id (the adapter maps Signal numbers to ids)
   * @param {string} text      the driver's message
   * @param {object} opts      { quotedOrderId } only if the adapter can reliably link a quoted reply
   */
  handleDriverMessage(driverId, text, opts = {}) {
    const d = this.state.drivers[driverId];
    if (!d) return { ok: false, error: 'unknown driver' };
    const reply = (t) => this._driverMsg(driverId, t, null, null);
    const up = String(text || '').toUpperCase().replace(/\s+/g, ' ').trim();

    // Duty, break and mode. status is the authoritative 3-state; onDuty is
    // kept in sync as a derived boolean (true only when status==='ON') so
    // every pre-existing onDuty read (dispatch, summary, tests) still works.
    if (/^(ON|ON DUTY|START|RESUME)$/.test(up)) {
      d.status = 'ON';
      d.onDuty = true;
      reply(fill(this.msg.driver_on, { mode: d.mode }));
      this._event(null, 'DRIVER_ON', driverId);
      this._offerWaitingOrders();
      return { ok: true };
    }
    if (/^(OFF|OFF DUTY|STOP)$/.test(up)) {
      if (d.activeOrderId) return reply(fill(this.msg.driver_finish_first, { current: d.activeOrderId })), { ok: false };
      d.status = 'OFF';
      d.onDuty = false;
      reply(this.msg.driver_off);
      this._event(null, 'DRIVER_OFF', driverId);
      return { ok: true };
    }
    if (/^(BREAK|ON BREAK|PAUSE)$/.test(up)) {
      if (d.activeOrderId) return reply(fill(this.msg.driver_finish_first, { current: d.activeOrderId })), { ok: false };
      d.status = 'BREAK';
      d.onDuty = false; // BREAK receives no new offers, same as OFF - see _freeDrivers()
      reply(this.msg.driver_break);
      this._event(null, 'DRIVER_BREAK', driverId);
      return { ok: true };
    }
    if (/^(CAR|DRIVING)$/.test(up) || /^(FOOT|ON FOOT|WALK|WALKING)$/.test(up)) {
      d.mode = /^(CAR|DRIVING)$/.test(up) ? 'CAR' : 'FOOT';
      reply(fill(this.msg.driver_mode, { mode: d.mode }));
      this._event(null, 'DRIVER_MODE', `${driverId} -> ${d.mode}`);
      // Switching to CAR can immediately make this driver eligible for an
      // order that's been sitting CONFIRMED because the only free driver
      // was FOOT and it wasn't a Nailsea job - re-check right away, same
      // as ON/COMPLETE already do, rather than leaving it stuck until some
      // unrelated event nudges dispatch.
      if (d.onDuty) this._offerWaitingOrders();
      return { ok: true };
    }
    if (up === 'HELP') return reply(this.msg.driver_help), { ok: true };

    // TAKE = driver takes an item from their OWN driver stock. Deliberately
    // its own top-level command (not an ACCEPT alias - see below) and does
    // not require/consume an order id. Duplicate TAKE messages are already
    // made safe by the caller: server/index.js calls engine.firstSeen()
    // against the transport messageId before handleDriverMessage() is ever
    // invoked for a driver message, so a retried/duplicated TAKE text never
    // reaches here twice.
    if (/^TAKE\b/.test(up)) return this._take(d, up, reply);

    const cmd = [
      ['ACCEPT', /^(ACCEPT|ACC)\b/],
      ['EN_ROUTE', /^(EN ROUTE|ENROUTE|OMW|ON MY WAY|LEAVING)\b/],
      ['FIVE_MIN', /^(5 ?MIN|5 ?MINS|FIVE MIN|FIVE)\b/],
      ['HERE', /^(HERE|ARRIVED)\b/],
      ['COMPLETE', /^(COMPLETE|COMPLETED|DONE)\b/],
      ['PROBLEM', /^(PROBLEM|ISSUE)\b/],
    ].find(([, re]) => re.test(up));
    if (!cmd) return reply(this.msg.driver_unknown_command), { ok: false };
    const [command] = cmd;

    // Never guess which order a command is for.
    const idMatch = up.match(ORDER_ID_RE);
    const orderId = idMatch ? idMatch[1].toUpperCase() : opts.quotedOrderId || null;
    if (!orderId) return reply(fill(this.msg.driver_need_id, { command: command.replace('_', ' ') })), { ok: false };
    const order = this.state.orders[orderId];
    if (!order || !OPEN.has(order.state)) {
      if (order && command === 'ACCEPT') return reply(fill(this.msg.driver_not_available, { id: orderId })), { ok: false };
      return reply(fill(this.msg.driver_unknown_order, { id: orderId })), { ok: false };
    }
    const rest = up.replace(ORDER_ID_RE, ' ');
    const minsMatch = rest.match(/\b(\d{1,3})\b/);
    const mins = minsMatch && command !== 'FIVE_MIN' ? parseInt(minsMatch[1], 10) : null;

    if (command === 'ACCEPT') return this._accept(order, d, mins, reply);

    if (order.driverId !== driverId) return reply(fill(this.msg.driver_not_yours, { id: order.id })), { ok: false };

    switch (command) {
      case 'EN_ROUTE':
        if (order.state === 'ASSIGNED') order.state = 'EN_ROUTE';
        this._event(order, 'DRIVER_EN_ROUTE', mins ? `${mins}m` : null);
        if (mins) {
          order.etaMinutes = mins;
          this._sendOnce(order, 'DRIVER_ETA', fill(this.msg.driver_assigned_eta, { minutes: mins }));
        }
        reply(fill(this.msg.driver_ok, { id: order.id, status: 'EN ROUTE' }));
        return { ok: true };
      case 'FIVE_MIN':
        if (order.state === 'ASSIGNED') order.state = 'EN_ROUTE';
        this._event(order, 'DRIVER_FIVE_MIN');
        this._sendOnce(order, 'FIVE_MIN', this.msg.five_minutes);
        reply(fill(this.msg.driver_ok, { id: order.id, status: '5 MIN' }));
        return { ok: true };
      case 'HERE':
        order.state = 'ARRIVED';
        this._event(order, 'DRIVER_HERE');
        this._sendOnce(order, 'ARRIVED', this.msg.arrived);
        reply(fill(this.msg.driver_ok, { id: order.id, status: 'HERE' }));
        return { ok: true };
      case 'COMPLETE':
        return this._complete(order, d, rest, reply);
      case 'PROBLEM':
        this._review(order, `driver reported a problem: ${String(text).slice(0, 200)}`);
        reply(fill(this.msg.driver_problem, { id: order.id }));
        return { ok: true };
      default:
        return { ok: false };
    }
  }

  _accept(order, d, mins, reply) {
    if (order.driverId === d.id) return reply(fill(this.msg.driver_already_yours, { id: order.id })), { ok: true, duplicate: true };
    if (order.driverId || order.state !== 'OFFERED') return reply(fill(this.msg.driver_not_available, { id: order.id })), { ok: false };
    if (!d.onDuty) return reply(this.msg.driver_off), { ok: false };
    if (d.activeOrderId) return reply(fill(this.msg.driver_finish_first, { current: d.activeOrderId })), { ok: false };
    // Defense-in-depth mirror of _freeDrivers()'s FOOT/Nailsea filter: a
    // FOOT driver must never acquire a non-Nailsea job even via a stray/
    // hand-crafted ACCEPT that bypassed the offer step.
    if (d.mode === 'FOOT' && !this._isNailseaLocation(order.location && order.location.confirmed)) {
      return reply(this.msg.driver_mode_foot_area), { ok: false };
    }
    // £250 cash limit: a driver already holding at/over the limit must
    // bank it before taking another cash-collecting job - "do not
    // silently continue accumulating beyond the configured limit".
    const cashLimit = (this.config.driverCash && this.config.driverCash.limit) ?? 250;
    if (d.cash && d.cash.held >= cashLimit) {
      return reply(fill(this.msg.driver_cash_limit, { held: money(d.cash.held), limit: money(cashLimit) })), { ok: false };
    }
    if (!order.offeredTo.includes(d.id)) return reply(fill(this.msg.driver_not_available, { id: order.id })), { ok: false };

    // First valid acceptance wins. JS runs this synchronously, so two ACCEPTs
    // can't interleave; the second sees driverId already set.
    order.driverId = d.id;
    order.state = 'ASSIGNED';
    order.assignedAt = this.now();
    d.activeOrderId = order.id;
    this._event(order, 'DRIVER_ACCEPTED', d.id);
    reply(fill(this.msg.driver_accepted, { id: order.id, nav: this._navLink(order.location.confirmed, d.mode) }));
    for (const other of order.offeredTo) {
      if (other !== d.id) this._driverMsg(other, fill(this.msg.driver_taken, { id: order.id }), order.id, `TAKEN:${other}`);
    }
    if (mins) {
      order.etaMinutes = mins;
      this._sendOnce(order, 'DRIVER_ETA', fill(this.msg.driver_assigned_eta, { minutes: mins }));
    } else {
      this._sendOnce(order, 'DRIVER_ASSIGNED', this.msg.driver_assigned_no_eta);
    }
    return { ok: true };
  }

  /**
   * TAKE <code|name> [qty]  or  TAKE [qty] <code|name> - a driver taking
   * item(s) from their own carried stock (loaded onto them via
   * loadDriverStock, a Boss-only action). This is NOT job acceptance - see
   * the brief's "ACCEPT/TAKE command separation" - it only ever adjusts
   * d.stock, never an order. Never lets stock go negative: a driver can't
   * take more than they're currently holding.
   *
   * A TAKE is stock leaving the business through a driver, not through a
   * sale - "driver wage" in the brief means the driver's Bonus, so the
   * taken item's menu value is deducted from that driver's running Bonus
   * total (floored at £0 - a TAKE can reduce today's Bonus to nothing, but
   * never put it in the red), and a dedicated, Boss-visible warning is
   * raised every time (never silently absorbed into the ordinary stock
   * audit trail alone).
   */
  _take(d, up, reply) {
    const rest = up.replace(/^TAKE\b/, '').trim();
    if (!rest) return reply(this.msg.driver_take_unknown_item), { ok: false };
    const qtyMatch = rest.match(/^(\d{1,4})\b(.*)$/) || [null, null, rest];
    let qty = qtyMatch[1] ? parseInt(qtyMatch[1], 10) : null;
    let namePart = (qtyMatch[2] || rest).trim();
    const trailingQty = namePart.match(/^(.*?)\s+(\d{1,4})$/);
    if (qty == null && trailingQty) {
      namePart = trailingQty[1].trim();
      qty = parseInt(trailingQty[2], 10);
    }
    if (qty == null) qty = 1;
    if (!Number.isInteger(qty) || qty < 1) return reply(this.msg.driver_take_unknown_item), { ok: false };

    const needle = namePart.toUpperCase();
    const item = (this.menu.items || []).find(
      (i) => i.code.toUpperCase() === needle || String(i.name).toUpperCase() === needle
    );
    if (!item) return reply(this.msg.driver_take_unknown_item), { ok: false };

    d.stock = d.stock || {};
    const held = d.stock[item.code] || 0;
    if (held < qty) {
      return reply(fill(this.msg.driver_take_insufficient, { qty, item: item.name, held })), { ok: false };
    }
    d.stock[item.code] = held - qty;
    this._event(null, 'DRIVER_TAKE', `${d.id} took ${qty} x ${item.code}, now holding ${d.stock[item.code]}`);

    // Deduct the taken item(s)' menu value from this driver's Bonus
    // ("driver wage" = Driver Bonus), floored at £0 - never negative.
    const value = Math.round(item.unitPrice * qty * 100) / 100;
    d.earnings = d.earnings || { totalBonus: 0, completedOrders: 0 };
    const before = d.earnings.totalBonus;
    d.earnings.totalBonus = Math.max(0, Math.round((d.earnings.totalBonus - value) * 100) / 100);
    const actuallyDeducted = Math.round((before - d.earnings.totalBonus) * 100) / 100;
    this._event(null, 'DRIVER_TAKE_BONUS_DEDUCTED', `${d.id} TAKE of ${qty} x ${item.code} (${money(value)}) deducted from Bonus: ${money(before)} -> ${money(d.earnings.totalBonus)}${actuallyDeducted < value ? ` (floored at £0, ${money(value - actuallyDeducted)} short)` : ''}`);

    // Always a dedicated, Boss-visible warning - a TAKE is stock leaving
    // via a driver, not a sale, and Boss must see every one of them, not
    // just find it buried in the general stock ledger. Pushed directly
    // (not via the general _review() helper) because that helper
    // deliberately de-duplicates identical reasons for the same order -
    // correct for repeated system-detected conditions, but wrong here:
    // two separate TAKEs of the same item/qty by the same driver are two
    // separate real-world events, each deserving its own flag.
    this.state.review.push({
      id: crypto.randomUUID(),
      orderId: null,
      reason: `driver ${d.id} took ${qty} x ${item.code} (${item.name}, ${money(value)}) from their own carried stock - deducted from Bonus`,
      at: this.now(),
      resolved: false,
    });
    this._event(null, 'REVIEW_FLAGGED', `driver ${d.id} TAKE ${qty} x ${item.code}`);

    reply(fill(this.msg.driver_take_ok, { qty, item: item.name, held: d.stock[item.code] }));
    return { ok: true };
  }

  /**
   * Boss-only: load stock onto a driver (so TAKE has something to deduct
   * from). Purely additive to d.stock; nothing here touches orders/menu
   * pricing - this is a minimal addition, since no driver-stock-loading
   * mechanism existed anywhere in the codebase before this pass.
   */
  loadDriverStock(driverId, code, qty) {
    const d = this.state.drivers[driverId];
    if (!d) throw new Error('unknown driver');
    const item = (this.menu.items || []).find((i) => i.code.toUpperCase() === String(code).toUpperCase());
    if (!item) throw new Error('unknown item');
    if (!Number.isInteger(qty) || qty < 1) throw new Error('qty must be a positive integer');
    d.stock = d.stock || {};
    d.stock[item.code] = (d.stock[item.code] || 0) + qty;
    this._event(null, 'DRIVER_STOCK_LOADED', `${driverId} += ${qty} x ${item.code} (now ${d.stock[item.code]})`);
    return d.stock[item.code];
  }

  _complete(order, d, rest, reply) {
    if (order.state === 'COMPLETED') {
      return reply(fill(this.msg.driver_completed, {
        id: order.id, bonus: money(order.driverBonus || 0), total: money(d.earnings ? d.earnings.totalBonus : 0),
      })), { ok: true, duplicate: true };
    }
    const paidMatch = rest.match(/\bPAID\s*£?\s*(\d+(?:\.\d{1,2})?)\b/);
    const paid = paidMatch ? parseFloat(paidMatch[1]) : order.total;
    order.paid = paid;
    order.state = 'COMPLETED';
    d.activeOrderId = null;
    this._event(order, 'COMPLETED', `paid ${money(paid)}`);

    // Stock: deduct exactly once, now the order is genuinely fulfilled.
    this._deductStock(order);

    // Driver cash/takings: separate from Bonus entirely. Cash actually
    // collected on this order is added to what the driver is physically
    // holding, warned as it nears/reaches the configured limit, never
    // silently allowed past it without a flag.
    const cashLimit = (this.config.driverCash && this.config.driverCash.limit) ?? 250;
    d.cash = d.cash || { held: 0, adjustments: [] };
    if (paid > 0) {
      const wouldBeHeld = Math.round((d.cash.held + paid) * 100) / 100;
      if (wouldBeHeld > cashLimit + 0.001) {
        // The £250 figure is what Rocket is willing to let a driver keep
        // RECORDED as held cash, not a promise that they physically
        // haven't collected more - a same-visit debt payment on top of a
        // cash order's own total can genuinely push the true amount in
        // hand over the limit (this is exactly that case: ACCEPT already
        // checked the driver was under the limit for the order alone, but
        // the customer chose to also settle an old debt in cash here at
        // completion). Rocket never lets its own `held` figure silently
        // climb past the limit either way: it caps at the limit and
        // raises a named, Boss-visible flag for the genuine overflow
        // amount, which must be banked/handled immediately rather than
        // quietly carried forward - "do not silently continue
        // accumulating beyond the configured limit".
        const overflow = Math.round((wouldBeHeld - cashLimit) * 100) / 100;
        d.cash.held = cashLimit;
        this._event(order, 'DRIVER_CASH_COLLECTED', `${d.id} +${money(paid)} (capped at limit £${cashLimit})`);
        this._event(order, 'DRIVER_CASH_LIMIT_EXCEEDED', `${d.id} collected ${money(paid)} which would take held cash to ${money(wouldBeHeld)} - over the £${cashLimit} limit by ${money(overflow)}; recorded held capped at £${cashLimit}, overflow of ${money(overflow)} needs immediate banking`);
        this._review(order, `driver ${d.id} collected cash taking them ${money(overflow)} OVER the £${cashLimit} cash limit (held capped at £${cashLimit}) - must bank immediately, not just when convenient`);
      } else {
        d.cash.held = wouldBeHeld;
        this._event(order, 'DRIVER_CASH_COLLECTED', `${d.id} +${money(paid)} (holding ${money(d.cash.held)})`);
        if (d.cash.held >= cashLimit) {
          this._review(order, `driver ${d.id} is holding ${money(d.cash.held)} cash - at/over the £${cashLimit} limit, must bank before more cash orders`);
          this._event(order, 'DRIVER_CASH_LIMIT_REACHED', `${d.id} holding ${money(d.cash.held)} (limit £${cashLimit})`);
        } else if (d.cash.held >= cashLimit * 0.8) {
          this._event(order, 'DRIVER_CASH_LIMIT_APPROACHING', `${d.id} holding ${money(d.cash.held)} (limit £${cashLimit})`);
        }
      }
    }

    // Driver bonus: firstItemBonus for the order's first item, plus
    // extraItemBonus for every item after that - counted by TOTAL quantity
    // across the whole order (all lines summed), not by distinct menu
    // lines or by order count. £0 for a priced-but-empty order can't
    // actually happen (priceOrder requires at least one real item), but
    // guarded anyway rather than assumed.
    const totalQty = order.items.reduce((sum, i) => sum + i.qty, 0);
    const { firstItemBonus, extraItemBonus } = this.config.driverPay;
    const bonus = totalQty > 0 ? firstItemBonus + (totalQty - 1) * extraItemBonus : 0;
    order.driverBonus = Math.round(bonus * 100) / 100;
    d.earnings = d.earnings || { totalBonus: 0, completedOrders: 0 };
    d.earnings.totalBonus = Math.round((d.earnings.totalBonus + order.driverBonus) * 100) / 100;
    d.earnings.completedOrders += 1;
    this._event(order, 'DRIVER_BONUS', `${d.id} earned ${money(order.driverBonus)} (${totalQty} item${totalQty === 1 ? '' : 's'}), running total ${money(d.earnings.totalBonus)}`);

    // Debt + this order's payment, allocated in one go (see the brief's
    // own worked example: existing debt £20, new order £10, customer pays
    // £30 -> £20 clears the debt, £10 pays the order, remaining debt £0).
    // This order's own total is paid first; only genuine EXCESS beyond it
    // goes toward existing open debts, oldest first. A shortfall against
    // THIS order's total still becomes a new debt exactly as before -
    // paying alongside never lets an old debt eat into what's owed for
    // today's order.
    const orderShortfall = Math.max(0, Math.round((order.total - paid) * 100) / 100);
    let excess = Math.max(0, Math.round((paid - order.total) * 100) / 100);
    if (orderShortfall > 0.001) {
      const due = this.now() + this.config.debtReminderDays * 86400000;
      this.state.debts.push({
        id: crypto.randomUUID(), phone: order.phone, orderId: order.id,
        amount: orderShortfall, createdAt: this.now(), dueAt: due, remindedAt: null, payments: [],
      });
      this._event(order, 'DEBT_RECORDED', money(orderShortfall));
    } else if (excess > 0.001) {
      for (const debt of this._openDebtsForPhone(order.phone)) {
        if (excess <= 0.001) break;
        const remaining = this._debtRemaining(debt);
        const pay = Math.round(Math.min(remaining, excess) * 100) / 100;
        debt.payments.push({ at: this.now(), amount: pay, orderId: order.id, note: `paid alongside order ${order.id}` });
        debt.amount = Math.max(0, Math.round((debt.amount - pay) * 100) / 100);
        excess = Math.round((excess - pay) * 100) / 100;
        this._event(order, 'DEBT_PAYMENT', `${money(pay)} toward debt ${debt.id} (paid alongside this order)`);
      }
      if (excess > 0.001) {
        this._review(order, `driver reported paid ${money(paid)} - ${money(excess)} above order total + all open debts`);
      }
    }

    // Loyalty: Rocket's ONE rule, 3 points per purchased item (see
    // config.rewards.pointsPerItem). Awarded only here, on a genuine
    // completion (never on cancellation - _cancel never reaches this
    // method), and the duplicate-COMPLETE guard at the top of this
    // function stops a repeat award the same way it stops a repeat Bonus.
    const cust = (this.state.customers[order.phone] = this.state.customers[order.phone] || { points: 0, completedOrders: 0 });
    const totalItemsForLoyalty = order.items.reduce((sum, i) => sum + i.qty, 0);
    const earned = totalItemsForLoyalty * this.config.rewards.pointsPerItem;
    cust.points += earned;
    cust.completedOrders += 1;
    this._event(order, 'LOYALTY_POINTS_AWARDED', `${order.phone.slice(-4)} +${earned} (${totalItemsForLoyalty} item${totalItemsForLoyalty === 1 ? '' : 's'} x ${this.config.rewards.pointsPerItem}), balance ${cust.points}`);

    // Referral reward: ONE FREE ITEM for the referrer, not points - the
    // reward sits as 'available' until the referrer redeems it on a future
    // order (see _applyFreeItemReward, called from _confirm()).
    if (order.referralCode) {
      const rc = this.state.referralCodes[order.referralCode];
      if (rc && !rc.redeemed && rc.usedByOrder === order.id) {
        rc.redeemed = true;
        rc.redeemedAt = this.now();
        const reward = {
          id: crypto.randomUUID(), phone: rc.ownerPhone, sourceReferralCode: order.referralCode,
          status: 'available', earnedAt: this.now(), redeemedAt: null, redeemedOrderId: null, itemCode: null,
        };
        this.state.freeItemRewards.push(reward);
        this._event(order, 'REFERRAL_REWARDED', `${order.referralCode} -> free item ${reward.id} for ${rc.ownerPhone.slice(-4)}`);
      }
    }

    const code = this._issueReferralCode(order);
    this._sendOnce(order, 'COMPLETED', fill(this.msg.completed, { points: earned, balance: cust.points, code }));
    reply(fill(this.msg.driver_completed, { id: order.id, bonus: money(order.driverBonus), total: money(d.earnings.totalBonus) }));

    // This driver just freed up (activeOrderId cleared above). Without this,
    // an order that was already CONFIRMED-but-unoffered (no driver was free
    // when it confirmed) would sit stuck until something unrelated nudged
    // dispatch - another driver toggling ON/OFF, or a brand-new order
    // arriving. Completing a job is exactly the moment a driver becomes
    // available again, so re-check the waiting queue right here.
    this._offerWaitingOrders();
    return { ok: true };
  }

  _offerWaitingOrders() {
    const waiting = Object.values(this.state.orders)
      .filter((o) => o.state === 'CONFIRMED')
      .sort((a, b) => a.createdAt - b.createdAt);
    for (const o of waiting) this._dispatch(o);
    for (const o of Object.values(this.state.orders)) {
      if (o.state === 'OFFERED') for (const d of this._freeDrivers(o)) this._offerTo(o, d);
    }
  }

  // --------------------------------------------------------------- timers

  tick() {
    const now = this.now();
    const draftMs = this.config.draftTimeoutMinutes * 60000;
    for (const o of Object.values(this.state.orders)) {
      // Only unfinished drafts expire. Never an order a driver has taken.
      if (o.state === 'DRAFT' && now - o.lastCustomerAt > draftMs) {
        o.state = 'EXPIRED';
        this._releaseReferral(o);
        this._event(o, 'DRAFT_EXPIRED');
      }
      if (o.state === 'OFFERED' && now - o.offeredAt > this.config.offerTimeoutMinutes * 60000) {
        this._review(o, 'no driver accepted the offer in time');
      }
    }
    const staleMs = (this.config.gps?.staleAfterMinutes ?? 8) * 60000;
    for (const d of Object.values(this.state.drivers)) {
      if (!d.activeOrderId) continue; // only matters while someone is waiting on this driver
      if (!d.traccarId) continue; // never linked a phone - not a GPS fault, don't flag it as one
      // Measured from when THIS driver accepted (assignedAt), not from when
      // the order was first offered (offeredAt) - an order that sat OFFERED
      // for a while before anyone accepted must not count against the
      // driver's GPS the instant they take it.
      const noFixYet = d.locationAt == null && now - (this.state.orders[d.activeOrderId]?.assignedAt || now) > staleMs;
      const wentStale = d.locationAt != null && now - d.locationAt > staleMs;
      if (noFixYet || wentStale) {
        this._review(this.state.orders[d.activeOrderId], `driver ${d.id} GPS ${wentStale ? 'went stale' : 'never reported'} while order is open`);
      }
    }
    for (const debt of this.state.debts) {
      if (debt.amount > 0.001 && !debt.remindedAt && now >= debt.dueAt) {
        debt.remindedAt = now;
        this._queue('sms', debt.phone, fill(this.msg.debt_reminder, { amount: money(debt.amount) }), debt.orderId, `DEBT_REMINDER:${debt.id}`);
        this.audit({ at: now, orderId: debt.orderId, type: 'DEBT_REMINDER_QUEUED', detail: null });
      }
    }
    const leaseMs = this.config.outboxLeaseSeconds * 1000;
    for (const m of this.state.outbox) {
      if (m.status === 'claimed' && now - m.claimedAt > leaseMs) {
        // We don't know if it went out. Don't resend automatically (could duplicate); flag it.
        m.status = 'unknown';
        this._review(m.orderId ? this.state.orders[m.orderId] : null, `outgoing ${m.channel} message not confirmed by the gateway (id ${m.id})`);
      }
    }
    // prune inbound de-dup memory older than a day
    for (const [k, at] of Object.entries(this.state.seenInbound)) if (now - at > 86400000) delete this.state.seenInbound[k];
  }

  // --------------------------------------------------------------- outbox

  claimOutbox(channel, limit = 10) {
    const now = this.now();
    const out = [];
    for (const m of this.state.outbox) {
      if (out.length >= limit) break;
      if (m.channel === channel && m.status === 'pending') {
        m.status = 'claimed';
        m.claimedAt = now;
        // orderId included so a transport (the Signal adapter) can record
        // which order THIS outgoing message belongs to, at the moment it
        // sends it - needed to later resolve a driver's quoted reply back
        // to an order id without the driver having to type it themselves.
        // sms/Tasker ignores this extra field; it's additive.
        out.push({ id: m.id, to: m.to, text: m.text, orderId: m.orderId || null });
      }
    }
    return out;
  }

  ackOutbox(id, ok, error) {
    const m = this.state.outbox.find((x) => x.id === id);
    if (!m) return false;
    if (m.status === 'sent') return true; // duplicate ack is harmless
    m.status = ok ? 'sent' : 'failed';
    m.error = ok ? null : String(error || 'failed').slice(0, 200);
    this.audit({ at: this.now(), orderId: m.orderId, type: ok ? 'MSG_SENT' : 'MSG_FAILED', detail: m.key });
    if (!ok) this._review(m.orderId ? this.state.orders[m.orderId] : null, `${m.channel} message failed: ${m.error}`);
    return true;
  }

  /**
   * Pure check, no side effect: has this id been marked seen already?
   * Use this (not firstSeen) when checking several ids from one batch
   * before deciding whether to process it - firstSeen's own mark-as-seen
   * side effect makes it unsafe to call speculatively inside a short-
   * circuiting check like Array.some() over multiple ids (see
   * server/index.js processBurst: calling firstSeen() per id there marked
   * some ids seen while still bailing out before the burst was actually
   * processed, silently losing whichever new messages came after the
   * first already-seen id in the same batch).
   */
  alreadySeen(messageId) {
    if (!messageId) return false;
    return Object.prototype.hasOwnProperty.call(this.state.seenInbound, messageId);
  }

  /** Returns true the first time an inbound message id is seen. */
  firstSeen(messageId) {
    if (!messageId) return true;
    // Use hasOwnProperty, not truthiness: a timestamp of 0 (e.g. in tests,
    // or an epoch-0 clock) must still count as "already seen".
    if (Object.prototype.hasOwnProperty.call(this.state.seenInbound, messageId)) return false;
    this.state.seenInbound[messageId] = this.now();
    return true;
  }

  // ------------------------------------------------- inbound SMS durability

  /**
   * Durably records a raw inbound SMS BEFORE the gateway is told 202
   * accepted, and before any burst-window batching or order processing
   * happens - see CHANGELOG_SMS_INBOUND_DURABILITY.md. Without this, an
   * accepted message lived only in the server's in-memory burst buffer
   * for the whole burst window; a crash in that gap lost it silently even
   * though the customer's phone shows it as sent and Tasker got a 202.
   * Returns an internal id, used by clearPendingInboundSms once this
   * record has actually been folded into a processed (or correctly
   * skipped-as-duplicate) burst. This is separate from the seenInbound/
   * firstSeen dedup, which stops the GATEWAY's own retries from being
   * double-counted - this is about never losing a message that was never
   * retried at all.
   */
  recordPendingInboundSms(from, text, messageId) {
    const id = `pend-${this.state.pendingInboundSms.length}-${this.now()}-${Math.random().toString(36).slice(2, 8)}`;
    this.state.pendingInboundSms.push({ id, from, text, messageId: messageId || null, receivedAt: this.now() });
    return id;
  }

  /** Removes durable pending-inbound records once their burst has been
   * processed (or correctly skipped as an already-seen duplicate) - see
   * recordPendingInboundSms above. */
  clearPendingInboundSms(ids) {
    if (!ids || !ids.length) return;
    const remove = new Set(ids);
    this.state.pendingInboundSms = this.state.pendingInboundSms.filter((p) => !remove.has(p.id));
  }

  // --------------------------------------------------------------- boss

  recordDebtPayment(debtId, amount, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      const debt = this.state.debts.find((x) => x.id === debtId);
      if (!debt) return false;
      const a = Math.round(amount * 100) / 100;
      if (!(a > 0)) return false;
      debt.payments.push({ at: this.now(), amount: a });
      debt.amount = Math.max(0, Math.round((debt.amount - a) * 100) / 100);
      this._event(this.state.orders[debt.orderId] || null, 'DEBT_PAYMENT', `${money(a)} toward debt ${debt.id} (Boss-recorded)`);
      return true;
    });
  }

  /** Boss manual debt adjustment (write-off, correction) - separate from a real payment, still audited. */
  adjustDebt(debtId, delta, note, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      const debt = this.state.debts.find((x) => x.id === debtId);
      if (!debt) throw new Error('unknown debt');
      debt.amount = Math.max(0, Math.round((debt.amount + delta) * 100) / 100);
      this._event(this.state.orders[debt.orderId] || null, 'DEBT_ADJUSTED', `${delta >= 0 ? '+' : ''}${money(delta)} (now ${money(debt.amount)})${note ? ' - ' + note : ''}`);
      return debt;
    });
  }

  /**
   * Debt summary for one phone, for Boss visibility: open debts, total
   * owed, total overdue (past the 7-day due date), and a "returning
   * debtor" flag - true once this customer has had more than one debt
   * recorded, ever (not just currently open), a simple repeat-offender
   * signal rather than a stored/mutable field that could drift.
   */
  debtSummaryForPhone(phone) {
    const all = this.state.debts.filter((d) => d.phone === phone);
    const open = this._openDebtsForPhone(phone);
    return {
      phone,
      openCount: open.length,
      totalOwed: Math.round(open.reduce((s, d) => s + this._debtRemaining(d), 0) * 100) / 100,
      totalOverdue: this._overdueDebtTotal(phone),
      returningDebtor: all.length > 1,
      debts: open,
    };
  }

  /**
   * Boss manual loyalty adjustment (goodwill points, correction). Audited
   * durably (pointsAdjustments + the general audit trail via _event).
   */
  adjustLoyaltyPoints(phone, delta, note, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      if (!Number.isFinite(delta) || delta === 0) throw new Error('delta must be a non-zero number');
      const cust = (this.state.customers[phone] = this.state.customers[phone] || { points: 0, completedOrders: 0 });
      cust.points = Math.max(0, Math.round(cust.points + delta));
      const entry = { at: this.now(), phone, delta, note: note || null, balance: cust.points };
      this.state.pointsAdjustments.push(entry);
      this._event(null, 'LOYALTY_ADJUSTED', `${phone.slice(-4)} ${delta >= 0 ? '+' : ''}${delta}pts (now ${cust.points})${note ? ' - ' + note : ''}`);
      return cust;
    });
  }

  /**
   * Boss banks (removes) cash from a driver, or makes a corrective
   * adjustment. delta is negative for "banked £200" (cash handed in),
   * positive only for a genuine correction (e.g. a miscount found later).
   * Never allowed to go negative.
   */
  adjustDriverCash(driverId, delta, note, idempotencyKey) {
    return this.idempotent(idempotencyKey, () => {
      const d = this.state.drivers[driverId];
      if (!d) throw new Error('unknown driver');
      if (!Number.isFinite(delta) || delta === 0) throw new Error('delta must be a non-zero number');
      d.cash = d.cash || { held: 0, adjustments: [] };
      const newHeld = Math.round((d.cash.held + delta) * 100) / 100;
      if (newHeld < -0.001) throw new Error('adjustment would take driver cash below zero');
      d.cash.held = Math.max(0, newHeld);
      const entry = { at: this.now(), delta, note: note || null, held: d.cash.held };
      d.cash.adjustments.push(entry);
      this._event(null, 'DRIVER_CASH_ADJUSTED', `${driverId} ${delta >= 0 ? '+' : ''}${money(delta)} (now holding ${money(d.cash.held)})${note ? ' - ' + note : ''}`);
      return d.cash;
    });
  }

  /** Cash summary for one driver (Boss visibility), including the configured limit and how close they are to it. */
  driverCashSummary(driverId) {
    const d = this.state.drivers[driverId];
    if (!d) return null;
    const limit = (this.config.driverCash && this.config.driverCash.limit) ?? 250;
    const held = (d.cash && d.cash.held) || 0;
    return { driverId, held, limit, atOrOverLimit: held >= limit, approachingLimit: held >= limit * 0.8 };
  }

  /**
   * Mark one open review-queue entry as handled. Nothing in the engine
   * previously ever cleared a review flag - _review() pushed entries with
   * resolved: false and nothing read or set that field again, so the queue
   * only ever grew. This is what the Boss app's review screen calls.
   */
  /** Public wrapper for a general (non-order) durable audit note - e.g. server/index.js recording a config change. */
  auditNote(type, detail) {
    this._event(null, type, detail);
  }

  resolveReview(reviewId, note) {
    const r = this.state.review.find((x) => x.id === reviewId && !x.resolved);
    if (!r) return false;
    r.resolved = true;
    r.resolvedAt = this.now();
    r.resolvedNote = note ? String(note).slice(0, 500) : null;
    this.audit({ at: this.now(), orderId: r.orderId, type: 'REVIEW_RESOLVED', detail: r.resolvedNote });
    return true;
  }

  /**
   * Replace the live menu's items/bundles (in place, so every part of the
   * engine already holding a reference to `this.menu` - e.g. an in-flight
   * order pricing calculation - sees the update immediately). Validated
   * defensively: this is meant to be called from a Boss-app HTTP endpoint,
   * i.e. from input a person typed, not from trusted internal code.
   */
  setMenu(next) {
    if (!next || !Array.isArray(next.items)) throw new Error('menu.items must be an array');
    for (const item of next.items) {
      if (!item.code || !item.name) throw new Error('every item needs a code and a name');
      if (typeof item.unitPrice !== 'number' || !(item.unitPrice >= 0)) throw new Error(`${item.code}: unitPrice must be a non-negative number`);
      for (const tier of item.tiers || []) {
        if (!(tier.qty > 0) || !(tier.price >= 0)) throw new Error(`${item.code}: each tier needs a positive qty and a non-negative price`);
      }
    }
    const codes = new Set(next.items.map((i) => i.code));
    for (const b of next.bundles || []) {
      if (!b.code || !b.label) throw new Error('every bundle needs a code and a label');
      if (typeof b.price !== 'number' || !(b.price >= 0)) throw new Error(`${b.code}: price must be a non-negative number`);
      for (const itemCode of Object.keys(b.contains || {})) {
        if (!codes.has(itemCode)) throw new Error(`bundle ${b.code} refers to unknown item code ${itemCode}`);
      }
    }
    this.menu.items = next.items;
    this.menu.bundles = next.bundles || [];
    this.audit({ at: this.now(), orderId: null, type: 'MENU_UPDATED', detail: `${next.items.length} items, ${(next.bundles || []).length} bundles` });
  }

  summary() {
    const s = this.state;
    const count = (pred) => Object.values(s.orders).filter(pred).length;
    return {
      openOrders: count((o) => OPEN.has(o.state)),
      driversOnDuty: Object.values(s.drivers).filter((d) => d.onDuty).length,
      pendingSms: s.outbox.filter((m) => m.channel === 'sms' && m.status === 'pending').length,
      pendingDriver: s.outbox.filter((m) => m.channel === 'driver' && m.status === 'pending').length,
      failedOrUnknown: s.outbox.filter((m) => m.status === 'failed' || m.status === 'unknown').length,
      openReview: s.review.filter((r) => !r.resolved).length,
      driversReportingGps: Object.values(s.drivers).filter((d) => d.traccarId && d.locationAt != null).length,
      driverEarnings: Object.values(s.drivers).map((d) => ({
        id: d.id,
        name: d.name,
        totalBonus: (d.earnings && d.earnings.totalBonus) || 0,
        completedOrders: (d.earnings && d.earnings.completedOrders) || 0,
      })),
    };
  }
}

module.exports = { Engine, emptyEngineState, ORDER_STATES, maskPhone };
