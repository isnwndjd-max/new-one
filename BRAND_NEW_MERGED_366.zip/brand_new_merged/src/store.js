'use strict';

/*
 * Crash-safe, encrypted-at-rest persistence for the engine state: write to a
 * temp file, fsync, then rename over the real file. A crash mid-write leaves
 * the old file intact (POSIX rename is atomic) instead of a half-written
 * file that fails to load on restart.
 *
 * state.json holds every customer's phone number, every order (items,
 * meeting point, price), every debt, and every referral relationship -
 * plaintext on disk was a real exposure (anyone with read access to the
 * disk, a backup, or a misconfigured static-file server could read it
 * directly). Every write is now AES-256-GCM encrypted; every read is
 * decrypted and integrity-checked (GCM's auth tag rejects a tampered or
 * corrupted file the same way the old plaintext version rejected invalid
 * JSON - see "a corrupt state file is refused" in test/engine.test.js,
 * which still passes unchanged against the encrypted format).
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ALGO = 'aes-256-gcm';

// Used ONLY when ROCKET_STATE_KEY isn't set - keeps every test and local
// `node server/index.js` run working without extra setup, while being
// unambiguously not a real secret (fixed, public, in this file). Loud
// warning below is what stops it from being mistaken for real protection.
const DEV_FALLBACK_KEY = crypto.createHash('sha256')
  .update('rocket-dispatch-insecure-default-dev-key-DO-NOT-USE-IN-PRODUCTION')
  .digest();

function resolveKey(encryptionKey) {
  const hex = encryptionKey || process.env.ROCKET_STATE_KEY;
  if (!hex) {
    console.warn(
      '[store] ROCKET_STATE_KEY is not set - state.json is being encrypted with a ' +
      'fixed, publicly-known development key, which is NOT real protection. Set ' +
      'ROCKET_STATE_KEY to a real secret (64 hex characters - `openssl rand -hex 32` ' +
      'generates one) before this server holds any real customer data.'
    );
    return { key: DEV_FALLBACK_KEY, usingDevFallback: true };
  }
  const key = Buffer.from(hex, 'hex');
  if (key.length !== 32) {
    throw new Error('ROCKET_STATE_KEY must be 64 hex characters (32 bytes) for AES-256-GCM - got ' + key.length + ' bytes');
  }
  return { key, usingDevFallback: false };
}

class Store {
  constructor(filePath, { encryptionKey } = {}) {
    this.filePath = filePath;
    this.tmpPath = filePath + '.tmp';
    const { key, usingDevFallback } = resolveKey(encryptionKey);
    this.key = key;
    this.usingDevFallback = usingDevFallback;
  }

  _encrypt(state) {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv(ALGO, this.key, iv);
    const plaintext = Buffer.from(JSON.stringify(state), 'utf8');
    const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
    const tag = cipher.getAuthTag();
    return JSON.stringify({
      v: 1,
      alg: ALGO,
      iv: iv.toString('base64'),
      tag: tag.toString('base64'),
      data: ciphertext.toString('base64'),
    });
  }

  _decrypt(raw) {
    const envelope = JSON.parse(raw);
    if (!envelope || envelope.v !== 1 || envelope.alg !== ALGO || !envelope.iv || !envelope.tag || !envelope.data) {
      throw new Error('not a recognised encrypted state envelope');
    }
    const iv = Buffer.from(envelope.iv, 'base64');
    const tag = Buffer.from(envelope.tag, 'base64');
    const ciphertext = Buffer.from(envelope.data, 'base64');
    const decipher = crypto.createDecipheriv(ALGO, this.key, iv);
    decipher.setAuthTag(tag);
    // Throws (bad auth tag) if the file was tampered with, corrupted, or
    // encrypted under a different key - caught by load()'s try/catch below,
    // same "refuse and back up" handling as a plaintext parse failure used
    // to get.
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    return JSON.parse(plaintext.toString('utf8'));
  }

  load(defaultState) {
    if (!fs.existsSync(this.filePath)) return defaultState();
    try {
      const raw = fs.readFileSync(this.filePath, 'utf8');
      return this._decrypt(raw);
    } catch (err) {
      const backup = this.filePath + `.corrupt-${Date.now()}`;
      fs.copyFileSync(this.filePath, backup);
      throw new Error(
        `state file ${this.filePath} is corrupt or unreadable with the configured key (${err.message}). ` +
        `Copied to ${backup} for inspection. Refusing to start with unreadable state - ` +
        `restore from the last good backup, confirm ROCKET_STATE_KEY matches what wrote this file, ` +
        `or delete the file to start fresh (loses in-flight orders).`
      );
    }
  }

  save(state) {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const encoded = this._encrypt(state);
    const fd = fs.openSync(this.tmpPath, 'w');
    try {
      fs.writeSync(fd, encoded);
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(this.tmpPath, this.filePath);
  }
}

module.exports = { Store };
