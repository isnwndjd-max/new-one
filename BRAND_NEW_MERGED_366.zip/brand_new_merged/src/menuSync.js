'use strict';

/*
 * The boundary between the Boss app's master menu and what the VPS's order
 * engine actually needs. The master is what the Boss app edits, and lives
 * only in the Boss app's own browser storage - it is never written to the
 * VPS's disk (see server/index.js's file header). It can carry
 * internal-only fields - cost price, supplier notes, margin workings,
 * anything the owner wants to track that a customer or driver should never
 * see and the order-processing code never needs. This module is a strict
 * ALLOWLIST projection: only the fields the pricing/parsing code in
 * src/menu.js actually reads are ever copied into the minimal file
 * (data/menu.sync.json) the engine loads and the VPS actually persists - a
 * field added to the master schema later does not leak to the synced copy
 * by accident, it has to be added here deliberately.
 */

function projectItem(item) {
  return {
    code: item.code,
    name: item.name,
    aliases: Array.isArray(item.aliases) ? item.aliases.slice() : [],
    unitPrice: item.unitPrice,
    tiers: Array.isArray(item.tiers) ? item.tiers.map((t) => ({ qty: t.qty, price: t.price })) : [],
  };
}

function projectBundle(bundle) {
  return {
    code: bundle.code,
    label: bundle.label,
    contains: Object.assign({}, bundle.contains || {}),
    price: bundle.price,
  };
}

/** Master menu in, minimal order-processing projection out. Pure function - no I/O. */
function projectMenu(master) {
  if (!master || !Array.isArray(master.items)) throw new Error('menu.items must be an array');
  return {
    _note: 'SYNCED PROJECTION of the Boss app\'s master menu - minimal fields only, regenerated on every Boss menu save. Do not hand-edit; edit the menu through the Boss app instead (the master itself lives in the Boss app\'s own browser storage, not on this VPS - see boss/BOSS_APP.md).',
    items: master.items.map(projectItem),
    bundles: (master.bundles || []).map(projectBundle),
  };
}

module.exports = { projectMenu };
