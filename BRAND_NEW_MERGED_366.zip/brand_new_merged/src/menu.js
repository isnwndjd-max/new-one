'use strict';

const { normalise } = require('./text');

const NUMBER_WORDS = {
  one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
};

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find menu items and quantities in a message.
 * "2 A", "2x item a", "item a x2", "two item a", "item a two", "item a two
 * of them", "item a" (= 1).
 * Returns [{ code, qty }] or null. Never guesses an item that is not named.
 */
function parseItems(text, menu) {
  const key = normalise(text);
  const found = new Map();
  for (const item of menu.items) {
    const labels = [item.name, item.code, ...(item.aliases || [])]
      .map(normalise)
      .filter(Boolean)
      .sort((a, b) => b.length - a.length);
    for (const label of labels) {
      const L = escapeRe(label);
      // single-letter codes like "A" only count with a quantity next to them
      const short = label.length <= 2;
      const before = new RegExp(`(?:^| )(\\d{1,2}|${Object.keys(NUMBER_WORDS).join('|')}) ?x? ?${L}(?= |$)`);
      const after = new RegExp(`(?:^| )${L} ?x ?(\\d{1,2})(?= |$)`);
      // Trailing quantity with no "x" ("item c two", "item c two of them")
      // - the natural way people phrase it when the item comes first. Same
      // ambiguity trade-off the leading-number pattern above already
      // accepts (a stray following number could misfire as a quantity);
      // limited to the same small explicit number-word set plus 1-2 digit
      // numbers, not open-ended text matching.
      const afterWord = new RegExp(`(?:^| )${L} (\\d{1,2}|${Object.keys(NUMBER_WORDS).join('|')})(?= |$)`);
      const bare = new RegExp(`(?:^| )${L}(?= |$)`);
      let qty = null;
      let m = key.match(before);
      if (m) qty = NUMBER_WORDS[m[1]] || parseInt(m[1], 10);
      else if ((m = key.match(after))) qty = parseInt(m[1], 10);
      else if ((m = key.match(afterWord))) qty = NUMBER_WORDS[m[1]] || parseInt(m[1], 10);
      else if (!short && bare.test(key)) qty = 1;
      if (qty) {
        found.set(item.code, qty);
        break;
      }
    }
  }
  if (!found.size) return null;
  return [...found].map(([code, qty]) => ({ code, qty }));
}

/** Merge newly named items into an existing list. A re-named item takes the new quantity. */
function mergeItems(existing, incoming) {
  const map = new Map((existing || []).map((i) => [i.code, i.qty]));
  for (const i of incoming) map.set(i.code, i.qty);
  return [...map].map(([code, qty]) => ({ code, qty }));
}

/**
 * Exact cheapest price for an order using unit prices, per-item quantity tiers
 * and mixed bundles. Returns { ok, total, breakdown } or { ok:false, reason }.
 * Never estimates: if a quantity cannot be priced exactly, it fails.
 */
function priceOrder(menu, items) {
  const byCode = new Map(menu.items.map((i) => [i.code, i]));
  for (const i of items) {
    if (!byCode.has(i.code)) return { ok: false, reason: `unknown item ${i.code}` };
    if (!Number.isInteger(i.qty) || i.qty < 1 || i.qty > 50) return { ok: false, reason: `bad quantity ${i.qty}` };
  }
  const codes = items.map((i) => i.code);
  const start = items.map((i) => i.qty);

  // Every way to take a "pack" off the order: single unit, item tier, or mixed bundle.
  const packs = [];
  codes.forEach((code, idx) => {
    const it = byCode.get(code);
    if (typeof it.unitPrice === 'number') {
      const v = codes.map((_, j) => (j === idx ? 1 : 0));
      packs.push({ label: `1 x ${it.name}`, take: v, price: it.unitPrice });
    }
    for (const t of it.tiers || []) {
      const v = codes.map((_, j) => (j === idx ? t.qty : 0));
      packs.push({ label: `${t.qty} x ${it.name} deal`, take: v, price: t.price });
    }
  });
  for (const b of menu.bundles || []) {
    const keys = Object.keys(b.contains);
    if (!keys.every((k) => codes.includes(k))) continue;
    packs.push({ label: b.label, take: codes.map((c) => b.contains[c] || 0), price: b.price });
  }

  let states = 1;
  for (const q of start) states *= q + 1;
  if (states > 200000) return { ok: false, reason: 'order too large to price automatically' };

  const memo = new Map();
  const solve = (rem) => {
    const k = rem.join(',');
    if (memo.has(k)) return memo.get(k);
    if (rem.every((q) => q === 0)) return { cost: 0, used: [] };
    let best = null;
    for (const p of packs) {
      if (p.take.some((t, j) => t > rem[j])) continue;
      const next = rem.map((q, j) => q - p.take[j]);
      const sub = solve(next);
      if (!sub) continue;
      const cost = Math.round((sub.cost + p.price) * 100) / 100;
      if (!best || cost < best.cost) best = { cost, used: [p.label, ...sub.used] };
    }
    memo.set(k, best);
    return best;
  };
  const result = solve(start);
  if (!result) return { ok: false, reason: 'no exact price for that quantity' };
  return { ok: true, total: result.cost, breakdown: result.used };
}

function describeItems(menu, items) {
  const byCode = new Map(menu.items.map((i) => [i.code, i]));
  return items.map((i) => `${i.qty} x ${byCode.get(i.code) ? byCode.get(i.code).name : i.code}`).join(', ');
}

function menuText(menu) {
  const lines = menu.items.map((i) => {
    const deals = (i.tiers || []).map((t) => `${t.qty} for £${t.price.toFixed(2)}`);
    const base = typeof i.unitPrice === 'number' ? `£${i.unitPrice.toFixed(2)}` : '';
    return `${i.name} ${[base, ...deals].filter(Boolean).join(', ')}`.trim();
  });
  for (const b of menu.bundles || []) lines.push(`${b.label}: £${b.price.toFixed(2)}`);
  return lines.join('\n');
}

module.exports = { parseItems, mergeItems, priceOrder, describeItems, menuText };
