'use strict';

/**
 * Matching key for free text. The raw message is always kept separately;
 * this only produces a comparison key (research recommendation 1).
 */
function normalise(text) {
  return String(text || '')
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '') // strip accents
    .toLowerCase()
    .replace(/[‘’ʼ`]/g, "'")
    .replace(/&/g, ' and ')
    .replace(/'/g, '') // "o'bells" -> "obells", "mary's" -> "marys"
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Alternate key: drop a leading "the" (only as an extra key, never in place). */
function withoutLeadingThe(key) {
  return key.startsWith('the ') ? key.slice(4) : null;
}

/** True if `phrase` occurs in `key` on word boundaries. Both must be normalised. */
function containsPhrase(key, phrase) {
  if (!phrase) return false;
  return (' ' + key + ' ').includes(' ' + phrase + ' ');
}

/** All start offsets (in words) where phrase occurs in key. */
function phraseSpans(key, phrase) {
  const words = key.split(' ');
  const pw = phrase.split(' ');
  const spans = [];
  for (let i = 0; i + pw.length <= words.length; i++) {
    let ok = true;
    for (let j = 0; j < pw.length; j++) {
      if (words[i + j] !== pw[j]) { ok = false; break; }
    }
    if (ok) spans.push([i, i + pw.length]);
  }
  return spans;
}

module.exports = { normalise, withoutLeadingThe, containsPhrase, phraseSpans };
