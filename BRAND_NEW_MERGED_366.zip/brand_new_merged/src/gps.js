'use strict';

/*
 * GPS ingestion: turns a Traccar "position forwarding" webhook into a plain
 * {uniqueId, lat, lng, speedKph, course, accuracy, at} object, and answers
 * the two questions the engine actually needs from a position - "how far"
 * and "how long at this speed" - without pulling in a mapping library.
 *
 * Nothing here talks to Traccar's REST API or assumes a particular deployment
 * (self-hosted vs traccar.org's hosted demo). Traccar is the one doing GPS;
 * this module only understands the shape of what it forwards.
 */

const EARTH_RADIUS_M = 6371000;

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

/** Great-circle distance between two {lat,lng} points, in metres. */
function haversineMetres(a, b) {
  if (!a || !b || a.lat == null || a.lng == null || b.lat == null || b.lng == null) return null;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s1 = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(s1)));
}

/**
 * Rough ETA in minutes from straight-line distance and current speed.
 * Deliberately not routed (no roads/turns) - it is a floor, not a promise,
 * and callers should present it as "about" and re-derive it on every fix
 * rather than trusting one reading. Falls back to a fixed average speed
 * when the device isn't reporting motion (stopped at a light, weak fix),
 * because ETA=infinity at a red light is a worse answer than "roughly".
 * @param {number} distanceMetres
 * @param {number|null} speedKph  current reported speed, or null/0 if unknown
 * @param {object} opts
 */
function etaMinutes(distanceMetres, speedKph, opts = {}) {
  if (distanceMetres == null) return null;
  const fallbackKph = opts.fallbackKph ?? 25; // car, mixed suburban roads
  const minKph = opts.minKph ?? 8; // don't divide by near-zero and report "400 minutes"
  const kph = speedKph && speedKph > minKph ? speedKph : fallbackKph;
  const minutes = (distanceMetres / 1000 / kph) * 60;
  return Math.max(0, Math.round(minutes));
}

/**
 * Parse a Traccar JSON position-forwarding payload.
 * Traccar (Settings -> position forwarding, type "json") POSTs:
 *   { position: { deviceId, latitude, longitude, speed, course, accuracy,
 *                 fixTime, deviceTime, valid, attributes: {...} },
 *     device:   { id, uniqueId, name } }
 * `position.speed` from Traccar is in knots (its internal unit); this
 * converts to km/h so the rest of the engine only ever sees km/h.
 * Returns null if the payload doesn't look like a position at all, so the
 * caller can tell "not GPS data" apart from "GPS data with a bad fix".
 */
function parseTraccarForward(body) {
  if (!body || typeof body !== 'object') return null;
  const pos = body.position;
  const dev = body.device;
  if (!pos || typeof pos.latitude !== 'number' || typeof pos.longitude !== 'number') return null;
  const uniqueId = (dev && dev.uniqueId) || body.uniqueId || null;
  if (!uniqueId) return null;
  const knots = typeof pos.speed === 'number' ? pos.speed : null;
  return {
    uniqueId: String(uniqueId),
    lat: pos.latitude,
    lng: pos.longitude,
    speedKph: knots != null ? Math.round(knots * 1.852 * 10) / 10 : null,
    course: typeof pos.course === 'number' ? pos.course : null,
    accuracy: typeof pos.accuracy === 'number' ? pos.accuracy : null,
    valid: pos.valid !== false, // Traccar marks a fix invalid on GPS loss/HDOP failure; default true if absent
    firedAt: pos.fixTime || pos.deviceTime || pos.serverTime || null,
  };
}

module.exports = { haversineMetres, etaMinutes, parseTraccarForward };
