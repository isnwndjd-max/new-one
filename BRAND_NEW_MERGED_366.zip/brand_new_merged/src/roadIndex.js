'use strict';

const { normalise, phraseSpans } = require('./text');

/**
 * Road and alley/footway layer, built offline from OpenStreetMap and
 * spatially joined against the existing Rocket postcode database (see
 * data/roads.json / data/alleys.json _provenance and
 * CHANGELOG_ROAD_ALLEY_INTEGRATION.md). This is a SEPARATE data layer from
 * data/locations.json's venues/postcodes - nothing here replaces or edits
 * that file, and this module is only ever consulted after postcode and
 * venue matching have both already failed (see locationConversation.js).
 *
 * Match priority within this module: an exact road name/alias always beats
 * an alley/footway match - findMatch() tries roads first and only falls
 * back to alleys if no road phrase is found at all.
 *
 * Every candidate this module returns carries a road/alley centroid
 * coordinate, never a fabricated one - see roads.json/alleys.json
 * _provenance for how each was derived. exactPointKnown is always false for
 * these (a road/path centroid is not a verified entrance), same treatment
 * engine.js already gives a bare postcode.
 */

// Road-suffix abbreviation pairs, kept in sync with the offline build
// (road_enrichment/build_alley4_finalize.py's ABBR dict) so a name typed
// with the other spelling ("weston rd" vs "Weston Road") still matches even
// if it isn't already one of the pre-generated alias rows.
const ABBR = {
  road: 'rd', street: 'st', lane: 'ln', avenue: 'ave', drive: 'dr',
  close: 'cl', court: 'ct', crescent: 'cres', terrace: 'ter',
  gardens: 'gdns', grove: 'gr', place: 'pl', square: 'sq',
  hill: 'hl', green: 'gn', walk: 'wlk', park: 'pk',
};
const REV_ABBR = Object.fromEntries(Object.entries(ABBR).map(([k, v]) => [v, k]));

// Kind strength: a bare/base name or an OSM-native name is the strongest
// signal ('name'); every generated alias form (abbreviation, concatenated,
// locality-suffixed, OSM name_variant) is weaker ('alias') - this is what
// lets "exact road name" (priority 3) rank above "exact road alias"
// (priority 4) in the spec this module implements.
// 'colloquial_confirmed'/'colloquial_confirmed_variant': a name that isn't
// OSM's or the official name, but has been directly confirmed as what
// locals actually call the road (e.g. "High Street" for Hill Road,
// Clevedon - see data/roads.json's alias_provenance and
// CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md). Treated as
// name-strength, not weaker alias-strength, precisely because it is
// evidence-backed and confirmed rather than mechanically generated.
const NAME_KINDS = new Set(['base', 'osm_named_base', 'colloquial_confirmed']);

class RoadIndex {
  /**
   * @param {object} roadsData data/roads.json
   * @param {object} alleysData data/alleys.json
   * @param {object|null} contextData data/localityContext.json (optional) -
   *   evidence-backed accepted_town_contexts, scoped per road_id (see
   *   CHANGELOG_LOCALITY_CONTEXT_AND_HIGHSTREET_FIX.md). Absent/omitted
   *   means no context layer - a road whose OSM locality differs from what
   *   a customer naturally calls it just won't get the extra town match,
   *   same behaviour as before that layer existed.
   * @param {object|null} alleyAliasData data/alleyAliases.json (optional) -
   *   customer-facing local-landmark aliases for alleys/footways ("Station
   *   Road alleyway", "alley by the Bridge Inn"), geometry-derived from the
   *   real alley/road/venue coordinates - see
   *   CHANGELOG_ALLEY_LOCAL_ALIAS.md. Absent/omitted means no local-alias
   *   layer - alleys still match by their own OSM name/generated label only,
   *   same behaviour as before this addition.
   */
  constructor(roadsData, alleysData, contextData, alleyAliasData) {
    this.byId = new Map();
    this.roadPhrases = new Map(); // normalised phrase -> Map(id -> kind)
    this.alleyPhrases = new Map();
    this.byDistrict = new Map(); // district -> [id,...] (roads only, for postcode-district context)
    // road_id -> Set(normalised accepted town names). Deliberately scoped
    // per road_id, never a blanket "locality X = town Y" remap - see the
    // changelog for why a global remap was rejected as too risky.
    this.acceptedTownContexts = new Map();
    for (const c of (contextData && contextData.contexts) || []) {
      if (!c.road_id || !c.accepted_town) continue;
      let set = this.acceptedTownContexts.get(c.road_id);
      if (!set) {
        set = new Set();
        this.acceptedTownContexts.set(c.road_id, set);
      }
      set.add(normalise(c.accepted_town));
    }
    // First-word bucket index, built once at startup: for a ~1500-word SMS
    // vocabulary against ~1700 roads + ~1900 alleys, scanning every phrase
    // for every message is unnecessary - only phrases that START with a
    // word actually present in the message can ever match (findVenue/
    // _longestMatch below only match on word boundaries), so this prunes
    // the per-message scan from "every phrase" down to "phrases starting
    // with one of this message's words", which is normally a handful.
    this.roadFirstWord = new Map(); // firstWord -> [phrase, ...]
    this.alleyFirstWord = new Map();
    this._buildLayer(roadsData.roads, this.roadPhrases, this.roadFirstWord, 'ROAD');
    this._buildLayer(alleysData.alleys, this.alleyPhrases, this.alleyFirstWord, 'ALLEY');

    // Local landmark/anchor aliases for alleys ("Station Road alleyway",
    // "alley by the Bridge Inn") - a separate, weaker-by-default phrase kind
    // ('local_alias') layered onto the same alleyPhrases/alleyFirstWord
    // index used above, so lookup goes through the exact same first-word
    // bucket and longest-match logic. Each phrase+alley pairing carries its
    // own metadata (anchor strength, whether it's allowed to auto-resolve)
    // in `alleyAliasMeta`, keyed "phrase::alleyId", because the SAME alley
    // can carry both a strong alias ("kenn road alley", auto-resolve) and a
    // weak one ("alley near church road", confirm-only) - the underlying
    // alley's own anchor_strength (from data/alleys.json) is not enough on
    // its own to decide that, see _resolveRoad()'s `weak` check.
    this.alleyAliasMeta = new Map();
    for (const row of (alleyAliasData && alleyAliasData.aliases) || []) {
      if (!row.alley_id || !row.alias) continue;
      const rec = this.byId.get(row.alley_id);
      if (!rec) continue; // alias references an alley not in this build - skip, never guess
      this._addPhrase(this.alleyPhrases, this.alleyFirstWord, row.alias, row.alley_id, 'local_alias');
      const key = `${normalise(row.alias)}::${row.alley_id}`;
      this.alleyAliasMeta.set(key, {
        anchorStrength: row.anchor_strength,
        autoResolveAllowed: !!row.auto_resolve_allowed,
        anchorType: row.anchor_type,
        anchorName: row.anchor_name,
        relationship: row.relationship,
      });
    }
  }

  _addPhrase(map, firstWordMap, phrase, id, kind) {
    const key = normalise(phrase);
    if (!key || key.length < 3) return;
    let m = map.get(key);
    if (!m) {
      m = new Map();
      map.set(key, m);
      const first = key.split(' ', 1)[0];
      let bucket = firstWordMap.get(first);
      if (!bucket) {
        bucket = [];
        firstWordMap.set(first, bucket);
      }
      bucket.push(key);
    }
    const rank = kind === 'name' ? 1 : 0;
    const prev = m.get(id);
    if (prev === undefined || rank > (prev === 'name' ? 1 : 0)) m.set(id, kind);
  }

  _buildLayer(records, phraseMap, firstWordMap, layer) {
    for (const rec of records) {
      this.byId.set(rec.id, rec);
      this._addPhrase(phraseMap, firstWordMap, rec.name, rec.id, 'name');
      for (const a of rec.aliases || []) {
        this._addPhrase(phraseMap, firstWordMap, a.alias, rec.id, NAME_KINDS.has(a.kind) ? 'name' : 'alias');
      }
      // Extra safety-net forms beyond the pre-generated alias rows, so a
      // spelling the offline build didn't happen to enumerate still
      // matches (e.g. a road suffix abbreviation combined with punctuation
      // the generator didn't see). Cheap - these collapse onto existing map
      // entries via normalise() if already present.
      const words = normalise(rec.name).split(' ');
      const last = words[words.length - 1];
      if (ABBR[last]) {
        this._addPhrase(phraseMap, firstWordMap, [...words.slice(0, -1), ABBR[last]].join(' '), rec.id, 'alias');
      }
      if (REV_ABBR[last]) {
        this._addPhrase(phraseMap, firstWordMap, [...words.slice(0, -1), REV_ABBR[last]].join(' '), rec.id, 'alias');
      }

      if (layer === 'ROAD') {
        if (!this.byDistrict.has(rec.district)) this.byDistrict.set(rec.district, []);
        this.byDistrict.get(rec.district).push(rec.id);
      }
    }
  }

  get(id) {
    return this.byId.get(id);
  }

  /** True if `town` (already normalised) is an evidence-backed accepted
   * customer-facing context for this specific road_id - see the
   * acceptedTownContexts comment in the constructor. */
  acceptsTown(roadId, normalisedTown) {
    const set = this.acceptedTownContexts.get(roadId);
    return !!set && set.has(normalisedTown);
  }

  /**
   * Longest phrase match in the message, same "longest wins" rule as
   * LocationIndex.findVenue - a locality-suffixed alias ("weston road
   * congresbury") beats the bare name ("weston road") when both are
   * present, since the longer phrase already carries town context.
   * Tries the road layer first; only falls back to alleys if the road
   * layer found nothing at all (roads outrank alleys - see module header).
   *
   * One deliberate exception: a local alley alias (see the constructor's
   * alleyAliasMeta comment and CHANGELOG_ALLEY_LOCAL_ALIAS.md) is allowed
   * to win over a road match when its matched phrase is STRICTLY LONGER
   * (more words) than the road's - e.g. an alley whose anchor road happens
   * to share a name with a real road elsewhere ("Zig Zag" road vs "Zig Zag"
   * alley): "zig zag alley" (3 words, a local-alias phrase) should resolve
   * the alley the customer is clearly describing, not the shorter "zig
   * zag" road-name substring match. This mirrors the same "only a strictly
   * longer, more specific phrase can override" rule locationConversation.js
   * already applies for a weak venue match vs a road/alias match - it never
   * applies when the alley side won on its own NAME (not a local_alias),
   * which is exactly the case the "roads always outrank alleys" module rule
   * is there to protect (see roadAlleyIntegration.test.js).
   */
  findMatch(key) {
    const road = this._longestMatch(key, this.roadPhrases, this.roadFirstWord, 'ROAD');
    const alley = this._longestMatch(key, this.alleyPhrases, this.alleyFirstWord, 'ALLEY');
    if (!road) return alley;
    if (
      alley &&
      alley.candidates.some((c) => c.kind === 'local_alias') &&
      alley.phrase.split(' ').length > road.phrase.split(' ').length
    ) {
      return alley;
    }
    return road;
  }

  _longestMatch(key, phraseMap, firstWordMap, layer) {
    // Only phrases starting with one of THIS message's words can ever
    // match on a word boundary - look those up instead of scanning every
    // phrase this layer knows about (see the firstWordMap comment in the
    // constructor).
    const candidatePhrases = new Set();
    for (const w of key.split(' ')) {
      const bucket = firstWordMap.get(w);
      if (bucket) for (const p of bucket) candidatePhrases.add(p);
    }
    let best = null;
    for (const phrase of candidatePhrases) {
      if (!(' ' + key + ' ').includes(' ' + phrase + ' ')) continue;
      const words = phrase.split(' ').length;
      if (!best || words > best.words || (words === best.words && phrase.length > best.phrase.length)) {
        best = { phrase, words, ids: phraseMap.get(phrase), layer };
      }
    }
    if (!best) return null;
    const seen = new Map(); // dedupe by id, keep the strongest kind
    for (const [id, kind] of best.ids) {
      const prev = seen.get(id);
      if (!prev || (kind === 'name' && prev !== 'name')) seen.set(id, kind);
    }
    const candidates = [];
    for (const [id, kind] of seen) {
      const rec = this.byId.get(id);
      if (!rec) continue;
      const aliasMeta = kind === 'local_alias' ? this.alleyAliasMeta.get(`${best.phrase}::${id}`) : null;
      candidates.push({ road: rec, kind, aliasMeta: aliasMeta || null });
    }
    return { phrase: best.phrase, layer, candidates, span: phraseSpans(key, best.phrase)[0] };
  }
}

module.exports = { RoadIndex, ABBR, REV_ABBR };
